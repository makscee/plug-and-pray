(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e={},t={};function n(t){e[t.id]=t}function r(e){for(let t of e)n(t)}function i(e,n){t[e]=n}var a=t=>{let n=e[t.mod];if(!n)throw Error(`unknown module ${t.mod}`);return n};function o(e,t,n){let r=a(e).params[t]??n;return e.roll&&e.roll.key===t&&typeof r==`number`?r*e.roll.mult:r}function s(e){return(e.roll?e.roll.tag+` `:``)+a(e).name}var c=(e,t)=>t.on&&e.t>=t.readyAt;function l(e,t){return e.player.installed.filter(n=>a(n).family===t&&c(e,n))}function u(e){let t=e.player.core;for(let n of e.player.installed)a(n).family===`power`&&n.on&&(t+=Math.round(o(n,`power`,0)));return t}function d(e){let t=0;for(let n of e.player.installed)n.on&&(t+=a(n).power);return t}function f(e,t){if(t.on)return null;let n=a(t);return d(e)+n.power>u(e)?`not enough power: ${n.name} needs ${n.power}, ${u(e)-d(e)} free`:(t.on=!0,t.readyAt=e.t+n.warm,e.events.push({type:`warm`,data:t.uid}),null)}function p(e,t){t.on=!1;let n=e.player.installed.filter(e=>e.on);for(;d(e)>u(e)&&n.length;){let e=n.pop();a(e).family!==`power`&&(e.on=!1)}}function m(e,n){for(let r of e.player.installed)c(e,r)&&t[a(r).family]?.tick?.(e,r,n)}r([{id:`servo-gait`,name:`servo gait`,family:`gait`,power:1,warm:1,tier:0,params:{keys:!0,pace:4},text:`pistons that answer the arrow keys. esc leaves the console, enter goes back.`},{id:`gyro-heart`,name:`gyro heart`,family:`gait`,power:2,warm:2,tier:1,params:{free:!0,speed:2.5},text:`a spinning heart: wasd to walk, click the eye to turn with the mouse.`},{id:`tunnel-tongue`,name:`tunnel tongue`,family:`gait`,power:2,warm:1.5,tier:1,params:{dig:!0,cooldown:1},text:`a rasp of bone-iron. it eats plain wall, not ore.`},{id:`votive-battery`,name:`votive battery`,family:`power`,power:0,warm:1,tier:1,params:{power:3,loud:1},text:`a jar of prayers that still hold a charge. they whisper.`},{id:`heart-shard`,name:`heart-shard`,family:`power`,power:0,warm:2,tier:2,params:{power:5,loud:3},text:`a splinter of the god's heart. it beats against your board, and everything hears it.`},{id:`slot-board`,name:`slot board`,family:`power`,power:0,warm:0,tier:1,params:{slots:1},text:`a spare socket. install it: one more slot.`},{id:`ledger`,name:`tithe ledger`,family:`mind`,power:1,warm:.5,tier:0,params:{what:`ledger`,tithe:2},text:`a clerk of the dead counts every kill: twice as many pay out.`},{id:`clock-of-hours`,name:`clock of hours`,family:`mind`,power:2,warm:1.5,tier:1,params:{what:`clock`,range:8,ahead:1},text:`it ticks a second ahead of the world.`},{id:`dawn-eye`,name:`dawn eye`,family:`camera`,power:2,warm:.5,tier:0,params:{res:96,colors:0,fps:8,fov:75,range:9,filter:`color`},text:`a clear colour eye. honest, but it needs light to see far.`},{id:`pinhole-eye`,name:`pinhole eye`,family:`camera`,power:0,warm:1,tier:0,params:{res:24,colors:4,fps:3,fov:60,range:6,filter:`gray`},text:`a bead of black glass. it remembers light, slowly.`},{id:`vidicon-tube`,name:`vidicon tube`,family:`camera`,power:1,warm:1.5,tier:0,params:{res:64,colors:4,fps:4,fov:70,range:8,lag:.4,filter:`color`},text:`a glass tube that drags its ghosts behind it.`},{id:`saints-lens`,name:`saint's lens`,family:`camera`,power:4,warm:3,tier:2,params:{res:200,colors:0,fps:15,fov:80,range:14,filter:`color`},text:`ground from a saint, they say. it sees as he did.`},{id:`stepper-relay`,name:`stepper relay`,family:`gait`,power:1,warm:.5,tier:0,params:{go:!0},text:`clicks your legs forward one cell at a time. go n 3.`},{id:`spark-finger`,name:`spark finger`,family:`weapon`,power:1,warm:.5,tier:0,params:{damage:1,cooldown:1.2,range:1.5,aim:`auto`},text:`it bites whatever comes close.`},{id:`carrion-eye`,name:`carrion eye`,family:`camera`,power:2,warm:.5,tier:0,params:{res:96,fps:12,fov:70,range:8,filter:`1bit`,noise:.1},text:`a crow saw the world in two colours and never blinked.`},{id:`bat-psalter`,name:`bat psalter`,family:`camera`,power:2,warm:1,tier:0,params:{res:64,fps:6,fov:90,range:10,colors:8,filter:`sonar`,loud:3},text:`it sings into the dark and reads the answer. everything hears it sing.`},{id:`ember-iris`,name:`ember iris`,family:`camera`,power:2,warm:2,tier:1,params:{res:48,fps:3,fov:60,range:12,colors:6,filter:`heat`,noise:.15},text:`it sees only what is warm. walls are rumours.`},{id:`lattice-eye`,name:`lattice eye`,family:`camera`,power:3,warm:1,tier:1,params:{res:128,fps:10,fov:75,range:11,filter:`edge`},text:`a lacemaker's eye: every thing is its outline.`},{id:`fog-of-saints`,name:`fog of saints`,family:`camera`,power:1,warm:2.5,tier:1,params:{res:96,fps:2,fov:80,range:12,blur:1,lag:.8,filter:`color`},text:`colour, the old way: slow, soft, kind.`},{id:`heat-choir`,name:`heat choir`,family:`scanner`,power:1,warm:1,tier:0,params:{range:7,sees:[`heat`],refresh:1.5,shape:`ring`},text:`small throats that hum when something warm draws near.`},{id:`lodestone`,name:`lodestone`,family:`scanner`,power:1,warm:.5,tier:0,params:{range:8,sees:[`metal`,`cards`],refresh:2,shape:`ring`},text:`a black stone that leans toward iron.`},{id:`bone-listener`,name:`bone-listener`,family:`scanner`,power:1,warm:1,tier:1,params:{range:10,sees:[`flesh`],refresh:.8,shape:`cone`},text:`a jawbone pressed to the wall. it hears the hidden.`},{id:`conduit-dowser`,name:`conduit dowser`,family:`scanner`,power:1,warm:1,tier:0,params:{range:9,sees:[`doors`],refresh:3,shape:`ring`},text:`a forked rib that twitches over passages.`},{id:`marrow-rod`,name:`marrow rod`,family:`scanner`,power:1,warm:1.5,tier:1,params:{range:8,sees:[`veins`],refresh:3,shape:`cone`},text:`it drinks a little of every vein it finds.`},{id:`watchers-bell`,name:`watcher's bell`,family:`scanner`,power:2,warm:1.5,tier:2,params:{range:12,sees:[`enemies`,`cards`],refresh:1,shape:`ring`},text:`it rings for every eye that turns to you.`},{id:`halo`,name:`halo`,family:`lamp`,power:1,warm:.5,tier:0,params:{radius:3,color:`ffe0a8`,flicker:0},text:`a ring of light. it was meant for a head.`},{id:`censer`,name:`censer of embers`,family:`lamp`,power:1,warm:1,tier:0,params:{radius:4,color:`ff9040`,flicker:.5},text:`smoke and coal on a chain. it gutters, it breathes.`},{id:`cold-star`,name:`cold star`,family:`lamp`,power:2,warm:2,tier:2,params:{radius:7,color:`a8c8ff`,flicker:.05},text:`a shard of a star, still cold. everything sees it.`},{id:`ember-cell`,name:`ember cell`,family:`power`,power:0,warm:0,tier:0,params:{power:2},text:`a coal that will not go out.`},{id:`leech-needle`,name:`leech needle`,family:`tool`,power:1,warm:1,tier:0,params:{drain:1,cooldown:1.5,noise:8},text:`a hollow needle. it drinks the walls. loudly.`},{id:`bone-auger`,name:`bone auger`,family:`tool`,power:2,warm:1.5,tier:1,params:{drain:2,cooldown:1,noise:12},text:`it chews veins to the root. everything hears.`},{id:`card-reader`,name:`card reader`,family:`mind`,power:1,warm:.5,tier:0,params:{what:`reader`},text:`a slot for memory cards. it reads what the dead wrote.`},{id:`map-spool`,name:`map spool`,family:`mind`,power:1,warm:1,tier:0,params:{what:`map`,span:33,reveal:7},text:`a reel of tape that remembers every turn.`},{id:`survey-spool`,name:`survey spool`,family:`mind`,power:2,warm:1.5,tier:2,params:{what:`map`,span:66,reveal:12},text:`a wider reel, wound by a surveyor long gone.`},{id:`drowned-compass`,name:`drowned compass`,family:`mind`,power:0,warm:1,tier:1,params:{what:`compass`},text:`it pulls toward what the cards promised.`},{id:`ninth-eye`,name:`the ninth eye`,family:`camera`,power:3,warm:2,tier:3,params:{res:160,colors:0,fps:10,fov:100,range:16,filter:`color`},text:`eight were made for the god. this one stayed.`},{id:`thaw-engine`,name:`thaw engine`,family:`unique`,power:0,warm:0,tier:3,params:{},text:`a cold heart the size of a fist. it wants a breast.`},{id:`nail-psalm`,name:`nail psalm`,family:`weapon`,power:1,warm:1,tier:0,params:{damage:1.5,cooldown:.9,range:8,aim:`aimed`},text:`a verse that ends in a nail. shoot.`},{id:`ember-spit`,name:`ember spit`,family:`weapon`,power:2,warm:.5,tier:1,params:{damage:.8,cooldown:.35,range:6,aim:`aimed`},text:`it coughs sparks as fast as you ask.`},{id:`bone-lance`,name:`bone lance`,family:`weapon`,power:2,warm:2,tier:1,params:{damage:6,cooldown:2.2,range:5,aim:`aimed`},text:`a rib sharpened by a patient god.`},{id:`choir-bell`,name:`choir bell`,family:`weapon`,power:2,warm:1.5,tier:1,params:{damage:1.5,cooldown:1.6,range:2.4,aim:`auto`,sweep:!0},text:`it rings at anything that comes near.`},{id:`lead-lung`,name:`lead lung`,family:`body`,power:1,warm:1,tier:0,params:{regen:.3},text:`heavy breath. you mend faster, and still mend in the cold.`},{id:`frost-coat`,name:`frost coat`,family:`body`,power:1,warm:1.5,tier:1,params:{armour:.5},text:`rime that takes the edge off every blow.`},{id:`mirror-ward`,name:`mirror ward`,family:`body`,power:2,warm:2,tier:1,params:{ward:!0,recharge:8},text:`it gives the next blow back. then it rests.`},{id:`reliquary-ribs`,name:`reliquary ribs`,family:`body`,power:1,warm:1,tier:2,params:{hp:5},text:`a cage of holy bone around your core.`},{id:`wayfinder-moth`,name:`wayfinder moth`,family:`gait`,power:1,warm:1,tier:0,params:{pilot:!0,plan:40,pace:2.5},text:`a moth that remembers every lamp. click the map: it leads you there.`},{id:`psalm-of-roads`,name:`psalm of roads`,family:`gait`,power:2,warm:1.5,tier:1,params:{pilot:!0,plan:120,pace:3.2,avoid:!0},text:`a hymn for long roads. it walks you far, around what it sees.`},{id:`sleepwalker`,name:`sleepwalker`,family:`gait`,power:0,warm:2,tier:0,params:{pilot:!0,plan:20,pace:1.6},text:`it walks for you while you dream. slowly, not far.`},{id:`waystone-log`,name:`waystone log`,family:`mind`,power:1,warm:.5,tier:0,params:{what:`log`,keep:8,range:8,auto:[`start`,`printer`,`reader`,`card`,`vector`]},text:`a pilgrim's tally of the places that matter.`},{id:`pilgrims-rosary`,name:`pilgrim's rosary`,family:`mind`,power:1,warm:1,tier:1,params:{what:`log`,keep:16,range:12,auto:[`start`,`printer`,`reader`,`card`,`vector`,`mods`,`veins`]},text:`a bead for every thing you passed. it forgets nothing it can hold.`},{id:`rivet-sling`,name:`rivet sling`,family:`weapon`,power:1,warm:.5,tier:0,params:{damage:1,cooldown:1.6,range:4,aim:`auto`},text:`it flicks iron at anything that comes in sight.`},{id:`censer-flail`,name:`censer flail`,family:`weapon`,power:2,warm:1,tier:1,params:{damage:1.5,cooldown:1.5,range:1.8,aim:`auto`,sweep:!0,glow:2.5},text:`a burning censer on a chain. it swings at all of them, and keeps you warm.`},{id:`heat-lance`,name:`heat lance`,family:`weapon`,power:3,warm:2,tier:2,params:{damage:7,cooldown:1.8,range:8,aim:`aimed`},text:`a needle of the furnace. it goes through what it finds.`},{id:`reliquary-saw`,name:`reliquary saw`,family:`weapon`,power:3,warm:1,tier:2,params:{damage:3,cooldown:.9,range:1.6,aim:`auto`},text:`teeth taken from a hundred saints. it never tires.`},{id:`ossuary-plate`,name:`ossuary plate`,family:`body`,power:2,warm:1.5,tier:2,params:{armour:1},text:`a breastplate of knitted bone. heavy. good.`},{id:`overclock-coil`,name:`overclock coil`,family:`body`,power:3,warm:2,tier:1,params:{haste:.4,loud:2},text:`it runs your weapons hot, and whines for it.`},{id:`suture-moth`,name:`suture moth`,family:`body`,power:1,warm:1,tier:1,params:{mend:4,recharge:18},text:`a moth that sews. it waits until you are torn.`},{id:`rime-hood`,name:`rime hood`,family:`body`,power:1,warm:1,tier:1,params:{heatproof:1,chill:1},text:`frost that keeps a head cool in the furnace, and cold everywhere else.`},{id:`thorn-mantle`,name:`thorn mantle`,family:`body`,power:1,warm:1,tier:1,params:{thorns:1},text:`whatever bites you bleeds for it.`}]);var h={wall:0,floor:1,vein:10},g=[`bone`,`glass`,`copper`,`ichor`],_=e=>e>=h.vein&&e<h.vein+g.length?g[e-h.vein]:null,v=null,y=[];function b(e){v=e}function x(e){y.push(e)}var S=(e,t)=>`${e},${t}`;function C(e,t,n){let r=S(t,n),i=e.chunks.get(r);if(i)return i;if(!v)throw Error(`no generator: import src/world`);i=v(e.seed,t,n),e.chunks.set(r,i);for(let t of y)t(e,i);return i}function w(e,t,n){let r=Math.floor(t),i=Math.floor(n),a=Math.floor(r/16),o=Math.floor(i/16);return C(e,a,o).cells[(i-o*16)*16+(r-a*16)]}var T=0;function E(e,t,n,r){T++;let i=Math.floor(t),a=Math.floor(n),o=Math.floor(i/16),s=Math.floor(a/16);C(e,o,s).cells[(a-s*16)*16+(i-o*16)]=r}var D=(e,t,n)=>w(e,t,n)===h.floor;function O(e,t,n,r=1){let i=Math.floor(t/16),a=Math.floor(n/16);for(let t=-r;t<=r;t++)for(let n=-r;n<=r;n++)C(e,i+n,a+t)}var k={n:[0,-1],e:[1,0],s:[0,1],w:[-1,0]},A=(e,t)=>Math.atan2(e,-t);function j(e,t,n,r,i){let a=Math.ceil(Math.hypot(r-t,i-n)*3);for(let o=1;o<a;o++){let s=o/a;if(!D(e,t+(r-t)*s,n+(i-n)*s))return!1}return!0}i(`lamp`,{status:(e,t)=>[[`light ${o(t,`radius`,3)} cells; things that see light come from farther.`]]});function ee(e){return l(e,`lamp`).map(e=>({radius:o(e,`radius`,3),color:parseInt(String(o(e,`color`,`ffd8a0`)).replace(`#`,``),16)||16767136,flicker:o(e,`flicker`,0)}))}function M(e){let t=0;for(let n of e.player.installed)n.on&&e.t>=n.readyAt&&(t=Math.max(t,o(n,`glow`,0)));for(let n of ee(e))t=Math.max(t,n.radius);return t}function te(e){let t=0;for(let n of e.player.installed)n.on&&e.t>=n.readyAt&&(t+=o(n,`loud`,0));return t}function ne(e){return M(e)+te(e)}function re(e,t){if(!e.flicker)return 1;let n=Math.sin(t*13.1)*.5+Math.sin(t*7.3+1.7)*.3+Math.sin(t*23.9)*.2;return Math.max(.2,1-e.flicker*(.5+.5*n))}var N={};function ie(e,t){N[e]=t}var P=[],ae=1.5;function oe(e){let t={seed:e,t:0,player:{x:8.5,y:8.5,dir:0,hp:10,maxHp:10,slots:3,core:4,installed:[],inv:[],path:[],pace:2.5,move:null,hurtAt:-99},ents:[],chunks:new Map,vectors:[],cards:[],seen:new Set,log:[],nextId:1,ended:null,stats:{mods:[],far:0,kills:0},events:[]};return O(t,t.player.x,t.player.y),t}function F(e,...t){for(let n of t)e.log.push(typeof n==`string`?[n]:n)}function I(e,t){let n={...t,id:e.nextId++};return e.ents.push(n),n}function se(e,t,n,r){let i=N[t];if(!i)throw Error(`unknown enemy ${t}`);return I(e,{kind:`enemy`,x:n,y:r,enemy:{type:t,hp:i.hp,readyAt:0,data:i.armour?{armour:i.armour}:{}}})}function L(e){return e.kind===`mod`?s(e):e.kind===`res`?`${e.n} ${e.res}`:e.card.startsWith(`shard`)?`scripture shard`:`memory card`}var R=(e,t)=>Math.hypot(e.x-t.x,e.y-t.y);function ce(e,t,n){let r=e.player;if(!e.ended){for(let r of le)t=r(e,t,n);t<=0||(r.hp=Math.max(0,r.hp-t),r.hurtAt=e.t,e.events.push({type:`hurt`,data:t}),r.hp<=0&&(e.ended=`dead`,e.events.push({type:`die`}),F(e,`you stop. ${n?.enemy?N[n.enemy.type]?.name??`something`:`something`} took you.`)))}}var le=[];function ue(e,t,n){if(!t.enemy)return;let r=t.enemy.data.armour??0;if(r>0&&(n=Math.max(n*.2,n-r)),e.t<(t.enemy.data.open??0)&&(n*=1.5),t.enemy.hp-=n,e.events.push({type:`hit`,at:[t.x,t.y],data:t.id}),t.enemy.hp<=0){e.ents=e.ents.filter(e=>e!==t),e.stats.kills++,e.events.push({type:`kill`,at:[t.x,t.y],data:t.enemy.type});for(let n of de)n(e,t)}}var de=[];function fe(e,t,n,r,i,a=400){let o=Math.floor(t),s=Math.floor(n),c=Math.floor(r),l=Math.floor(i),u=(e,t)=>e*100003+t,d=new Map([[u(o,s),-1]]),f=[[o,s]];for(let t=0;t<f.length&&f.length<a;t++){let[n,r]=f[t];if(n===c&&r===l){let e=[n,r];for(;;){let t=d.get(u(e[0],e[1]));if(t===u(o,s)||t===-1)return[e[0]+.5,e[1]+.5];e=[Math.round(t/100003),t-Math.round(t/100003)*100003]}}for(let[t,i]of[[1,0],[-1,0],[0,1],[0,-1]]){let a=n+t,o=r+i;!d.has(u(a,o))&&D(e,a+.5,o+.5)&&(d.set(u(a,o),u(n,r)),f.push([a,o]))}}return null}function pe(e,t,n){let r=N[t.enemy.type],i=e.player,a=R(t,i);if(!t.enemy.data.noticed){if(a<r.sense+ne(e)&&j(e,t.x,t.y,i.x,i.y))t.enemy.data.noticed=!0;else return}let o=t.enemy.data.post,s=o&&Math.hypot(i.x-o[0],i.y-o[1])>7;if(s&&Math.hypot(t.x-o[0],t.y-o[1])<.3)return;let c=s?{x:o[0],y:o[1]}:i;if(Math.floor(t.x)!==Math.floor(c.x)||Math.floor(t.y)!==Math.floor(c.y)){let n=t.enemy.data;(!n.stepAt||e.t>=n.stepAt)&&(n.step=fe(e,t.x,t.y,c.x,c.y),n.stepAt=e.t+.4),n.step&&(c={x:n.step[0],y:n.step[1]})}if(s||a>1.1){let i=c.x-t.x,a=c.y-t.y,o=r.speed*n,s=(n,r)=>{let i=t.x+n,a=t.y+r;return D(e,i+Math.sign(n)*.3,a+Math.sign(r)*.3)?(t.x=i,t.y=a,!0):!1},l=Math.sign(i)*Math.min(o,Math.abs(i)),u=Math.sign(a)*Math.min(o,Math.abs(a));Math.abs(i)>Math.abs(a)?s(l,0)||s(0,u||o):s(0,u)||s(l||o,0)}!s&&R(t,i)<=1.5&&e.t>=t.enemy.readyAt&&(t.enemy.readyAt=e.t+r.cooldown,t.enemy.data.felt=e.t,ce(e,r.damage,t))}function me(e,t){let n=e.player,r=n.pace;if(n.path.length){let[i,a]=n.path[0],o=i-n.x,s=a-n.y,c=Math.hypot(o,s);c>.01&&!(e.t<(n.faceLock??0))&&(n.dir=Math.atan2(o,-s)),c<=r*t?(n.x=i,n.y=a,n.path.shift()):(n.x+=o/c*r*t,n.y+=s/c*r*t)}else if(n.move){let[r,i]=n.move,a=.25,o=n.x+r*t;D(e,o+Math.sign(r)*a,n.y-a)&&D(e,o+Math.sign(r)*a,n.y+a)&&(n.x=o);let s=n.y+i*t;D(e,n.x-a,s+Math.sign(i)*a)&&D(e,n.x+a,s+Math.sign(i)*a)&&(n.y=s)}}function he(e,t){if(e.ended)return;e.events=[],e.t+=t;let n=e.player;me(e,t),O(e,n.x,n.y),e.stats.far=Math.max(e.stats.far,Math.round(Math.hypot(n.x-8.5,n.y-8.5))),m(e,t);for(let r of[...e.ents])if(!(!r.enemy||R(r,n)>24)&&((N[r.enemy.type]?.ai??pe)(e,r,t),e.ended))return;for(let n of P)n(e,t)}function ge(e){return e.ents.filter(t=>t.kind===`item`&&R(t,e.player)<1.6)}var z=e=>(Math.round(e*10)/10).toString(),_e={color:`colour`,gray:`grey`,"1bit":`black & white`,heat:`heat only`,sonar:`sonar`,edge:`outlines only`},B={color:`needs light in the dark`,gray:`needs light in the dark`,"1bit":`half the light it needs; reads scratched walls, sees mimics breathe`,heat:`warm things only, through walls, the hidden too; shows warm handprints; blind in the furnace`,sonar:`sees in the dark and the hidden; hears hollow walls`,edge:`sees in the dark; reads scratched walls`},ve={heat:`warm things`,metal:`metal`,flesh:`hidden flesh`,doors:`passages`,cards:`memory cards`,enemies:`enemies`,veins:`veins`};function ye(e){let t=a(e),n=t=>o(e,t);switch(t.family){case`camera`:{let e=n(`colors`),t=[`${Math.round(n(`res`))} px`,_e[n(`filter`)]??n(`filter`)];return e&&t.push(`${e} shades`),t.push(`${z(n(`fps`))} fps`,`sees ${z(n(`range`))} cells`),n(`noise`)&&t.push(`noisy`),t.push(B[n(`filter`)]??`needs light in the dark`),n(`lag`)&&t.push(`smears`),`eye · `+t.join(` · `)}case`scanner`:return`scanner · shows ${(n(`sees`)??[]).map(e=>ve[e]??e).join(`, `)}${(n(`sees`)??[]).includes(`metal`)?` (mimics wake early)`:``}${(n(`sees`)??[]).includes(`doors`)?` (onto your map)`:``} through walls · ${z(n(`range`))} cells · ${n(`shape`)===`cone`?`ahead`:`all round`} · every ${z(n(`refresh`))} s`;case`lamp`:return`lamp · lights ${z(n(`radius`))} cells · things see you farther`;case`gait`:return n(`pilot`)?`pilot · walks you to a spot: click the map or goto, ${z(n(`pace`))} cells/s, plans ${z(n(`plan`))} cells${n(`avoid`)?`, around enemies`:``}`:n(`go`)?`legs · walk cells: go <dir> <n>, or the n e s w buttons`:n(`keys`)?`legs · arrow keys, ${z(n(`pace`))} cells/s`:n(`free`)?`legs · free walking, wasd + mouse, ${z(n(`speed`))} cells/s`:n(`dig`)?`digger · dig: eats the wall in front, every ${z(n(`cooldown`))} s`:`legs`;case`weapon`:return`weapon · ${z(n(`damage`))} dmg every ${z(n(`cooldown`))} s · ${n(`aim`)===`aimed`?`shoot, ${z(n(`range`))} cells`:`hits ${n(`sweep`)?`everything`:`whatever`} you see within ${z(n(`range`))} cells`}${n(`glow`)?` · glows ${z(n(`glow`))} cells (warmth in the cold)`:``}`;case`body`:return n(`hp`)?`body · +${z(n(`hp`))} max hp`:n(`regen`)?`body · mend ${z(n(`regen`))} hp/s more`:n(`armour`)?`body · takes ${z(n(`armour`))} off every hit`:n(`ward`)?`body · throws the next hit back, then rests ${z(n(`recharge`))} s`:n(`haste`)?`body · weapons cool ${Math.round(n(`haste`)*100)}% faster`:n(`mend`)?`body · +${z(n(`mend`))} hp when you drop below half, every ${z(n(`recharge`))} s`:n(`heatproof`)?`body · keeps ${Math.round(Math.min(1,n(`heatproof`))*100)}% of the furnace's heat off${n(`chill`)?` · elsewhere you are cold: no mending without light`:``}`:n(`thorns`)?`body · ${z(n(`thorns`))} dmg back at whatever strikes you up close`:`body`;case`mind`:{let e=n(`what`);return e===`map`?`map · unrolls what lies in sight ${z(n(`reveal`))} cells around you, ${z(n(`span`))} cells across`:e===`log`?`log · keeps ${z(n(`keep`))} places that matter, noted within ${z(n(`range`))} cells, each with go`:e===`reader`?`reader · reads memory cards: read card`:e===`ledger`?`ledger · kills pay out ${z(n(`tithe`)||1)}× as often`:e===`compass`?`compass · points to what the cards promised`:e===`clock`?`clock · shows where enemies will be ${z(n(`ahead`))} s ahead, ${z(n(`range`))} cells`:`mind · `+e}case`power`:return n(`slots`)?`slot board · install it: +${z(n(`slots`))} slot, used up`:`power · +${z(n(`power`))} power while on · takes a slot`;case`tool`:return`tool · drains a vein beside you ×${z(n(`drain`))} every ${z(n(`cooldown`))} s · loud: wakes ${z(n(`noise`))} cells`;case`unique`:return`the thaw engine · install it to end the run`;default:return t.family}}function be(e){let t=a(e),n=[t.family===`power`?`draws no power`:`uses ${t.power} power`];t.warm&&n.push(`warms ${z(t.warm)} s`);let r=o(e,`loud`,0);return r&&n.push(`loud: things notice you ${z(r)} cells farther`),e.roll&&n.push(`${e.roll.tag}: ${e.roll.key} ×${e.roll.mult}`),n.join(` · `)}var V=e=>[ye(e),be(e),a(e).text],H={};function U(e,t){H[e]=t}function W(e,t){let n=t.trim().toLowerCase().split(/\s+/).filter(Boolean);if(!n.length)return;if(F(e,[{text:`> `+n.join(` `),cmd:``}]),e.ended)return F(e,`nothing answers.`);let[r,...i]=n,a=H[r];if(!a)return F(e,`${r}: unknown. try `,[{text:`help`,cmd:`help`}]);if(a.when&&!a.when(e))return F(e,xe(e,a)??a.whenFail?.(e)??`${r}: nothing installed can do that.`);a.run(e,i)}function xe(e,t){let n=e.player.installed.filter(t=>t.on&&e.t<t.readyAt);if(!n.length)return null;let r=n.map(e=>e.readyAt);for(let t of n)t.readyAt=e.t;let i=!1;try{i=t.when(e)}finally{n.forEach((e,t)=>e.readyAt=r[t])}if(!i)return null;let a=n.sort((e,t)=>e.readyAt-t.readyAt)[0];return`${s(a)} is warming up (${Math.max(1,Math.ceil(a.readyAt-e.t))} s).`}function Se(e,t,n,r=!1){let i=e.player,[a,o]=[Math.floor(i.x),Math.floor(i.y)],[s,c]=[Math.floor(t)-a,Math.floor(n)-o],l=(e,t,n)=>`go ${e} ${Math.abs(t)-(n&&r?1:0)}`,u=!c||!!s&&D(e,a+s,o),d=[u?[`x`,s]:[`y`,c],u?[`y`,c]:[`x`,s]].filter(([,e])=>e).map(([e,t],n,r)=>l(e===`x`?t>0?`e`:`w`:t>0?`s`:`n`,t,n===r.length-1)).filter(e=>!e.endsWith(` 0`)),f=(c<0?`n`:c>0?`s`:``)+(s>0?`e`:s<0?`w`:``),p=Math.max(Math.abs(s),Math.abs(c));return[`${p} cell${p===1?``:`s`} ${f||`here`}`,{text:`go there`,cmd:d.join(`; `)}]}var Ce=e=>e.replace(/-/g,` `);function we(e,t){let n=Ce(t.join(` `));return n?e.player.inv.findIndex(e=>Ce(L(e)).includes(n)):-1}function Te(e,t,n){let r=t.length>1&&/^\d+$/.test(t[t.length-1])?Number(t[t.length-1]):0,i=(r?t.slice(0,-1):t).join(` `);if(!i)return;if(r){let t=e.player.installed.filter(e=>s(e)===i);if(t[r-1])return t[r-1]}let a=e.player.installed.filter(e=>Ce(s(e)).includes(Ce(i)));return n&&a.find(n)||a[0]}function Ee(e,t){let n=e.player.installed.filter(e=>s(e)===s(t));return n.length>1?`${s(t)} ${n.indexOf(t)+1}`:s(t)}function De(e){let t=L(e);return e.kind===`mod`?[{text:t,cmd:`install ${a(e).name}`},`  ${a(e).family}${a(e).family===`power`||!a(e).power?``:` · ${a(e).power}p`}`]:e.kind===`card`?[{text:t,cmd:`read card`}]:[t]}function Oe(e,t){if(t.kind===`res`){let n=e.player.inv.find(e=>e.kind===`res`&&e.res===t.res);if(n&&n.kind===`res`)return void(n.n+=t.n)}e.player.inv.push(t)}var ke=new Set([`conjure`]),Ae=new Set([`tidy`,`pause`]);U(`help`,{help:`the goal, the keys and what you can do: help, help go`,run(e,[t]){if(t){let n=H[t];return!n||ke.has(t)?F(e,[`${t}: no such verb. `,{text:`help`,cmd:`help`}]):F(e,`${t}: ${n.help}${n.when&&!n.when(e)?` (nothing installed can do it now)`:``}`)}F(e,Object.keys(H).filter(t=>!ke.has(t)&&(!H[t].when||H[t].when(e))).flatMap((e,t)=>t?[`  `,{text:e,cmd:e}]:[{text:e,cmd:e}])),F(e,[`help <verb> tells one: `,{text:`help go`,cmd:`help go`}],`the goal: three elites guard three shards of scripture, in the nave, the ossuary and the furnace.`,`read them with a card reader: together they point to the Thaw Engine. reach it and wake the god.`,`keys: arrows or wasd walk · q e turn · t tidies windows · p pauses · 1-4 setups · esc leaves the console, enter comes back`)}}),U(`inv`,{help:`what you carry`,run(e){if(!e.player.inv.length)return F(e,`you carry nothing.`);for(let t of e.player.inv)F(e,De(t))}}),U(`take`,{help:`take what is within reach: take (or take all), take pinhole`,run(e,t){let n=t.join(` `)===`all`?``:t.join(` `),r=ge(e).filter(e=>!n||L(e.item).includes(n));if(!r.length)return F(e,n?`no ${n} within reach.`:`nothing within reach.`);for(let t of r){if(t.data?.mimic)continue;e.ents=e.ents.filter(e=>e!==t),Oe(e,t.item),e.events.push({type:`take`,at:[t.x,t.y]});let n=t.item;n.kind===`mod`?F(e,[`you take: `,...De(n)],`  ${ye(n)}`):F(e,[`you take: `,...De(n)])}}});var je=new WeakMap;function Me(e){let t=e.player,[n,r]=[Math.floor(t.x),Math.floor(t.y)],i=e.ents.filter(e=>e.kind===`item`&&e.item?.kind===`res`&&!e.data?.mimic&&Math.floor(e.x)===n&&Math.floor(e.y)===r);if(!i.length)return;let a=je.get(e);(!a||e.t-a.t>3||e.log[e.log.length-1]!==a.line)&&(a={line:[``],t:e.t,got:[]},F(e,a.line),je.set(e,a)),a.t=e.t;for(let t of i){let n=t.item;e.ents=e.ents.filter(e=>e!==t),Oe(e,{...n}),e.events.push({type:`take`,at:[t.x,t.y]});let r=a.got.find(([e])=>e===n.res);r?r[1]+=n.n:a.got.push([n.res,n.n])}a.line[0]=a.got.map(([e,t])=>`+${t} ${e}`).join(`, `)}P.push(Me),U(`drop`,{help:`leave an item here`,run(e,t){let n=we(e,t);if(n<0)return F(e,`you carry no such thing.`);let[r]=e.player.inv.splice(n,1);I(e,{kind:`item`,x:e.player.x,y:e.player.y,item:r}),F(e,`dropped ${L(r)}.`)}}),U(`install`,{help:`put a module in a free slot: install pinhole eye`,run(e,t){let n=e.player,r=we(e,t),i=n.inv[r];if(!i||i.kind!==`mod`)return F(e,`no such module in your inventory. `,[{text:`inv`,cmd:`inv`}]);if(n.installed.length>=n.slots)return F(e,`no free slot (${n.slots}). remove something, swap it in, or buy a slot at a printer.`);n.inv.splice(r,1);let o={uid:e.nextId++,mod:i.mod,roll:i.roll,on:!1,readyAt:0,data:{}};n.installed.push(o),e.stats.mods.includes(i.mod)||e.stats.mods.push(i.mod),e.events.push({type:`install`,data:o.uid});let c=f(e,o);F(e,`installed ${s(o)}.`+(c?` it stays off: ${c}.`:a(o).warm?` warming up.`:``))}}),U(`remove`,{help:`take a module out of its slot`,run(e,t){let n=Te(e,t,e=>e.on);if(!n)return F(e,`nothing installed by that name.`);p(e,n),e.player.installed=e.player.installed.filter(e=>e!==n),Oe(e,{kind:`mod`,mod:n.mod,roll:n.roll}),e.events.push({type:`remove`,data:n.uid}),F(e,`removed ${s(n)}.`)}}),U(`on`,{help:`switch a module on (it warms up first)`,run(e,t){let n=Te(e,t,e=>!e.on);if(!n)return F(e,`nothing installed by that name.`);F(e,f(e,n)??`${s(n)} warming up.`)}}),U(`off`,{help:`switch a module off: frees its power`,run(e,t){let n=Te(e,t,e=>e.on);if(!n)return F(e,`nothing installed by that name.`);p(e,n),F(e,`${s(n)} off.`)}}),U(`status`,{help:`your body: hp, slots, power`,run(e){let t=e.player;F(e,`hp ${Math.ceil(t.hp)}/${t.maxHp}   slots ${t.installed.length}/${t.slots}   power ${d(e)}/${u(e)}`);for(let n of t.installed)F(e,[{text:s(n),cmd:`${n.on?`off`:`on`} ${a(n).name}`},`  ${n.on?e.t>=n.readyAt?`on`:`warming`:`off`}  ${a(n).power}p`])}});var Ne={leg(e,t,n){let[r,i]=[t-e.player.x,n-e.player.y];return[Math.abs(r)>Math.abs(i)?r>0?`e`:`w`:i>0?`s`:`n`,Math.max(1,Math.min(9,Math.round(Math.max(Math.abs(r),Math.abs(i)))))]},long(e,t,n){let[r,i,a,o]=[Math.floor(e.player.x),Math.floor(e.player.y),Math.floor(t),Math.floor(n)];if(r===a&&i===o)return Ne.leg(e,t,n);let[s,c,l,u]=[Math.min(r,a)-12,Math.max(r,a)+12,Math.min(i,o)-12,Math.max(i,o)+12],d=new Map([[a+`,`+o,0]]),f=[[a,o]];for(let t=1;f.length&&!d.has(r+`,`+i)&&t<120;t++){let n=[];for(let[a,o]of f)for(let[f,p]of[[1,0],[-1,0],[0,1],[0,-1]]){let[m,h]=[a+f,o+p],g=m+`,`+h;d.has(g)||m<s||m>c||h<l||h>u||(m===r&&h===i||D(e,m+.5,h+.5))&&(d.set(g,t),n.push([m,h]))}f=n}let p=d.get(r+`,`+i);if(p===void 0)return Ne.leg(e,t,n);let m=null;for(let e of[`n`,`e`,`s`,`w`]){let[t,n]=k[e],a=0;for(;a<9&&d.get(r+t*(a+1)+`,`+(i+n*(a+1)))===p-a-1;)a++;a&&(!m||a>m[1])&&(m=[e,a])}return m??Ne.leg(e,t,n)}};U(`listen`,{help:`what you hear around you`,run(e){let t=e.player,n=t=>e.ents.filter(e=>e.enemy&&R(e,t)<2.5).length,r=t=>e.ents.filter(e=>e.kind===`item`&&R(e,t)<2).length,i=e=>e.kind!==`prop`||!!e.data?.altar,a=e.ents.filter(e=>R(e,t)<10&&i(e)).sort((e,n)=>R(e,t)-R(n,t)).filter((e,t,r)=>e.enemy?n(e)<3||!r.slice(0,t).some(t=>t.enemy&&R(t,e)<2.5):e.kind!==`item`||!r.slice(0,t).some(t=>t.kind===`item`&&R(t,e)<2));if(!a.length)return F(e,`only the slow drip of something warm.`);let s=l(e,`gait`).some(e=>o(e,`go`,!1));for(let i of a.slice(0,4)){let[a,o]=[i.x-t.x,i.y-t.y],c=R(i,t),l=c<1.6?`within reach`:`${Math.round(c)} cells`,u=(Math.atan2(a,-o)*180/Math.PI+360)%360,d=[`n`,`ne`,`e`,`se`,`s`,`sw`,`w`,`nw`][Math.round(u/45)%8],f=i.kind===`item`?r(i):1,p=i.enemy?i.enemy.data.elite?`something large, keeping time`:n(i)>=3?`a swarm, ${n(i)} or so`:`something moving`:i.kind===`printer`?i.data?.shop?`a reliquary humming`:`a printer humming`:i.kind===`prop`?`an altar, breathing slow`:f>1?`things lying still ×${f}`:`something lying still`,[m,h]=Ne.long(e,i.x,i.y),g=c<1.6?i.kind===`item`?`take`:``:s?`go ${m} ${h}`:`crawl ${m}`;F(e,[`${p}, ${l}${c<1.6?``:`, `+d}.  `,...g?[{text:g,cmd:g}]:[]])}}});var Pe=new Set([`take`,`drop`,`install`,`remove`,`on`,`off`,`go`,`crawl`,`face`,`step`,`print`,`save`,`setup`,`conjure`,`read`,`goto`,`buy`,`info`,`recycle`,`swap`,`uninstall`]),Fe=(e,t)=>!!H[t]&&(!H[t].when||H[t].when(e));function Ie(e){let t=e.player,n=(e,t=e)=>({label:e,cmd:t}),r=Math.floor(t.x)+.5,i=Math.floor(t.y)+.5,a=t=>{let[n,a]=k[t],o=0;for(;o<9&&D(e,r+n*(o+1),i+a*(o+1));)o++;return o},o=[];for(let t of[`n`,`e`,`s`,`w`]){let r=a(t);r&&(Fe(e,`go`)?o.push(n(`go ${t} ${r}`)):Fe(e,`step`)?o.push(n(`step ${t}`)):o.push(n(`crawl ${t}`)))}Fe(e,`stop`)&&t.path.length>1&&o.push(n(`stop`));let s=Object.keys(H).filter(t=>!Pe.has(t)&&!ke.has(t)&&!Ae.has(t)&&t!==`stop`&&Fe(e,t)).map(e=>n(e));return[[`move`,o],[`other`,s]].filter(([,e])=>e.length)}function G(...e){let t=2166136261;for(let n of e)t^=n|0,t=Math.imul(t,16777619),t^=t>>>15,t=Math.imul(t,739982445),t^=t>>>12;return t>>>0}function Le(e){let t=e>>>0||1,n=(()=>{t=t+1831565813>>>0;let e=t;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296});return n.int=(e,t)=>e+Math.floor(n()*(t-e+1)),n.pick=e=>e[Math.floor(n()*e.length)],n.chance=e=>n()<e,n}var Re=[`bone`,`glass`,`copper`,`ichor`];i(`gait`,{buttons:(e,t)=>[...o(t,`go`,!1)?[`n`,`e`,`s`,`w`].map(e=>({label:e,cmd:`go ${e}`})):[],...o(t,`keys`,!1)?[`n`,`e`,`s`,`w`].map(e=>({label:e,cmd:`step ${e}`})):[],...o(t,`dig`,!1)?[{label:`dig`,cmd:`dig`}]:[]]});var ze=e=>t=>l(t,`gait`).some(t=>o(t,e,!1));function Be(e,t,n){let r=k[t];if(!r)return 0;let i=e.player,[a,o]=i.path.length?i.path[i.path.length-1]:[Math.floor(i.x)+.5,Math.floor(i.y)+.5],s=0;for(;s<n&&D(e,a+r[0],o+r[1]);s++)a+=r[0],o+=r[1],i.path.push([a,o]);return s||(i.dir=A(r[0],r[1])),s}U(`go`,{help:`walk: go n 3 (n e s w, up to 9 cells)`,when:ze(`go`),run(e,[t,n]){if(!t||!k[t[0]])return F(e,`go where? n e s w`);e.player.pace=2.5,Be(e,t[0],Math.min(9,Math.max(1,Number(n)||1)))?Ve.set(e,t[0]):F(e,`a wall.`)}});var Ve=new WeakMap;P.push(e=>{let t=Ve.get(e),n=e.player;if(!t||n.path.length)return;Ve.delete(e);let[r,i]=[Math.floor(n.x)+.5,Math.floor(n.y)+.5];if(D(e,r+k[t][0],i+k[t][1]))return;let a={n:`s`,s:`n`,e:`w`,w:`e`}[t],o=null;for(let t of[`n`,`e`,`s`,`w`]){let n=0;for(;n<9&&D(e,r+k[t][0]*(n+1),i+k[t][1]*(n+1));)n++;let s=t===a?n/2:n;n&&(!o||s>o[1])&&(o=[t,s])}o&&(n.dir=A(k[o[0]][0],k[o[0]][1]))}),U(`crawl`,{help:`drag yourself one cell: crawl n (slow, needs nothing)`,run(e,[t]){if(!t||!k[t[0]])return F(e,`crawl where? n e s w`);if(e.player.path.length)return F(e,`you are still moving.`);e.player.pace=.5,Be(e,t[0],1)||F(e,`a wall.`)}});var He={ne:[1,-1],se:[1,1],sw:[-1,1],nw:[-1,-1]};U(`face`,{help:`turn: face n (n ne e se s sw w nw)`,when:ze(`go`),run(e,[t]){let n=t&&(He[t]??k[t[0]]);if(!n)return F(e,`face where? n ne e se s sw w nw`);e.player.dir=A(n[0],n[1])}}),U(`stop`,{help:`stop walking`,when:ze(`go`),run(e){e.player.path=e.player.path.slice(0,1)}});var Ue=(e,t)=>l(e,`gait`).find(e=>o(e,t,!1));function We(e,t){let n=Ue(e,`keys`),r=k[t];if(!n||!r)return!1;let i=e.player;if(i.dir=A(r[0],r[1]),i.path.length>1)return!1;i.move=null,i.pace=o(n,`pace`,4);let a=Be(e,t,1);return a&&e.events.push({type:`step`}),a>0}U(`step`,{help:`servo gait: step n (one cell, arrow keys do the same)`,when:e=>!!Ue(e,`keys`),run(e,[t]){if(!t||!k[t[0]])return F(e,`step where? n e s w`);!We(e,t[0])&&!e.player.path.length&&F(e,`a wall.`)}});function Ge(e,t,n){let r=e.player,i=Ue(e,`free`);if(!i||!t&&!n){r.move=null;return}r.path=r.path.slice(0,1);let a=o(i,`speed`,2.5),s=Math.sin(r.dir),c=-Math.cos(r.dir),l=t*s-n*c,u=t*c+n*s,d=Math.hypot(l,u)||1;l=l/d*a,u=u/d*a,r.move=[l,u]}var Ke=e=>!!Ue(e,`free`);function qe(e,t){if(!Ue(e,`free`))return;let n=e.player;n.dir=((n.dir+t)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)}P.push(e=>{e.player.move&&!Ue(e,`free`)&&(e.player.move=null)});function Je(e){let t=e.player,n=Math.round(t.dir/(Math.PI/2))&3,[r,i]=[k.n,k.e,k.s,k.w][n];return[Math.floor(t.x)+r,Math.floor(t.y)+i]}U(`dig`,{help:`tunnel tongue: turn the wall in front into floor`,when:e=>!!Ue(e,`dig`),run(e){let t=Ue(e,`dig`),n=t.data.readyAt??0;if(e.t<n)return F(e,`the tongue is still grinding.`);let[r,i]=Je(e),a=w(e,r,i);if(a===h.floor)return F(e,`nothing to dig: open ahead.`);if(a!==h.wall)return F(e,`too hard. the tongue slips off it.`);E(e,r,i,h.floor),t.data.readyAt=e.t+o(t,`cooldown`,1),e.events.push({type:`dig`,at:[r+.5,i+.5]}),F(e,`the tongue grinds through. the way ahead is open.`)}});var Ye=H.install;U(`install`,{...Ye,run(e,t){let n=e.player,r=n.inv[we(e,t)],i=r?.kind===`mod`?o(r,`slots`,0):0;if(!i)return Ye.run(e,t);if(n.slots>=8)return F(e,`the motherboard is full: 8 slots.`);n.inv.splice(n.inv.indexOf(r),1),n.slots=Math.min(8,n.slots+Math.round(i)),e.events.push({type:`install`}),F(e,`the board seats itself. slots ${n.installed.length}/${n.slots}.`)}});var Xe=new WeakMap,Ze=e=>{let t=Xe.get(e);return t||Xe.set(e,t={}),t};function Qe(e,t){let n=e.player.installed.filter(e=>e.on).map(e=>e.mod);return Ze(e)[t]=n,n}function $e(e,t){let n=Ze(e)[t];if(!n)return null;let r=[...n],i=new Set;for(let t of e.player.installed){let e=r.indexOf(t.mod);e>=0&&(r.splice(e,1),i.add(t.uid))}let c=[],l=e=>a(e).family===`power`,m=e.player;for(let t of[...r]){let n=m.inv.findIndex(e=>e.kind===`mod`&&e.mod===t);if(n<0)continue;if(m.installed.length>=m.slots){let t=m.installed.filter(e=>!i.has(e.uid)&&!l(e)).sort((e,t)=>Number(e.on)-Number(t.on))[0];if(!t)break;p(e,t),m.installed=m.installed.filter(e=>e!==t),Oe(e,{kind:`mod`,mod:t.mod,roll:t.roll}),e.events.push({type:`remove`,data:t.uid})}let[a]=m.inv.splice(n,1);if(a.kind!==`mod`)continue;let o={uid:e.nextId++,mod:a.mod,roll:a.roll,on:!1,readyAt:0,data:{}};m.installed.push(o),e.stats.mods.includes(a.mod)||e.stats.mods.push(a.mod),e.events.push({type:`install`,data:o.uid}),i.add(o.uid),r.splice(r.indexOf(t),1)}for(let t of e.player.installed)!i.has(t.uid)&&t.on&&!l(t)&&p(e,t);for(let t of e.player.installed)i.has(t.uid)&&l(t)&&f(e,t);for(let t of e.player.installed){if(!i.has(t.uid)||l(t))continue;let n=f(e,t);n&&c.push(`${s(t)}: ${n}`)}for(let t of e.player.installed)!i.has(t.uid)&&t.on&&l(t)&&d(e)<=u(e)-o(t,`power`,0)&&p(e,t);for(let e of r)c.push(`${e.replace(/-/g,` `)} is ${m.inv.some(t=>t.kind===`mod`&&t.mod===e)?`carried, no slot gives way`:`not carried`}`);return c}U(`save`,{help:`save setup battle: remember what is on now`,run(e,[t,n]){if(t!==`setup`||!n)return F(e,`save what? save setup battle`);let r=Qe(e,n);F(e,[`setup ${n}: ${r.length?r.map(e=>e.replace(/-/g,` `)).join(`, `):`nothing on`}. `,{text:`setup ${n}`,cmd:`setup ${n}`}])}}),U(`setup`,{help:`setup battle: turn on exactly that saved set, installing what you carry of it`,run(e,[t]){let n=Object.keys(Ze(e));if(!t)return n.length?F(e,[`setups: `,...n.flatMap((e,t)=>[t?`  `:``,{text:e,cmd:`setup ${e}`}])]):F(e,`no setups saved. turn on what you want, then: save setup battle`);/^\d$/.test(t)&&!n.includes(t)&&n[Number(t)-1]&&(t=n[Number(t)-1]);let r=$e(e,t);if(!r)return F(e,`no setup called ${t}.`);F(e,`setup ${t}: warming up.${r.length?` `+r.join(`; `)+`.`:``}`)}});var et=`clockSeen`;P.push((e,t)=>{if(!(!tt(e).length||t<=0))for(let n of e.ents){if(!n.enemy)continue;let e=n.enemy.data,r=e[et];if(r){let i=(n.x-r[0])/t,a=(n.y-r[1])/t,o=e.clockV??[i,a];e.clockV=[o[0]*.7+i*.3,o[1]*.7+a*.3]}e[et]=[n.x,n.y]}});var tt=e=>l(e,`mind`).filter(e=>o(e,`what`,``)===`clock`);function nt(e,t){let n=tt(e)[0];if(!n)return[];let r=o(n,`range`,8),i=t??o(n,`ahead`,1),a=[];for(let t of e.ents){if(!t.enemy||R(t,e.player)>r)continue;let[n,o]=t.enemy.data.clockV??[0,0],s=i;for(;s>.05&&!j(e,t.x,t.y,t.x+n*s,t.y+o*s);)s*=.6;s<=.05&&(s=0),a.push({e:t,x:t.x+n*s,y:t.y+o*s})}return a}var rt=new WeakSet;for(let e of[`on`,`install`]){let t=H[e];t&&(H[e]={...t,run(n,r){let i=n.log.length,a=new Set(n.player.installed);if(t.run(n,r),!n.log.slice(i).some(e=>e.some(e=>(typeof e==`string`?e:e.text).includes(`not enough power`))))return;let o=e===`on`?Te(n,r,e=>!e.on):n.player.installed.find(e=>!a.has(e)),c=o&&!o.on?lt(n,o,!0):null;c&&typeof c!=`string`&&o&&F(n,[`or swap: `,{text:`turn off ${c.off.map(e=>s(e)).join(` and `)} and turn on ${s(o)}`,cmd:`swap in ${Ee(n,o)}`}]),!rt.has(n)&&(rt.add(n),F(n,[`power runs out before slots do. switch something off, or keep two setups and swap: `,{text:`save setup explore`,cmd:`save setup explore`},`  `,{text:`save setup battle`,cmd:`save setup battle`},`. a generator (ember cell, votive battery) trades a slot for power.`]))}})}var it=H.install;U(`install`,{...it,help:`put a module in a free slot: install pinhole eye, or install all`,run(e,t){if(t.join(` `)!==`all`)return it.run(e,t);let n=e.player.inv.filter(e=>e.kind===`mod`);if(!n.length)return F(e,`you carry no modules.`);for(let t of n){let n=e.log.length;if(it.run(e,s(t).split(` `)),e.log.slice(n).some(e=>e.some(e=>/no free slot|stays off|motherboard is full/.test(typeof e==`string`?e:e.text))))break}}});var at={weapon:4,body:3,lamp:3,scanner:2,mind:2,gait:2,tool:1},ot=e=>a(e).family===`gait`&&[`go`,`keys`,`free`].some(t=>o(e,t,!1)),st=e=>a(e).family===`weapon`;function ct(e,t){return ot(t)&&!e.player.installed.some(e=>e!==t&&e.on&&ot(e))||o(t,`what`,``)===`map`||st(t)&&t.on&&!e.player.installed.some(e=>e!==t&&e.on&&st(e))?9:at[a(t).family]??9}function lt(e,t,n){let r=e.player,i=at[a(t).family]??9,s=t=>a(t).family!==`power`&&ct(e,t)<9&&ct(e,t)<=i,c;if(!n&&r.installed.length>=r.slots){let n=r.installed.filter(e=>!e.on&&a(e).family!==`power`).sort((t,n)=>ct(e,t)-ct(e,n)),i=r.installed.filter(e=>e.on&&s(e)).sort((t,n)=>ct(e,t)-ct(e,n)||a(n).power-a(t).power);if(c=(a(t).family===`camera`?r.installed.filter(e=>a(e).family===`camera`).sort((e,t)=>+e.on-t.on||o(e,`res`,0)-o(t,`res`,0)):[])[0]??n[0]??i[0],!c)return`no slot gives way for ${a(t).name}: all ${r.slots} hold what weighs more.`}let l=a(t).power-(u(e)-d(e))-(c?.on?a(c).power:0),f=[];if(l>0){let n=r.installed.filter(e=>e.on&&e!==c&&a(e).power>0&&s(e)),i=n.filter(e=>a(e).power>=l).sort((t,n)=>ct(e,t)-ct(e,n)||a(t).power-a(n).power)[0];if(i)f.push(i),l=0;else for(let t of n.sort((t,n)=>ct(e,t)-ct(e,n)||a(n).power-a(t).power)){if(l<=0)break;f.push(t),l-=a(t).power}if(l>0)return`not enough power for ${a(t).name}, and nothing lighter to switch off.`}return{remove:c,off:f}}U(`swap`,{help:`swap in censer: make room for a module (off or out with what weighs least) and turn it on`,run(e,t){let n=t[0]===`in`?t.slice(1):t;if(!n.length)return F(e,`swap in what? swap in censer`);let r=e.player,i=Te(e,n,e=>!e.on),a=i&&!i.on?-1:we(e,n),o=a>=0?r.inv[a]:i;if(!o||`kind`in o&&o.kind!==`mod`)return F(e,`swap in what? a module you carry, or one installed and off.`);if(o===i&&i.on)return F(e,`${s(i)} is on already.`);let c=lt(e,o,o===i);if(typeof c==`string`)return F(e,c);let l=[];if(c.remove){let t=c.remove;p(e,t),r.installed=r.installed.filter(e=>e!==t),Oe(e,{kind:`mod`,mod:t.mod,roll:t.roll}),e.events.push({type:`remove`,data:t.uid}),l.push(`${s(t)} out`)}for(let t of c.off)p(e,t),l.push(`${s(t)} off`);let u=l.length?`; ${l.join(`; `)}.`:`.`;if(o===i)return F(e,f(e,i)??`${s(i)} on${u}`);let d=new Set(r.installed);it.run(e,n);let m=r.installed.find(e=>!d.has(e));m&&F(e,`${s(m)} ${m.on?`on`:`in, off`}${u}`)}}),H.remove&&!H.uninstall&&(H.uninstall={...H.remove,help:`the same as remove`});var ut=[{id:0,name:`the cradle`,until:1.5,look:{tint:`c8a070`,fog:`100c0a`,dark:0},enter:`the cradle. warm, close, almost kind.`,foe:{hp:1,damage:1},tier:0,need:0},{id:1,name:`the choir nave`,until:3.5,look:{tint:`d0b890`,fog:`141018`,dark:.15},enter:`the choir nave. many small voices, all of them hungry.`,foe:{hp:1.2,damage:1.15},tier:1,need:9},{id:2,name:`the ossuary`,until:5.5,look:{tint:`9aa8b0`,fog:`080a10`,dark:.4},enter:`the ossuary. the marrow is cold: without a lamp you will not mend.`,foe:{hp:1.7,damage:1.45},tier:2,need:40},{id:3,name:`the furnace`,until:1/0,look:{tint:`ff7a40`,fog:`200804`,dark:.25},enter:`the furnace. the god's heat sears here: keep it off or burn.`,foe:{hp:2,damage:1.6},tier:2,need:70}];function dt(e,t){let n=Math.hypot(e,t);return ut.findIndex(e=>n<e.until)}var ft=(e,t)=>dt(Math.floor(e/16),Math.floor(t/16)),pt=e=>ut.findIndex(t=>e<t.until),mt=.15,ht=new WeakMap;P.push(e=>{let t=ft(e.player.x,e.player.y),n=ht.get(e);n||ht.set(e,n=new Set([0])),!n.has(t)&&(n.add(t),e.events.push({type:`zone`,data:t}),F(e,ut[t].enter,..._t(e,t)))});var gt={2:e=>{let t=a(e),n=o(e,`filter`,``);return t.family===`lamp`||o(e,`glow`,0)>0||n===`sonar`||n===`edge`||n===`heat`||o(e,`sees`,[]).includes(`flesh`)||t.family===`weapon`&&o(e,`damage`,0)>=3||o(e,`armour`,0)>0||o(e,`regen`,0)>0},3:e=>o(e,`heatproof`,0)>0};function _t(e,t){let n=gt[t];if(!n)return[];let r=e.player,i=[...new Map(r.inv.flatMap(e=>e.kind===`mod`&&n(e)?[[a(e).name,e]]:[])).values()].slice(0,4);if(!i.length)return t===3?[[`nothing you carry keeps it off. a rime hood would.`]]:[];let o=u(e)-d(e),s=t=>{let n=a(t).name;return r.installed.length<r.slots&&a(t).power<=o||typeof lt(e,t,!1)==`string`?`install ${n}`:`swap in ${n}`};return[[`you carry what answers it: `,...i.flatMap((e,t)=>[t?`  `:``,{text:s(e),cmd:s(e)}])]]}var vt=(e,t,n,r)=>2+G(e,t,n,r)%12;function yt(e,t,n){if(t===0&&n===0)return[[5,5,11,11,`box`]];let r=Le(G(e,7,t,n)),i=Math.hypot(t,n),a=1+ +(i>=2)+(i>=4?r.int(0,1):0)+ +(i>=6),o=Math.min(.85,i*.13),s=[];for(let e=0;s.length<a&&e<40;e++){let e=s.length===0,t=r.int(3,e?8:5),n=r.int(3,e?8:5),i=r.int(2,14-t),a=r.int(2,14-n),c=i+t-1,l=a+n-1;if(s.some(([e,t,n,r])=>i<=n+2&&c>=e-2&&a<=r+2&&l>=t-2))continue;let u=t>=5&&n>=5&&r.chance(o)?r.pick([`ribs`,`oval`,`cross`]):`box`;s.push([i,a,c,l,u])}return s}var bt=([e,t,n,r])=>[e+n>>1,t+r>>1];function xt(e,[t,n,r,i,a]){let o=r-t+1,s=i-n+1,[c,l]=[(t+r)/2,(n+i)/2];for(let u=n;u<=i;u++)for(let d=t;d<=r;d++){let f=!0;a===`ribs`&&(f=!((u===n||u===i)&&(d-t)%2==1||(d-t)%2==0&&(u-n)%2==0&&d>t&&d<r&&u>n&&u<i&&d!==Math.floor(c)&&u!==Math.floor(l))),a===`oval`&&(f=((d-c)/(o/2))**2+((u-l)/(s/2))**2<=1.05),a===`cross`&&(f=Math.abs(d-c)<=o/6+.5||Math.abs(u-l)<=s/6+.5),f&&e(d,u,h.floor)}}function St(e,t,n,r,i){let[a,o]=n;e(a,o,h.floor);let s=[];for(let e=0;e<i;e++)s.push([t.int(Math.min(a,r[0]),Math.max(a,r[0])),t.int(Math.min(o,r[1]),Math.max(o,r[1]))]);s.push(r);for(let[n,r]of s){let i=t.chance(.5),s=()=>{for(;a!==n;)a+=Math.sign(n-a),e(a,o,h.floor)},c=()=>{for(;o!==r;)o+=Math.sign(r-o),e(a,o,h.floor)};i?(s(),c()):(c(),s())}}function Ct(e,t,n){let r=new Uint8Array(256),i=(e,t,n)=>r[t*16+e]=n,a=(e,t)=>r[t*16+e],o=Le(G(e,8,t,n)),s=Math.hypot(t,n),c=yt(e,t,n);for(let e of c)xt(i,e);let l=s<1?0:s<3?1:2;for(let e=1;e<c.length;e++)St(i,o,bt(c[e]),bt(c[e-1]),l);let u=[[[0,vt(e,1,t,n)],[1,0]],[[15,vt(e,1,t+1,n)],[-1,0]],[[vt(e,2,t,n),0],[0,1]],[[vt(e,2,t,n+1),15],[0,-1]]];for(let[[e,t],[n,r]]of u){i(e,t,h.floor),i(e+n,t+r,h.floor);let a=[e+n*2,t+r*2],s=c.map(bt).sort((e,t)=>Math.hypot(e[0]-a[0],e[1]-a[1])-Math.hypot(t[0]-a[0],t[1]-a[1]))[0];St(i,o,a,s,l)}if(s>=3)for(let e=0;e<Math.min(3,Math.floor(s/3));e++)St(i,o,bt(o.pick(c)),[o.int(1,14),o.int(1,14)],1);let d=new Uint8Array(256),f=[u[0][0]];for(d[u[0][0][1]*16+u[0][0][0]]=1;f.length;){let[e,t]=f.pop();for(let[n,r]of[[1,0],[-1,0],[0,1],[0,-1]]){let i=e+n,o=t+r;i<0||o<0||i>=16||o>=16||d[o*16+i]||a(i,o)!==h.floor||(d[o*16+i]=1,f.push([i,o]))}}for(let e=0;e<r.length;e++)r[e]===h.floor&&!d[e]&&(r[e]=h.wall);let p=Le(G(e,9,t,n)),m=Math.min(18,6+Math.round(s*1.5));for(let e=0;e<m;e++){let e=p.int(1,14),t=p.int(1,14);if(a(e,t)!==h.wall||![[1,0],[-1,0],[0,1],[0,-1]].some(([n,r])=>a(e+n,t+r)===h.floor))continue;let n=p.chance(Math.min(.25,s*.03))?3:p.int(0,2);i(e,t,h.vein+n)}return{cx:t,cy:n,cells:r,zone:dt(t,n)}}function wt(e){let t=[];for(let n=0;n<16;n++)for(let r=0;r<16;r++)e.cells[n*16+r]===h.floor&&t.push([r,n]);return t}function Tt(e,t,n,r,i=Ct(e,t,n)){let a=Le(G(e,13,t,n,r)),o=yt(e,t,n);for(let e=0;e<30;e++){let[e,r,s,c]=a.pick(o),l=a.int(e,s),u=a.int(r,c);if(i.cells[u*16+l]===h.floor)return[t*16+l+.5,n*16+u+.5]}let[s,c]=a.pick(wt(i));return[t*16+s+.5,n*16+c+.5]}b(Ct);function Et(e,t){let n={shot:!0,vx:t.vx,vy:t.vy,dmg:t.dmg,left:t.range,foe:t.foe,src:t.src?.id??0,type:t.src?.enemy?.type};return I(e,{kind:`prop`,x:t.x,y:t.y,data:n})}var Dt=e=>e.ents.filter(e=>e.kind===`prop`&&e.data?.shot),Ot=.45;function kt(e,t){for(let n of Dt(e)){let r=n.data,i=Math.hypot(r.vx,r.vy),a=Math.max(1,Math.ceil(i*t/.2)),o=!1;for(let s=0;s<a&&!o;s++)if(n.x+=r.vx*t/a,n.y+=r.vy*t/a,r.left-=i*t/a,!D(e,n.x,n.y)||r.left<=0)o=!0;else if(r.foe){if(Math.hypot(n.x-e.player.x,n.y-e.player.y)<Ot){let t=e.ents.find(e=>e.id===r.src)??{id:r.src,kind:`enemy`,x:n.x,y:n.y,enemy:{type:r.type??`seraph`,hp:0,readyAt:0,data:{}}};ce(e,r.dmg,t),o=!0}}else{let t=e.ents.find(e=>e.enemy&&Math.hypot(e.x-n.x,e.y-n.y)<Ot);t&&(ue(e,t,r.dmg),o=!0)}if(o&&(e.ents=e.ents.filter(e=>e!==n)),e.ended)return}}P.push(kt);function At(e,t){let n=t.item;t.kind=`enemy`;let r=ut[ft(t.x,t.y)].foe;t.enemy={type:`mimic`,hp:N.mimic.hp*r.hp,readyAt:e.t+.6,data:{noticed:!0,dressed:n,mult:r.damage}},delete t.item,t.data={...t.data,mimic:!1},e.events.push({type:`mimic`,at:[t.x,t.y]}),F(e,`the ${n?L(n):`thing`} on the floor opens a mouth. a mimic.`)}P.push(e=>{for(let t of e.ents)t.kind===`item`&&t.data?.mimic&&Math.hypot(t.x-e.player.x,t.y-e.player.y)<1.1&&At(e,t)});var jt=H.take.run;H.take.run=(e,t)=>{for(let t of ge(e))t.data?.mimic&&At(e,t);jt(e,t)};var Mt=new Set([`mite`,`seraph`,`pyre`,`saint`,`warden`,`mimic`,`hum`]),Nt=.35,Pt=2.5,Ft=e=>ut[ft(e.player.x,e.player.y)].look.dark>=.3,It=e=>ft(e.player.x,e.player.y)===3;function Lt(e,t){let n=o(t,`range`,8),r=o(t,`filter`,`color`);if(r===`heat`)return It(e)?n*Nt:n;if(r===`sonar`||r===`edge`||!Ft(e))return n;let i=Math.max(Pt,M(e)*1.5);return Math.min(n,r===`1bit`?i*2:i)}function Rt(e,t,n){let r=o(t,`filter`,`color`),i=n.enemy.type;return N[i]?.hidden&&r!==`sonar`&&r!==`heat`||r===`heat`&&!Mt.has(i)?!1:R(n,e.player)<=Lt(e,t)&&j(e,e.player.x,e.player.y,n.x,n.y)}function zt(e,t,n){let r=o(t,`sees`,[]),i=n.enemy.type;return R(n,e.player)>o(t,`range`,6)?!1:r.includes(`flesh`)?!0:r.includes(`heat`)?Mt.has(i):r.includes(`enemies`)&&!N[i]?.hidden}function Bt(e,t){return t.enemy?l(e,`camera`).some(n=>Rt(e,n,t))||l(e,`scanner`).some(n=>zt(e,n,t)):!1}function Vt(e,t){return t.enemy?N[t.enemy.type]?.hidden?Bt(e,t)||R(t,e.player)<=1.5&&e.t-(t.enemy.data.felt??-99)<1.5:R(t,e.player)<=1.5||Bt(e,t):!1}function Ht(e,t){let n=R(t,e.player);return l(e,`scanner`).some(e=>o(e,`sees`,[]).includes(`metal`)&&n<=o(e,`range`,6))||l(e,`camera`).some(t=>o(t,`filter`,``)===`sonar`&&n<=Lt(e,t))}P.push(e=>{for(let t of[...e.ents])t.kind===`item`&&t.data?.mimic&&Ht(e,t)&&(F(e,`something on the floor is not a thing. it knows you know.`),At(e,t))}),P.push(e=>{for(let t of l(e,`scanner`)){if(!o(t,`sees`,[]).includes(`doors`)||e.t<(t.data.dowsedAt??0))continue;t.data.dowsedAt=e.t+o(t,`refresh`,3);let n=Math.ceil(o(t,`range`,9)),r=Math.floor(e.player.x),i=Math.floor(e.player.y);for(let t=i-n;t<=i+n;t++)for(let a=r-n;a<=r+n;a++)Math.hypot(a-r,t-i)<=n&&w(e,a,t)===h.floor&&e.seen.add(`${a},${t}`)}});var Ut=e=>1+l(e,`body`).reduce((e,t)=>e+o(t,`haste`,0),0);i(`weapon`,{tick(e,t){if(o(t,`aim`,`auto`)!==`auto`)return;let n=t.data.readyAt??0;if(e.t<n)return;let r=o(t,`range`,1.3),i=e.player,a=e.ents.filter(t=>t.enemy&&R(t,i)<=r&&j(e,i.x,i.y,t.x,t.y)&&Vt(e,t)).sort((e,t)=>R(e,i)-R(t,i));if(a.length){t.data.readyAt=e.t+o(t,`cooldown`,1)/Ut(e);for(let n of o(t,`sweep`,!1)?a:a.slice(0,1))ue(e,n,o(t,`damage`,1))}}});var Wt=1.5,Gt=1.2,Kt=.5,qt=25*Math.PI/180,Jt=new WeakMap,Yt=e=>{let t=Jt.get(e);return t||Jt.set(e,t={manual:-99,hitBy:0,hitAt:-99,seenHit:-99,hold:-99,on:0}),t},Xt=e=>void(Yt(e).manual=e.t),Zt=(e,t)=>Math.atan2(t.x-e.player.x,-(t.y-e.player.y)),Qt=(e,t)=>{let n=Zt(e,t)-e.player.dir;return Math.abs(Math.atan2(Math.sin(n),Math.cos(n)))},$t=e=>l(e,`gait`).some(e=>o(e,`free`,!1));function en(e,t){let n=Yt(e);n.hold=e.t+Gt,n.on=t.id,!(Qt(e,t)<qt)&&(e.player.dir=Zt(e,t),e.events.push({type:`snap`,data:t.id}))}var tn=H.face;if(tn){let e=tn.run;tn.run=(t,n)=>{Xt(t),e(t,n)}}le.push((e,t,n)=>(t>0&&n?.enemy&&Object.assign(Yt(e),{hitBy:n.id,hitAt:e.t}),t)),P.push(e=>{let t=e.player;if(e.ended||$t(e))return;let n=Yt(e),r=e.t-n.manual>=Wt;if(r&&t.path.length===1){let r=e.ents.filter(e=>e.enemy?.data.noticed&&!N[e.enemy.type]?.hidden&&R(e,t)<=2.5).sort((e,n)=>R(e,t)-R(n,t))[0];r&&Object.assign(n,{on:r.id,hold:Math.max(n.hold,e.t+.5)})}let i=r&&e.t<n.hold&&e.ents.find(e=>e.id===n.on&&e.enemy);if(i&&R(i,t)<=4&&(t.dir=Zt(e,i),t.faceLock=e.t+.1,t.path.length&&(n.hold=Math.max(n.hold,e.t+Kt))),n.hitAt>n.seenHit&&(!r||e.t-n.hitAt>.5)&&(n.seenHit=n.hitAt),!r)return;if(n.hitAt>n.seenHit){n.seenHit=n.hitAt;let t=e.ents.find(e=>e.id===n.hitBy&&e.enemy);if(t)return en(e,t)}let a=e.ents.filter(n=>n.enemy&&!n.enemy.data.eyed&&n.enemy.data.noticed&&!N[n.enemy.type]?.hidden&&R(n,t)<=3&&j(e,t.x,t.y,n.x,n.y)).sort((e,n)=>R(e,t)-R(n,t));for(let e of a)e.enemy.data.eyed=!0;a.length&&en(e,a[0])});var nn=e=>l(e,`weapon`).filter(e=>o(e,`aim`,`auto`)===`aimed`),rn=t.weapon,an=rn.buttons;rn.buttons=(e,t)=>o(t,`aim`,`auto`)===`aimed`?[{label:`shoot`,cmd:`shoot`}]:an?.(e,t)??[];var on=25*Math.PI/180;function sn(e,t){let n=e.player;return e.ents.filter(r=>r.enemy&&R(r,n)<=t&&Vt(e,r)&&j(e,n.x,n.y,r.x,r.y)).sort((e,t)=>R(e,n)-R(t,n))}function cn(e,t){let n=sn(e,t);return!n.length||n.some(t=>Qt(e,t)<on)?!1:(e.player.dir=Zt(e,n[0]),Xt(e),!0)}function ln(e){let t=[];for(let n of new Set(nn(e).map(e=>e.mod))){let r=nn(e).find(t=>t.mod===n&&e.t>=(t.data.readyAt??0));r&&t.push(r)}return t}function un(e,t){let n=nn(e).filter(e=>e.mod===t.mod).length;return o(t,`cooldown`,1)*.75**(n-1)/Ut(e)}U(`shoot`,{help:`fire your aimed weapons where you face (turns to a foe in reach first)`,when:e=>nn(e).length>0,run(e){let t=e.player,n=ln(e);if(!n.length){let t=nn(e).sort((e,t)=>(e.data.readyAt??0)-(t.data.readyAt??0))[0];return F(e,`${a(t).name}: still cooling.`)}l(e,`gait`).some(e=>o(e,`free`,!1))||cn(e,Math.max(...n.map(e=>o(e,`range`,6))));let r=Math.sin(t.dir),i=-Math.cos(t.dir);for(let a of n){let n=e.t+un(e,a);for(let t of nn(e).filter(e=>e.mod===a.mod))t.data.readyAt=n;Et(e,{x:t.x+r*.3,y:t.y+i*.3,vx:r*12,vy:i*12,dmg:o(a,`damage`,1),range:o(a,`range`,6),src:null,foe:!1}),e.events.push({type:`shoot`,data:a.uid})}}});var dn=.5,fn=e=>l(e,`body`);function pn(e){let t=e.player;return e.ents.some(n=>{let r=n.enemy?.data;return r?r.elite&&e.t-(r.hitAt??-99)<10?!0:!!r.noticed&&!N[n.enemy.type]?.hidden&&R(n,t)<=6&&j(e,t.x,t.y,n.x,n.y):!1})}var mn=(e,t)=>fn(e).reduce((e,n)=>e+o(n,t,0),0);function hn(e,t){let n=e.player;n.maxHp=10+(n.flesh??0)+mn(e,`hp`),n.hp>n.maxHp&&(n.hp=n.maxHp);let r=ft(n.x,n.y),i=(r===2||r!==3&&mn(e,`chill`)>0)&&!M(e)?mn(e,`regen`)/2:dn+mn(e,`regen`);if(e.t-n.hurtAt>=6&&n.hp<n.maxHp&&!pn(e)&&(n.hp=Math.min(n.maxHp,n.hp+i*t)),r===3){let r=mt*Math.max(0,1-mn(e,`heatproof`))*t;r>0&&(n.hp-r<=0?(F(e,`the furnace burns you down.`),ce(e,n.hp+1)):n.hp-=r)}for(let t of fn(e)){let r=o(t,`mend`,0);!r||n.hp>=n.maxHp/2||e.t<(t.data.mendAt??0)||(t.data.mendAt=e.t+o(t,`recharge`,20),n.hp=Math.min(n.maxHp,n.hp+r),F(e,`the suture moth stitches you: +${r} hp.`))}}P.push(hn);var gn=(e,t)=>e.t>=(t.data.wardAt??0);le.unshift((e,t,n)=>t*((n&&(e.ents.find(e=>e.id===n.id)??n))?.enemy?.data.mult??1)),le.push((e,t,n)=>{if(t<=0)return t;let r=fn(e).find(t=>o(t,`ward`,!1)&&gn(e,t));if(!r)return t;r.data.wardAt=e.t+o(r,`recharge`,8);let i=n&&e.ents.find(e=>e===n||e.id===n.id);return F(e,i?.enemy?`the mirror ward throws the hit back at ${N[i.enemy.type]?.name??`it`}.`:`the mirror ward drinks the hit.`),i?.enemy&&ue(e,i,t),0}),le.push((e,t)=>t>0?Math.max(t>.5?.25:0,t-mn(e,`armour`)):t),le.push((e,t,n)=>{let r=mn(e,`thorns`),i=n&&e.ents.find(e=>e.id===n.id);return r>0&&t>0&&i?.enemy&&R(i,e.player)<=1.7&&ue(e,i,r),t}),i(`body`,{status:(e,t)=>o(t,`ward`,!1)?[[gn(e,t)?`ward: ready`:`ward: recharging`]]:[]});var _n=7.5;function vn(e,t,n=[]){let r=[];for(let e=0;e<t.cells.length;e++){let i=e%16,a=e/16|0,o=Math.hypot(t.cx*16+i+.5-8.5,t.cy*16+a+.5-8.5)<_n,s=t.cx*16+i+.5,c=t.cy*16+a+.5,l=n.some(e=>Math.hypot(e.x-s,e.y-c)<6);t.cells[e]===h.floor&&i>1&&a>1&&i<14&&a<14&&!o&&!l&&r.push(e)}if(!r.length)return null;let i=e.pick(r);return[t.cx*16+i%16+.5,t.cy*16+(i/16|0)+.5]}function yn(e){if(e===0)return[[`mite`,1,2]];let t=pt(e);return t===0?[[`mite`,.85,2],[`mite`,.35,2],[`seraph`,.25,1]]:t===1?e<2.5?[[`mite`,.8,2],[`mite`,.15,2],[`seraph`,.2,1],[`mimic`,.1,1]]:[[`mite`,.8,3],[`mite`,.35,3],[`seraph`,.3,1],[`mimic`,.1,1]]:t===2?[[`mite`,.55,3],[`walker`,.5,1],[`seraph`,.3,1],[`hum`,.3,1],[`mimic`,.15,1]]:[[`mite`,.65,4],[`mite`,.3,3],[`walker`,.55,1],[`pyre`,.4,1],[`hum`,.25,2],[`mimic`,.3,1]]}function bn(e,t,n,r){let i=se(e,t,n,r),a=ft(n,r),o=ut[a].foe;return t===`mite`&&a<=1||(i.enemy.hp=Math.round(i.enemy.hp*o.hp*10)/10),i.enemy.data.mult=o.damage,i}function xn(e,t){let[n,r]=zr(e.seed).engine;if(t.cx===n&&t.cy===r)return;let i=Le(G(e.seed,23,t.cx,t.cy)),a=Math.hypot(t.cx,t.cy);for(let[n,r,o]of yn(a)){if(!i.chance(r))continue;let s=vn(i,t,e.ents.filter(e=>e.enemy?.data.elite));if(s)for(let t=0;t<o;t++){let[r,c]=[s[0]+(t-(o-1)/2)*.3,s[1]];n===`mimic`?I(e,{kind:`item`,x:r,y:c,item:ii(i,a),data:{mimic:!0}}):bn(e,n,r,c)}}}x(xn);var Sn={mite:[`bone`,1,.12],seraph:[`glass`,2,.25],walker:[`bone`,3,.35],hum:[`ichor`,1,.4],mimic:[`copper`,2,0],pyre:[`glass`,2,.3],warden:[`copper`,3,1],abbot:[`bone`,5,1],saint:[`ichor`,2,1]};de.push((e,t)=>{let n=t.enemy.type,r=Le(G(e.seed,31,t.id)),i=(n,r)=>I(e,{kind:`item`,x:t.x+(r?.3:0),y:t.y,item:n}),[a,s,c]=Sn[n]??[`bone`,1,0],u=l(e,`mind`).reduce((e,t)=>Math.max(e,o(t,`tithe`,1)),1);r.chance(Math.min(1,.35*u))&&i({kind:`res`,res:a,n:s},0);let d=t.enemy.data.dressed;d?i(d,1):r.chance(c)&&i(ii(r,Math.hypot(t.x,t.y)/16),1)});var Cn={mite:`the mite bursts.`,seraph:`the seraph lamp gutters out.`,pyre:`the pyre seraph burns down to a wick.`,walker:`the ossuary walker folds into its bones.`,abbot:`the bone abbot kneels, and comes apart.`,warden:`the choir warden falls silent.`,saint:`the furnace saint goes out.`,hum:`the hum goes quiet.`,mimic:`the mimic splits. it was never a module.`},wn=new WeakMap,Tn=e=>(N[e]?.name??`it`).replace(/^(a|an|the) /,``),En=(e,t)=>e.set(t,(e.get(t)??0)+1),Dn=e=>e>1?` ×${e}`:``;function On(e){let t=wn.get(e);return(!t||!t.hit.size&&!t.took.size)&&wn.set(e,t={start:e.t,hit:new Map,took:new Map}),t}function kn(e){let t=wn.get(e);if(!t||!t.hit.size&&!t.took.size)return;let n=[...[...t.hit].map(([e,t])=>`you hit ${e}${Dn(t)}`),...[...t.took].map(([e,t])=>`${e} hits you${Dn(t)}`)];t.took.size&&n.push(`hp ${An(e.player.hp)}/${e.player.maxHp}`),wn.delete(e),F(e,n.join(` · `)+`.`)}P.push(e=>{let t=new Set(e.events.filter(e=>e.type===`kill`).map(e=>e.at.join()));for(let n of e.events)if(n.type===`kill`)kn(e),F(e,Cn[n.data]??`it stops.`);else if(n.type===`hit`&&!t.has(n.at.join())){let t=e.ents.find(e=>e.id===n.data);t?.enemy&&En(On(e).hit,Tn(t.enemy.type))}let n=wn.get(e);n&&e.t-n.start>=1.2&&kn(e)}),le.push((e,t,n)=>(t<=0||(En(On(e).took,n?.enemy?Tn(n.enemy.type):`something`),e.player.hp-t<=0&&(e.player.hp-=t,kn(e),e.player.hp+=t)),t));var An=e=>String(Math.max(0,Math.ceil(e*2)/2)),jn=2.5,Mn=(e,t)=>{let n=(Math.atan2(t.x-e.player.x,-(t.y-e.player.y))*180/Math.PI+360)%360;return[`n`,`ne`,`e`,`se`,`s`,`sw`,`w`,`nw`][Math.round(n/45)%8]};function Nn(e,t,n){let r=e.player,i=[`⚠ ${t}, ${Math.round(R(n,r))} cells ${Mn(e,n)}. `];i.push(Ze(e).battle?{text:`setup battle`,cmd:`setup battle`}:{text:`setup`,cmd:`setup`}),F(e,i),e.events.push({type:`warn`,at:[n.x,n.y]})}var Pn=new WeakMap;function Fn(e,t){let n=t.enemy.data,r=N[t.enemy.type],i=+(r.damage*(n.mult??1)).toFixed(1),a=Math.ceil(t.enemy.hp),s=l(e,`weapon`).length>0,c=`${r.name} turns to you. it hits ${i}, it has ${a} hp`,u=l(e,`weapon`).reduce((e,t)=>e+o(t,`damage`,0)/Math.max(.1,o(t,`cooldown`,1)),0),d=s&&u*8<a,f=[`⚠ ${c}.${s?d?` your weapon may be too weak. `:` `:` you have no weapon on! `}`];f.push(Ze(e).battle?{text:`setup battle`,cmd:`setup battle`}:{text:`unstuck`,cmd:`unstuck`}),F(e,f),Pn.set(e,{text:s?c:`${c} · no weapon on`,at:e.t}),e.events.push({type:`warn`,at:[t.x,t.y]})}P.push(e=>{let t=e.player;if(e.ended)return;for(let n of e.ents){let r=n.enemy?.data;r?.elite&&(r.noticed?!r.turned&&R(n,t)<=10&&e.t>=(r.turnedAt??-99)+20&&(r.turned=!0,r.turnedAt=e.t,Fn(e,n)):r.turned=!1)}let n=e.ents.filter(e=>e.enemy&&!e.enemy.data.noticed&&!N[e.enemy.type]?.hidden&&R(e,t)<=12);for(let t of n){let r=t.enemy.data;if(r.warned)continue;if(r.elite){r.warned=!0,Nn(e,`${N[t.enemy.type].name} waits ahead`,t);continue}let i=n.filter(e=>!e.enemy.data.elite&&R(e,t)<jn);if(i.length<4)continue;for(let e of i)e.enemy.data.warned=!0;let a=new Set(i.map(e=>e.enemy.type));Nn(e,`${a.size===1&&a.has(`mite`)?`a swarm of ${i.length} mites`:`a pack of ${i.length}`} ahead`,t)}});var In=[{id:`log-surveyor`,lines:[`unit 7, surveyor. descent day 3.`,`the walls are warm here. they flex.`,`i logged a heartbeat. one. it took an hour.`,`i left a cache ahead. go and see.`]},{id:`log-cantor`,lines:[`this is cantor. my lamp drew them.`,`they sing when they come. three voices.`,`i am turning the lamp off now.`,`i will sit in the dark and listen.`]},{id:`log-ferry`,lines:[`ferry-12 to anyone.`,`i carried glass for the printers.`,`the printers ate it and gave me eyes.`,`more of them lie the way i point.`]},{id:`log-abbot`,lines:[`the abbot machine, last entry.`,`we were sent to wake it. we failed.`,`the engine is not lost. it is waiting.`,`the scripture knows. i only half do.`]},{id:`log-leech`,lines:[`drill-4. veins run copper here.`,`every time i bleed one, something hears.`,`i stopped counting what hears.`,`the rich seam is where i point.`]},{id:`log-blind`,lines:[`i lost my eye in the ribbed hall.`,`i mapped the rest by touch.`,`the map is good. the map is all i have.`,`take it. it is where this points.`]},{id:`log-pilgrim`,lines:[`pilgrim, of the second descent.`,`we walked toward the cold for weeks.`,`the cold is the heart. it is not dead.`,`it is only very, very still.`]},{id:`log-twin`,lines:[`my twin went deeper. i stayed.`,`his signal stopped at the oval rooms.`,`if you find his shell, he had a printer.`,`it was still warm. it is that way.`]},{id:`log-choir`,lines:[`the mites are not animals.`,`they are the body cleaning itself.`,`we are the dirt it cleans.`,`move fast. stay quiet. read everything.`]},{id:`log-tally`,lines:[`tally: four slots. six power.`,`not enough. never enough.`,`a printer gave me a fifth.`,`there is another one. it is yours.`]},{id:`log-ninth`,lines:[`there is an eye down here, the ninth.`,`eight were made for the god. one stayed.`,`it sees farther than any lens.`,`i saw where it lies. i could not reach.`]},{id:`log-last`,lines:[`nobody reads these. i write anyway.`,`i was warm once. we all were.`,`if you are reading: you are not alone.`,`you are only the last. go on.`]}],Ln=[In[0],{id:`log-lamplighter`,lines:[`lamplighter, ninth of the choir.`,`i lit the nave for the last mass.`,`the dark came in anyway, singing.`,`my lamps still burn ahead. go and see.`]},{id:`log-mason`,lines:[`mason unit. i was mending a rib.`,`the rib mended me instead. it is warm.`,`some walls here are only shells.`,`i hid my tools ahead. go and see.`]},{id:`log-cartographer`,lines:[`cartographer, first descent.`,`the halls move when no one looks.`,`so i looked. i never stopped looking.`,`my last mark is ahead. go and see.`]}],Rn=[{id:`shard-1`,shard:1,lines:[`THE FIRST SHARD.`,`in the beginning the god was warm,`,`and the warmth went out of the god,`,`and the engine of thaw was set aside.`,`reckon its distance from your waking:`]},{id:`shard-2`,shard:2,lines:[`THE SECOND SHARD.`,`and the machines came down to the cold,`,`and the cold took them one by one,`,`yet the engine kept its bearing.`,`turn your face toward it:`]},{id:`shard-3`,shard:3,lines:[`THE THIRD SHARD.`,`whoso holds the three holds the way.`,`set the engine in thy breast,`,`and the heart shall beat, and be warm.`,`go now. the way is whole:`]}],zn=Object.fromEntries([...In,...Ln,...Rn].map(e=>[e.id,e])),Bn=e=>Rn.filter(t=>e.cards.includes(t.id)||e.player.inv.some(e=>e.kind===`card`&&e.card===t.id)).length,Vn=new WeakMap,Hn=[`the engine's distance from where you woke`,`the engine's bearing`,`the whole way to the thaw engine`];P.push(e=>{let t=Bn(e);if(t<=(Vn.get(e)?.n??0))return;Vn.set(e,{n:t,t:e.t}),e.events.push({type:`shard`,data:t});let n=l(e,`mind`).some(e=>o(e,`what`,``)===`reader`);F(e,`SCRIPTURE SHARD ${t} of 3.`,[`it opens ${Hn[t-1]}. `,n?{text:`read card`,cmd:`read card`}:`a card reader reads it.`])});var Un=1.2,Wn=.35,Gn=6.5,Kn=e=>Math.max(0,Math.min(1,e)),qn=e=>e*e*(3-2*e);function Jn(e){return qn(Kn(e/4))}function Yn(e,t){return Kn((e-Un-t*Wn)/3)}function Xn(e){let t=.7+.9*Jn(e);return Math.max(0,Math.sin(e*t*Math.PI*2))**6}function Zn(e){return e>=Gn}function Qn(e){let t=Math.max(0,Math.round(e));return`${Math.floor(t/60)}:${String(t%60).padStart(2,`0`)}`}function $n(e){let t=e.stats,n=(e,t)=>`${e} ${t}${e===1?``:`s`}`;return`${n(t.far,`cell`)} out · ${n(t.mods.length,`module`)} found · ${t.kills} put down · ${Qn(e.t)}`}var er=[[100,`spring`],[40,`the god stirs`],[0,`a cold waking`]],tr=e=>er.find(([t])=>e>=t)[1];function nr(e){let t=Re.map(t=>[t,e.player.inv.reduce((e,n)=>e+(n.kind===`res`&&n.res===t?n.n:0),0)]).filter(([,e])=>e>0),n=t.reduce((e,[,t])=>e+t,0);return{lines:t,total:n,grade:tr(n)}}var rr=new WeakMap;function ir(e){let t=nr(e);return e.player.inv=e.player.inv.filter(e=>e.kind!==`res`),rr.set(e,t),t}var ar=e=>rr.get(e),or=.8,sr=.45;function cr(e,t){return Math.max(0,Math.min(t+1,Math.floor((e-Gn-or)/sr+1e-6)+1))}var lr=new WeakMap,ur=e=>lr.get(e)??[];le.push((e,t,n)=>{if(t<=0)return t;let r=lr.get(e);r||lr.set(e,r=[]);let i=!n&&ft(e.player.x,e.player.y)===3,a=n?.enemy?.type??(i?`heat`:`something`),o=n?.enemy?N[a]?.name??`something`:i?`the furnace's heat`:`something`,s=n&&e.ents.find(e=>e.id===n.id);return r.push({type:a,name:o,n:t,t:e.t,seen:!!s&&Bt(e,s),id:n?.id}),r.length>40&&r.shift(),t});function dr(e){let t=ur(e).slice(-3),n=t[t.length-1];if(!n)return`mend before the next fight.`;let r=e.player.installed.filter(e=>a(e).family===`weapon`);if(r.length&&!r.some(e=>e.on))return`your ${a(r[0]).name} was off: no weapon on. switch it on before the next fight.`;let i=new Set(t.map(e=>e.type)),o=ut[ft(e.player.x,e.player.y)].look.dark>=.3&&M(e)<=0;return n.type===`heat`?`a rime hood, or anything heatproof, keeps the furnace off.`:Pr.includes(n.type)?`a stronger weapon or a heal first; and ${{warden:`step aside when it draws breath`,abbot:`two cells back when it raises both arms`,saint:`come at it on a diagonal, off its lines`}[n.type]}.`:n.type===`hum`?`sonar, a heat eye or a bone-listener shows the hum; colour eyes never do.`:n.type===`mimic`?`a lodestone or sonar shows a mimic before you reach for it.`:o&&!n.seen?`light or sonar: you could not see what hit you.`:t.filter(e=>e.type===`mite`).length>=2?`something that hits many (a censer flail, a bell), or walk back the way you came: mites are slower than you.`:i.size>1?`something that hits many (a bell, a flail), or back off so they come at you one by one.`:n.type===`seraph`||n.type===`pyre`?`step out of its line: a lamp only fires down its row or column.`:n.type===`walker`?`step back when it lifts its arm.`:n.seen?`mend to full before the next fight, or fight from range.`:`an eye on the threat: turn to what hits you, or carry a scanner.`}var fr=.12;function pr(e){let t=[];for(let n of e){let e=t[t.length-1];e&&e.type===n.type&&n.t-e.t<=fr?Object.assign(e,{n:e.n+n.n,count:e.count+1,seen:e.seen||n.seen}):t.push({type:n.type,name:n.name,n:n.n,t:n.t,seen:n.seen,count:1})}return t}function mr(e){let t=ur(e),n=pr(t).slice(-3),r=n[n.length-1],i=e=>e.name.replace(/^(a|an|the) /,``);return{killer:r?`${r.name} took you`:`something took you`,blows:n.map(e=>`${e.count>1?`${e.count} ${i(e)}s at once`:i(e)} −${e.n.toFixed(1)} hp at ${Qn(e.t)}${e.seen?``:` (unseen)`}`),lesson:dr(e),killerId:t[t.length-1]?.id}}var hr=(e,t)=>Math.hypot(e.x-t.x,e.y-t.y),gr={seraph:2.2,pyre:3.6,saint:4};function _r(e,t){let n=N[t.enemy.type],r=e.player,i=r.x-t.x,a=r.y-t.y;if(!(Math.abs(i)<.6||Math.abs(a)<.6)||hr(t,r)>n.sense||!j(e,t.x,t.y,r.x,r.y)||e.t<t.enemy.readyAt)return;t.enemy.readyAt=e.t+n.cooldown;let[o,s]=Math.abs(i)>Math.abs(a)?[Math.sign(i),0]:[0,Math.sign(a)];t.enemy.data.noticed||(t.enemy.data.noticed=!0,F(e,`a seraph lamp turns its light on you.`));let c=gr[t.enemy.type]??2.2;Et(e,{x:t.x,y:t.y,vx:o*c,vy:s*c,dmg:n.damage,range:n.sense+2,src:t,foe:!0})}function vr(e,t,n){let r=e.player,i=t.enemy;return i.data.windup?(e.t<i.data.windup||(i.data.windup=0,i.data.move=``,i.data.wide=!1,i.readyAt=e.t+N[i.type].cooldown,hr(t,r)<=n.reach+.2?ce(e,N[i.type].damage*(n.hit??1),t):n.opens?br(e,t,n.miss):F(e,n.miss)),!0):hr(t,r)>n.reach||e.t<i.readyAt?!1:(i.data.windup=e.t+n.windup,i.data.windAt=e.t,i.data.move=n.move,i.data.wide=n.reach>2,F(e,n.say),!0)}var yr={secs:2,mult:1.5};function br(e,t,n){t.enemy.data.open=e.t+yr.secs,F(e,`${n} it is open: hit it now.`)}function xr(e,t,n){vr(e,t,{windup:.8,reach:1.5,say:`the ossuary walker lifts its arm.`,move:`walker lifts its arm`,miss:`its arm comes down on nothing.`})||hr(t,e.player)>1.1&&pe(e,t,n)}var Sr=.5;function Cr(e,t,n){let r=t.enemy,i=(r.data.blows??0)%3==2?{windup:1.2,reach:2.3,say:`⚠ the bone abbot raises both arms. it will sweep: get two cells away.`,move:`abbot raises both arms`,miss:`the sweep cuts the air.`,hit:Sr,opens:!0}:{windup:.8,reach:ae,say:`the bone abbot lifts its arm.`,move:`abbot lifts its arm`,miss:`its arm comes down on nothing.`},a=r.data.windup;vr(e,t,i)?a&&!r.data.windup&&(r.data.blows=(r.data.blows??0)+1):hr(t,e.player)>1.1&&pe(e,t,n)}var wr=.3,Tr=.3,Er=.4,Dr=(e,t)=>G(e.id,Number(e.enemy.data.bites??0),t)/2**32;function Or(e,t,n){let r=t.enemy,i=e.player;if(r.data.windup){if(e.t<r.data.windup)return;r.data.windup=0,r.data.move=``,r.data.bites=Number(r.data.bites??0)+1,r.readyAt=e.t+N[r.type].cooldown+(Dr(t,2)*2-1)*Er,hr(t,i)<=1.7&&ce(e,N[r.type].damage,t);return}let a=r.readyAt;r.readyAt=1/0,pe(e,t,n),r.readyAt=a,r.data.noticed&&hr(t,i)<=1.5&&e.t>=a&&(r.data.windup=e.t+wr+Dr(t,1)*(Tr+(r.data.bites?0:Er)),r.data.move=`mite rears`)}var kr={windup:1,cells:3.5,speed:9,cooldown:8,stun:1.5,hit:1,min:1.2,back:2};function Ar(e,t,n){let r=t.enemy,i=e.player,a=r.data;if(e.t<(a.stun??0))return;if(a.windup){let r=a.back??0;if(r>0&&a.dash){let[i,o]=a.dash,s=Math.min(r,kr.back*2*n),[c,l]=[t.x-i*s,t.y-o*s];D(e,c-i*.3,l-o*.3)&&([t.x,t.y]=[c,l]),a.back=r-s,a.backed=(a.backed??0)+s}if(e.t<a.windup)return;a.windup=0,a.move=``,a.left=kr.cells+(a.backed??0),a.back=0,a.backed=0;return}if(a.dash){let[o,s]=a.dash,c=kr.speed*n,l=t.x+o*c,u=t.y+s*c;a.left-=c;let d=!D(e,l+o*.3,u+s*.3);d||([t.x,t.y]=[l,u]),hr(t,i)<.75?(a.dash=null,r.readyAt=e.t+N[r.type].cooldown,ce(e,N[r.type].damage*kr.hit,t)):(d||a.left<=0)&&(a.dash=null,a.stun=e.t+kr.stun,F(e,`the warden's rush misses. it reels: hit it now.`));return}pe(e,t,n);let o=a.post,s=o&&Math.hypot(i.x-o[0],i.y-o[1])>7,c=hr(t,i);if(!a.noticed||s||c<kr.min||c>4.5||e.t<(a.dashAt??0)||!j(e,t.x,t.y,i.x,i.y))return;a.dashAt=e.t+kr.cooldown;let[l,u]=[(i.x-t.x)/c,(i.y-t.y)/c];a.dash=[l,u];let[d,f]=Math.abs(l)>Math.abs(u)?[0,1]:[1,0],p=!D(e,t.x+d,t.y+f)&&!D(e,t.x-d,t.y-f);a.back=p?kr.back:0,a.windup=e.t+kr.windup+(p?.5:0),a.windAt=e.t,a.move=`warden draws breath`,F(e,p?`⚠ the choir warden backs off and draws breath. no room to step aside: get round a corner.`:`⚠ the choir warden draws breath. step aside.`)}var jr={windup:1,cooldown:7,speed:4,hit:.5,near:5};function Mr(e,t,n){let r=t.enemy,i=e.player,a=r.data;if(a.windup){if(e.t<a.windup)return;a.windup=0,a.move=``;let n=N[r.type].damage*jr.hit;for(let[i,a]of[[1,0],[-1,0],[0,1],[0,-1]])Et(e,{x:t.x,y:t.y,vx:i*jr.speed,vy:a*jr.speed,dmg:n,range:N[r.type].sense+2,src:t,foe:!0});r.readyAt=e.t+N[r.type].cooldown,Math.abs(i.x-t.x)>=.6&&Math.abs(i.y-t.y)>=.6&&br(e,t,`the cross burns past you.`)}else hr(t,i)<=jr.near&&e.t>=(a.crossAt??0)&&j(e,t.x,t.y,i.x,i.y)?(a.crossAt=e.t+jr.cooldown,a.windup=e.t+jr.windup,a.windAt=e.t,a.move=`saint gathers a cross`,F(e,`⚠ the furnace saint gathers its light into a cross. get off its lines.`)):_r(e,t)}function Nr(e,t,n){let r=e.player;if(ft(r.x,r.y)<2){t.enemy.data.noticed=!1;let i=hr(t,r);if(i<3&&i>.01){let a=N.hum.speed*n,[o,s]=[t.x-(r.x-t.x)/i*a,t.y-(r.y-t.y)/i*a];D(e,o,s)&&([t.x,t.y]=[o,s])}}else pe(e,t,n)}ie(`mite`,{name:`a choir mite`,hp:1,speed:2,damage:.5,cooldown:1.8,sense:6,ai:Or}),ie(`seraph`,{name:`a seraph lamp`,hp:3,speed:0,damage:1.5,cooldown:3.5,sense:8,ai:_r}),ie(`walker`,{name:`an ossuary walker`,hp:5,speed:.7,damage:2,cooldown:2.5,sense:7,ai:xr,armour:1.2}),ie(`hum`,{name:`the hum`,hp:4,speed:1.1,damage:1,cooldown:2,sense:5,hidden:!0,ai:Nr}),ie(`mimic`,{name:`a mimic`,hp:3,speed:1.4,damage:1.5,cooldown:1.6,sense:8}),ie(`pyre`,{name:`a pyre seraph`,hp:3,speed:0,damage:1.5,cooldown:2.4,sense:9,ai:_r}),ie(`warden`,{name:`the choir warden`,hp:10,speed:1.7,damage:1.5,cooldown:1.3,sense:7,ai:Ar}),ie(`abbot`,{name:`the bone abbot`,hp:18,speed:.8,damage:4,cooldown:2.2,sense:8,ai:Cr,armour:1.2}),ie(`saint`,{name:`the furnace saint`,hp:28,speed:0,damage:3.5,cooldown:1.8,sense:10,ai:Mr});var Pr=[``,`warden`,`abbot`,`saint`],Fr={warden:`the choir warden keeps it. it draws breath, then rushes: step aside.`,abbot:`the bone abbot keeps it. bone shrugs off small hits; it sweeps two cells round.`,saint:`the furnace saint keeps it. it burns down its lines, and crosses all four at once: come at it on a diagonal.`};P.push(e=>{let t=e.player;for(let n of e.ents){let r=n.enemy?.data,i=r?.post;if(!r?.elite||!i)continue;let a=Number(r.maxHp??n.enemy.hp),o=Math.hypot(n.x-i[0],n.y-i[1])<.3,s=Math.hypot(t.x-i[0],t.y-i[1])>7,c=e.t-(r.hitAt??-99)>3;Math.hypot(t.x-i[0],t.y-i[1])>16&&(r.warned=!1),o&&s&&c&&(n.enemy.hp>=a||(n.enemy.hp=a,F(e,`${N[n.enemy.type].name} settles at its post, whole again.`)))}});var Ir=new WeakMap;P.push(e=>{let t=e.player;if(e.ended||t.hurtAt!==e.t||t.path.length<2)return;let[n,r]=t.path[t.path.length-1],[i,a]=[n-t.x,r-t.y],o=Math.abs(i)>Math.abs(a)?i>0?`w`:`e`:a>0?`n`:`s`;t.path=[[Math.floor(t.x)+.5,Math.floor(t.y)+.5]],!(e.t-(Ir.get(e)??-99)<3)&&(Ir.set(e,e.t),F(e,[`${e.ents.find(e=>e.enemy&&Math.hypot(e.x-t.x,e.y-t.y)<=1.8)?.enemy?.type===`mite`?`bitten`:`struck`}. you stop. `,{text:`go ${o} 3`,cmd:`go ${o} 3`},` back the way you came`]))});var Lr=new Map,Rr=[2.5,4.1,5.8];function zr(e){let t=Lr.get(e);if(t)return t;let n=Le(G(e,21)),r=n()*Math.PI*2,i=(e,t)=>[Math.round(Math.sin(t)*e),Math.round(-Math.cos(t)*e)],a=(e,t,n)=>{for(let r of[t,t-.4,t+.4,t-.8,t+.8]){let t=i(r,n);if(dt(t[0],t[1])===e)return t}return i(t,n)},o=r+2.1+n()*.6,s=r+4.2+n()*.6,c=a(3,Rr[2],s),l=i(Rr[2]+1.7,s);for(let e of[1.7,2.1,2.5,3.1].map(e=>Rr[2]+e))if(l=i(e,s),l[0]!==c[0]||l[1]!==c[1])break;return t={shards:[a(1,Rr[0],r),a(2,Rr[1],o),c],engine:l},Lr.set(e,t),t}var Br=new WeakMap,Vr=e=>{let t=Br.get(e);return t||Br.set(e,t={spawned:0,pointed:[],ninth:!1}),t};function Hr(e){let t=Vr(e).spawned++;return t===0?Le(G(e.seed,67)).pick(Ln).id:In[t%In.length].id}function Ur(e,t,n){let r=e.player,i=Math.round((Math.atan2(t-r.x,-(n-r.y))*180/Math.PI+360)%360),a=[`n`,`ne`,`e`,`se`,`s`,`sw`,`w`,`nw`][Math.round(i/45)%8];return`${Math.round(R(r,{x:t,y:n}))} cells, bearing ${i} (${a})`}var Wr=(e,t)=>[Math.floor(e/16),Math.floor(t/16)];function Gr(e,t){let[n,r]=Wr(t.x,t.y);e.chunks.has(`${n},${r}`)&&Kr(e,t)}function Kr(e,t){let n=Math.hypot(...Wr(t.x,t.y));if(t.what===`printer`)I(e,{kind:`printer`,x:t.x,y:t.y,data:{far:n,made:0}});else if(t.what===`ninth eye`)I(e,{kind:`item`,x:t.x,y:t.y,item:{kind:`mod`,mod:`ninth-eye`}});else if(t.what===`cache`){let r=Le(G(e.seed,31,t.x,t.y));I(e,{kind:`item`,x:t.x,y:t.y,item:ii(r,n+2)}),I(e,{kind:`item`,x:t.x,y:t.y,item:{kind:`res`,res:r.pick([`bone`,`glass`,`copper`]),n:r.int(3,5)}}),I(e,{kind:`item`,x:t.x,y:t.y,item:{kind:`res`,res:`ichor`,n:1}})}}x((e,t)=>{let n=zr(e.seed);if(n.shards.forEach(([n,r],i)=>{if(t.cx!==n||t.cy!==r)return;let[a,o]=Tt(e.seed,n,r,1,t);I(e,{kind:`item`,x:a,y:o,item:{kind:`card`,card:Rn[i].id}}),I(e,{kind:`item`,x:a,y:o,item:{kind:`res`,res:`ichor`,n:1}}),qr(e,a,o,Pr[Math.max(1,Math.min(3,ft(a,o)))])}),t.cx===n.engine[0]&&t.cy===n.engine[1]){let[n,r]=Tt(e.seed,t.cx,t.cy,2,t);I(e,{kind:`item`,x:n,y:r,item:{kind:`mod`,mod:`thaw-engine`}});let i=(i,a,o=0)=>{let[s,c]=a?Tt(e.seed,t.cx,t.cy,a,t):[n+1,r],l=bn(e,i,(D(e,s,c)?s:n)+o,D(e,s,c)?c:r);l.enemy.data.post=[l.x,l.y]};i(`walker`,0);for(let e of[-.45,-.15,.15,.45])i(`mite`,6,e)}for(let n of e.vectors){let[r,i]=Wr(n.x,n.y);r===t.cx&&i===t.cy&&n.what!==`scripture shard`&&n.what!==`thaw engine`&&Kr(e,n)}});function qr(e,t,n,r){for(let[i,a]of[[2,0],[-2,0],[0,2],[0,-2],[1,0],[-1,0],[0,1],[0,-1]]){if(!D(e,t+i,n+a))continue;let o=se(e,r,t+i,n+a);o.enemy.data.elite=!0,o.enemy.data.post=[o.x,o.y],e.ents=e.ents.filter(e=>!e.enemy||e===o||Math.hypot(e.x-t,e.y-n)>6);return}}function Jr(e,t){let[n,r]=zr(e.seed).shards[t];return Tt(e.seed,n,r,1)}function Yr(e){let[t,n]=zr(e.seed).engine;return Tt(e.seed,t,n,2)}var Xr=(e,t)=>e.cards.includes(t)||e.player.inv.some(e=>e.kind===`card`&&e.card===t);function Zr(e,t){let n=Vr(e);for(let r=0;r<3;r++){if(n.pointed.includes(r)||Xr(e,Rn[r].id))continue;n.pointed.push(r);let[i,a]=Jr(e,r);return{card:t,x:i,y:a,what:`scripture shard`,found:!1}}let r=Le(G(e.seed,41,e.cards.length)),i=!n.ninth&&e.cards.length>=3?`ninth eye`:r.chance(.5)?`printer`:`cache`;i===`ninth eye`&&(n.ninth=!0);let a=r()*Math.PI*2,o=r.int(2,3),[s,c]=Wr(e.player.x,e.player.y),[l,u]=[s+Math.round(Math.sin(a)*o),c+Math.round(-Math.cos(a)*o)],[d,f]=Tt(e.seed,l,u,3+e.cards.length);return{card:t,x:d,y:f,what:i,found:!1}}var Qr=e=>l(e,`mind`).some(e=>o(e,`what`,``)===`reader`),$r={bone:1},ei=e=>e.player.inv.some(e=>e.kind===`mod`&&a(e).family===`mind`&&o(e,`what`,``)===`reader`),ti=e=>e.player.inv.reduce((e,t)=>e+(t.kind===`res`&&t.res===`bone`?t.n:0),0);U(`read`,{help:`read a memory card: read card (needs the card reader: installed it reads free, carried it wants a bone)`,when:e=>Qr(e)||ei(e),whenFail:e=>e.player.installed.some(e=>e.mod===`card-reader`&&!e.on)?`read: your card reader is off. on card reader`:`read: you need a card reader, installed or carried.`,run(e){let t=e.player.inv.findIndex(e=>e.kind===`card`);if(t<0)return F(e,`you carry no memory card.`);let n=e.player.inv[t];if(n.kind!==`card`)return;if(!Qr(e)){if(ti(e)<$r.bone)return F(e,`held in the hand, the reader wants a bone to read by. install it to read free.`);let t=e.player.inv.find(e=>e.kind===`res`&&e.res===`bone`);t&&t.kind===`res`&&(t.n-=$r.bone),e.player.inv=e.player.inv.filter(e=>e.kind!==`res`||e.n>0),F(e,`you hold the reader to the light and feed it a bone. it reads.`)}e.player.inv.splice(e.player.inv.indexOf(n),1);let r=zn[n.card];if(e.cards.includes(n.card)||e.cards.push(n.card),e.events.push({type:`read`,data:n.card}),F(e,...(r?.lines??[`the card is blank.`]).map(e=>`  `+e)),r?.shard){let t=Rn.filter(t=>e.cards.includes(t.id)).length,[r,i]=Yr(e),a=Math.round(Math.hypot(r-8.5,i-8.5)/10)*10,o=Math.round((Math.atan2(r-e.player.x,-(i-e.player.y))*180/Math.PI+360)%360),s=[`n`,`ne`,`e`,`se`,`s`,`sw`,`w`,`nw`][Math.round(o/45)%8];if(t===1?F(e,`  the engine: about ${a} cells from where you woke, bearing near ${Math.round(o/45)*45} (${s}) from here.`):t===2&&F(e,`  the engine: about ${a} cells out, bearing near ${Math.round(o/45)*45} from here.`),t<3){let t=[0,1,2].find(t=>!Xr(e,Rn[t].id)),[r,i]=t===void 0?[0,0]:Jr(e,t);if(t!==void 0){Vr(e).pointed.includes(t)||Vr(e).pointed.push(t),e.vectors.some(e=>!e.found&&e.what===`scripture shard`&&e.x===r&&e.y===i)||e.vectors.push({card:n.card,x:r,y:i,what:`scripture shard`,found:!1}),F(e,[`  the next shard lies in ${ut[ft(r,i)].name}. vector: ${Ur(e,r,i)}. `,{text:`vectors`,cmd:`vectors`}]);let a=Fr[Pr[Math.max(1,Math.min(3,ft(r,i)))]];a&&F(e,`  ${a}`)}}else{let t={card:n.card,x:r,y:i,what:`thaw engine`,found:!1};e.vectors.push(t),F(e,[`  vector: ${Ur(e,r,i)}. `,`the thaw engine.`])}}else{let t=Zr(e,n.card);e.vectors.push(t),Gr(e,t),F(e,`  vector: ${Ur(e,t.x,t.y)}. ${t.what}.`);let r=t.what===`scripture shard`&&Fr[Pr[Math.max(1,Math.min(3,ft(t.x,t.y)))]];r&&F(e,`  ${r}`)}F(e,`the card goes blank.`)}}),U(`vectors`,{help:`the vectors you know`,when:e=>e.vectors.length>0,run(e){for(let t of e.vectors)F(e,`${t.found?`(reached) `:``}${t.what}: ${Ur(e,t.x,t.y)}`)}});function ni(e){return e.vectors.filter(e=>!e.found).sort((t,n)=>R(t,e.player)-R(n,e.player))[0]}P.push(e=>{for(let t of e.vectors){if(t.found||R(t,e.player)>1.6)continue;t.found=!0,e.events.push({type:`vector`,at:[t.x,t.y]});let n=t.what===`hollow wall`?`break`:t.what===`scratched wall`||t.what===`warm prints`?``:`take`;F(e,[`the vector ends here: the ${t.what}. `,...n?[{text:n,cmd:n}]:[]])}if(!e.ended&&e.player.installed.some(e=>a(e).id===`thaw-engine`)){e.ended=`thaw`,e.events.push({type:`thaw`});let t=ir(e);F(e,`the engine turns over. something vast, warming. it drinks what you carry: ${t.total}. ${t.grade}.`)}});var ri=[`heat-lance`,`reliquary-saw`,`heart-shard`,`saints-lens`];function ii(t,n,r){let i=pt(n),a=ut[i].tier,o=Object.values(e).filter(e=>e.tier<=a&&e.family!==`unique`&&(i===3||!ri.includes(e.id))&&(!r||e.family===r)),s=o.filter(e=>i===3?ri.includes(e.id):e.tier===a),c=t.pick(a>=1&&s.length&&t.chance(.6)?s:o),l={kind:`mod`,mod:c.id},u=Object.entries(c.params).filter(([e,t])=>typeof t==`number`&&ui[e]);if(u.length&&t.chance(.25)){let[e]=t.pick(u),n=t.chance(.5);l.roll={key:e,mult:di(e,n),tag:n?`attuned`:`cracked`}}return l}var ai=(e,t)=>t.kind===`mod`&&(e.player.inv.some(e=>e.kind===`mod`&&e.mod===t.mod)||e.player.installed.some(e=>e.mod===t.mod));function oi(e,t,n,r,i=4){for(let a=0;a<i&&ai(e,t);a++)t=ii(n,r);return t}function si(e){let t=Le(G(e,61)),n=[[1,0],[0,1],[-1,0],[0,-1]];for(let e=n.length-1;e>0;e--){let r=t.int(0,e);[n[e],n[r]]=[n[r],n[e]]}return{eye:n[0],reader:n[1],printer:n[2],shop:n[3]}}var ci=(e,[t,n])=>e.cx===t&&e.cy===n,li=[`rivet-sling`,`choir-bell`,`censer-flail`],ui={range:`up`,damage:`up`,radius:`up`,hp:`up`,regen:`up`,armour:`up`,mend:`up`,thorns:`up`,haste:`up`,heatproof:`up`,glow:`up`,drain:`up`,power:`up`,speed:`up`,pace:`up`,plan:`up`,span:`up`,reveal:`up`,keep:`up`,tithe:`up`,fov:`up`,ahead:`up`,cooldown:`down`,recharge:`down`,noise:`down`,lag:`down`,blur:`down`,refresh:`down`,loud:`down`},di=(e,t)=>ui[e]===`down`===t?.7:1.4;function fi(e,t,n){let[r,i,a,o]=e.pick(yt(n,t.cx,t.cy));for(let n=0;n<20;n++){let n=e.int(r,a),s=e.int(i,o);if(t.cells[s*16+n]===h.floor)return[t.cx*16+n+.5,t.cy*16+s+.5]}let[s,c]=e.pick(wt(t));return[t.cx*16+s+.5,t.cy*16+c+.5]}var pi=(e,t)=>fi(Le(G(e,57,t.cx,t.cy)),t,e);function mi(e,t){let n=(e,n)=>[t.cx*16+e+.5,t.cy*16+n+.5];if(t.cx===0&&t.cy===0){let[t,r]=n(8,8);I(e,{kind:`item`,x:t,y:r,item:{kind:`mod`,mod:`halo`}});return}let r=Le(G(e.seed,11,t.cx,t.cy)),i=Math.hypot(t.cx,t.cy),a=si(e.seed);if(ci(t,a.eye)){let[n,i]=fi(r,t,e.seed);I(e,{kind:`item`,x:n,y:i,item:{kind:`mod`,mod:`dawn-eye`}})}if(ci(t,a.reader)){let[n,i]=fi(r,t,e.seed);I(e,{kind:`item`,x:n,y:i,item:{kind:`mod`,mod:`card-reader`}}),I(e,{kind:`item`,x:n,y:i,item:{kind:`card`,card:Hr(e)}}),I(e,{kind:`item`,x:n+.3,y:i,item:{kind:`mod`,mod:`ember-cell`}})}if(ci(t,a.printer)||i>=1.5&&r.chance(.15)){let[n,o]=fi(r,t,e.seed);I(e,{kind:`printer`,x:n,y:o,data:{far:i,made:0}}),ci(t,a.printer)&&I(e,{kind:`item`,x:n+.3,y:o,item:{kind:`mod`,mod:Le(G(e.seed,63)).pick(li)}})}let o=Le(G(e.seed,57,t.cx,t.cy));if(ci(t,a.shop)||i>=2&&o.chance(.1)){let[n,r]=ci(t,a.shop)?pi(e.seed,t):fi(o,t,e.seed);I(e,{kind:`printer`,x:n,y:r,data:{far:i,shop:!0}})}if(i>=1.5&&r.chance(.18)){let[n,i]=fi(r,t,e.seed);I(e,{kind:`item`,x:n,y:i,item:{kind:`card`,card:Hr(e)}})}if(i>=3&&r.chance(.3)){let[n,i]=fi(r,t,e.seed);I(e,{kind:`item`,x:n,y:i,item:{kind:`res`,res:`ichor`,n:1}})}let s=r.int(1,2)+ +(i>=4),c=Le(G(e.seed,14,t.cx,t.cy));for(let n=0;n<s;n++){let[n,a]=fi(r,t,e.seed),o=r.chance(.55)?ii(r,i):{kind:`res`,res:r.pick(Re.slice(0,3)),n:r.int(1,2)};I(e,{kind:`item`,x:n,y:a,item:c.chance(.5)?oi(e,o,c,i):o})}}x(mi);var hi={hands:[`heat`],script:[`1bit`,`edge`],hollow:[`sonar`],breath:[`heat`,`1bit`],veins:[`color`]},gi=new WeakMap;function _i(e){let t=gi.get(e);return t||gi.set(e,t=[]),t}var vi=[[.2,.4,.4],[.34,.33,.33],[.4,.3,.3],[.15,.4,.45]],yi=(e,t,n)=>t>=0&&n>=0&&t<16&&n<16&&e.cells[n*16+t]===h.floor,bi=(e,t,n)=>t>=0&&n>=0&&t<16&&n<16&&e.cells[n*16+t]===h.wall,xi=[[0,-1],[1,0],[0,1],[-1,0]];function Si(e,t){let n=[];for(let r=1;r<15;r++)for(let i=1;i<15;i++)if(yi(e,i,r)&&t(i,r))for(let[t,a]of xi)bi(e,i+t,r+a)&&n.push([i,r,t,a]);return n}var Ci=(e,t)=>{let n=yt(e,t.cx,t.cy);return(e,t)=>n.some(([n,r,i,a])=>e>=n&&e<=i&&t>=r&&t<=a)},wi=(e,[t,n])=>[...e].sort((e,r)=>Math.hypot(e[0]-t,e[1]-n)-Math.hypot(r[0]-t,r[1]-n)).slice(0,3);function Ti(e,t,n,r){let i=Si(t,()=>!0).filter(([e,n,r,i])=>{let[a,o,s,c]=[e+r,n+i,e+2*r,n+2*i];return s<1||c<1||s>14||c>14||!bi(t,s,c)||yi(t,a+i,o+r)||yi(t,a-i,o-r)?!1:!xi.some(([e,n])=>(s+e!==a||c+n!==o)&&yi(t,s+e,c+n))});if(!i.length)return null;let a=Ci(n,t),o=i.filter(([e,t])=>a(e,t)),[s,c,l,u]=e.pick(r?wi(i,r):o.length?o:i),[d,f]=[t.cx*16,t.cy*16];return{x:d+s+l,y:f+c+u,fx:-l,fy:-u,trail:[[d+s+2*l,f+c+2*u]]}}function Ei(e,t,n,r,i){let a=Ci(n,t),o=([e,n,r,a])=>!i||i.x!==t.cx*16+e+r||i.y!==t.cy*16+n+a,s=Si(t,a).filter(o),c=s.length?s:Si(t,()=>!0).filter(o);if(!c.length)return null;let[l,u,d,f]=e.pick(r?wi(c,r):c);return{x:t.cx*16+l+d,y:t.cy*16+u+f,fx:-d,fy:-f,trail:[]}}function Di(e,t,n){let r=Ci(n,t),i=[];for(let e=1;e<15;e++)for(let n=1;n<15;n++)yi(t,n,e)&&r(n,e)&&i.push([n,e]);if(!i.length)return null;let[a,o]=e.pick(i),s=new Map([[o*16+a,-1]]),c=[o*16+a],l=c;for(let e=0;e<8&&c.length;e++){let e=[];for(let n of c)for(let[r,i]of xi){let[a,o]=[n%16+r,(n/16|0)+i],c=o*16+a;yi(t,a,o)&&!s.has(c)&&(s.set(c,n),e.push(c))}e.length&&(l=e),c=e}let u=e.pick(l),d=[];for(;u>=0&&u!==o*16+a;)d.push([t.cx*16+u%16,t.cy*16+(u/16|0)]),u=s.get(u);return d.length<4?null:{x:t.cx*16+a,y:t.cy*16+o,fx:0,fy:0,trail:d}}function Oi(e,t){if(t.cx===0&&t.cy===0)return null;let n=Le(G(e,91,t.cx,t.cy)),r=ki(e,t);if(!n.chance(.5)&&!r)return null;let[i,a]=vi[Math.max(0,dt(t.cx,t.cy))],o=n(),s=r?`script`:o<i?`hands`:o<i+a?`script`:`hollow`,c=r?Ei(n,t,e,r,Ai(e,t)):(s===`hands`?Di:s===`script`?Ei:Ti)(n,t,e);return c?{kind:s,...c,found:!1,done:!1,salt:n.int(0,999)}:null}function ki(e,t){let[n,r]=si(e).shop;if(t.cx!==n||t.cy!==r)return;let[i,a]=pi(e,t);return[Math.floor(i)-t.cx*16,Math.floor(a)-t.cy*16]}function Ai(e,t){let n=ki(e,t);if(!n)return null;let r=Le(G(e,96,t.cx,t.cy)),i=Ti(r,t,e,n);return i?{kind:`hollow`,...i,found:!1,done:!1,salt:r.int(0,999)}:null}var ji=[`bat-psalter`,`carrion-eye`];function Mi(e){let[t,n]=si(e).shop,r=Le(G(e,65)).pick(ji);return r===`bat-psalter`&&!Ai(e,Ct(e,t,n))?`carrion-eye`:r}x((e,t)=>{let n=Oi(e.seed,t);n&&_i(e).push(n);let r=Ai(e.seed,t);r&&_i(e).push(r)});var Ni=(e,t)=>l(e,`camera`).filter(e=>hi[t].includes(o(e,`filter`,``))),Pi=e=>[e.x+.5+e.fx*.55,e.y+.5+e.fy*.55];function Fi(e,t,n){let r=e.player,i=Math.ceil(Math.hypot(t-r.x,n-r.y)*3);for(let a=1;a<i;a++)if(w(e,r.x+(t-r.x)*a/i,r.y+(n-r.y)*a/i)!==h.floor)return!1;return!0}function Ii(e,t,n,r,i){let a=e.player,s=Math.hypot(n-a.x,r-a.y);if(s>Math.min(i,Lt(e,t)))return!1;if(s<1.2)return!0;let c=Math.atan2(n-a.x,-(r-a.y))-a.dir;return Math.abs(Math.atan2(Math.sin(c),Math.cos(c)))<=(o(t,`fov`,60)/2+12)*Math.PI/180}var Li=e=>s(e),Ri=[`n`,`e`,`s`,`w`],zi=(e,t)=>{let[n,r]=[-t.fx,-t.fy],i=e.player,a=t.x+.5-i.x,o=t.y+.5-i.y;return Math.abs(a)>Math.abs(o)?a>0?`e`:`w`:o===0?Ri[xi.findIndex(([e,t])=>e===n&&t===r)]:o>0?`s`:`n`},Bi=[`here the choir knelt. here it was eaten.`,`we kept the furnace. the furnace kept us.`,`count the ribs. the ninth is a door.`,`it was warm once. it will be.`,`do not wake the abbot. he counts.`,`the saint does not burn. he is the burning.`,`eight eyes for the god. the ninth for us.`,`what you see is what sees you.`];function Vi(e,t){let[n,r]=[Math.floor(t.x/16),Math.floor(t.y/16)],[i,a]=si(e.seed).shop,o=n===i&&r===a&&_i(e).find(e=>e.kind===`hollow`&&!e.done&&Math.floor(e.x/16)===n&&Math.floor(e.y/16)===r);if(o)return o.found=!0,[o.x+.5+o.fx,o.y+.5+o.fy,`hollow wall`];let s=_i(e).filter(e=>e.kind===`hands`&&!e.found&&!e.done&&Math.hypot(e.x-t.x,e.y-t.y)<48).sort((e,n)=>Math.hypot(e.x-t.x,e.y-t.y)-Math.hypot(n.x-t.x,n.y-t.y))[0];return s?[s.x+.5+s.fx,s.y+.5+s.fy,`warm cache`]:null}function Hi(e,t,n,r,i){let a=[ii(Le(G(e.seed,93,t.x,t.y)),Math.hypot(Math.floor(t.x/16),Math.floor(t.y/16))+1.5),...i];for(let t of a)I(e,{kind:`item`,x:n,y:r,item:t});return a.map(e=>L(e)).join(`, `)}function Ui(e,t,n){if(t.done)return;t.done=!0,t.found=!0;let[r,i]=t.trail[0];E(e,t.x,t.y,h.floor),E(e,r,i,h.floor);let a=Le(G(e.seed,94,t.x,t.y)),o=Hi(e,t,r+.5,i+.5,[{kind:`res`,res:a.pick([`copper`,`glass`]),n:a.int(2,3)},...a.chance(.5)?[{kind:`res`,res:`ichor`,n:1}]:[]]);e.events.push({type:`dig`,at:[t.x+.5,t.y+.5]},{type:`reveal`,at:[r+.5,i+.5],data:`hollow`}),F(e,[`${n} a niche no door ever reached. in it: ${o}. `,{text:`go in`,cmd:`go ${zi(e,t)} 2`}])}var Wi=e=>{let t=Math.floor(e.player.x),n=Math.floor(e.player.y);return _i(e).find(e=>e.kind===`hollow`&&!e.done&&Math.abs(e.x-t)+Math.abs(e.y-n)===1)};function Gi(e,t){let[n,r]=Se(e,t.x+t.fx+.5,t.y+t.fy+.5);return[`stand ${n}, the shell is the wall to its ${Ri[xi.findIndex(([e,n])=>e===-t.fx&&n===-t.fy)]}. `,r]}U(`break`,{help:`break a hollow wall beside you with a weapon (loud)`,when:e=>l(e,`weapon`).length>0&&!!Wi(e)?.found,whenFail(e){if(!l(e,`weapon`).length)return`break: nothing on you can break a wall. any weapon can.`;let t=e.player,n=_i(e).filter(e=>e.kind===`hollow`&&e.found&&!e.done&&R({x:e.x+.5,y:e.y+.5},t)<12).sort((e,n)=>R({x:e.x,y:e.y},t)-R({x:n.x,y:n.y},t))[0];return n?[`no hollow wall beside you: `,...Gi(e,n)]:`break: no hollow wall known here. a sonar eye hears them.`},run(e){let t=Wi(e);if(!t)return F(e,`the wall rings dull. solid.`);if(!l(e,`weapon`).length)return F(e,`nothing on you can break a wall.`);for(let t of e.ents)t.enemy&&R(t,e.player)<=6&&(t.enemy.data.noticed=!0);e.events.push({type:`noise`,at:[e.player.x,e.player.y],data:6}),Ui(e,t,`your ${s(l(e,`weapon`)[0])} cracks the shell. behind it,`)}});var Ki=new WeakMap,qi=new WeakMap,Ji={heat:`shows what is warm: handprints on the floor where the dead machines crawled, and mimics breathing.`,sonar:`hears walls as echoes. a wall that rings hollow is a shell: break it, there is a niche behind.`,"1bit":`sees in black and white what colour hides: scripture scratched into the walls, and mimics breathing.`,edge:`traces every scratch: scripture cut into the walls shows as lines.`,color:`sees colour true: veins of glass, copper and ichor glint in the walls, and it names them. a needle or an auger drains them.`},Yi={heat:`hands`,sonar:`hollow`,"1bit":`script`,edge:`script`},Xi=Object.keys(Yi);function Zi(e,t){let n=e.player,r=(e,t,n)=>`${e||`no`} ${e===1?t:n}`;if(t===`color`){let t=0;for(let r=Math.floor(n.y)-32;r<=Math.floor(n.y)+32;r++)for(let i=Math.floor(n.x)-32;i<=Math.floor(n.x)+32;i++){let n=_(w(e,i,r));n&&n!==`bone`&&!Qi.get(e)?.has(`${i},${r}`)&&t++}return`glints here: ${r(t,`vein`,`veins`)} of glass, copper or ichor within 2 chunks.`}let i=_i(e).filter(e=>e.kind===Yi[t]&&!e.done&&Math.hypot(e.x-n.x,e.y-n.y)<32).length;return t===`sonar`?`rings hollow here: ${r(i,`shell`,`shells`)} within 2 chunks.`:t===`heat`?`runs warm here: ${r(i,`trail`,`trails`)} of handprints within 2 chunks.`:`is scratched here: ${r(i,`wall`,`walls`)} of scripture within 2 chunks.`}P.push(e=>{let t=e.player,n=_i(e),r=qi.get(e);r||qi.set(e,r=new Set);let i=Math.max(0,ft(t.x,t.y));for(let a of l(e,`camera`)){let s=o(a,`filter`,``);if(!Ji[s]||r.has(`${s}@${i}`))continue;if(r.add(`${s}@${i}`),r.has(s)){F(e,`the ${Li(a)}: ${ut[i].name} ${Zi(e,s)}`);continue}r.add(s);let c=n.filter(e=>e.kind===Yi[s]&&!e.done).sort((e,n)=>R({x:e.x+.5,y:e.y+.5},t)-R({x:n.x+.5,y:n.y+.5},t))[0],l=c&&R({x:c.x,y:c.y},t)<40?` the nearest lies ${Ur(e,c.x+.5,c.y+.5)}.`:``;F(e,`the ${Li(a)} ${Ji[s]}${l}`)}for(let r of n)if(!(r.done||Math.abs(r.x-t.x)>12||Math.abs(r.y-t.y)>12)){if(r.kind===`hands`){let n=Ni(e,`hands`)[0],i=e.vectors.some(e=>e.card===`scratch`&&Math.floor(e.x)===r.x&&Math.floor(e.y)===r.y);if(!n&&!i)continue;if(n&&!r.found&&r.trail.some(([t,r])=>Ii(e,n,t+.5,r+.5,6)&&Fi(e,t+.5,r+.5))&&(r.found=!0,e.events.push({type:`reveal`,at:[r.x+.5,r.y+.5],data:`hands`}),n.data.flashAt=e.t,F(e,`the ${Li(n)} shows handprints on the floor, still warm. they crawl somewhere. follow them.`)),Math.floor(t.x)===r.x&&Math.floor(t.y)===r.y){r.done=r.found=!0;let t=Le(G(e.seed,95,r.x,r.y)),n=Hi(e,r,r.x+.5,r.y+.5,[{kind:`res`,res:t.pick([`bone`,`glass`,`copper`]),n:t.int(3,4)},{kind:`res`,res:`copper`,n:t.int(1,2)}]);e.events.push({type:`reveal`,at:[r.x+.5,r.y+.5],data:`cache`}),F(e,[`the prints end at a floor plate, warm from a hundred hands. under it: ${n}. `,{text:`take`,cmd:`take`}])}}else if(r.kind===`script`){let t=Ni(e,`script`).find(t=>Ii(e,t,...Pi(r),3.5));if(!t||!Fi(e,...Pi(r)))continue;r.found=r.done=!0;let n=Bi[r.salt%Bi.length],i=Vi(e,r),a=[`the ${Li(t)} reads scripture scratched into the wall: "${n}"`];i&&(e.vectors.push({card:`scratch`,x:i[0],y:i[1],what:i[2],found:!1}),a.push(` it names a place. vector: ${Ur(e,i[0],i[1])}. ${i[2]}. `,{text:`vectors`,cmd:`vectors`})),e.events.push({type:`reveal`,at:Pi(r),data:`script`}),t.data.flashAt=e.t,F(e,a)}else if(r.kind===`hollow`){if(w(e,r.x,r.y)===h.floor){Ui(e,r,`the wall gives onto`);continue}if(r.found)continue;let t=Ni(e,`hollow`).find(t=>Ii(e,t,...Pi(r),4));if(!t||!Fi(e,...Pi(r)))continue;r.found=!0,e.events.push({type:`reveal`,at:Pi(r),data:`hollow`}),t.data.flashAt=e.t,Wi(e)===r?F(e,[`the ${Li(t)}'s song comes back hollow: the wall beside you is a shell. `,{text:`break`,cmd:`break`},` it (any weapon), or dig.`]):F(e,[`the ${Li(t)}'s song comes back hollow: a wall is a shell. `,...Gi(e,r),` then `,{text:`break`,cmd:`break`},` it (any weapon), or dig.`])}}ra(e);let a=Ni(e,`breath`);if(!a.length)return;let s=Ki.get(e);s||Ki.set(e,s=new Set);for(let t of e.ents){if(t.kind!==`item`||!t.data?.mimic||s.has(t.id))continue;let n=a.find(n=>Ii(e,n,t.x,t.y,7));n&&Fi(e,t.x,t.y)&&(s.add(t.id),e.events.push({type:`reveal`,at:[t.x,t.y],data:`breath`}),n.data.flashAt=e.t,F(e,`the ${Li(n)} sees the ${t.item?L(t.item):`thing`} on the floor rise and fall. it breathes. a mimic, waiting for a hand.`))}});var Qi=new WeakMap,$i=(e,t,n)=>!!Qi.get(e)?.has(`${t},${n}`),ea=(e,t,n)=>{let r=e.player,i=Math.max(t,Math.min(t+1,r.x)),a=Math.max(n,Math.min(n+1,r.y)),o=Math.hypot(r.x-i,r.y-a)||1;return[i+(r.x-i)/o*.05,a+(r.y-a)/o*.05]},ta=(e,t)=>[`n`,`ne`,`e`,`se`,`s`,`sw`,`w`,`nw`][Math.round((Math.atan2(e,-t)*180/Math.PI+360)/45)%8];function na(e){let t=Ni(e,`veins`);if(!t.length)return[];let n=Qi.get(e),r=e.player,i=[];for(let a=Math.floor(r.y)-9;a<=Math.floor(r.y)+9;a++)for(let o=Math.floor(r.x)-9;o<=Math.floor(r.x)+9;o++){let s=_(w(e,o,a));if(!s||s===`bone`||n?.has(`${o},${a}`))continue;let[c,l]=ea(e,o,a),u=t.find(t=>Ii(e,t,c,l,9));u&&Fi(e,c,l)&&i.push({x:o,y:a,res:s,eye:u,d:Math.hypot(o+.5-r.x,a+.5-r.y)})}return i.sort((e,t)=>e.d-t.d)}function ra(e){let t=na(e);if(!t.length)return;let n=Qi.get(e);n||Qi.set(e,n=new Set);for(let e of t)n.add(`${e.x},${e.y}`);let[r]=t,i=e.player,a=Math.round(Math.hypot(r.x+.5-i.x,r.y+.5-i.y)),o=t.length>1?` (${t.length-1} more vein${t.length>2?`s`:``} in view)`:``;e.events.push({type:`reveal`,at:[r.x+.5,r.y+.5],data:`vein`}),r.eye.data.flashAt=e.t,F(e,`the ${Li(r.eye)}: a vein of ${r.res} glints, ${a<=1?`beside you`:`${a} cells ${ta(r.x+.5-i.x,r.y+.5-i.y)}`}.${o}`)}var ia={print:[{bone:2,glass:1},{bone:2,glass:1,copper:2},{bone:3,glass:1,copper:3,ichor:1}],shop:[{bone:2,copper:1},{bone:3,glass:2,copper:1},{bone:4,glass:3,copper:2,ichor:1}],reroll:{bone:1,glass:1},scrap:[{bone:1,copper:1},{bone:2,glass:1,copper:1},{bone:2,glass:2,copper:1,ichor:1}]};function aa(e){let t=Math.max(0,e.player.slots-6),n={bone:6+3*t,glass:t?3+t:2,copper:2+2*t};return t>=1&&(n.ichor=t),n}var oa=e=>ut[pt(e)].tier;function sa(e){return ia.print[oa(e)]}var ca=(e,t)=>e.player.inv.reduce((e,n)=>e+(n.kind===`res`&&n.res===t?n.n:0),0),la=e=>Object.entries(e).map(([e,t])=>`${t} ${e}`).join(`, `),ua=(e,t)=>Object.entries(t).every(([t,n])=>ca(e,t)>=n);function da(e,t){for(let[n,r]of Object.entries(t)){let t=e.player.inv.find(e=>e.kind===`res`&&e.res===n);t&&t.kind===`res`&&(t.n-=r)}e.player.inv=e.player.inv.filter(e=>e.kind!==`res`||e.n>0)}function fa(e,t){let n=t?`reliquary`:`printer`,r=e.ents.filter(n=>n.kind===`printer`&&!!n.data?.shop===t&&R(n,e.player)<10).sort((t,n)=>R(t,e.player)-R(n,e.player))[0];if(!r)return[`no ${n} here.`];let[i,a]=Se(e,r.x,r.y,!0);return[`no ${n} within reach: step closer, it stands ${i}. `,a]}var pa=e=>e.ents.filter(t=>t.kind===`printer`&&!t.data?.shop&&R(t,e.player)<1.6).sort((t,n)=>R(t,e.player)-R(n,e.player))[0],ma={weapon:`weapon`,eye:`camera`,body:`body`,lamp:`lamp`,scanner:`scanner`,legs:`gait`,mind:`mind`,tool:`tool`},ha=e=>{let t={...sa(e)};return t.copper=(t.copper??0)+2,t};function ga(e,t){let n=t.data?.far??0,r=e.player.slots>=8?[`  slots: the board is full (8).`]:[{text:`print slot`,cmd:`print slot`},`  +1 slot: ${la(aa(e))}`],i=[`  or one kind: `,...Object.keys(ma).flatMap((e,t)=>[...t?[` `]:[],{text:e,cmd:`print ${e}`}]),`: ${la(ha(n))}`];return[r,[{text:`print module`,cmd:`print module`},`  a module: ${la(sa(n))}`],i]}U(`print`,{help:`at a printer: print slot, print module, or one kind for 2 copper more: print weapon, eye, body, lamp, scanner, legs, mind, tool`,run(e,[t]){let n=pa(e);if(!n)return F(e,fa(e,!1));t?.endsWith(`s`)&&(ma[t.slice(0,-1)]||t===`slots`||t===`modules`)&&(t=t.slice(0,-1));let r=n.data?.far??0;if(t===`slot`){if(e.player.slots>=8)return F(e,`the board is full: eight slots.`);let t=aa(e);return ua(e,t)?(da(e,t),e.player.slots++,e.events.push({type:`print`,at:[n.x,n.y]}),F(e,`the printer grinds out a slot board. slots: ${e.player.slots}.`)):F(e,`the printer wants ${la(t)}.`)}let i=ma[t];if(t===`module`||i){let t=i?ha(r):sa(r);if(!ua(e,t))return F(e,`the printer wants ${la(t)}.`);da(e,t);let a=(n.data.made??0)+1;n.data.made=a;let o=ii(Le(G(e.seed,51,n.id,a)),r,i);Oe(e,o),e.events.push({type:`print`,at:[n.x,n.y]}),o.kind===`mod`&&F(e,[`the printer spits out: `,{text:s(o),cmd:`install ${s(o)}`}])}else F(e,t?`no kind called ${t}.`:`a printer. it is warm, and it waits.`,...ga(e,n))}}),P.push(e=>{let t=pa(e);t&&!t.data?.greeted&&(t.data={...t.data,greeted:!0},F(e,`a printer hums here, warm.`,...ga(e,t)));let n=_a(e);n&&!n.data?.greeted&&(n.data={...n.data,greeted:!0},F(e,`a reliquary opens its glass doors. three relics wait inside.`,...Ca(e,n)))});var _a=e=>e.ents.filter(t=>t.kind===`printer`&&t.data?.shop&&R(t,e.player)<1.6).sort((t,n)=>R(t,e.player)-R(n,e.player))[0],va=e=>{if(e.kind!==`mod`)return{};let t={...ia.shop[Math.min(2,a(e).tier)]};return a(e).family===`power`&&(t.copper=(t.copper??0)+1,t.glass=(t.glass??0)+1),t},ya=e=>(e.data?.far??0)<1.5,ba=e=>{let{copper:t=0,...n}=e;return t?{...n,glass:(n.glass??0)+2*t}:e};function xa(e,t,n){if(ya(e)&&!e.data?.rolls&&n.kind===`mod`&&e.data?.layer===n.mod)return{copper:2};let r=va(n);return ya(e)&&t===0?ba(r):r}function Sa(e,t){let n=t.data??={};if(!n.offers){let r=n.far??0,i=Le(G(e.seed,53,t.id,n.rolls??0)),a=[];for(let t=0;t<20&&a.length<3;t++){let n=ii(i,r+2);n.kind===`mod`&&!a.some(e=>e.kind===`mod`&&e.mod===n.mod)&&(t>=14||!(t=>e.player.inv.some(e=>e.kind===`mod`&&e.mod===t)||e.player.installed.some(e=>e.mod===t))(n.mod))&&a.push(n)}if(ya(t)&&!n.rolls){let t=Mi(e.seed);a.splice(0,a.length,...a.filter(e=>e.kind!==`mod`||e.mod!==t).slice(0,2)),a.splice(1,0,{kind:`mod`,mod:t}),n.layer=t}n.offers=a}return n.offers}function Ca(e,t){let n=Sa(e,t).map((e,n)=>e&&e.kind===`mod`?[{text:`buy ${n+1}`,cmd:`buy ${n+1}`},`  ${s(e)}${a(e).family===`power`||!a(e).power?``:` (${a(e).power}p)`}: ${la(xa(t,n,e))}. ${ye(e)}`]:[`  ${n+1}: an empty niche.`]);return n.push([{text:`reroll`,cmd:`reroll`},`  new relics: ${la(ia.reroll)}`]),n}U(`buy`,{help:`at a reliquary: buy 1, buy 2, buy 3, or by name: buy bone lance`,run(e,t){let n=_a(e);if(!n)return F(e,fa(e,!0));let r=Sa(e,n),i=t.join(` `).replace(/-/g,` `),a=r.findIndex(e=>!!i&&!!e&&e.kind===`mod`&&s(e).replace(/-/g,` `).includes(i)),o=/^\d+$/.test(i)?Number(i)-1:a,c=r[o];if(!c)return F(e,`the reliquary shows:`,...Ca(e,n));let l=xa(n,o,c);if(!ua(e,l))return F(e,`the reliquary wants ${la(l)}.`);da(e,l),r[o]=null,Oe(e,c),e.events.push({type:`print`,at:[n.x,n.y]}),F(e,[`the glass slides open: `,c.kind===`mod`?{text:s(c),cmd:`install ${s(c)}`}:``])}}),U(`reroll`,{help:`at a reliquary: new relics for a price`,when:e=>!!_a(e),whenFail:e=>fa(e,!0),run(e){let t=_a(e);if(!t)return F(e,fa(e,!0));if(!ua(e,ia.reroll))return F(e,`a reroll wants ${la(ia.reroll)}.`);da(e,ia.reroll),t.data.rolls=(t.data.rolls??0)+1,delete t.data.offers,F(e,`the reliquary turns its shelves.`,...Ca(e,t))}});var wa=new WeakMap,Ta=e=>e.kind===`mod`&&a(e).family!==`unique`?ia.scrap[Math.min(2,a(e).tier)]:{};function Ea(e,t){if(!t||t.kind!==`mod`||t.mod!==`card-reader`)return null;let n=e.player,r=n.inv.filter(e=>e.kind===`mod`&&e.mod===`card-reader`).length+n.installed.filter(e=>e.mod===`card-reader`).length,i=e.cards.filter(e=>e.startsWith(`shard-`)).length;return r===1&&i<3?`that is your only card reader, and ${3-i} shard${i===2?``:`s`} still wait${i===2?`s`:``} to be read. no other reader lies out there.`:null}var Da=H.drop;Da&&(H.drop={...Da,run(e,t){let n=Ea(e,e.player.inv[we(e,t)]);if(n)return F(e,n);Da.run(e,t)}});var Oa=new WeakMap;U(`recycle`,{help:`grind a carried module into resources: recycle pinhole`,run(e,t){let n=e.player.inv.filter(e=>e.kind===`mod`&&Object.keys(Ta(e)).length>0);if(!t.length)return F(e,n.length?`recycle what?`:`you carry nothing that grinds.`,...n.map(e=>[{text:`recycle ${s(e)}`,cmd:`recycle ${s(e)}`},`  ${la(Ta(e))}`]));let r=we(e,t),i=e.player.inv[r];if(!i||i.kind!==`mod`)return F(e,Te(e,t)?`remove it from its slot first.`:`no such module in your inventory.`);let o={...Ta(i)};if(!Object.keys(o).length)return F(e,`this one will not break. it is waiting for something.`);let c=e.player,l=c.inv.filter(e=>e.kind===`mod`&&e.mod===`card-reader`).length+c.installed.filter(e=>e.mod===`card-reader`).length,u=Ea(e,i);if(u)return F(e,u);if(i.mod===`card-reader`&&l===1&&c.inv.some(e=>e.kind===`card`)&&(Oa.get(e)??-99)<e.t-20)return Oa.set(e,e.t),F(e,[`that is your only card reader, and you carry a card no one has read. `,{text:`recycle it anyway`,cmd:`recycle card reader`}]);let d=(wa.get(e)??0)+1;wa.set(e,d),a(i).tier===0&&Le(G(e.seed,57,d)).chance(.5)&&(o.glass=(o.glass??0)+1),e.player.inv.splice(r,1);for(let[t,n]of Object.entries(o))Oe(e,{kind:`res`,res:t,n});e.events.push({type:`recycle`}),F(e,`you grind ${s(i)} down: ${la(o)}.`)}}),U(`info`,{help:`what a module does: info pinhole`,run(e,t){let n=t.join(` `),r=[...e.player.installed,...e.player.inv.filter(e=>e.kind===`mod`),...ge(e).map(e=>e.item).filter(e=>e.kind===`mod`),...(()=>{let t=_a(e);return t?Sa(e,t).filter(e=>e?.kind===`mod`):[]})()].find(e=>s(e).includes(n)||n&&L({kind:`mod`,...e}).includes(n));if(!n||!r)return F(e,`info on what? a module you carry, wear or stand by.`);let[i,a,o]=V(r);F(e,[s(r)+`: `+i],`  `+a,`  `+o)}}),i(`power`,{});function ka(e){let t=Math.max(0,e.player.core-4);if(t===0)return{bone:4,copper:2};let n={bone:4+2*t,glass:t,copper:t};return t>=3&&(n.ichor=t-2),n}var Aa={bone:2};function ja(e){let t=(e.player.flesh??0)/2,n={bone:4+2*t,copper:1+Math.floor(t/2)};return t>=4&&(n.ichor=1),n}var Ma=e=>e.ents.find(t=>t.data?.altar&&R(t,e.player)<1.6);function Na(e){let t=e.ents.filter(t=>t.data?.altar&&R(t,e.player)<10).sort((t,n)=>R(t,e.player)-R(n,e.player))[0];if(!t)return[`no altar here. find one: it takes offerings.`];let[n,r]=Se(e,t.x,t.y,!0);return[`no altar within reach: step closer, it stands ${n}. `,r]}function Pa(t){let n=e[t.mod];if(!n||n.family===`unique`||n.family===`power`)return null;let r={weapon:`damage`,camera:`range`,lamp:`radius`}[n.family];return r&&typeof n.params[r]==`number`?r:Object.entries(n.params).filter(([e,t])=>typeof t==`number`&&ui[e]).map(([e])=>e)[0]??null}var Fa=(e,t=Pa(e))=>`${t} ×${di(t,!0)}`,Ia=t=>{let n=Math.min(2,e[t.mod].tier)+1,r={bone:3*n,glass:n===1?1:2*n,copper:2*n};return n>1&&(r.ichor=n-1),r},La=[`weapon`,`body`,`lamp`,`scanner`,`camera`,`mind`,`gait`,`tool`],Ra=(e,t)=>La.indexOf(a(e).family)-La.indexOf(a(t).family),za=e=>e.player.installed.filter(e=>Pa(e)&&e.roll?.tag!==`attuned`&&e.roll?.tag!==`tempered`).sort(Ra),Ba=e=>ui[e]===`down`?.85:1.2,Va=e=>e.roll?.tag===`tempered`?e.roll.n??1:0,Ha=e=>e.player.installed.filter(e=>(e.roll?.tag===`attuned`||e.roll?.tag===`tempered`&&Va(e)<3)&&Pa(e)).sort(Ra);function Ua(e){let t=Pa(e);return e.roll.key===t?{key:t,mult:Math.round(e.roll.mult*Ba(t)*100)/100}:{key:t,mult:di(t,!0)}}var Wa=t=>{let n=Math.min(2,e[t.mod].tier)+1,r=Va(t)+1,i={bone:2*n+r,glass:r,copper:3*n+3*r};return r>1&&(i.ichor=r-1),i};function Ga(e,t){let n=[];e.player.core<9&&n.push([`offer power`,ka(e)]),(e.player.flesh??0)<12&&n.push([`offer flesh`,ja(e)]);for(let t of za(e))n.push([`attune ${a(t).name}`,Ia(t)]);for(let t of Ha(e))n.push([`temper ${a(t).name}`,Wa(t)]);return e.player.hp<e.player.maxHp*.7&&n.push([`offer mend`,Aa]),n}function Ka(e,t){for(let[n,r]of Object.entries(t)){let t=e.player.inv.find(e=>e.kind===`res`&&e.res===n);t&&t.kind===`res`&&(t.n-=r)}e.player.inv=e.player.inv.filter(e=>e.kind!==`res`||e.n>0)}var qa=e=>[e.player.core<9?[{text:`offer power`,cmd:`offer power`},`  +1 power for good: ${la(ka(e))}`]:[`  power: the core is full.`],(e.player.flesh??0)<12?[{text:`offer flesh`,cmd:`offer flesh`},`  +2 max hp for good: ${la(ja(e))}`]:[`  flesh: as much as it can give.`],[{text:`offer mend`,cmd:`offer mend`},`  mend fully: ${la(Aa)}`],...za(e).map(e=>[{text:`attune ${a(e).name}`,cmd:`attune ${a(e).name}`},`  ${Fa(e)} for good: ${la(Ia(e))}`]),...Ha(e).map(e=>{let t=Ua(e),n=t.key===e.roll.key?`${t.key} ×${Ba(t.key)} more`:`${t.key} ×${t.mult} (for its ${e.roll.key})`;return[{text:`temper ${a(e).name}`,cmd:`temper ${a(e).name}`},`  ${n}: ${la(Wa(e))}`]})];U(`offer`,{help:`at an altar: offer power, offer flesh, offer mend`,when:e=>!!Ma(e),whenFail:Na,run(e,[t]){let n=Ma(e);if(!n)return F(e,Na(e));let r=e.player;if(t===`power`){if(r.core>=9)return F(e,`the altar is quiet. your core can hold no more.`);let t=ka(e);return ua(e,t)?(Ka(e,t),r.core++,e.events.push({type:`print`,at:[n.x,n.y]}),F(e,`the altar drinks it. your core runs warmer: power ${r.core} at the core.`)):F(e,`the altar wants ${la(t)}.`)}if(t===`flesh`){if((r.flesh??0)>=12)return F(e,`the altar has no more to give you.`);let t=ja(e);return ua(e,t)?(Ka(e,t),r.flesh=(r.flesh??0)+2,r.hp+=2,e.events.push({type:`print`,at:[n.x,n.y]}),F(e,`the altar knits you more of yourself: +2 max hp.`)):F(e,`the altar wants ${la(t)}.`)}if(t===`mend`)return ua(e,Aa)?(Ka(e,Aa),r.hp=r.maxHp,F(e,`the altar closes your wounds.`)):F(e,`the altar wants ${la(Aa)}.`);if(t)return F(e,`the altar takes no single ${t}. it takes these, and pays in power, flesh or mending:`,...qa(e));F(e,`an altar. it wants an offering.`,...qa(e))}}),U(`attune`,{help:`at an altar: attune an installed module (one number 40% better): attune spark finger`,when:e=>!!Ma(e),whenFail:Na,run(e,t){if(!Ma(e))return F(e,Na(e));let n=t.join(` `),r=n&&za(e).find(e=>s(e).includes(n))||Te(e,t);if(!r)return F(e,`attune what? an installed module.`,...qa(e));let i=Pa(r);if(!i)return F(e,`the altar will not touch that.`);if(r.roll?.tag===`attuned`||r.roll?.tag===`tempered`)return F(e,`${s(r)} is attuned already.`,...r.roll.tag===`attuned`?[[{text:`temper ${a(r).name}`,cmd:`temper ${a(r).name}`}]]:[]);let o=Ia(r);if(!ua(e,o))return F(e,`the altar wants ${la(o)}.`);Ka(e,o),r.roll={key:i,mult:di(i,!0),tag:`attuned`},e.events.push({type:`print`}),F(e,`the altar hums over it: ${s(r)}, ${Fa(r,i)}.`)}}),U(`temper`,{help:`at an altar: temper an attuned module (its number 20% better again, three times): temper bone lance`,when:e=>!!Ma(e),whenFail:Na,run(e,t){if(!Ma(e))return F(e,Na(e));let n=t.join(` `),r=n?Ha(e).filter(e=>s(e).includes(n)).sort((e,t)=>Va(e)-Va(t)):[],i=r.find(t=>ua(e,Wa(t)))??r[0]??Te(e,t);if(!i)return F(e,`temper what? an installed, attuned module.`,...qa(e));if(Va(i)>=3)return F(e,`${s(i)} is as true as it gets.`);if(!i.roll||i.roll.tag===`cracked`||!ui[i.roll.key]||!Pa(i))return F(e,`attune it first: ${a(i).name}.`);let o=Wa(i);if(!ua(e,o))return F(e,`the altar wants ${la(o)}.`);Ka(e,o);let{key:c,mult:l}=Ua(i);i.roll={key:c,mult:l,tag:`tempered`,n:Va(i)+1},e.events.push({type:`print`}),F(e,`the altar sings it truer: ${s(i)}, ${c} ×${i.roll.mult}.`)}}),x((e,t)=>{let n=Math.hypot(t.cx,t.cy),r=Le(G(e.seed,71,t.cx,t.cy));if(!(t.cx===1&&t.cy===1||n>=2&&r.chance(n>=3.5?.35:.2)))return;let[i,a]=Tt(e.seed,t.cx,t.cy,7,t);I(e,{kind:`prop`,x:i,y:a,data:{altar:!0}})}),P.push(e=>{let t=Ma(e);t&&!t.data.greeted&&(t.data.greeted=!0,F(e,`an altar stands here, stained and patient.`,...qa(e)))});var Ja=20;P.push(e=>{if(e.ended)return;let t=e.player,n=e.ents.filter(e=>(e.data?.altar||e.kind===`printer`)&&R(e,t)<3).sort((e,n)=>R(e,t)-R(n,t))[0];if(!n)return;let r=e.ents.filter(e=>e.enemy&&e.enemy.data.noticed&&!N[e.enemy.type]?.hidden&&R(e,t)<=6),i=n.data??={};if(r.length<3||e.t-(i.packAt??-20)<Ja)return;i.packAt=e.t;let a=new Set(r.map(e=>e.enemy.type)),o=a.size===1?`${r.length} ${(N[[...a][0]]?.name??`foe`).replace(/^(a|an|the) /,``)}s`:`${r.length} foes`,s=n.data?.altar?`altar`:n.data?.shop?`reliquary`:`printer`;F(e,n.data?.altar&&t.hp<t.maxHp&&ua(e,Aa)?[`⚠ ${o} close on the ${s}. `,{text:`offer mend`,cmd:`offer mend`},` now, or back off.`]:`⚠ ${o} close on the ${s}. back off, or fight them here.`),e.events.push({type:`warn`,at:[r[0].x,r[0].y]})});function Ya(e){let t=e.player,n=Math.floor(t.x),r=Math.floor(t.y),i=[Math.round(Math.sin(t.dir)),Math.round(-Math.cos(t.dir))];for(let[t,a]of[i,...Object.values(k)])if(_(w(e,n+t,r+a)))return[n+t,r+a];return null}var Xa=e=>l(e,`tool`).filter(e=>o(e,`drain`,0)>0);i(`tool`,{buttons:(e,t)=>o(t,`drain`,0)>0&&Ya(e)?[{label:`drain`,cmd:`drain`}]:[]}),U(`drain`,{help:`bleed a vein beside you into resources (loud)`,when:e=>Xa(e).length>0,run(e){let t=Xa(e)[0];if(e.t<(t.data.readyAt??0))return F(e,`the needle is still cooling.`);let n=Ya(e);if(!n)return F(e,`no vein beside you.`);let r=_(w(e,n[0],n[1])),i=Le(G(e.seed,61,n[0],n[1])),a=r===`ichor`?1:Math.max(1,Math.round(i.int(1,3)*o(t,`drain`,1)));E(e,n[0],n[1],h.wall),Oe(e,{kind:`res`,res:r,n:a}),t.data.readyAt=e.t+o(t,`cooldown`,1.5);let s=o(t,`noise`,8),c=0;for(let t of e.ents)t.enemy&&R(t,e.player)<=s&&!t.enemy.data.noticed&&(t.enemy.data.noticed=!0,c++);e.events.push({type:`drain`,at:[n[0]+.5,n[1]+.5],data:r},{type:`noise`,at:[e.player.x,e.player.y],data:s}),F(e,`the needle drinks the vein: +${a} ${r}. it screams as it goes.`+(c?` something heard.`:``))}});var Za=new WeakMap;P.push(e=>{if(!Xa(e).length)return;let t=Ya(e);if(!t)return;let n=`${Math.floor(e.player.x)},${Math.floor(e.player.y)}`;Za.get(e)!==n&&(Za.set(e,n),F(e,[`a vein of ${_(w(e,t[0],t[1]))} beside you. `,{text:`drain`,cmd:`drain`}]))});var Qa={};function $a(e,t){Qa[e]=t}var eo=new WeakMap;function to(e,t){let n=e.player,r=Math.floor(n.x),i=Math.floor(n.y),a=eo.get(e);a||eo.set(e,a=new Map);let o=`${r},${i},${e.chunks.size},${T}`;if(a.get(t)===o)return;a.set(t,o);let s=Math.ceil(t);for(let a=i-s;a<=i+s;a++)for(let i=r-s;i<=r+s;i++){if(Math.hypot(i+.5-n.x,a+.5-n.y)>t)continue;let r=`${i},${a}`;if(e.seen.has(r))continue;let o=i+.5-Math.sign(i+.5-n.x)*.45,s=a+.5-Math.sign(a+.5-n.y)*.45;j(e,n.x,n.y,o,s)&&e.seen.add(r)}}var no=[`reader`,`map`,`compass`],ro=e=>no.includes(o(e,`what`,``)),io=t.mind;i(`mind`,{tick:(e,t,n)=>ro(t)?void 0:io?.tick?.(e,t,n),status:(e,t)=>ro(t)?[]:io?.status?.(e,t)??[],buttons(e,t){if(!ro(t))return io?.buttons?.(e,t)??[];let n=o(t,`what`,``);return n===`reader`?e.player.inv.some(e=>e.kind===`card`)?[{label:`read card`,cmd:`read card`}]:[]:e.vectors.length&&n!==`map`?[{label:`vectors`,cmd:`vectors`}]:[]}}),P.push(e=>{let t=Math.floor(e.player.x),n=Math.floor(e.player.y);for(let r=n-1;r<=n+1;r++)for(let n=t-1;n<=t+1;n++)e.seen.add(`${n},${r}`);let r=0;for(let t of l(e,`mind`))o(t,`what`,``)===`map`&&(r=Math.max(r,o(t,`reveal`,7)));r&&to(e,r)});var ao={click:[],draw:[]},oo={zoom:null,px:e=>(oo.zoom??innerHeight>=900?297:198)/e},so={bone:`#d8c8a8`,glass:`#7fd8d0`,copper:`#e08a40`,ichor:`#e02848`},co={floor:`#6a5444`,wall:`#2c221d`,vein:`#7a4a2a`,ichor:`#a02838`,you:`#f0a050`,vec:`#e0d0a0`,printer:`#70a0a0`};function lo(e,t,n){let r=Math.round(o(t,`span`,33)),i=0,a=document.createElement(`canvas`);a.className=`map`,e.append(a);let s=a.getContext(`2d`),c=0,[l,u]=[0,0];return a.addEventListener(`click`,e=>{let t=a.getBoundingClientRect(),i=l+Math.floor((e.clientX-t.left)/t.width*r),o=u+Math.floor((e.clientY-t.top)/t.height*r);for(let e of ao.click)e(n,i,o)}),{update(e){if(!(t.on&&e.t>=t.readyAt))return;let n=Math.max(3,Math.floor(oo.px(r)));if(n!==i&&([i,c,a.width,a.height]=[n,0,r*n,r*n]),e.t<c)return;c=e.t+.25;let o=e.player;l=Math.floor(o.x)-(r>>1),u=Math.floor(o.y)-(r>>1),s.fillStyle=`#000`,s.fillRect(0,0,a.width,a.height);for(let t=0;t<r;t++)for(let n=0;n<r;n++){let r=l+n,a=u+t;if(!e.seen.has(`${r},${a}`)||!e.chunks.has(`${Math.floor(r/16)},${Math.floor(a/16)}`))continue;let o=w(e,r,a),c=_(o);s.fillStyle=o===h.floor?co.floor:c?$i(e,r,a)?so[c]:c===`ichor`?co.ichor:co.vein:co.wall,s.fillRect(n*i,t*i,i,i)}for(let t of e.ents)t.kind===`printer`&&e.seen.has(`${Math.floor(t.x)},${Math.floor(t.y)}`)&&(s.fillStyle=co.printer,s.fillRect((t.x-l)*i-i/2,(t.y-u)*i-i/2,i,i));for(let t of e.ents){if(t.kind!==`item`||!t.item||t.data?.mimic||!e.seen.has(`${Math.floor(t.x)},${Math.floor(t.y)}`))continue;let[n,r]=[(Math.floor(t.x)+.5-l)*i,(Math.floor(t.y)+.5-u)*i];if(t.item.kind===`res`)s.fillStyle=so[t.item.res],s.beginPath(),s.arc(n,r,Math.max(2,i*.25),0,Math.PI*2),s.fill();else{let e=Math.max(3,Math.round(i*.5));s.fillStyle=`#000`,s.fillRect(n-e/2-1,r-e/2-1,e+2,e+2),s.fillStyle=co.you,s.fillRect(n-e/2,r-e/2,e,e)}}let d=r*i/2;for(let t of e.vectors){if(t.found)continue;let e=(t.x-l)*i,n=(t.y-u)*i;if(!(e>=0&&n>=0&&e<r*i&&n<r*i)){let t=e-d,r=n-d,i=(d-4)/Math.max(Math.abs(t),Math.abs(r));e=d+t*i,n=d+r*i}s.strokeStyle=co.vec,s.lineWidth=2,s.beginPath(),s.moveTo(e-4,n-4),s.lineTo(e+4,n+4),s.moveTo(e+4,n-4),s.lineTo(e-4,n+4),s.stroke()}for(let t of ao.draw)t(e,s,l,u,i);let f=(o.x-l)*i,p=(o.y-u)*i,[m,g]=[Math.sin(o.dir),-Math.cos(o.dir)],v=Math.max(5,i*1.6);s.fillStyle=co.you,s.beginPath(),s.moveTo(f+m*v,p+g*v),s.lineTo(f-m*v*.6-g*v*.7,p-g*v*.6+m*v*.7),s.lineTo(f-m*v*.2,p-g*v*.2),s.lineTo(f-m*v*.6+g*v*.7,p-g*v*.6-m*v*.7),s.closePath(),s.fill()}}}function uo(e,t){let n=document.createElement(`canvas`);n.width=n.height=120,n.className=`compass`;let r=document.createElement(`p`);r.className=`flavour`,e.append(n,r);let i=n.getContext(`2d`);return{update(e){if(!(t.on&&e.t>=t.readyAt))return;let n=ni(e),a=e.player,o=n?Math.atan2(n.x-a.x,-(n.y-a.y))-a.dir:Math.sin(e.t*.7)*2.5;i.clearRect(0,0,120,120),i.strokeStyle=co.floor,i.lineWidth=2,i.beginPath(),i.arc(60,60,54,0,Math.PI*2),i.stroke(),i.strokeStyle=n?co.you:co.floor,i.lineWidth=3,i.beginPath(),i.moveTo(60-Math.sin(o)*50*.4,60+Math.cos(o)*50*.4),i.lineTo(60+Math.sin(o)*50,60-Math.cos(o)*50),i.stroke();let s=n?`${n.what}: ${Math.round(Math.hypot(n.x-a.x,n.y-a.y))} cells`:`the needle drifts.`;r.textContent!==s&&(r.textContent=s)}}}var fo=Qa.mind;$a(`mind`,(e,t,n)=>{let r=o(t,`what`,``);if(r===`map`)return lo(e,t,n);if(r===`compass`)return uo(e,t);if(!ro(t)&&fo)return fo(e,t,n);let i=document.createElement(`p`);return i.className=`flavour`,i.textContent=r===`reader`?`a slot for memory cards. it reads what the dead wrote.`:``,e.append(i),{update(){}}});var po=[`pinhole-eye`,`stepper-relay`,`map-spool`,`spark-finger`];function mo(e){let t=e.player;t.slots=6,t.inv.push({kind:`res`,res:`copper`,n:2}),t.core=4;for(let n of po)t.inv.push({kind:`mod`,mod:n}),e.stats.mods.push(n)}function ho(e){e.player.installed=[],e.player.inv=[]}var go=[8.5,8.5],_o=new WeakMap;function vo(e,t,n,r=4){let i=Math.floor(t),a=Math.floor(n);for(let t=0;t<=r;t++)for(let n=-t;n<=t;n++)for(let r=-t;r<=t;r++)if(Math.max(Math.abs(r),Math.abs(n))===t&&D(e,i+r+.5,a+n+.5))return[i+r+.5,a+n+.5];return null}U(`unstuck`,{help:`stuck or lost? unstuck: out of a wall, else home to where you woke (3 s with a foe on you)`,run(e){let t=e.player;if(t.path=[],t.move=null,!D(e,t.x,t.y)){let n=vo(e,t.x,t.y);if(n)return[t.x,t.y]=n,F(e,`you wrench yourself free, onto open floor.`)}let n=e.ents.some(e=>e.enemy&&R(e,t)<2);_o.set(e,e.t+(n?3:0)),F(e,n?`you fold up and let the god's veins carry you home. 3 s.`:`you fold up and let the god's veins carry you home.`)}}),P.push(e=>{let t=_o.get(e);if(t===void 0||e.t<t)return;_o.delete(e);let n=e.player;[n.x,n.y]=go,n.path=[],n.move=null,F(e,`you wake where you woke. the chamber is quiet.`)});var yo=typeof location>`u`?null:new URLSearchParams(location.search).get(`scene`),bo=new WeakSet;function xo(e,t){ho(e);let n=e.player;n.slots=Math.max(n.slots,t.length+1),n.core=12,e.ents=e.ents.filter(e=>e.kind!==`item`||Math.hypot(e.x-n.x,e.y-n.y)>2);for(let r of t)n.inv.push({kind:`mod`,mod:r}),W(e,`install ${r.replace(/-/g,` `).replace(`saints`,`saint's`)}`);for(let t of n.installed)t.readyAt=e.t-1}function So(e,t,n){e.player.x=t,e.player.y=n,e.player.path=[],O(e,t,n)}var Co={"world-map"(e){xo(e,[`vidicon-tube`,`stepper-relay`,`card-reader`,`map-spool`,`drowned-compass`]),e.player.inv.push({kind:`card`,card:`log-surveyor`}),W(e,`read card`),F(e,[`staged: the first card read. follow the compass. `,{text:`go n 3`,cmd:`go n 3`},`  `,{text:`go e 3`,cmd:`go e 3`},`  `,{text:`vectors`,cmd:`vectors`}])},"world-printer"(e){let[t,n]=si(e.seed).printer;C(e,t,n);let r=e.ents.find(e=>e.kind===`printer`&&!e.data?.shop&&Math.floor(e.x/16)===t&&Math.floor(e.y/16)===n);r&&So(e,r.x,r.y),xo(e,[`vidicon-tube`,`stepper-relay`,`leech-needle`]),e.player.inv.push({kind:`res`,res:`bone`,n:14},{kind:`res`,res:`glass`,n:5},{kind:`res`,res:`copper`,n:7},{kind:`res`,res:`ichor`,n:2}),F(e,`staged: at the printer by the start, resources in hand.`)},"world-deep"(e){let[t,n]=[5,-3],[r,i]=bt(yt(e.seed,t,n)[0]);So(e,t*16+r+.5,n*16+i+.5);for(let r=(n-1)*16;r<(n+2)*16;r++)for(let n=(t-1)*16;n<(t+2)*16;n++)e.seen.add(`${n},${r}`);xo(e,[`saints-lens`,`stepper-relay`,`survey-spool`,`leech-needle`]),F(e,`staged: ${Math.round(Math.hypot(t,n))} chunks out, where the chambers grow strange.`)},"world-engine"(e){let t=zr(e.seed).engine;C(e,t[0],t[1]);let[n,r]=Yr(e);xo(e,[`vidicon-tube`,`stepper-relay`,`card-reader`]),e.player.inv.push({kind:`card`,card:`shard-1`},{kind:`card`,card:`shard-2`},{kind:`card`,card:`shard-3`});for(let t=0;t<3;t++)W(e,`read card`);So(e,n,r),e.ents=e.ents.filter(e=>!e.enemy||Math.hypot(e.x-n,e.y-r)>10),F(e,[`staged: the engine lies at your feet. `,{text:`take thaw`,cmd:`take thaw`},`  `,{text:`install thaw engine`,cmd:`install thaw engine`}])}};P.push(e=>{yo&&Co[yo]&&!bo.has(e)&&(bo.add(e),Co[yo](e))});var wo=60,To=150,Eo={0:[`machine`,`reliquary`],1:[`patrol`,`reliquary`,`collapse`,`machine`],2:[`patrol`,`reliquary`,`collapse`,`machine`],3:[`flare`,`patrol`,`reliquary`,`collapse`,`machine`]},Do={1:[`mite`,`mite`],2:[`walker`,`mite`],3:[`walker`,`mite`,`mite`,`mite`]},Oo={1:[`mite`],2:[`mite`,`mite`],3:[`mite`,`mite`,`mite`]},ko=300,Ao=.6,jo=[`patrol`,`collapse`,`flare`],Mo=new WeakMap;function No(e,t,n=4,r=8){let i=e.player,a=Math.floor(i.x),o=Math.floor(i.y),s=new Set([a+`,`+o]),c=[[a,o]],l=[];for(let t=1;t<=r&&c.length;t++){let r=[];for(let[i,a]of c)for(let[o,c]of[[1,0],[-1,0],[0,1],[0,-1]]){let[u,d]=[i+o,a+c];!s.has(u+`,`+d)&&D(e,u+.5,d+.5)&&(s.add(u+`,`+d),r.push([u,d]),t>=n&&l.push([u,d]))}c=r}let u=l.filter(([t,n])=>!e.ents.some(e=>e.enemy?.data.elite&&Math.hypot(e.x-t-.5,e.y-n-.5)<7));if(!u.length)return null;let[d,f]=t.pick(u);return[d+.5,f+.5]}function Po(e,t,n){if(H.goto&&(!H.goto.when||H.goto.when(e)))return`goto ${Math.floor(t)} ${Math.floor(n)}`;let[r,i]=Ne.long(e,t,n);return`go ${r} ${i}`}var Fo=(e,t)=>[`n`,`ne`,`e`,`se`,`s`,`sw`,`w`,`nw`][Math.round((Math.atan2(e,-t)*180/Math.PI+360)%360/45)%8];function Io(e,t,n){let[r,i]=[t-e.player.x,n-e.player.y],a=Po(e,t,n);return[`${Math.round(Math.hypot(r,i))} cells ${Fo(r,i)}.  `,{text:a,cmd:a}]}var Lo={reliquary:`open reliquary`,collapse:`rubble`,machine:`dead machine`,flare:`vent`};function Ro(e,t=1/0){let n=e.player,r=[];for(let i of e.ents){let e=i.data?.set;i.kind!==`item`||!e||i.data?.mimic||R(i,n)>t||r.some(e=>Math.hypot(e.x-i.x,e.y-i.y)<1.5)||r.push({x:i.x,y:i.y,name:Lo[e]??`a find`,r:R(i,n),side:Fo(i.x-n.x,i.y-n.y),cmd:``,item:i.item})}return r.sort((e,t)=>e.r-t.r)}var zo=e=>Ro(e,12).filter(e=>e.r>=1.6).map(t=>({...t,cmd:Po(e,t.x,t.y)}));ao.draw.push((e,t,n,r,i)=>{let[a,o]=[t.canvas.width,t.canvas.height];for(let s of Ro(e)){let[e,c]=[(s.x-n)*i,(s.y-r)*i];if(e<0||c<0||e>=a||c>=o){let[t,n]=[e-a/2,c-o/2],r=(a/2-6)/Math.max(Math.abs(t),Math.abs(n));[e,c]=[a/2+t*r,o/2+n*r]}let l=Math.max(5,i*.8);for(let[n,r]of[[`#000`,4],[`#b0f080`,2]])t.strokeStyle=n,t.lineWidth=r,t.beginPath(),t.moveTo(e,c-l),t.lineTo(e+l,c),t.lineTo(e,c+l),t.lineTo(e-l,c),t.closePath(),t.stroke()}});var Bo=(e,t,n,r,i)=>I(e,{kind:`item`,x:t,y:n,item:r,data:{set:i}}),Vo=(e,t)=>(e.enemy.data.set=t,e);function Ho(t,n,r,i,a){let o=ft(r,i),s=Math.hypot(r-8.5,i-8.5)/16;if(n===`patrol`){let e=Do[o]??Do[1];e.forEach((n,a)=>{let o=Vo(bn(t,n,r+(a-(e.length-1)/2)*.3,i),`patrol`);o.enemy.data.noticed=!0}),F(t,[`feet in step, coming your way: a patrol, `,...Io(t,r,i)])}else if(n===`reliquary`)Bo(t,r,i,oi(t,ii(a,s+2),a,s+2),`reliquary`),Bo(t,r,i,{kind:`res`,res:a.pick([`bone`,`glass`]),n:a.int(2,4)},`reliquary`),F(t,[`a seal breaks somewhere close. a reliquary stands open, `,...Io(t,r,i)]);else if(n===`collapse`)Bo(t,r,i,{kind:`res`,res:a.pick([`bone`,`glass`]),n:a.int(2,3)},`collapse`),(Oo[o]??Oo[1]).forEach((e,n)=>Vo(bn(t,e,r+n*.3,i),`collapse`).enemy.data.noticed=!0),F(t,[`the vault groans and gives. rubble, and something shaken awake in it, `,...Io(t,r,i)]);else if(n===`machine`){let n=oi(t,ii(a,s+1),a,s+1);if(n.kind===`mod`){let t=Object.entries(e[n.mod]?.params??{}).filter(([e,t])=>typeof t==`number`&&ui[e]);if(t.length){let e=a.pick(t)[0];n.roll={key:e,mult:di(e,!0),tag:`attuned`}}}Bo(t,r,i,n,`machine`),F(t,[`a machine dies against the wall, still ticking. something in it works, `,...Io(t,r,i)])}else n===`flare`&&(Bo(t,r,i,{kind:`mod`,mod:a.pick(ri)},`flare`),Vo(bn(t,`pyre`,r,i+.01),`flare`),F(t,[`a vent breathes fire. a pyre lamp kindles over something bright, `,...Io(t,r,i)]));t.events.push({type:`set`,at:[r,i],data:n})}P.push(e=>{if(e.ended)return;let t=Mo.get(e);if(t||Mo.set(e,t={next:To,n:0}),e.t<t.next)return;let n=ft(e.player.x,e.player.y),r=e.ents.some(t=>t.enemy?.data.noticed&&R(t,e.player)<8);if(n===0&&e.t<ko||r)return void(t.next=e.t+10);if(e.player.path.length>2)return void(t.next=e.t+1);let i=Le(G(e.seed,71,t.n)),a=Eo[n],o=a[(G(e.seed,72)+t.n)%a.length];jo.includes(o)&&e.player.hp<e.player.maxHp*Ao&&(o=i.pick([`machine`,`reliquary`]));let s=No(e,i);if(!s)return void(t.next=e.t+5);Ho(e,o,s[0],s[1],i),t.n++,t.next=e.t+100+i()*wo});var Uo={heat:`hands`,sonar:`hollow`,"1bit":`script`,edge:`script`},Wo={hollow:`hollow wall`,script:`scratched wall`,hands:`warm prints`},Go=new WeakMap,Ko=new WeakMap,qo=new WeakMap,Jo=(e,t)=>{let n=e.get(t);return n||e.set(t,n=new Set),n},Yo=e=>e.kind===`hands`?[e.trail[0][0]+.5,e.trail[0][1]+.5]:[e.x+.5+e.fx,e.y+.5+e.fy],Xo=e=>`eye:${e.x},${e.y}`;function Zo(e,t,n,r,i){e.vectors.some(e=>e.card===Xo(t))||e.vectors.push({card:Xo(t),x:r,y:i,what:n,found:!1})}P.push(e=>{let t=e.player,n=_i(e),r=Jo(Ko,e);for(let i of l(e,`camera`)){let a=o(i,`filter`,``);if(!Uo[a]||r.has(a)||e.t<i.readyAt)continue;r.add(a);let s=n.filter(e=>e.kind===Uo[a]&&!e.done).sort((e,n)=>R({x:e.x+.5,y:e.y+.5},t)-R({x:n.x+.5,y:n.y+.5},t))[0];if(!s||R({x:s.x,y:s.y},t)>=40)continue;Jo(Go,e).add(s);let[c,l]=Yo(s);Math.hypot(c-t.x,l-t.y)>3&&Zo(e,s,Wo[s.kind],c,l),F(e,[`  marked on your map: `,{text:Wo[s.kind],cmd:`vectors`},`.`])}let i=Jo(qo,e);for(let t of n)if(t.kind===`hands`&&t.found&&!t.done&&!i.has(t)){i.add(t);let[n,r]=t.trail[0],a=(Math.atan2(t.x-n,-(t.y-r))*180/Math.PI+360)%360,o=[`n`,`ne`,`e`,`se`,`s`,`sw`,`w`,`nw`][Math.round(a/45)%8];Zo(e,t,`warm plate`,t.x+.5,t.y+.5),F(e,[`  the prints crawl ${o}, toward a warm plate: ${Ur(e,t.x+.5,t.y+.5)}. `,{text:`vectors`,cmd:`vectors`}])}for(let t of e.vectors)!t.found&&t.card.startsWith(`eye:`)&&n.find(e=>Xo(e)===t.card)?.done&&(t.found=!0)});var Qo=(e,t)=>t.found||Jo(Go,e).has(t)||e.vectors.some(e=>Math.floor(e.x-t.fx)===t.x&&Math.floor(e.y-t.fy)===t.y),$o=`#f0a050`,es=`#000`;ao.draw.push((e,t,n,r,i)=>{let a=t.canvas.width/i,o=Math.max(5.5,i);for(let s of _i(e)){if(s.x<n-2||s.y<r-2||s.x>n+a+2||s.y>r+a+2||!Qo(e,s))continue;let[c,l]=[(s.x-n+.5)*i,(s.y-r+.5)*i];if(s.kind===`hollow`&&!s.done){t.fillStyle=es,t.fillRect(c-o-1,l-o-1,2*o+2,2*o+2),t.strokeStyle=$o,t.lineWidth=Math.max(1,i/6),t.strokeRect(c-o+.5,l-o+.5,2*o-1,2*o-1),t.fillStyle=$o;for(let e=0;e<3;e++)t.fillRect(c-o+2,l-o+2+(2*o-4)*e/2.5,2*o-4,Math.max(1,o/4))}else if(s.kind===`script`){t.fillStyle=es,t.fillRect(c-o-1,l-o-1,2*o+2,2*o+2),t.fillStyle=s.done?`#a08a6a`:`#f0e4c8`,t.fillRect(c-o,l-o,2*o,2*o),t.fillStyle=es;for(let e=0;e<3;e++)t.fillRect(c-o+2,l-o+2+(2*o-4)*e/2.5,(2*o-4)*(e===2?.6:1),Math.max(1,o/5))}else if(s.kind===`hands`&&!s.done){t.fillStyle=$o;for(let[e,a]of s.trail)t.beginPath(),t.arc((e-n+.5)*i,(a-r+.5)*i,Math.max(1.5,i/6),0,Math.PI*2),t.fill();t.strokeStyle=es,t.lineWidth=4,t.beginPath(),t.arc(c,l,o*.8,0,Math.PI*2),t.stroke(),t.strokeStyle=$o,t.lineWidth=2;for(let e of[.8,.35])t.beginPath(),t.arc(c,l,o*e,0,Math.PI*2),t.stroke()}}}),globalThis.thawSecrets=_i;var ts=e=>l(e,`gait`).filter(e=>o(e,`pilot`,!1)),ns=e=>ts(e).sort((e,t)=>o(t,`plan`,0)-o(e,`plan`,0))[0],rs=(e,t,n)=>e.seen.has(`${t},${n}`)&&D(e,t+.5,n+.5),is=e=>e.ents.filter(e=>e.kind===`enemy`&&e.enemy&&!N[e.enemy.type]?.hidden);function as(e,t,n,r,i,a,o=!1,s=!1){let c=(e,t)=>`${e},${t}`,l=o?is(e).filter(e=>R(e,{x:t,y:n})<a):[],u=(e,t)=>1+(l.some(n=>Math.hypot(n.x-e-.5,n.y-t-.5)<2.5)?6:0),d=(e,t)=>Math.abs(e-r)+Math.abs(t-i),f=new Map,p=new Map([[c(t,n),0]]),m=[[t,n,d(t,n)]],h=[t,n],g=d(t,n),_=0;for(;m.length&&_++<8e3;){let t=0;for(let e=1;e<m.length;e++)m[e][2]<m[t][2]&&(t=e);let[n,o]=m.splice(t,1)[0],l=d(n,o);if(l<g&&([h,g]=[[n,o],l]),n===r&&o===i)break;let _=p.get(c(n,o));if(!(_>=a))for(let[t,r]of[[1,0],[-1,0],[0,1],[0,-1]]){let i=n+t,a=o+r;if(!(s?D(e,i+.5,a+.5):rs(e,i,a)))continue;let l=_+u(i,a);l>=(p.get(c(i,a))??1/0)||(p.set(c(i,a),l),f.set(c(i,a),c(n,o)),m.push([i,a,l+d(i,a)]))}}let v=[],y=c(h[0],h[1]);for(;y!==c(t,n);){let[e,t]=y.split(`,`).map(Number);v.unshift([e+.5,t+.5]),y=f.get(y)}return{path:v,whole:g===0}}var os=new WeakMap;function ss(e,t){os.delete(e);let n=e.player;n.path=n.path.slice(0,1),F(e,t)}function cs(e,t,n){let r=ns(e);if(!r)return F(e,`no pilot answers.`),!1;let i=e.player,a=Math.floor(i.x),s=Math.floor(i.y);if(a===t&&s===n)return F(e,`you are there.`),!1;let{path:c,whole:l}=as(e,a,s,t,n,o(r,`plan`,40),o(r,`avoid`,!1));return c.length?!l&&Math.abs(c[c.length-1][0]-t-.5)+Math.abs(c[c.length-1][1]-n-.5)>Math.abs(a-t)+Math.abs(s-n)-2?(F(e,`the pilot knows no way closer. walk some of it first.`),!1):(i.path=c,i.pace=o(r,`pace`,2.5),os.set(e,{to:[t,n],near:new Set(is(e).filter(e=>R(e,i)<3.5).map(e=>e.id)),hurtAt:i.hurtAt,inst:r}),F(e,l?`the pilot takes you: ${c.length} cells.`:`the pilot takes you as near as it knows: ${c.length} cells.`),!0):(F(e,`the pilot knows no way there. walk it once, or look at it.`),!1)}P.push(e=>{let t=os.get(e);if(!t)return;let n=e.player;if(!c(e,t.inst))return ss(e,`the pilot goes quiet. you stop.`);if(n.hurtAt>t.hurtAt)return ss(e,`struck. the pilot lets go.`);if(is(e).find(e=>R(e,n)<3.5&&!t.near.has(e.id)))return ss(e,`something close. the pilot lets go.`);if(n.path.length&&!D(e,n.path[0][0],n.path[0][1]))return ss(e,`the way is shut. the pilot lets go.`);if(!n.path.length){os.delete(e);let[r,i]=t.to;F(e,Math.floor(n.x)===r&&Math.floor(n.y)===i?`the pilot sets you down.`:`the pilot sets you down, as near as it knew.`)}});var ls=t.gait;i(`gait`,{...ls,buttons:(e,t)=>o(t,`pilot`,!1)?os.get(e)?[{label:`stop`,cmd:`stop`}]:[]:ls?.buttons?.(e,t)??[]}),U(`goto`,{help:`the pilot walks you there: goto 12 -3 (cells), or goto printer (a waypoint), or click the map`,when:e=>!!ns(e),run(e,t){let[n,r]=t;if(n!==void 0&&r!==void 0&&!isNaN(Number(n))&&!isNaN(Number(r)))return void cs(e,Math.floor(Number(n)),Math.floor(Number(r)));let i=t.join(` `),a=i&&fs(e).filter(e=>e.name.startsWith(i)).sort((t,n)=>R(t,e.player)-R(n,e.player))[0];if(!a)return F(e,`goto where? goto 12 -3, a waypoint name, or click the map.`);cs(e,Math.floor(a.x),Math.floor(a.y))}}),U(`stop`,{help:`stop walking`,when:e=>l(e,`gait`).some(e=>o(e,`go`,!1)||o(e,`pilot`,!1)),run(e){os.get(e)&&os.delete(e),e.player.path=e.player.path.slice(0,1)}}),ao.click.push((e,t,n)=>{ns(e)&&W(e,`goto ${t} ${n}`)});var us=e=>l(e,`mind`).filter(e=>o(e,`what`,``)===`log`),ds=e=>e.data.points??=[];function fs(e){let t=new Set,n=[];for(let r of us(e))for(let e of ds(r))t.has(e.key)||(t.add(e.key),n.push(e));return n.sort((t,n)=>R(t,e.player)-R(n,e.player))}function ps(e){return e.kind===`printer`?[`printer`,e.data?.shop?`shop printer`:`printer`]:e.kind!==`item`||!e.item?null:e.item.kind===`card`?[`card`,`memory card`]:e.item.kind===`mod`?e.item.mod===`card-reader`?[`reader`,`card reader`]:[`mods`,`module`]:e.item.kind===`res`?[`res`,e.item.res]:null}function ms(e,t,n){let r=ds(e);if(r.some(e=>e.key===n.key))return;r.push({...n,at:t.t});let i=o(e,`keep`,8);for(;r.length>i;){let e=r.findIndex(e=>e.auto&&e.key!==`start`);r.splice(e<0?0:e,1)}n.auto&&n.key!==`start`&&F(t,[`log: ${n.name} noted, ${_s(t,n)}.  `,{text:`go`,cmd:vs(t,n)}])}var hs=new WeakMap;P.push(e=>{for(let t of us(e)){if(!c(e,t)||e.t<(hs.get(t)??0))continue;hs.set(t,e.t+.5);let n=ds(t);for(let t=n.length-1;t>=0;t--){let r=n[t];(r.ent!==void 0&&!e.ents.some(e=>e.id===r.ent)||r.key.startsWith(`vec:`)&&e.vectors.find(e=>`vec:${e.card}`===r.key)?.found)&&n.splice(t,1)}let r=o(t,`auto`,[]),i=o(t,`range`,8),a=e.player;r.includes(`start`)&&ms(t,e,{key:`start`,name:`where you woke`,x:8.5,y:8.5,auto:!0});for(let n of e.ents){if(R(n,a)>i)continue;let o=ps(n);o&&r.includes(o[0])&&ms(t,e,{key:`e:${n.id}`,name:o[1],x:n.x,y:n.y,ent:n.kind===`item`?n.id:void 0,auto:!0})}if(r.includes(`vector`))for(let n of e.vectors)n.found||ms(t,e,{key:`vec:${n.card}`,name:n.what,x:n.x,y:n.y,auto:!0});if(r.includes(`veins`)){let r=Math.min(i,6);for(let i=Math.floor(a.y)-r;i<=Math.floor(a.y)+r;i++)for(let o=Math.floor(a.x)-r;o<=Math.floor(a.x)+r;o++){let r=_(w(e,o,i));r&&e.seen.has(`${o},${i}`)&&(n.some(e=>e.name.endsWith(`vein`)&&Math.hypot(e.x-o,e.y-i)<5)||ms(t,e,{key:`v:${o},${i}`,name:`${r} vein`,x:o+.5,y:i+.5,auto:!0}))}}}});var gs=[`n`,`ne`,`e`,`se`,`s`,`sw`,`w`,`nw`];function _s(e,t){let n=e.player,r=R(t,n);if(r<1.6)return`here`;let i=(Math.atan2(t.x-n.x,-(t.y-n.y))*180/Math.PI+360)%360;return`${Math.round(r)} cells ${gs[Math.round(i/45)%8]}`}function vs(e,t){if(ns(e))return`goto ${Math.floor(t.x)} ${Math.floor(t.y)}`;let n=e.player,[r,i]=[t.x-n.x,t.y-n.y],a=Math.abs(r)>Math.abs(i)?r>0?`e`:`w`:i>0?`s`:`n`,s=Math.max(1,Math.min(9,Math.round(Math.max(Math.abs(r),Math.abs(i)))));return l(e,`gait`).some(e=>o(e,`go`,!1))?`go ${a} ${s}`:`crawl ${a}`}U(`mark`,{help:`note this spot in your waypoint log: mark den`,when:e=>us(e).length>0,run(e,t){let n=us(e).find(t=>c(e,t));if(!n)return F(e,`the log is still warming.`);let r=e.player,i=t.join(` `)||`mark ${ds(n).filter(e=>!e.auto).length+1}`,a=Math.floor(r.x)+.5,s=Math.floor(r.y)+.5,l=ds(n);l.push({key:`m:${a},${s}`,name:i,x:a,y:s,auto:!1,at:e.t});let u=o(n,`keep`,8);for(;l.length>u;)l.splice(Math.max(0,l.findIndex(e=>e.auto)),1);F(e,`log: ${i} marked.`)}});var ys=t.mind,bs=e=>o(e,`what`,``)===`log`;i(`mind`,{...ys,tick:(e,t,n)=>bs(t)?void 0:ys?.tick?.(e,t,n),status:(e,t)=>bs(t)?[]:ys?.status?.(e,t)??[],buttons:(e,t)=>bs(t)?[{label:`mark here`,cmd:`mark`}]:ys?.buttons?.(e,t)??[]});var xs=e=>window.thaw.send(e),Ss=Qa.mind;$a(`mind`,(e,t,n)=>{if(!bs(t))return Ss?Ss(e,t,n):{update(){}};let r=document.createElement(`div`);r.className=`waypoints`,e.append(r);let i=``,a=0;return{update(e){if(e.t<a)return;a=e.t+.3;let n=(c(e,t)?ds(t).slice().sort((t,n)=>R(t,e.player)-R(n,e.player)):[]).map(t=>[t.name,_s(e,t),vs(e,t)]),o=JSON.stringify(n)+t.on;if(o!==i){if(i=o,r.replaceChildren(),!n.length){let n=document.createElement(`p`);n.className=`flavour`,n.textContent=c(e,t)?`nothing noted yet.`:`warming…`,r.append(n)}for(let[e,t,i]of n){let n=document.createElement(`div`);n.className=`wp`;let a=document.createElement(`span`);a.textContent=e;let o=document.createElement(`span`);o.className=`at`,o.textContent=t;let s=document.createElement(`button`);s.textContent=i.startsWith(`goto`)?`go`:i,s.dataset.cmd=i,s.addEventListener(`click`,()=>xs(i)),n.append(a,o,s),r.append(n)}}}}}),ao.draw.push((e,t,n,r,i)=>{if(os.get(e)){t.fillStyle=`#f0a05088`;for(let[a,o]of e.player.path)t.fillRect((a-n)*i-1,(o-r)*i-1,2,2)}for(let a of fs(e)){let e=(a.x-n)*i,o=(a.y-r)*i;e<0||o<0||e>t.canvas.width||o>t.canvas.height||(t.strokeStyle=a.auto?`#e0d0a0`:`#f0a050`,t.lineWidth=1.5,t.beginPath(),t.moveTo(e,o-4),t.lineTo(e+4,o),t.lineTo(e,o+4),t.lineTo(e-4,o),t.closePath(),t.stroke())}}),x((e,t)=>{let n=n=>{let r=Le(G(e.seed,53,t.cx,t.cy)),i=wt(t);if(!i.length)return;let[a,o]=i[r.int(0,i.length-1)];I(e,{kind:`item`,x:t.cx*16+a+.5,y:t.cy*16+o+.5,item:{kind:`mod`,mod:n}})};t.cx===0&&t.cy===-1&&n(`wayfinder-moth`),t.cx===-1&&t.cy===1&&n(`waystone-log`)});var Cs=new WeakSet,ws=60;function Ts(e,t,n){let r=e.player,[i,a]=[Math.floor(r.x),Math.floor(r.y)],{path:o}=as(e,i,a,Math.floor(t),Math.floor(n),ws,!1,!0);if(!o.length)return null;let s=([e,t],[n,r])=>[Math.round(n-e),Math.round(r-t)],[c,l]=s([i+.5,a+.5],o[0]),u=1;for(;u<Math.min(9,o.length);){let[e,t]=s(o[u-1],o[u]);if(e!==c||t!==l)break;u++}let d=Object.keys(k).find(e=>k[e][0]===c&&k[e][1]===l);return d?[d,u]:null}var Es=Ne.leg;Ne.leg=(e,t,n)=>Ts(e,t,n)??Es(e,t,n);function Ds(e,t,n,r=``){let i=[];for(let a of[`n`,`e`,`s`,`w`]){if(a===r)continue;let[o,s]=k[a],c=0;for(;c<9&&D(e,t+o*(c+1),n+s*(c+1));)c++;c&&i.push([a,c])}return i}var Os=H.go;Os&&(H.go={...Os,run(e,t){let n=e.player,r=n.path.length,i=e.log.length;Os.run(e,t);let a=t[0]?.[0];if(!a||!k[a])return;let o=Math.min(9,Math.max(1,Number(t[1])||1)),s=n.path.length-r;if(s>=o)return;e.log.length===i+1&&e.log[e.log.length-1][0]===`a wall.`&&e.log.pop();let[c,l]=n.path.length?n.path[n.path.length-1]:[Math.floor(n.x)+.5,Math.floor(n.y)+.5],u={n:`s`,s:`n`,e:`w`,w:`e`}[a],d=Ds(e,c,l,a),f=s&&d.length>1?d.filter(([e])=>e!==u):d,p=f.flatMap(([e,t],n)=>[n?`  `:``,{text:`go ${e} ${t}`,cmd:`go ${e} ${t}`}]);F(e,[`${s?`wall after ${s} cell${s>1?`s`:``}`:`a wall ${a}`}; open: ${f.length?f.map(([e])=>e).join(`, `):`none`}.  `,...p])}});function ks(e,t,n){let r=e.player,i=e.ents.find(e=>e.kind===`item`&&e.item?.kind===`mod`&&e.item.mod===t&&!e.data?.mimic);return!i||[...r.inv,...r.installed].some(e=>`mod`in e&&e.mod===t)?null:As(e,i.x,i.y,n)}function As(e,t,n,r,i=`take`){let a=e.player,[s,c]=[t-a.x,n-a.y];if(Math.abs(Math.floor(t)-Math.floor(a.x))+Math.abs(Math.floor(n)-Math.floor(a.y))<=1)return[`${r}: here. `,{text:i,cmd:i}];let u=[`n`,`ne`,`e`,`se`,`s`,`sw`,`w`,`nw`][Math.round((Math.atan2(s,-c)*180/Math.PI+360)%360/45)%8],[d,f]=Ne.long(e,t,n),p=l(e,`gait`).some(e=>o(e,`go`,!1))?`go ${d} ${f}`:`crawl ${d}`;return[`${r}, ${Math.round(Math.hypot(s,c))} cells ${u}. first: `,{text:p,cmd:p}]}var js=[`dawn-eye`,`card-reader`],Ms=e=>e.ents.filter(t=>t.kind===`printer`&&t.data?.shop&&(t.data?.far??0)<1.5&&!t.data?.greeted&&R(t,e.player)<40).sort((t,n)=>R(t,e.player)-R(n,e.player))[0],Ns=e=>{let t=Ms(e);return[ks(e,`dawn-eye`,`the dawn eye glints, waiting for a socket`),ks(e,`card-reader`,`a card reader ticks, waiting for a card`),t?As(e,t.x,t.y,`glass doors chime: a reliquary keeps an eye for hidden things`,`buy`):null].filter(e=>!!e)},Ps=H.take;Ps&&(H.take={...Ps,run(e,t){let n=e.player.inv.filter(e=>e.kind===`card`||e.kind===`mod`&&e.mod===`card-reader`).length;Ps.run(e,t);let r=e.player.inv.filter(e=>e.kind===`card`||e.kind===`mod`&&e.mod===`card-reader`).length,i=H.read;r>n&&e.player.inv.some(e=>e.kind===`card`)&&i&&(!i.when||i.when(e))&&F(e,[`a card to read, it points somewhere: `,{text:`[read card]`,cmd:`read card`}])}}),P.push(e=>{if(Cs.has(e)||!l(e,`gait`).some(e=>o(e,`go`,!1)))return;Cs.add(e);let t=Ns(e);t.length&&F(e,`you hear:`,...t,[`the walls bend; `,{text:`listen`,cmd:`listen`},` finds the way; the map marks them; `,{text:`where`,cmd:`where`},` says it again.`])}),U(`where`,{help:`what to head for next: the dawn eye, the card reader, a card to read, the nearest vector`,run(e){let t=Ns(e);t.length&&F(e,`you hear:`,...t);let n=Fs(e);if(n.length)return F(e,...n);t.length||F(e,`nothing left the wake hint points at.`)}});function Fs(e){let t=e.player,n=[];t.inv.some(e=>e.kind===`card`)&&n.push(H.read&&(!H.read.when||H.read.when(e))?[`a memory card waits to be read: `,{text:`read card`,cmd:`read card`}]:t.installed.some(e=>e.mod===`card-reader`&&!e.on)?[`a memory card waits; your card reader is off: `,{text:`on card reader`,cmd:`on card reader`}]:[`a memory card waits for a card reader.`]),![...t.inv,...t.installed].some(e=>`mod`in e&&e.mod===`card-reader`)&&e.cards.filter(e=>e.startsWith(`shard-`)).length<3&&!e.ents.some(e=>e.kind===`item`&&e.item?.kind===`mod`&&e.item.mod===`card-reader`)&&n.push([`no card reader: `,{text:`print mind`,cmd:`print mind`},` at a printer.`]);let r=ni(e);if(r&&n.push(As(e,r.x,r.y,`the ${r.what}`)),t.inv.some(e=>e.kind===`mod`&&!t.installed.some(t=>a(t).family===a(e).family))&&t.installed.length>=t.slots){let r=e.ents.filter(e=>e.kind===`printer`&&!e.data?.shop).sort((e,n)=>R(e,t)-R(n,t))[0];n.push(r?As(e,r.x,r.y,`slots are full; a printer sells slots`,`print`):[`slots are full; a printer sells slots.`])}return n}var Is=new Map,Ls=10,Rs=0;function zs(){let e=document.getElementById(`desk`);return e||(e=document.createElement(`div`),e.id=`desk`,document.body.append(e)),e}function Bs(e){return Is.get(e)}function Vs(e,t,n){let r=Is.get(e);if(r?.el.isConnected)return r;zs().children.length||(Rs=0);let i=document.createElement(`section`);i.className=`win`,i.dataset.win=e;let a=document.createElement(`header`);a.className=`title`;let o=document.createElement(`i`);o.className=`dot`;let s=document.createElement(`span`);s.textContent=t,a.append(o,s);let c=document.createElement(`div`);c.className=`body`;let l=document.createElement(`footer`);l.className=`foot`,i.append(a,c,l);let u=Rs++,d=Math.max(1,Math.floor((innerWidth-24-280)/280)),[f,p]=n??[24+u%d*280,32+Math.floor(u/d)%2*330];if(n&&Rs--,i.style.left=f+`px`,i.style.top=p+`px`,i.style.zIndex=String(++Ls),i.addEventListener(`pointerdown`,()=>i.style.zIndex=String(++Ls)),_c(i,a),zs().append(i),!n){i.classList.add(`mod-win`),a.title=`drag to move · double-click to minimise`,a.addEventListener(`dblclick`,e=>{e.target.classList.contains(`dot`)||i.classList.contains(`min`)||rc(i,!0)}),a.addEventListener(`click`,e=>{i.classList.contains(`min`)&&!e.target.classList.contains(`dot`)&&ic(i)});let e=!1;a.addEventListener(`pointerdown`,()=>{i.classList.contains(`min`)||(e=!0)});let t=()=>{e||!i.isConnected||i.classList.contains(`min`)||(Gs(i)||!Ks(i))&&Qs(i)};i.dataset.fresh=`1`,queueMicrotask(t),setTimeout(t,300),setTimeout(()=>(t(),delete i.dataset.fresh,fc()),1200)}let m={id:e,el:i,title:a,body:c,foot:l,dot:o};return Is.set(e,m),m}var Hs=284;function Us(e,t){let n=[...document.querySelectorAll(`.win`)].filter(n=>n!==e&&!n.dataset.tidy&&!t?.(n)).map(e=>e.getBoundingClientRect());return n.push({left:innerWidth-Hs,top:0,right:innerWidth,bottom:innerHeight}),n}var Ws=(e,t,n,r,i,a)=>e<i.right+a&&e+n+a>i.left&&t<i.bottom+a&&t+r+a>i.top;function Gs(e){let t=e.getBoundingClientRect();return Us(e).some(e=>Ws(t.left,t.top,t.width,t.height,e,-2))}function Ks(e){let t=e.getBoundingClientRect();return t.left>=0&&t.top>=0&&t.right<=innerWidth&&t.bottom<=innerHeight}function qs(e,t){let{width:n,height:r}=e.getBoundingClientRect(),i=Us(e,t);for(let e=32;e+r<=innerHeight-8;e+=16)for(let t=16;t+n<=innerWidth-8;t+=16)if(!i.some(i=>Ws(t,e,n,r,i,8)))return[t,e];return null}var Js=(e,[t,n])=>[e.style.left,e.style.top]=[t+`px`,n+`px`];function Ys(e){return e.dataset.state===`off`?4:e.classList.contains(`fam-camera`)?e.dataset.layer?0:.5:e.querySelector(`canvas.map`)?1:e.querySelector(`.foot button`)?2:3}var Xs=()=>sc().some(e=>e.classList.contains(`min`)&&!e.dataset.hand&&Ys(e)<3);function Zs(e,t){let n=qs(e);if(n)return Js(e,n),!0;let r=Ys(e),i=sc().filter(t=>t!==e&&!t.classList.contains(`min`)&&!t.dataset.moved&&(Ys(t)>r||r<1&&!!e.dataset.fresh&&Ys(t)===r)).sort((e,t)=>Ys(t)-Ys(e)||e.offsetWidth*e.offsetHeight-t.offsetWidth*t.offsetHeight),a=[];for(let t of i){a.push(t);let n=qs(e,e=>a.includes(e));if(!n)continue;Js(e,n);let r=e.getBoundingClientRect();for(let e of a)Ws(r.left,r.top,r.width,r.height,e.getBoundingClientRect(),8)&&rc(e);return!0}return t&&rc(e),!1}function Qs(e){if(Js(e,[0,32]),Ys(e)>=3&&Xs())return rc(e);let t=qs(e);if(t){Js(e,t);return}let n=sc().map(e=>[e,e.style.left,e.style.top,e.classList.contains(`min`),e.dataset.was]);if(cc(!1),e.classList.contains(`min`)||!n.every(([e,,,t])=>t||!e.classList.contains(`min`))){for(let[e,t,r,i,a]of n)[e.style.left,e.style.top]=[t,r],e.classList.toggle(`min`,i),a===void 0?delete e.dataset.was:e.dataset.was=a;Js(e,[0,32]),Zs(e,!0),ac()}}function $s(e){if(!e.classList.contains(`min`)||e.dataset.hand||e.dataset.moved)return;let t=Ys(e);if(t>=3&&Xs()||!sc().some(n=>!n.classList.contains(`min`)&&(Ys(n)>t||t<1&&!!e.dataset.fresh))&&!qs(e))return;let n=e.dataset.was;e.classList.remove(`min`),Js(e,[0,32]),Zs(e,!1)?(e.style.zIndex=String(++Ls),ac()):(rc(e),n!==void 0&&(e.dataset.was=n))}function ec(e){delete e.dataset.hand,delete e.dataset.moved,e.dataset.fresh=`1`,$s(e),delete e.dataset.fresh,e.style.zIndex=String(++Ls)}function tc(){let e=sc().filter(e=>e.classList.contains(`min`)&&!e.dataset.hand&&!e.dataset.moved);for(let t of e.sort((e,t)=>Ys(e)-Ys(t)))$s(t)}function nc(e){if(e.classList.contains(`min`)||!Gs(e)&&Ks(e))return!0;let t=[e.offsetLeft,e.offsetTop];return Js(e,[0,32]),Zs(e,!1)?!0:(Js(e,t),!1)}function rc(e,t=!1){e.classList.contains(`min`)||(e.dataset.was=`${e.style.left},${e.style.top}`),t&&(e.dataset.hand=`1`),e.classList.add(`min`),ac()}function ic(e){e.classList.remove(`min`),delete e.dataset.hand;let[t,n]=(e.dataset.was??``).split(`,`);if(t&&n&&([e.style.left,e.style.top]=[t,n]),Gs(e)||!Ks(e)){let t=Ys(e),n=e=>e.classList.contains(`mod-win`)&&!e.classList.contains(`min`),r=qs(e)??qs(e,e=>n(e)&&Ys(e)>t)??qs(e,n);r?Js(e,r):oc(e);let i=e.getBoundingClientRect();for(let t of sc())t!==e&&!t.classList.contains(`min`)&&Ws(i.left,i.top,i.width,i.height,t.getBoundingClientRect(),-2)&&rc(t)}e.style.zIndex=String(++Ls),ac()}function ac(){let e=[...document.querySelectorAll(`.win.min`)];e.forEach(e=>e.dataset.tidy=`1`);for(let t of e){let{width:e,height:n}=t.getBoundingClientRect(),r=Us(t),i=null;for(let t=innerHeight-n-6;t>=32&&!i;t-=n+4)for(let a=16;a+e<=innerWidth-8;a+=8)if(!r.some(r=>Ws(a,t,e,n,r,3))){i=[a,t];break}Js(t,i??[16,innerHeight-n-6]),delete t.dataset.tidy}}function oc(e){let t=e.getBoundingClientRect(),n=Math.max(0,Math.min(innerWidth-t.width,t.left)),r=Math.max(32,Math.min(innerHeight-t.height,t.top));Js(e,[Math.max(0,n),Math.max(0,r)])}var sc=()=>[...document.querySelectorAll(`.win.mod-win`)];function cc(e){let t=sc().filter(t=>e||!t.dataset.moved&&!t.dataset.hand);for(let e of t)e.classList.remove(`min`),Js(e,[0,32]),e.dataset.tidy=`1`,delete e.dataset.moved,delete e.dataset.hand;let n=e=>e.offsetWidth*e.offsetHeight,r=e=>Ys(e)===.5?1.5:Ys(e);t.sort((e,t)=>r(e)-r(t)||n(t)-n(e));for(let e of t){delete e.dataset.tidy;let t=qs(e);t?Js(e,t):(e.classList.contains(`min`)||(e.dataset.was=``),e.classList.add(`min`))}if(Xs())for(let e of t)Ys(e)>=3&&!e.classList.contains(`min`)&&rc(e);ac()}var lc=()=>[Math.max(16,innerWidth/2-220),Math.max(32,innerHeight-(innerHeight<800?350:390))];function uc(){let e=document.querySelector(`.win-console`);e&&(e.dataset.moved||Js(e,lc()),oc(e))}function dc(){uc(),cc(!0),fc()}function fc(){for(let e of sc())Ys(e)===1&&e.classList.contains(`min`)&&!e.dataset.hand&&!e.dataset.moved&&$s(e)}var pc;typeof window<`u`&&addEventListener(`resize`,()=>{uc(),clearTimeout(pc),pc=setTimeout(()=>{uc(),sc().some(e=>!e.classList.contains(`min`)&&(!Ks(e)||Gs(e)))?cc(!1):ac(),tc()},150)});function mc(e){let t=Is.get(e)?.el.classList.contains(`min`);Is.get(e)?.el.remove(),Is.delete(e),t?ac():/^m\d+$/.test(e)&&tc()}function hc(){return[...Is.keys()]}function gc(e,t,n){let r=t.map(e=>e.label+`\0`+e.cmd).join(``);e.foot.dataset.sig!==r&&(e.foot.dataset.sig=r,e.foot.replaceChildren(...t.map(e=>{let t=document.createElement(`button`);return t.textContent=e.label,t.dataset.cmd=e.cmd,t.addEventListener(`click`,()=>n(e.cmd)),t})))}function _c(e,t){t.addEventListener(`pointerdown`,n=>{if(n.target.classList.contains(`dot`)||e.classList.contains(`min`))return;let r=n.clientX-e.offsetLeft,i=n.clientY-e.offsetTop;t.setPointerCapture(n.pointerId);let a=t=>{let n=Math.max(0,Math.min(innerWidth-60,t.clientX-r)),a=Math.max(0,Math.min(innerHeight-24,t.clientY-i));e.style.left=n+`px`,e.style.top=a+`px`,e.dataset.moved=`1`},o=()=>{t.removeEventListener(`pointermove`,a),t.removeEventListener(`pointerup`,o)};t.addEventListener(`pointermove`,a),t.addEventListener(`pointerup`,o)})}var vc=120,yc=class{g;out;input;shown=0;history=[];hpos=0;win;bar;barKey=``;follow=!1;seenH=0;lastSig=``;constructor(e){this.g=e,this.win=Vs(`console`,`console`,lc()),this.win.el.classList.add(`win-console`),this.out=document.createElement(`div`),this.out.className=`out`;let t=document.createElement(`label`);t.className=`in`,t.textContent=`> `,this.input=document.createElement(`input`),this.input.spellcheck=!1,this.input.autocomplete=`off`,t.append(this.input),this.bar=document.createElement(`div`),this.bar.className=`acts`,this.win.body.append(this.out,t,this.bar),this.input.addEventListener(`keydown`,e=>{if(e.key===`Enter`){let e=this.input.value;this.input.value=``,e.trim()&&this.history.push(e),this.hpos=this.history.length,this.send(e)}else!this.input.value&&!e.ctrlKey&&/^Arrow/.test(e.key)||(e.key===`ArrowUp`&&this.history.length?(this.hpos=Math.max(0,this.hpos-1),this.input.value=this.history[this.hpos],e.preventDefault()):e.key===`ArrowDown`&&(this.hpos=Math.min(this.history.length,this.hpos+1),this.input.value=this.history[this.hpos]??``,e.preventDefault()));e.stopPropagation()}),this.win.el.addEventListener(`click`,e=>{e.target.tagName!==`BUTTON`&&this.input.focus()})}send(e){for(let t of e.split(`;`))W(this.g,t);this.follow=!0,this.draw()}draw(){let e=this.g.log,t=this.out;this.shown>e.length&&(t.replaceChildren(),this.shown=0);let n=t.scrollHeight-t.scrollTop-t.clientHeight<24||this.follow||this.seenH>0&&t.clientHeight!==this.seenH,r=!1;if(this.shown&&this.shown<=e.length&&bc(e[this.shown-1])!==this.lastSig&&t.lastElementChild&&(t.lastElementChild.replaceWith(xc(e[this.shown-1],e=>this.send(e))),r=!0),this.shown<e.length){for(;this.shown<e.length;this.shown++)t.append(xc(e[this.shown],e=>this.send(e)));for(;t.childElementCount>vc;)t.firstElementChild.remove();r=!0}this.shown&&(this.lastSig=bc(e[this.shown-1])),(r||this.follow||t.clientHeight!==this.seenH)&&n&&(t.scrollTop=t.scrollHeight),this.follow=!1,this.seenH=t.clientHeight,this.drawBar()}drawBar(){let e=this.g.ended?[]:Ie(this.g),t=JSON.stringify(e);t!==this.barKey&&(this.barKey=t,this.bar.replaceChildren(...e.map(([e,t])=>{let n=document.createElement(`div`),r=document.createElement(`span`);r.className=`echo`,r.textContent=e,n.append(r);for(let e of t){let t=document.createElement(`button`);t.textContent=e.label,t.dataset.cmd=e.cmd,t.addEventListener(`click`,()=>this.send(e.cmd)),n.append(t)}return n})))}},bc=e=>e.map(e=>typeof e==`string`?e:e.text).join(``);function xc(e,t){let n=document.createElement(`div`);for(let r of e)if(typeof r==`string`)n.append(r);else if(r.cmd){let e=document.createElement(`button`);e.textContent=r.text,e.dataset.cmd=r.cmd,e.addEventListener(`click`,()=>t(r.cmd)),n.append(e)}else{let e=document.createElement(`span`);e.className=`echo`,e.textContent=r.text,n.append(e)}return n}var Sc=class{p=Array(256).fill(``);set(e,t,n){e=Math.round(e),t=Math.round(t),e>=0&&t>=0&&e<16&&t<16&&(this.p[t*16+e]=n)}get(e,t){return this.p[t*16+e]??``}rect(e,t,n,r,i){for(let a=t;a<=r;a++)for(let t=e;t<=n;t++)this.set(t,a,i)}line(e,t,n,r,i){let a=Math.max(Math.abs(n-e),Math.abs(r-t),1);for(let o=0;o<=a;o++)this.set(e+(n-e)*o/a,t+(r-t)*o/a,i)}circle(e,t,n,r,i=!1){for(let a=0;a<16;a++)for(let o=0;o<16;o++){let s=Math.hypot(o+.5-e,a+.5-t);(i?s<=n:Math.abs(s-n)<.55)&&this.set(o,a,r)}}arc(e,t,n,r,i,a){for(let o=0;o<16;o++)for(let s=0;s<16;s++){let c=s+.5-e,l=o+.5-t,u=Math.atan2(l,c);u<r&&(u+=Math.PI*2),Math.abs(Math.hypot(c,l)-n)<.55&&u>=r&&u<=i&&this.set(s,o,a)}}outline(e=Cc){let t=[...this.p];for(let n=0;n<16;n++)for(let r=0;r<16;r++)t[n*16+r]||[[1,0],[-1,0],[0,1],[0,-1]].some(([i,a])=>{let[o,s]=[r+i,n+a];return o>=0&&s>=0&&o<16&&s<16&&t[s*16+o]&&t[s*16+o]!==e})&&(this.p[n*16+r]=e)}},Cc=`#0b0807`,wc=`#d8c8b0`,Tc=`#8a7a66`,Ec=`#b07838`,Dc=`#6a4420`,Oc=`#f0a050`,kc=`#ffd070`,Ac=`#a04428`,jc=`#5a6470`,Mc=`#a8c8ff`,Nc=`#9fd8d0`,Pc=`#e05838`,Fc=`#c06070`,Ic=[`#4a3a2c`,`#8a5030`,`#6a7c90`,`#c09040`];function Lc(e,t){let n=new Sc;return e.forEach((e,r)=>[...e].forEach((e,i)=>t[e]&&n.set(i,r,t[e]))),n}var Rc=(e,t,n=0)=>typeof e[t]==`number`?e[t]:n;function zc(e,t,n){let r=String(t.filter??`color`),i=r===`gray`||r===`1bit`?Tc:r===`heat`?Pc:r===`sonar`?Nc:r===`edge`?Mc:Oc,a=Rc(t,`res`,64),o=a<=32?4.6:a<=64?5.6:6.6,s=G(...[...n].map(e=>e.charCodeAt(0)))%3;if(s===1?(e.rect(8-o,8-o,7+o,7+o,Dc),e.rect(9-o,9-o,6+o,6+o,Ec)):(e.circle(8,8,o,Ec,!0),e.circle(8,8,o,Dc)),s===2)for(let t=0;t<8;t++)e.set(8+Math.cos(t/8*Math.PI*2)*(o+.6)-.5,8+Math.sin(t/8*Math.PI*2)*(o+.6)-.5,kc);let c=a<=32?1.6:o-2.4;e.circle(8,8,c+1,Cc,!0),e.circle(8,8,c,i,!0),a>32&&e.circle(8,8,Math.max(.8,c*.35),Cc,!0),e.set(9,6,wc),r===`1bit`&&e.rect(6,7,7,8,wc),r===`sonar`&&[0,1].forEach(t=>e.arc(8,8,o+1.5+t*1.6,-.7,.7,Nc)),r===`heat`&&[[3,2],[5,1],[11,1],[13,2]].forEach(([t,n])=>e.set(t,n,Oc)),r===`edge`&&e.line(8-o,8,7+o,8,Mc),(Rc(t,`lag`)>.5||Rc(t,`blur`)>0)&&[[2,14],[4,15],[12,15],[14,14]].forEach(([t,n])=>e.set(t,n,Tc));for(let n=0;n<Math.min(3,Math.floor(Rc(t,`fps`)/4));n++)e.set(5+n*3,0,Tc)}function Bc(e,t){let n=t.sees??[],r=n.includes(`heat`)?Pc:n.includes(`veins`)?Ec:n.includes(`flesh`)?Fc:n.includes(`enemies`)?Ac:n.includes(`doors`)?wc:Nc,i=Math.max(1,Math.min(3,Math.round(Rc(t,`range`,8)/4))),a=t.shape===`cone`;for(let t=0;t<i;t++){let n=3+t*2.4;a?e.arc(3,13,n,-Math.PI/2,0,r):e.circle(8,8,n,t===0?r:Tc)}a?(e.rect(1,12,4,14,Ec),e.set(2,13,r)):e.circle(8,8,1.3,r,!0)}function Vc(e,t){let n=typeof t.color==`string`?`#`+t.color:Oc,r=Math.min(7,2+Rc(t,`radius`,3)*.7);e.circle(8,8,r,Dc);for(let t=4;t<=12;t++){let r=Math.max(0,Math.round((t-4)*.45+(t>9?-(t-9)*.9:0)));e.rect(8-r,t,7+r+ +(t>6),t,n)}e.set(8,3,n),e.rect(7,9,8,11,kc),Rc(t,`flicker`)>.2&&[[3,5],[12,4],[13,10]].forEach(([t,n])=>e.set(t,n,kc))}function Hc(e,t){t.pilot?(e.circle(5,7,3.6,Tc,!0),e.circle(11,7,3.6,Tc,!0),e.circle(5,11.5,2.2,Dc,!0),e.circle(11,11.5,2.2,Dc,!0),e.rect(7,4,8,13,Ec),e.set(6,2,Ec),e.set(9,2,Ec),t.avoid&&[[5,7],[10,7]].forEach(([t,n])=>e.rect(t,n,t+1,n,Oc))):t.dig?(e.arc(8,11,7,Math.PI*1.15,Math.PI*1.85,wc),e.arc(8,11,6,Math.PI*1.15,Math.PI*1.85,Tc),e.line(8,4,8,15,Ec)):t.free||t.keys?(e.circle(8,8,6,Ec),e.arc(8,8,4,0,Math.PI,Tc),e.arc(8,8,4,Math.PI,Math.PI*2,wc),e.circle(8,8,1.8,t.free?Oc:kc,!0)):(e.rect(4,2,11,4,Ec),e.line(5,5,3,10,wc),e.line(3,10,5,14,wc),e.line(10,5,12,10,wc),e.line(12,10,10,14,wc),e.set(3,10,Oc),e.set(12,10,Oc),e.rect(4,14,6,14,Dc),e.rect(9,14,11,14,Dc))}function Uc(e,t){let n=Rc(t,`damage`,1),r=n>=5?kc:n>=2?Mc:wc;if(t.aim===`aimed`){let i=Rc(t,`cooldown`,1)<.5,a=Rc(t,`range`,6)>=8;if(i){for(let[t,n]of[[0,0],[-4,-1],[-1,4]])e.line(5+t,10+n,9+t,6+n,Ec),e.rect(9+t,5+n,10+t,6+n,r);return}e.line(a?1:3,a?14:12,12,3,Ec);let o=n>=5?2:+(n>=2);e.rect(12-o,3,13,4+o-1,r),e.rect(12,2-o,13+o,3,r),e.set(14,1,r),a?[[1,12],[2,13],[3,14],[0,13]].forEach(([t,n])=>e.set(t,n,Oc)):e.line(2,10,4,12,Oc);return}if(Rc(t,`range`,1.5)>=3){e.line(8,1,8,15,r),e.line(1,8,15,8,r),e.line(3,3,13,13,Oc),e.line(13,3,3,13,Oc),e.circle(8,8,1.6,kc,!0);return}if(t.sweep||Rc(t,`range`,1.5)>=2.2){e.line(2,14,6,10,Ec);for(let t=0;t<4;t++)e.set(7+t,9-t,t%2?Tc:wc);e.circle(12,4.5,2.6,r,!0),e.set(12,4,Oc),t.sweep&&e.arc(8,8,7,Math.PI*1.05,Math.PI*1.5,Oc);return}let i=n>=3?2:1;for(let t=0;t<=i;t++)e.line(3+t,13,12+t,4,t===0?wc:r);e.set(13+i-1,3,wc),e.line(3,10,6,13,Ec),e.line(2,14,3,13,Dc),Rc(t,`cooldown`,1)<1&&e.line(9,13,13,9,Tc)}function Wc(e,t){if(t.hp||t.regen||t.mend){e.circle(5.5,6,3,Fc,!0),e.circle(10.5,6,3,Fc,!0);for(let t=7;t<=13;t++)e.rect(2+(t-7),t,13-(t-7),t,Fc);e.set(5,4,wc),(t.regen||t.mend)&&[[6,9],[8,8],[10,9]].forEach(([t,n])=>e.set(t,n,wc)),t.hp&&e.rect(7,6,8,11,kc);return}if(t.haste){for(let t=3;t<=13;t+=2)e.line(4,t,11,t+1,Ec);e.line(4,3,4,13,Dc),e.line(11,4,11,14,Dc),e.line(9,1,6,8,kc),e.line(6,8,10,8,kc),e.line(10,8,7,15,kc);return}if(t.ward){for(let t=1;t<=14;t++){let n=7-Math.abs(t-7.5);e.rect(8-n,t,7+n,t,t<8?Mc:jc)}e.line(5,7,8,4,wc);return}let n=t.heatproof?Oc:t.thorns?Ac:Tc;e.rect(3,2,12,9,jc);for(let t=10;t<=14;t++)e.rect(3+(t-9),t,12-(t-9),t,jc);for(let n=0;n<Math.min(3,Math.ceil(Rc(t,`armour`,1)*2));n++)e.rect(5,4+n*3,10,4+n*3,Tc);e.line(3,2,12,2,n),e.line(3,2,3,9,n),e.line(12,2,12,9,n),t.thorns&&[[2,4],[13,4],[2,8],[13,8],[8,15]].forEach(([t,n])=>e.set(t,n,Ac)),t.haste&&[[1,3],[0,5],[14,3],[15,5]].forEach(([t,n])=>e.set(t,n,kc))}function Gc(e,t){let n=String(t.what??``);if(n===`map`)e.rect(2,3,13,12,wc),e.rect(1,2,2,13,Ec),e.rect(13,2,14,13,Ec),e.line(4,10,6,6,Ac),e.line(6,6,9,8,Ac),e.line(9,8,11,5,Ac),e.set(11,5,Oc),Rc(t,`span`)>40&&e.rect(4,4,5,4,Tc);else if(n===`compass`)e.circle(8,8,6.5,Ec,!0),e.circle(8,8,5.2,Cc,!0),e.line(8,3,8,8,Oc),e.line(8,8,8,13,Tc),e.set(8,2,kc);else if(n===`clock`){e.circle(8,8,6.5,Tc,!0),e.circle(8,8,5.4,Cc,!0);for(let t=0;t<12;t+=3)e.set(8+Math.round(Math.sin(t/12*Math.PI*2)*4.5),8-Math.round(Math.cos(t/12*Math.PI*2)*4.5),wc);e.line(8,8,8,4,Oc),e.line(8,8,11,9,wc)}else if(n===`reader`)e.rect(2,8,13,14,Ec),e.rect(3,9,12,9,Cc),e.rect(5,2,10,9,wc),e.rect(6,4,9,4,Tc),e.rect(6,6,8,6,Tc),e.set(11,12,Oc);else{e.rect(3,2,12,14,n===`log`?Ac:Dc),e.rect(4,3,11,13,wc),e.line(7,3,7,13,Tc);for(let t=5;t<=11;t+=2)e.line(9,t,10,t,Tc);if(Rc(t,`keep`)>8)for(let t=3;t<=13;t+=2)e.set(13,t,kc);n===`log`&&e.rect(10,1,10,4,Oc)}}function Kc(e,t){if(t.slots){e.rect(3,3,12,12,`#2a3a2a`),e.rect(5,5,10,10,jc);for(let t=4;t<=11;t+=2)e.set(t,1,Ec),e.set(t,14,Ec),e.set(1,t,Ec),e.set(14,t,Ec),e.set(t,2,Dc),e.set(t,13,Dc);e.rect(7,7,8,8,Oc);return}let n=Rc(t,`power`,2);e.rect(4,1,11,2,Ec),e.rect(3,3,12,14,jc),e.rect(4,4,11,13,Cc);let r=Math.min(5,n);for(let t=0;t<r;t++)e.rect(5,12-t*2,10,12-t*2,t===r-1?kc:Oc);e.set(6,2,kc)}function qc(e,t){let n=Rc(t,`drain`,1)>1?12:10;e.line(13,2,13-n,2+n,wc),e.line(13,3,14-n,3+n,Tc),e.rect(11,1,14,4,Ec),e.circle(2.5+(12-n),13.5,1.4,Pc,!0)}function Jc(e){for(let t=1;t<=14;t++){let n=t<6?(t-1)*.8:(14-t)*.45;e.rect(8-n,t,7+n,t,t<6?kc:Oc)}e.line(8,2,8,12,`#fff0c0`),e.set(5,6,wc)}function Yc(e,t){let n=G(...[...t].map(e=>e.charCodeAt(0)));for(let t=0;t<5;t++)for(let r=0;r<3;r++)n>>t*3+r&1&&(e.rect(3+r*2,3+t*2,4+r*2,4+t*2,wc),e.rect(11-r*2,3+t*2,12-r*2,4+t*2,wc))}var Xc={camera:zc,scanner:Bc,lamp:Vc,gait:Hc,weapon:Uc,body:Wc,mind:Gc,power:Kc,tool:qc,unique:e=>Jc(e)};function Zc(e,t){let n=a({mod:e}),r=new Sc;(Xc[n.family]??(t=>Yc(t,e)))(r,{...n.params,...t?{[t.key]:Rc(n.params,t.key)*t.mult}:{}},e),r.outline();let i=Ic[Math.min(3,n.tier)];for(let[e,t,n,a]of[[0,0,1,1],[15,0,-1,1],[0,15,1,-1],[15,15,-1,-1]])r.get(e,t)||r.set(e,t,i),r.get(e+n,t)||r.set(e+n,t,i),r.get(e,t+a)||r.set(e,t+a,i);return(t?.tag===`attuned`||t?.tag===`tempered`)&&[[13,1],[12,2],[14,2],[13,3]].forEach(([e,t])=>r.set(e,t,`#fff6d0`)),t?.tag===`cracked`&&(r.line(2,4,7,9,Cc),r.line(7,9,5,13,Cc)),r}var Qc={bone:Lc([`................`,`..##........##..`,`.#BB#......#BB#.`,`.#BBB#....#BBB#.`,`..#BBB####BBB#..`,`...#BBBBBBBB#...`,`....#bbbbbb#....`,`....#bbbbbb#....`,`...#BBBBBBBB#...`,`..#BBB####BBB#..`,`.#BBB#....#BBB#.`,`.#BB#......#BB#.`,`..##........##..`,`................`],{"#":Cc,B:wc,b:jc}),glass:Lc([`.......##.......`,`......#gg#......`,`.....#gWgg#.....`,`....#gWggGg#....`,`...#gWggGGgg#...`,`..#gggggGGggg#..`,`.#ggggggGGgggg#.`,`..#GGgggGGgGG#..`,`...#GGggGGGG#...`,`....#GGgGGG#....`,`.....#GGGG#.....`,`......#GG#......`,`.......##.......`],{"#":Cc,g:Nc,G:`#5a9890`,W:`#e8fff8`}),copper:Lc([`................`,`.....####.......`,`....#cccC##.....`,`...#cWcccCC#....`,`..#cWccccCCC##..`,`..#cccccCCCCCC#.`,`.#ccccCCCCCCdC#.`,`.#cccCCCCCCddd#.`,`.#CCCCCCCCddd#..`,`..#CCCCCdddd#...`,`...#ddddddd#....`,`....#######.....`],{"#":Cc,c:`#e08a48`,C:Ec,d:Dc,W:kc}),ichor:Lc([`.......#........`,`......#i#.......`,`......#i#.......`,`.....#iii#......`,`.....#iii#......`,`....#iWiii#.....`,`...#iWiiiii#....`,`...#iiiiiiI#....`,`..#iiiiiiiII#...`,`..#iiiiiiIII#...`,`..#IiiiiIIII#...`,`...#IIIIIII#....`,`....#IIIII#.....`,`.....#####......`],{"#":Cc,i:Pc,I:`#902818`,W:kc})};function $c(e){let t=!e.startsWith(`log`),n=new Sc;if(n.rect(3,1,12,14,t?`#3a2410`:jc),n.rect(4,2,11,13,t?`#5a3a18`:`#3a4048`),t)n.circle(8,7,2.6,kc),n.line(8,3,8,12,kc),n.set(8,7,`#fff0c0`);else{for(let e=4;e<=11;e+=2)n.line(5,e,e%4?10:9,e,Tc);n.rect(9,11,10,12,Oc)}return n.rect(5,14,10,15,Ec),n.outline(),n}var el={printer:Lc([`................`,`..############..`,`..#SSSSSSSSSS#..`,`..#S########S#..`,`..#S#eeeeee#S#..`,`..#S########S#..`,`..#SSSSSSSSSS#..`,`.##############.`,`.#ssssssssssss#.`,`.#s#BBBBBBBB#s#.`,`.#s#BbbbbbbB#s#.`,`.#s##########s#.`,`.#ssssssssssss#.`,`.##############.`,`..##........##..`],{"#":Cc,S:jc,s:`#3a4048`,e:Oc,B:wc,b:Tc}),shop:Lc([`......####......`,`....##GGGG##....`,`...#GG####GG#...`,`..#G##....##G#..`,`..#G#......#G#..`,`.#G#........#G#.`,`.#G#.e..e..e#G#.`,`.#G#........#G#.`,`.#G##########G#.`,`.#GBBBBBBBBBBG#.`,`.#G##########G#.`,`.#GG#......#GG#.`,`.#GG#......#GG#.`,`################`],{"#":Cc,G:`#c09040`,B:Dc,e:Oc}),altar:Lc([`.......#........`,`......#f#.......`,`.....#fFf#......`,`.....#fFf#......`,`......#f#.......`,`...##########...`,`..#BBBBBBBBBB#..`,`..############..`,`....#bbbbbb#....`,`....#b#bb#b#....`,`....#bbbbbb#....`,`....#b#bb#b#....`,`...##########...`,`..#BBBBBBBBBB#..`,`..############..`],{"#":Cc,B:wc,b:Tc,f:Oc,F:kc}),enemy:Lc([`................`,`.....######.....`,`...##rrrrrr##...`,`..#rrRRRRRRrr#..`,`..#rR#RRRR#Rr#..`,`..#rRRRRRRRRr#..`,`...#rR####Rr#...`,`....#rrrrrr#....`,`...#.#....#.#...`,`..#...#..#...#..`],{"#":Cc,r:Ac,R:Pc})};function tl(e){let t=e===`bone`?wc:e===`glass`?Nc:e===`copper`?`#e08a48`:Pc,n=new Sc;n.rect(0,0,15,15,`#2a201a`),n.rect(0,0,15,0,`#3a2e24`);for(let e=0;e<3;e++)n.line(1+e*5,15,4+e*4,2+e*3,t);return n.line(2,6,13,9,Tc),n}function nl(e){if(`thing`in e)return`thing:`+e.thing;if(`vein`in e)return`vein:`+e.vein;if(`kind`in e&&e.kind===`res`)return`res:`+e.res;if(`kind`in e&&e.kind===`card`)return`card:`+e.card;let t=e;return`mod:${t.mod}:${t.roll?`${t.roll.key}:${t.roll.tag}`:``}`}function rl(e){if(`thing`in e)return el[e.thing];if(`vein`in e)return tl(e.vein);if(`kind`in e&&e.kind===`res`)return Qc[e.res]??il(e.res);if(`kind`in e&&e.kind===`card`)return $c(e.card);let t=e;return Zc(t.mod,t.roll)}function il(e){let t=new Sc;return Yc(t,e),t}var al=new Map;function ol(e){let t=nl(e),n=al.get(t);if(n)return n;let r=document.createElement(`canvas`);r.width=r.height=16;let i=r.getContext(`2d`),a=rl(e);for(let e=0;e<16;e++)for(let t=0;t<16;t++){let n=a.get(t,e);n&&(i.fillStyle=n,i.fillRect(t,e,1,1))}return n=r.toDataURL(),al.set(t,n),n}function sl(e,t=2){let n=document.createElement(`img`);return n.className=`icon`,n.src=ol(e),n.width=n.height=16*t,n.draggable=!1,n}var cl=(e,t)=>!!H[t]&&(!H[t].when||H[t].when(e)),ll=2;function ul(e,t){let n=e>=t;if(Math.max(t,e)>8)return`<span class="pips bar${n?` full`:``}"><b style="width:${Math.min(100,e/Math.max(1,t)*100)}%"></b></span>`;let r=``;for(let n=0;n<Math.max(t,e);n++)r+=`<b class="${n<e?`used`:``}${n>=t?` over`:``}"></b>`;return`<span class="pips${n?` full`:``}">${r}</span>`}var dl=e=>[ye(e),be(e),a(e).text],fl=class{g;send;keys=new Map;sel=new Map;constructor(e,t){this.g=e,this.send=t;for(let[e,t]of[[`modules`,`modules`],[`inv`,`inventory`],[`near`,`nearby`]])Vs(e,t,[innerWidth-260-16,32]).el.classList.add(`panel`,`panel-`+e)}frame(){let e=this.g,[t,n]=this.modules(e);this.grid(`modules`,t,n,this.head(e),``,this.setups(e));let[r,i]=this.inv(e);this.grid(`inv`,r,i,``,r.length?``:`you carry nothing.`),this.list(`near`,this.near(e)),this.stack()}head(e){let t=e.player;return`<div class="res-row"><span>slots ${t.installed.length}/${t.slots}</span>${ul(t.installed.length,t.slots)}</div><div class="res-row"><span>power ${d(e)}/${u(e)}</span>${ul(d(e),u(e))}</div>`}setups(e){let t=Ze(e),n=Object.keys(t),r=n.length+1;for(;n.includes(String(r));)r++;let i=e.player.installed.filter(e=>e.on).map(e=>e.mod).sort().join();return[...n.map((e,n)=>({label:n<4&&e!==String(n+1)?`${n+1} ${e}`:e,cmd:`setup ${e}`,on:[...t[e]].sort().join()===i})),{label:`+ save`,cmd:`save setup ${r}`}]}modules(e){let t=e.player,n=t.installed.map(t=>{let n=t.on?c(e,t)?`on`:`warm`:`off`;return{sel:`u`+t.uid,icon:{mod:t.mod,roll:t.roll},title:`${s(t)} · ${n}`,state:n,mod:t.mod,dbl:`${t.on?`off`:`on`} ${Ee(e,t)}`}});for(let e=t.installed.length;e<t.slots;e++)n.push({sel:`empty`+e,title:`an empty socket`});let r=this.sel.get(`modules`),i=t.installed.find(e=>`u`+e.uid===r);return i?[n,{icon:{mod:i.mod,roll:i.roll},title:s(i),lines:[i.on?c(e,i)?`on`:`warming up`:`off`,...dl(i)],buttons:[{label:i.on?`off`:`on`,cmd:`${i.on?`off`:`on`} ${Ee(e,i)}`},{label:`remove`,cmd:`remove ${Ee(e,i)}`}]}]:[n,null]}inv(e){let t=e.player,n=t.installed.length<t.slots,r=u(e)-d(e),i=new Map,o=[],c=null,l=this.sel.get(`inv`);for(let u of t.inv){let t=u.kind===`res`?u.res:u.kind===`card`?`memory card`:s(u),d=(i.get(t)??0)+1;i.set(t,d);let f=`${t}#${d}`,p={label:`drop`,cmd:`drop ${pl(u)}`},m,h,g;if(u.kind===`mod`){let t=a(u),i=!n||t.power>r?lt(e,u,!1):null,o=i&&typeof i!=`string`?[...i.remove?[`takes out ${s(i.remove)}`]:[],...i.off.map(e=>`turns off ${s(e)}`)].join(`, `):``,c=i&&typeof i!=`string`?{label:`swap in`,cmd:`swap in ${s(u)}`,note:o||`swap in`}:n?t.power>r?{label:`install`,cmd:`install ${s(u)}`,note:`it stays off: needs ${t.power}⚡︎, ${r} free`}:{label:`install`,cmd:`install ${s(u)}`}:{label:`install`,note:`no free slot: printers sell slots`},l=Ta(u),d=Object.keys(l).length?{label:`recycle`,cmd:`recycle ${s(u)}`,note:`recycle: ${la(l)}`}:{label:`recycle`,note:`it will not break`};h=[c,{label:`?`,cmd:`info ${s(u)}`},d,p],g=dl(u),m={sel:f,icon:u,title:`${s(u)} · ${ye(u)}`,mod:u.mod,dbl:c.cmd,dim:!n}}else if(u.kind===`card`){let t=!u.card.startsWith(`log`);h=[cl(e,`read`)?{label:`read`,cmd:`read card`}:{label:`read`,note:`needs a card reader`},p],g=[t?`a shard of scripture. read it to learn where the engine lies.`:`a machine's last log. read it: it points somewhere.`],m={sel:f,icon:u,title:`memory card`,dbl:cl(e,`read`)?`read card`:void 0}}else h=[p],g=[`${u.n} ${u.res}. printers, reliquaries and altars take it.`],m={sel:f,icon:u,title:`${u.res} ×${u.n}`,badge:String(u.n)};o.push(m),f===l&&(c={icon:u,title:u.kind===`res`?`${u.res} ×${u.n}`:m.title.split(` · `)[0],lines:g,buttons:h})}return[o,c]}near(e){let t=e.player,n=[],r=ge(e);r.length>1&&n.push({name:``,buttons:[{label:`take all`,cmd:`take`}]});for(let e of r){let t=e.item;n.push({icon:t,name:t.kind===`mod`?s(t):L(t),tip:t.kind===`mod`?`${ye(t)}\n${be(t)}`:void 0,buttons:[...t.kind===`mod`?[{label:`?`,cmd:`info ${s(t)}`}]:[],{label:`take`,cmd:`take ${L(t)}`}]})}e.ents.some(e=>e.kind===`printer`&&!e.data?.shop&&R(e,t)<1.6)&&n.push({icon:{thing:`printer`},name:`printer`,buttons:[{label:`print slot`,cmd:`print slot`},{label:`print module`,cmd:`print module`}]});let i=_a(e);i&&(n.push({icon:{thing:`shop`},name:`reliquary`,buttons:[{label:`reroll`,cmd:`reroll`,note:`reroll: ${la(ia.reroll)}`}]}),Sa(e,i).forEach((t,r)=>{if(!t||t.kind!==`mod`)return void n.push({name:`${r+1}. sold`,buttons:[],dim:!0});let a=xa(i,r,t);n.push({icon:t,name:s(t),tip:`${ye(t)}\n${be(t)}`,buttons:[{label:`?`,cmd:`info ${s(t)}`},ua(e,a)?{label:`buy`,cmd:`buy ${r+1}`,note:la(a)}:{label:`buy`,note:`${la(a)}: short`}]})}));let a=Ma(e);if(a){n.push({icon:{thing:`altar`},name:`altar`,buttons:[]});for(let[t,r]of Ga(e,a))n.push({name:``,buttons:[ua(e,r)?{label:t,cmd:t,note:la(r)}:{label:t,note:`${la(r)}: short`}]})}for(let t of zo(e))n.push({icon:t.item,name:`${t.name} ${Math.round(t.r)} ${t.side}`,tip:`${t.name}, ${Math.round(t.r)} cells ${t.side}: a set piece's finds`,buttons:[{label:t.cmd.startsWith(`goto`)?`go`:t.cmd,cmd:t.cmd}]});let[o,c]=[Math.floor(t.x),Math.floor(t.y)];for(let[t,r,i]of[[`n`,0,-1],[`e`,1,0],[`s`,0,1],[`w`,-1,0]]){let a=w(e,o+r,c+i),s=a>=h.vein?_(a):null;s&&n.push({icon:{vein:s},name:`${s} vein (${t})`,buttons:[cl(e,`drain`)?{label:`drain`,cmd:`drain`}:{label:`drain`,note:`needs a needle`}]})}return n.length?n:[{name:`nothing here.`,buttons:[],dim:!0}]}grid(e,t,n,r=``,i=``,a=[]){let o=Bs(e);if(!o)return;let s=r+JSON.stringify([t,n,i,a])+(this.sel.get(e)??``);if(this.keys.get(e)===s)return;this.keys.set(e,s),this.sel.has(e)&&!t.some(t=>t.sel===this.sel.get(e))&&this.sel.delete(e);let c=[];if(r){let e=document.createElement(`div`);e.className=`res`,e.innerHTML=r,c.push(e)}if(a.length){let e=document.createElement(`div`);e.className=`setups`;let t=document.createElement(`span`);t.className=`dim`,t.textContent=`setups`,e.append(t,...this.buttons(a)),c.push(e)}if(i){let e=document.createElement(`div`);e.className=`dim`,e.textContent=i,c.push(e)}let l=document.createElement(`div`);l.className=`grid`;for(let n of t){let t=document.createElement(`button`);if(t.className=`cell`+(n.icon?``:` socket`)+(n.state?` st-`+n.state:``)+(n.dim?` dim`:``)+(this.sel.get(e)===n.sel?` sel`:``),t.title=n.title,t.dataset.key=n.sel,n.mod&&(t.dataset.mod=n.mod),n.icon&&t.append(sl(n.icon,ll)),n.badge){let e=document.createElement(`span`);e.className=`badge`,e.textContent=n.badge,t.append(e)}n.icon?(t.addEventListener(`click`,()=>{this.sel.get(e)===n.sel?this.sel.delete(e):this.sel.set(e,n.sel),this.keys.delete(e),this.frame()}),n.dbl&&t.addEventListener(`dblclick`,()=>this.send(n.dbl))):t.disabled=!0,l.append(t)}t.length&&c.push(l),n&&c.push(this.detail(n)),o.body.replaceChildren(...c)}detail(e){let t=document.createElement(`div`);t.className=`detail`;let n=document.createElement(`div`);n.className=`dtop`,n.append(sl(e.icon,3));let r=document.createElement(`span`);return r.className=`name`,r.textContent=e.title,n.append(r),t.append(n),e.lines.forEach((n,r)=>{let i=document.createElement(`div`);i.className=r===e.lines.length-1&&e.lines.length>2?`flavour-line`:`does`,i.textContent=n,t.append(i)}),t.append(...this.buttons(e.buttons)),t}buttons(e){let t=document.createElement(`div`);t.className=`btns`;let n=[];for(let r of e){let e=document.createElement(`button`);if(e.textContent=r.label,r.on&&(e.className=`on`),r.cmd?(e.dataset.cmd=r.cmd,e.addEventListener(`click`,()=>this.send(r.cmd))):e.disabled=!0,r.note){e.title=r.note;let t=document.createElement(`span`);t.className=`dim note`,t.textContent=r.note,n.push(t)}t.append(e)}return e.length?[t,...n]:n}list(e,t){let n=Bs(e);if(!n)return;let r=JSON.stringify(t);this.keys.get(e)!==r&&(this.keys.set(e,r),n.body.replaceChildren(...t.map(e=>{let t=document.createElement(`div`);if(t.className=`row`+(e.dim?` dim`:``),e.icon&&t.append(sl(e.icon,ll)),e.name){let n=document.createElement(`span`);n.className=`name`,n.textContent=e.name,e.tip&&(n.title=e.tip),t.append(n)}return t.append(...this.buttons(e.buttons)),t})))}stack(){let e=[`modules`,`inv`,`near`].map(e=>Bs(e)).filter(e=>e&&!e.el.dataset.moved),t=e=>e.el.offsetHeight-e.body.clientHeight+e.body.scrollHeight,n=innerHeight-32-8-(e.length-1)*8,r=e.map(t).reduce((e,t)=>e+t,0),i=new Map;if(r>n){let r=[`near`,`modules`,`inv`].map(t=>e.find(e=>e.id===t)).filter(e=>!!e),a={near:150,modules:140,inv:100};for(let e of r)i.set(e,Math.min(t(e),a[e.id]));n-=[...i.values()].reduce((e,t)=>e+t,0);for(let e of r){let r=Math.max(0,Math.min(n,t(e)-i.get(e)));i.set(e,i.get(e)+r),n-=r}}let a=32;for(let t of e){let e=i.get(t),n=t.el.offsetHeight-t.body.clientHeight,r=e?Math.max(60,e-n)+`px`:``;t.body.style.maxHeight!==r&&(t.body.style.maxHeight=r);let o=t.body;o.classList.toggle(`more`,o.scrollHeight-o.scrollTop-o.clientHeight>2),t.el.style.left=innerWidth-260-16+`px`,t.el.style.top=a+`px`,a+=t.el.offsetHeight+8}}};function pl(e){return e.kind===`res`?e.res:e.kind===`card`?`memory card`:s(e)}if(/[?&]icons\b/.test(globalThis.location?.search??``)){let t=()=>{let t=document.createElement(`div`);t.className=`icon-sheet`;let n=(e,n)=>{let r=document.createElement(`figure`);r.append(sl(e,3));let i=document.createElement(`figcaption`);i.textContent=n,r.append(i),t.append(r)},r=Object.values(e).sort((e,t)=>e.family.localeCompare(t.family)||e.tier-t.tier);for(let e of r)n({mod:e.id},e.name);let i=r.find(e=>e.family===`weapon`);n({mod:i.id,roll:{key:`damage`,mult:1.4,tag:`attuned`}},`attuned ${i.name}`),n({mod:i.id,roll:{key:`damage`,mult:.7,tag:`cracked`}},`cracked ${i.name}`);for(let e of Re)n({kind:`res`,res:e,n:1},e);for(let e of Re)n({vein:e},`${e} vein`);n({kind:`card`,card:`log-surveyor`},`log card`),n({kind:`card`,card:`shard-1`},`scripture`),n({thing:`printer`},`printer`),n({thing:`shop`},`reliquary`),n({thing:`altar`},`altar`),document.body.append(t)};document.readyState===`loading`?addEventListener(`DOMContentLoaded`,t):setTimeout(t,0)}var ml=`#f0a050`;function hl(e){let t=e.player,n=[];for(let r of js){if(t.inv.some(e=>e.kind===`mod`&&e.mod===r)||t.installed.some(e=>e.mod===r))continue;let i=e.ents.find(e=>e.kind===`item`&&e.item?.kind===`mod`&&e.item.mod===r&&!e.data?.mimic);i&&n.push({x:i.x,y:i.y,name:L(i.item)})}for(let t of e.vectors)t.found||n.push({x:t.x,y:t.y,name:t.what});let r=Ms(e);return r&&n.push({x:r.x,y:r.y,name:`a reliquary`}),n}var gl=`legend: ◆ where the hints and cards point · green ◇ a set piece's finds · small dot a pile (bone, glass, copper, ichor) · small square a module · teal printer or reliquary · red enemy · arrow you`,_l=new WeakMap;function vl(e){e.addEventListener(`mousemove`,t=>{let n=_l.get(e);if(!n)return;let r=e.getBoundingClientRect(),i=n.ox+Math.floor((t.clientX-r.left)/r.width*(e.width/n.px)),a=n.oy+Math.floor((t.clientY-r.top)/r.height*(e.height/n.px)),o=`${yl(n.g,i,a)}\n\n${gl}`;e.title!==o&&(e.title=o)});let t=document.createElement(`p`);t.className=`map-legend`,t.innerHTML=`<i style="color:${ml}">◆</i> hints · <i style="color:#b0f080">◇</i> finds · <i style="color:#7fd8d0">•</i> piles · <i style="color:${ml}">▪</i> mods · `;let n=document.createElement(`button`),r=()=>oo.zoom??innerHeight>=900;n.textContent=r()?`smaller`:`zoom`,addEventListener(`resize`,()=>n.textContent=r()?`smaller`:`zoom`);let i=()=>document.querySelectorAll(`.map-legend .zoom`).forEach(e=>e.textContent=r()?`smaller`:`zoom`);n.className=`zoom`,n.addEventListener(`click`,()=>{oo.zoom=!r(),i();let t=e.closest(`.win`);t&&setTimeout(()=>{nc(t)||(oo.zoom=!r(),i(),n.textContent=`no room to zoom`,setTimeout(i,1500))},100)});let a=document.createElement(`button`);a.textContent=`where`,a.title=`where the hints point, again`,a.addEventListener(`click`,()=>window.thaw.send(`where`));let o=document.createElement(`button`);o.textContent=`vectors`,o.className=`map-vectors`,o.addEventListener(`click`,()=>window.thaw.send(`vectors`));let s=document.createElement(`span`);s.textContent=` · `,t.append(n,` · `,a,s,o),o.hidden=s.hidden=!0,e.after(t)}function yl(e,t,n){let r=e.player,i=e=>Math.floor(e.x)===t&&Math.floor(e.y)===n,a=hl(e).find(i);if(i(r))return`you`;if(a)return`${a.name} (the hints point here)`;if(!e.seen.has(`${t},${n}`))return`unseen`;let o=e.ents.find(e=>i(e)&&(e.kind===`printer`||e.kind===`item`||e.enemy&&!N[e.enemy.type]?.hidden));if(o?.kind===`printer`)return o.data?.shop?`reliquary`:`printer`;if(o?.enemy)return N[o.enemy.type]?.name??`something moving`;if(o?.item&&!o.data?.mimic)return L(o.item);let s=w(e,t,n),c=_(s);return s===h.floor?`floor`:c?`${c} vein`:`wall`}ao.draw.push((e,t,n,r,i)=>{let a=t.canvas;_l.has(a)||vl(a),_l.set(a,{g:e,ox:n,oy:r,px:i});let o=a.parentElement?.querySelector(`.map-vectors`);o&&o.hidden===!!e.vectors.length&&(o.hidden=o.previousElementSibling.hidden=!e.vectors.length);let[s,c]=[a.width,a.height];for(let a of hl(e)){let e=(a.x-n)*i,o=(a.y-r)*i;if(e<0||o<0||e>=s||o>=c){let[t,n]=[e-s/2,o-c/2],r=(s/2-6)/Math.max(Math.abs(t),Math.abs(n));[e,o]=[s/2+t*r,c/2+n*r]}let l=Math.max(5,i*.8);t.fillStyle=`#000`,t.beginPath(),t.moveTo(e,o-l-2),t.lineTo(e+l+2,o),t.lineTo(e,o+l+2),t.lineTo(e-l-2,o),t.closePath(),t.fill(),t.fillStyle=ml,t.beginPath(),t.moveTo(e,o-l),t.lineTo(e+l,o),t.lineTo(e,o+l),t.lineTo(e-l,o),t.closePath(),t.fill()}});var bl=new WeakSet;ao.click.push((e,t,n)=>{if(H.goto&&(!H.goto.when||H.goto.when(e)))return;let r=e.player;if(Math.floor(r.x)===t&&Math.floor(r.y)===n)return;let i=window.thaw.send,a=Ts(e,t+.5,n+.5);if(!a)return F(e,`no open way there that you know of.`);let s=l(e,`gait`).some(e=>o(e,`go`,!1));i(s?`go ${a[0]} ${a[1]}`:`crawl ${a[0]}`),s&&xl.set(e,{x:t,y:n,hp:r.hp,at:`${Math.floor(r.x)},${Math.floor(r.y)}`,legs:1,log:e.log.length}),!bl.has(e)&&(bl.add(e),F(e,`the stepper walks it leg by leg, until you arrive or something hits you. a pilot (the wayfinder moth) walks it faster.`))});var xl=new WeakMap;P.push(e=>{let t=xl.get(e);if(!t)return;let n=e.player,r=n.hp<t.hp;if(t.hp=n.hp,n.path.length&&!r)return;let i=`${Math.floor(n.x)},${Math.floor(n.y)}`,a=e.log.slice(t.log).some(e=>typeof e[0]==`object`&&e[0].text.startsWith(`> `)),s=Ts(e,t.x+.5,t.y+.5)&&Ne.long(e,t.x+.5,t.y+.5);if(r||a||i===t.at||i===`${t.x},${t.y}`||++t.legs>40||!s||!l(e,`gait`).some(e=>o(e,`go`,!1)))return void xl.delete(e);t.at=i,W(e,`go ${s[0]} ${s[1]}`),t.log=e.log.length});var Sl=!1,Cl=!1,wl=null,Tl=()=>Sl||Cl;function El(){typeof document<`u`&&((!wl||!wl.isConnected)&&(wl=document.createElement(`div`),wl.className=`paused`,wl.innerHTML=`<div><span>paused</span><small>p or a click resumes</small></div>`,wl.addEventListener(`click`,()=>Dl(!1)),document.body.append(wl)),wl.hidden=!Tl())}function Dl(e=!Sl){Sl=e,El()}typeof document<`u`&&addEventListener(`visibilitychange`,()=>{Cl=document.visibilityState===`hidden`,El()}),U(`tidy`,{help:`lay the windows out again, none on another (key t)`,run(e){dc(),F(e,`windows tidied. a title in the dock along the bottom opens that window; double-click a title to dock it.`)}}),U(`pause`,{help:`stop the world while you think (key p)`,run(){Dl()}});var Ol=new WeakMap,kl=[],Al=class{g;con;panels;views=new Map;constructor(e){this.g=e,this.con=new yc(e),this.panels=new fl(e,e=>this.con.send(e))}frame(e){let t=this.g,n=new Set(t.player.installed.map(e=>`m`+e.uid));for(let e of hc()){if(!/^m\d+$/.test(e)||n.has(e))continue;let t=Number(e.slice(1));this.views.get(t)?.dispose?.(),this.views.delete(t),mc(e)}for(let n of t.player.installed)this.sync(n,e);this.con.draw(),this.panels.frame();for(let n of kl)n(t,e)}sync(e,n){let r=this.g,i=`m`+e.uid,l=Bs(i),u=a(e);if(!l){l=Vs(i,s(e)),l.el.classList.add(`fam-`+u.family),l.dot.title=`on / off`,l.dot.addEventListener(`click`,()=>this.con.send(`${e.on?`off`:`on`} ${Ee(r,e)}`));let t=document.createElement(`p`);t.className=`does`,l.body.append(t);let n=Qa[u.family];if(n)this.views.set(e.uid,n(l.body,e,r));else{let e=document.createElement(`p`);e.className=`flavour`,e.textContent=u.text,l.body.append(e)}}let d=s(e),f=ye(e),p=d+`\0`+f+`\0`+be(e);if(l.el.dataset.key!==p){l.el.dataset.key=p,l.title.querySelector(`span`).textContent=d;let t=l.body.querySelector(`.does`);t.textContent=f,t.title=be(e)}let m=u.family===`camera`?o(e,`filter`,``):``;Xi.includes(m)&&!r.player.installed.some(t=>t!==e&&t.on&&t.uid<e.uid&&a(t).family===`camera`&&o(t,`filter`,``)===m)?l.el.dataset.layer=`1`:delete l.el.dataset.layer;let h=e.data.flashAt,g=Ol.get(r);g||Ol.set(r,g=new Set),h!==void 0&&Xi.includes(m)&&!g.has(e.uid)&&(g.add(e.uid),l.el.classList.contains(`min`)&&queueMicrotask(()=>ec(l.el)));let _=e.on?c(r,e)?`on`:`warm`:`off`,v=l.el.dataset.state;l.el.dataset.state=_,v===`off`&&_!==`off`?queueMicrotask(()=>$s(l.el)):v&&v!==`off`&&_===`off`&&queueMicrotask(tc),this.views.get(e.uid)?.update(r,n);let y=t[u.family];gc(l,e.on?y?.buttons?.(r,e)??[]:[],e=>this.con.send(e))}},jl=1e3,Ml=1001,Nl=1002,Pl=1003,Fl=1004,Il=1005,Ll=1006,Rl=1007,zl=1008,Bl=1009,Vl=1010,Hl=1011,Ul=1012,Wl=1013,Gl=1014,Kl=1015,ql=1016,Jl=1017,Yl=1018,Xl=1020,Zl=35902,Ql=35899,$l=1021,eu=1022,tu=1023,nu=1026,ru=1027,iu=1028,au=1029,ou=1030,su=1031,cu=1033,lu=33776,uu=33777,du=33778,fu=33779,pu=35840,mu=35841,hu=35842,gu=35843,_u=36196,vu=37492,yu=37496,bu=37488,xu=37489,Su=37490,Cu=37491,wu=37808,Tu=37809,Eu=37810,Du=37811,Ou=37812,ku=37813,Au=37814,ju=37815,Mu=37816,Nu=37817,Pu=37818,Fu=37819,Iu=37820,Lu=37821,Ru=36492,zu=36494,Bu=36495,Vu=36283,Hu=36284,Uu=36285,Wu=36286,Gu=2300,Ku=2301,qu=2302,Ju=2303,Yu=2400,Xu=2401,Zu=2402,Qu=3200,$u=`srgb`,ed=`srgb-linear`,td=`linear`,nd=`srgb`,rd=7680,id=35044,ad=2e3;function od(e){for(let t=e.length-1;t>=0;--t)if(e[t]>=65535)return!0;return!1}function sd(e){return ArrayBuffer.isView(e)&&!(e instanceof DataView)}function cd(e){return document.createElementNS(`http://www.w3.org/1999/xhtml`,e)}function ld(){let e=cd(`canvas`);return e.style.display=`block`,e}var ud={};function dd(...e){let t=`THREE.`+e.shift();console.log(t,...e)}function fd(e){let t=e[0];if(typeof t==`string`&&t.startsWith(`TSL:`)){let t=e[1];t&&t.isStackTrace?e[0]+=` `+t.getLocation():e[1]=`Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.`}return e}function K(...e){e=fd(e);let t=`THREE.`+e.shift();{let n=e[0];n&&n.isStackTrace?console.warn(n.getError(t)):console.warn(t,...e)}}function q(...e){e=fd(e);let t=`THREE.`+e.shift();{let n=e[0];n&&n.isStackTrace?console.error(n.getError(t)):console.error(t,...e)}}function pd(...e){let t=e.join(` `);t in ud||(ud[t]=!0,K(...e))}function md(e,t,n){return new Promise(function(r,i){function a(){switch(e.clientWaitSync(t,e.SYNC_FLUSH_COMMANDS_BIT,0)){case e.WAIT_FAILED:i();break;case e.TIMEOUT_EXPIRED:setTimeout(a,n);break;default:r()}}setTimeout(a,n)})}var hd={0:1,2:6,4:7,3:5,1:0,6:2,7:4,5:3},gd=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){let n=this._listeners;return n!==void 0&&n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){let n=this._listeners;if(n===void 0)return;let r=n[e];if(r!==void 0){let e=r.indexOf(t);e!==-1&&r.splice(e,1)}}dispatchEvent(e){let t=this._listeners;if(t===void 0)return;let n=t[e.type];if(n!==void 0){e.target=this;let t=n.slice(0);for(let n=0,r=t.length;n<r;n++)t[n].call(this,e);e.target=null}}},_d=`00.01.02.03.04.05.06.07.08.09.0a.0b.0c.0d.0e.0f.10.11.12.13.14.15.16.17.18.19.1a.1b.1c.1d.1e.1f.20.21.22.23.24.25.26.27.28.29.2a.2b.2c.2d.2e.2f.30.31.32.33.34.35.36.37.38.39.3a.3b.3c.3d.3e.3f.40.41.42.43.44.45.46.47.48.49.4a.4b.4c.4d.4e.4f.50.51.52.53.54.55.56.57.58.59.5a.5b.5c.5d.5e.5f.60.61.62.63.64.65.66.67.68.69.6a.6b.6c.6d.6e.6f.70.71.72.73.74.75.76.77.78.79.7a.7b.7c.7d.7e.7f.80.81.82.83.84.85.86.87.88.89.8a.8b.8c.8d.8e.8f.90.91.92.93.94.95.96.97.98.99.9a.9b.9c.9d.9e.9f.a0.a1.a2.a3.a4.a5.a6.a7.a8.a9.aa.ab.ac.ad.ae.af.b0.b1.b2.b3.b4.b5.b6.b7.b8.b9.ba.bb.bc.bd.be.bf.c0.c1.c2.c3.c4.c5.c6.c7.c8.c9.ca.cb.cc.cd.ce.cf.d0.d1.d2.d3.d4.d5.d6.d7.d8.d9.da.db.dc.dd.de.df.e0.e1.e2.e3.e4.e5.e6.e7.e8.e9.ea.eb.ec.ed.ee.ef.f0.f1.f2.f3.f4.f5.f6.f7.f8.f9.fa.fb.fc.fd.fe.ff`.split(`.`),vd=Math.PI/180,yd=180/Math.PI;function bd(){let e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(_d[e&255]+_d[e>>8&255]+_d[e>>16&255]+_d[e>>24&255]+`-`+_d[t&255]+_d[t>>8&255]+`-`+_d[t>>16&15|64]+_d[t>>24&255]+`-`+_d[n&63|128]+_d[n>>8&255]+`-`+_d[n>>16&255]+_d[n>>24&255]+_d[r&255]+_d[r>>8&255]+_d[r>>16&255]+_d[r>>24&255]).toLowerCase()}function xd(e,t,n){return Math.max(t,Math.min(n,e))}function Sd(e,t){return(e%t+t)%t}function Cd(e,t,n){return(1-n)*e+n*t}function wd(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return e/4294967295;case Uint16Array:return e/65535;case Uint8Array:case Uint8ClampedArray:return e/255;case Int32Array:return Math.max(e/2147483647,-1);case Int16Array:return Math.max(e/32767,-1);case Int8Array:return Math.max(e/127,-1);default:throw Error(`THREE.MathUtils: Invalid component type.`)}}function Td(e,t){switch(t.constructor){case Float32Array:return e;case Uint32Array:return Math.round(e*4294967295);case Uint16Array:return Math.round(e*65535);case Uint8Array:case Uint8ClampedArray:return Math.round(e*255);case Int32Array:return Math.round(e*2147483647);case Int16Array:return Math.round(e*32767);case Int8Array:return Math.round(e*127);default:throw Error(`THREE.MathUtils: Invalid component type.`)}}var J=class e{static{e.prototype.isVector2=!0}constructor(e=0,t=0){this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw Error(`THREE.Vector2: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw Error(`THREE.Vector2: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,n=this.y,r=e.elements;return this.x=r[0]*t+r[3]*n+r[6],this.y=r[1]*t+r[4]*n+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=xd(this.x,e.x,t.x),this.y=xd(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=xd(this.x,e,t),this.y=xd(this.y,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(xd(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(xd(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let n=Math.cos(t),r=Math.sin(t),i=this.x-e.x,a=this.y-e.y;return this.x=i*n-a*r+e.x,this.y=i*r+a*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},Ed=class{constructor(e=0,t=0,n=0,r=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=r}static slerpFlat(e,t,n,r,i,a,o){let s=n[r+0],c=n[r+1],l=n[r+2],u=n[r+3],d=i[a+0],f=i[a+1],p=i[a+2],m=i[a+3];if(u!==m||s!==d||c!==f||l!==p){let e=s*d+c*f+l*p+u*m;e<0&&(d=-d,f=-f,p=-p,m=-m,e=-e);let t=1-o;if(e<.9995){let n=Math.acos(e),r=Math.sin(n);t=Math.sin(t*n)/r,o=Math.sin(o*n)/r,s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o}else{s=s*t+d*o,c=c*t+f*o,l=l*t+p*o,u=u*t+m*o;let e=1/Math.sqrt(s*s+c*c+l*l+u*u);s*=e,c*=e,l*=e,u*=e}}e[t]=s,e[t+1]=c,e[t+2]=l,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,r,i,a){let o=n[r],s=n[r+1],c=n[r+2],l=n[r+3],u=i[a],d=i[a+1],f=i[a+2],p=i[a+3];return e[t]=o*p+l*u+s*f-c*d,e[t+1]=s*p+l*d+c*u-o*f,e[t+2]=c*p+l*f+o*d-s*u,e[t+3]=l*p-o*u-s*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,r){return this._x=e,this._y=t,this._z=n,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let n=e._x,r=e._y,i=e._z,a=e._order,o=Math.cos,s=Math.sin,c=o(n/2),l=o(r/2),u=o(i/2),d=s(n/2),f=s(r/2),p=s(i/2);switch(a){case`XYZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`YXZ`:this._x=d*l*u+c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`ZXY`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u-d*f*p;break;case`ZYX`:this._x=d*l*u-c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u+d*f*p;break;case`YZX`:this._x=d*l*u+c*f*p,this._y=c*f*u+d*l*p,this._z=c*l*p-d*f*u,this._w=c*l*u-d*f*p;break;case`XZY`:this._x=d*l*u-c*f*p,this._y=c*f*u-d*l*p,this._z=c*l*p+d*f*u,this._w=c*l*u+d*f*p;break;default:K(`Quaternion: .setFromEuler() encountered an unknown order: `+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let n=t/2,r=Math.sin(n);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,n=t[0],r=t[4],i=t[8],a=t[1],o=t[5],s=t[9],c=t[2],l=t[6],u=t[10],d=n+o+u;if(d>0){let e=.5/Math.sqrt(d+1);this._w=.25/e,this._x=(l-s)*e,this._y=(i-c)*e,this._z=(a-r)*e}else if(n>o&&n>u){let e=2*Math.sqrt(1+n-o-u);this._w=(l-s)/e,this._x=.25*e,this._y=(r+a)/e,this._z=(i+c)/e}else if(o>u){let e=2*Math.sqrt(1+o-n-u);this._w=(i-c)/e,this._x=(r+a)/e,this._y=.25*e,this._z=(s+l)/e}else{let e=2*Math.sqrt(1+u-n-o);this._w=(a-r)/e,this._x=(i+c)/e,this._y=(s+l)/e,this._z=.25*e}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<1e-8?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(xd(this.dot(e),-1,1)))}rotateTowards(e,t){let n=this.angleTo(e);if(n===0)return this;let r=Math.min(1,t/n);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x*=e,this._y*=e,this._z*=e,this._w*=e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=t._x,s=t._y,c=t._z,l=t._w;return this._x=n*l+a*o+r*c-i*s,this._y=r*l+a*s+i*o-n*c,this._z=i*l+a*c+n*s-r*o,this._w=a*l-n*o-r*s-i*c,this._onChangeCallback(),this}slerp(e,t){let n=e._x,r=e._y,i=e._z,a=e._w,o=this.dot(e);o<0&&(n=-n,r=-r,i=-i,a=-a,o=-o);let s=1-t;if(o<.9995){let e=Math.acos(o),c=Math.sin(e);s=Math.sin(s*e)/c,t=Math.sin(t*e)/c,this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this._onChangeCallback()}else this._x=this._x*s+n*t,this._y=this._y*s+r*t,this._z=this._z*s+i*t,this._w=this._w*s+a*t,this.normalize();return this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),r=Math.sqrt(1-n),i=Math.sqrt(n);return this.set(r*Math.sin(e),r*Math.cos(e),i*Math.sin(t),i*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},Y=class e{static{e.prototype.isVector3=!0}constructor(e=0,t=0,n=0){this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw Error(`THREE.Vector3: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw Error(`THREE.Vector3: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Od.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Od.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6]*r,this.y=i[1]*t+i[4]*n+i[7]*r,this.z=i[2]*t+i[5]*n+i[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=e.elements,a=1/(i[3]*t+i[7]*n+i[11]*r+i[15]);return this.x=(i[0]*t+i[4]*n+i[8]*r+i[12])*a,this.y=(i[1]*t+i[5]*n+i[9]*r+i[13])*a,this.z=(i[2]*t+i[6]*n+i[10]*r+i[14])*a,this}applyQuaternion(e){let t=this.x,n=this.y,r=this.z,i=e.x,a=e.y,o=e.z,s=e.w,c=2*(a*r-o*n),l=2*(o*t-i*r),u=2*(i*n-a*t);return this.x=t+s*c+a*u-o*l,this.y=n+s*l+o*c-i*u,this.z=r+s*u+i*l-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,n=this.y,r=this.z,i=e.elements;return this.x=i[0]*t+i[4]*n+i[8]*r,this.y=i[1]*t+i[5]*n+i[9]*r,this.z=i[2]*t+i[6]*n+i[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=xd(this.x,e.x,t.x),this.y=xd(this.y,e.y,t.y),this.z=xd(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=xd(this.x,e,t),this.y=xd(this.y,e,t),this.z=xd(this.z,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(xd(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let n=e.x,r=e.y,i=e.z,a=t.x,o=t.y,s=t.z;return this.x=r*s-i*o,this.y=i*a-n*s,this.z=n*o-r*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Dd.copy(this).projectOnVector(e),this.sub(Dd)}reflect(e){return this.sub(Dd.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let n=this.dot(e)/t;return Math.acos(xd(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,n=this.y-e.y,r=this.z-e.z;return t*t+n*n+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){let r=Math.sin(t)*e;return this.x=r*Math.sin(n),this.y=Math.cos(t)*e,this.z=r*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=r,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Dd=new Y,Od=new Ed,X=class e{static{e.prototype.isMatrix3=!0}constructor(e,t,n,r,i,a,o,s,c){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c)}set(e,t,n,r,i,a,o,s,c){let l=this.elements;return l[0]=e,l[1]=r,l[2]=o,l[3]=t,l[4]=i,l[5]=s,l[6]=n,l[7]=a,l[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[3],s=n[6],c=n[1],l=n[4],u=n[7],d=n[2],f=n[5],p=n[8],m=r[0],h=r[3],g=r[6],_=r[1],v=r[4],y=r[7],b=r[2],x=r[5],S=r[8];return i[0]=a*m+o*_+s*b,i[3]=a*h+o*v+s*x,i[6]=a*g+o*y+s*S,i[1]=c*m+l*_+u*b,i[4]=c*h+l*v+u*x,i[7]=c*g+l*y+u*S,i[2]=d*m+f*_+p*b,i[5]=d*h+f*v+p*x,i[8]=d*g+f*y+p*S,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8];return t*a*l-t*o*c-n*i*l+n*o*s+r*i*c-r*a*s}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=l*a-o*c,d=o*s-l*i,f=c*i-a*s,p=t*u+n*d+r*f;if(p===0)return this.set(0,0,0,0,0,0,0,0,0);let m=1/p;return e[0]=u*m,e[1]=(r*c-l*n)*m,e[2]=(o*n-r*a)*m,e[3]=d*m,e[4]=(l*t-r*s)*m,e[5]=(r*i-o*t)*m,e[6]=f*m,e[7]=(n*s-c*t)*m,e[8]=(a*t-n*i)*m,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,r,i,a,o){let s=Math.cos(i),c=Math.sin(i);return this.set(n*s,n*c,-n*(s*a+c*o)+a+e,-r*c,r*s,-r*(-c*a+s*o)+o+t,0,0,1),this}scale(e,t){return pd(`Matrix3: .scale() is deprecated. Use .makeScale() instead.`),this.premultiply(kd.makeScale(e,t)),this}rotate(e){return pd(`Matrix3: .rotate() is deprecated. Use .makeRotation() instead.`),this.premultiply(kd.makeRotation(-e)),this}translate(e,t){return pd(`Matrix3: .translate() is deprecated. Use .makeTranslation() instead.`),this.premultiply(kd.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<9;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}},kd=new X,Ad=new X().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),jd=new X().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Md(){let e={enabled:!0,workingColorSpace:ed,spaces:{},convert:function(e,t,n){return this.enabled===!1||t===n||!t||!n||(this.spaces[t].transfer===`srgb`&&(e.r=Pd(e.r),e.g=Pd(e.g),e.b=Pd(e.b)),this.spaces[t].primaries!==this.spaces[n].primaries&&(e.applyMatrix3(this.spaces[t].toXYZ),e.applyMatrix3(this.spaces[n].fromXYZ)),this.spaces[n].transfer===`srgb`&&(e.r=Fd(e.r),e.g=Fd(e.g),e.b=Fd(e.b))),e},workingToColorSpace:function(e,t){return this.convert(e,this.workingColorSpace,t)},colorSpaceToWorking:function(e,t){return this.convert(e,t,this.workingColorSpace)},getPrimaries:function(e){return this.spaces[e].primaries},getTransfer:function(e){return e===``?td:this.spaces[e].transfer},getToneMappingMode:function(e){return this.spaces[e].outputColorSpaceConfig.toneMappingMode||`standard`},getLuminanceCoefficients:function(e,t=this.workingColorSpace){return e.fromArray(this.spaces[t].luminanceCoefficients)},define:function(e){Object.assign(this.spaces,e)},_getMatrix:function(e,t,n){return e.copy(this.spaces[t].toXYZ).multiply(this.spaces[n].fromXYZ)},_getDrawingBufferColorSpace:function(e){return this.spaces[e].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(e=this.workingColorSpace){return this.spaces[e].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(t,n){return pd(`ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace().`),e.workingToColorSpace(t,n)},toWorkingColorSpace:function(t,n){return pd(`ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking().`),e.colorSpaceToWorking(t,n)}},t=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],r=[.3127,.329];return e.define({[ed]:{primaries:t,whitePoint:r,transfer:td,toXYZ:Ad,fromXYZ:jd,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:$u},outputColorSpaceConfig:{drawingBufferColorSpace:$u}},[$u]:{primaries:t,whitePoint:r,transfer:nd,toXYZ:Ad,fromXYZ:jd,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:$u}}}),e}var Nd=Md();function Pd(e){return e<.04045?e*.0773993808:(e*.9478672986+.0521327014)**2.4}function Fd(e){return e<.0031308?e*12.92:1.055*e**.41666-.055}var Id,Ld=class{static getDataURL(e,t=`image/png`){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>`u`)return e.src;let n;if(e instanceof HTMLCanvasElement)n=e;else{Id===void 0&&(Id=cd(`canvas`)),Id.width=e.width,Id.height=e.height;let t=Id.getContext(`2d`);e instanceof ImageData?t.putImageData(e,0,0):t.drawImage(e,0,0,e.width,e.height),n=Id}return n.toDataURL(t)}static sRGBToLinear(e){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap){let t=cd(`canvas`);t.width=e.width,t.height=e.height;let n=t.getContext(`2d`);n.drawImage(e,0,0,e.width,e.height);let r=n.getImageData(0,0,e.width,e.height),i=r.data;for(let e=0;e<i.length;e++)i[e]=Pd(i[e]/255)*255;return n.putImageData(r,0,0),t}if(e.data){let t=e.data.slice(0);for(let e=0;e<t.length;e++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[e]=Math.floor(Pd(t[e]/255)*255):t[e]=Pd(t[e]);return{data:t,width:e.width,height:e.height}}return K(`ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied.`),e}},Rd=0,zd=class{constructor(e=null){this.isTextureSource=!0,Object.defineProperty(this,"id",{value:Rd++}),this.uuid=bd(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){let t=this.data;return typeof HTMLVideoElement<`u`&&t instanceof HTMLVideoElement?e.set(t.videoWidth,t.videoHeight,0):typeof VideoFrame<`u`&&t instanceof VideoFrame?e.set(t.displayWidth,t.displayHeight,0):t===null?e.set(0,0,0):e.set(t.width,t.height,t.depth||0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let n={uuid:this.uuid,url:``},r=this.data;if(r!==null){let e;if(Array.isArray(r)){e=[];for(let t=0,n=r.length;t<n;t++)r[t].isDataTexture?e.push(Bd(r[t].image)):e.push(Bd(r[t]))}else e=Bd(r);n.url=e}return t||(e.images[this.uuid]=n),n}};function Bd(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap?Ld.getDataURL(e):e.data?{data:Array.from(e.data),width:e.width,height:e.height,type:e.data.constructor.name}:(K(`Texture: Unable to serialize Texture.`),{})}var Vd=0,Hd=new Y,Ud=class e extends gd{constructor(t=e.DEFAULT_IMAGE,n=e.DEFAULT_MAPPING,r=Ml,i=Ml,a=Ll,o=zl,s=tu,c=Bl,l=e.DEFAULT_ANISOTROPY,u=``){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:Vd++}),this.uuid=bd(),this.name=``,this.source=new zd(t),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=r,this.wrapT=i,this.magFilter=a,this.minFilter=o,this.anisotropy=l,this.format=s,this.internalFormat=null,this.type=c,this.offset=new J(0,0),this.repeat=new J(1,1),this.center=new J(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new X,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=u,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(t&&t.depth&&t.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(Hd).x}get height(){return this.source.getSize(Hd).y}get depth(){return this.source.getSize(Hd).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(let t in e){let n=e[t];if(n===void 0){K(`Texture.setValues(): parameter '${t}' has value of undefined.`);continue}let r=this[t];r===void 0?K(`Texture.setValues(): property '${t}' does not exist.`):r&&n&&r.isVector2&&n.isVector2||r&&n&&r.isVector3&&n.isVector3||r&&n&&r.isMatrix3&&n.isMatrix3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let n={metadata:{version:4.7,type:`Texture`,generator:`Texture.toJSON`},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:`dispose`})}transformUv(e){if(this.mapping!==300)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case jl:e.x-=Math.floor(e.x);break;case Ml:e.x=e.x<0?0:1;break;case Nl:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x-=Math.floor(e.x)}if(e.y<0||e.y>1)switch(this.wrapT){case jl:e.y-=Math.floor(e.y);break;case Ml:e.y=e.y<0?0:1;break;case Nl:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y-=Math.floor(e.y)}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}};Ud.DEFAULT_IMAGE=null,Ud.DEFAULT_MAPPING=300,Ud.DEFAULT_ANISOTROPY=1;var Wd=class e{static{e.prototype.isVector4=!0}constructor(e=0,t=0,n=0,r=1){this.x=e,this.y=t,this.z=n,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,r){return this.x=e,this.y=t,this.z=n,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw Error(`THREE.Vector4: index is out of range: `+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw Error(`THREE.Vector4: index is out of range: `+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w===void 0?1:e.w,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,n=this.y,r=this.z,i=this.w,a=e.elements;return this.x=a[0]*t+a[4]*n+a[8]*r+a[12]*i,this.y=a[1]*t+a[5]*n+a[9]*r+a[13]*i,this.z=a[2]*t+a[6]*n+a[10]*r+a[14]*i,this.w=a[3]*t+a[7]*n+a[11]*r+a[15]*i,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,r,i,a=.01,o=.1,s=e.elements,c=s[0],l=s[4],u=s[8],d=s[1],f=s[5],p=s[9],m=s[2],h=s[6],g=s[10];if(Math.abs(l-d)<a&&Math.abs(u-m)<a&&Math.abs(p-h)<a){if(Math.abs(l+d)<o&&Math.abs(u+m)<o&&Math.abs(p+h)<o&&Math.abs(c+f+g-3)<o)return this.set(1,0,0,0),this;t=Math.PI;let e=(c+1)/2,s=(f+1)/2,_=(g+1)/2,v=(l+d)/4,y=(u+m)/4,b=(p+h)/4;return e>s&&e>_?e<a?(n=0,r=.707106781,i=.707106781):(n=Math.sqrt(e),r=v/n,i=y/n):s>_?s<a?(n=.707106781,r=0,i=.707106781):(r=Math.sqrt(s),n=v/r,i=b/r):_<a?(n=.707106781,r=.707106781,i=0):(i=Math.sqrt(_),n=y/i,r=b/i),this.set(n,r,i,t),this}let _=Math.sqrt((h-p)*(h-p)+(u-m)*(u-m)+(d-l)*(d-l));return Math.abs(_)<.001&&(_=1),this.x=(h-p)/_,this.y=(u-m)/_,this.z=(d-l)/_,this.w=Math.acos((c+f+g-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=xd(this.x,e.x,t.x),this.y=xd(this.y,e.y,t.y),this.z=xd(this.z,e.z,t.z),this.w=xd(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=xd(this.x,e,t),this.y=xd(this.y,e,t),this.z=xd(this.z,e,t),this.w=xd(this.w,e,t),this}clampLength(e,t){let n=this.length();return this.divideScalar(n||1).multiplyScalar(xd(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Gd=class extends gd{constructor(e=1,t=1,n={}){super(),n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ll,depthBuffer:!0,stencilBuffer:!1,resolveColorBuffer:!0,resolveDepthBuffer:!0,resolveStencilBuffer:!0,storeMultisampledColorBuffer:!0,storeMultisampledDepthBuffer:!0,storeMultisampledStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1,useArrayDepthTexture:!1},n),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=n.depth,this.scissor=new Wd(0,0,e,t),this.scissorTest=!1,this.viewport=new Wd(0,0,e,t),this.textures=[];let r=new Ud({width:e,height:t,depth:n.depth}),i=n.count;for(let e=0;e<i;e++)this.textures[e]=r.clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;this._setTextureOptions(n),this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveColorBuffer=n.resolveColorBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this.storeMultisampledColorBuffer=n.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=n.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=n.storeMultisampledStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples,this.multiview=n.multiview,this.useArrayDepthTexture=n.useArrayDepthTexture}_setTextureOptions(e={}){let t={minFilter:Ll,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(t.mapping=e.mapping),e.wrapS!==void 0&&(t.wrapS=e.wrapS),e.wrapT!==void 0&&(t.wrapT=e.wrapT),e.wrapR!==void 0&&(t.wrapR=e.wrapR),e.magFilter!==void 0&&(t.magFilter=e.magFilter),e.minFilter!==void 0&&(t.minFilter=e.minFilter),e.format!==void 0&&(t.format=e.format),e.type!==void 0&&(t.type=e.type),e.anisotropy!==void 0&&(t.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(t.colorSpace=e.colorSpace),e.flipY!==void 0&&(t.flipY=e.flipY),e.generateMipmaps!==void 0&&(t.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(t.internalFormat=e.internalFormat);for(let e=0;e<this.textures.length;e++)this.textures[e].setValues(t)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&this._depthTexture.renderTarget===this&&(this._depthTexture.renderTarget=null),e!==null&&e.renderTarget===null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let r=0,i=this.textures.length;r<i;r++)this.textures[r].image.width=e,this.textures[r].image.height=t,this.textures[r].image.depth=n,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;let n=Object.assign({},e.textures[t].image);this.textures[t].source=new zd(n)}if(this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveColorBuffer=e.resolveColorBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,this.storeMultisampledColorBuffer=e.storeMultisampledColorBuffer,this.storeMultisampledDepthBuffer=e.storeMultisampledDepthBuffer,this.storeMultisampledStencilBuffer=e.storeMultisampledStencilBuffer,e.depthTexture!==null){if(e.depthTexture.renderTarget===e){let t=e.depthTexture.clone();t.renderTarget=null,this.depthTexture=t}else this.depthTexture=e.depthTexture}return this.samples=e.samples,this.multiview=e.multiview,this.useArrayDepthTexture=e.useArrayDepthTexture,this}dispose(){this.dispatchEvent({type:`dispose`})}},Kd=class extends Gd{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}},qd=class extends Ud{constructor(e=null,t=1,n=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Pl,this.minFilter=Pl,this.wrapR=Ml,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}},Jd=class extends Ud{constructor(e=null,t=1,n=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:r},this.magFilter=Pl,this.minFilter=Pl,this.wrapR=Ml,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}copy(e){return super.copy(e),this.wrapR=e.wrapR,this}},Yd=class e{static{e.prototype.isMatrix4=!0}constructor(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h)}set(e,t,n,r,i,a,o,s,c,l,u,d,f,p,m,h){let g=this.elements;return g[0]=e,g[4]=t,g[8]=n,g[12]=r,g[1]=i,g[5]=a,g[9]=o,g[13]=s,g[2]=c,g[6]=l,g[10]=u,g[14]=d,g[3]=f,g[7]=p,g[11]=m,g[15]=h,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new e().fromArray(this.elements)}copy(e){let t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){let t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return this.determinantAffine()===0?(e.set(1,0,0),t.set(0,1,0),n.set(0,0,1),this):(e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this)}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){if(e.determinantAffine()===0)return this.identity();let t=this.elements,n=e.elements,r=1/Xd.setFromMatrixColumn(e,0).length(),i=1/Xd.setFromMatrixColumn(e,1).length(),a=1/Xd.setFromMatrixColumn(e,2).length();return t[0]=n[0]*r,t[1]=n[1]*r,t[2]=n[2]*r,t[3]=0,t[4]=n[4]*i,t[5]=n[5]*i,t[6]=n[6]*i,t[7]=0,t[8]=n[8]*a,t[9]=n[9]*a,t[10]=n[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,n=e.x,r=e.y,i=e.z,a=Math.cos(n),o=Math.sin(n),s=Math.cos(r),c=Math.sin(r),l=Math.cos(i),u=Math.sin(i);if(e.order===`XYZ`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=-s*u,t[8]=c,t[1]=n+r*c,t[5]=e-i*c,t[9]=-o*s,t[2]=i-e*c,t[6]=r+n*c,t[10]=a*s}else if(e.order===`YXZ`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e+i*o,t[4]=r*o-n,t[8]=a*c,t[1]=a*u,t[5]=a*l,t[9]=-o,t[2]=n*o-r,t[6]=i+e*o,t[10]=a*s}else if(e.order===`ZXY`){let e=s*l,n=s*u,r=c*l,i=c*u;t[0]=e-i*o,t[4]=-a*u,t[8]=r+n*o,t[1]=n+r*o,t[5]=a*l,t[9]=i-e*o,t[2]=-a*c,t[6]=o,t[10]=a*s}else if(e.order===`ZYX`){let e=a*l,n=a*u,r=o*l,i=o*u;t[0]=s*l,t[4]=r*c-n,t[8]=e*c+i,t[1]=s*u,t[5]=i*c+e,t[9]=n*c-r,t[2]=-c,t[6]=o*s,t[10]=a*s}else if(e.order===`YZX`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=i-e*u,t[8]=r*u+n,t[1]=u,t[5]=a*l,t[9]=-o*l,t[2]=-c*l,t[6]=n*u+r,t[10]=e-i*u}else if(e.order===`XZY`){let e=a*s,n=a*c,r=o*s,i=o*c;t[0]=s*l,t[4]=-u,t[8]=c*l,t[1]=e*u+i,t[5]=a*l,t[9]=n*u-r,t[2]=r*u-n,t[6]=o*l,t[10]=i*u+e}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Qd,e,$d)}lookAt(e,t,n){let r=this.elements;return nf.subVectors(e,t),nf.lengthSq()===0&&(nf.z=1),nf.normalize(),ef.crossVectors(n,nf),ef.lengthSq()===0&&(Math.abs(n.z)===1?nf.x+=1e-4:nf.z+=1e-4,nf.normalize(),ef.crossVectors(n,nf)),ef.normalize(),tf.crossVectors(nf,ef),r[0]=ef.x,r[4]=tf.x,r[8]=nf.x,r[1]=ef.y,r[5]=tf.y,r[9]=nf.y,r[2]=ef.z,r[6]=tf.z,r[10]=nf.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let n=e.elements,r=t.elements,i=this.elements,a=n[0],o=n[4],s=n[8],c=n[12],l=n[1],u=n[5],d=n[9],f=n[13],p=n[2],m=n[6],h=n[10],g=n[14],_=n[3],v=n[7],y=n[11],b=n[15],x=r[0],S=r[4],C=r[8],w=r[12],T=r[1],E=r[5],D=r[9],O=r[13],k=r[2],A=r[6],j=r[10],ee=r[14],M=r[3],te=r[7],ne=r[11],re=r[15];return i[0]=a*x+o*T+s*k+c*M,i[4]=a*S+o*E+s*A+c*te,i[8]=a*C+o*D+s*j+c*ne,i[12]=a*w+o*O+s*ee+c*re,i[1]=l*x+u*T+d*k+f*M,i[5]=l*S+u*E+d*A+f*te,i[9]=l*C+u*D+d*j+f*ne,i[13]=l*w+u*O+d*ee+f*re,i[2]=p*x+m*T+h*k+g*M,i[6]=p*S+m*E+h*A+g*te,i[10]=p*C+m*D+h*j+g*ne,i[14]=p*w+m*O+h*ee+g*re,i[3]=_*x+v*T+y*k+b*M,i[7]=_*S+v*E+y*A+b*te,i[11]=_*C+v*D+y*j+b*ne,i[15]=_*w+v*O+y*ee+b*re,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[12],a=e[1],o=e[5],s=e[9],c=e[13],l=e[2],u=e[6],d=e[10],f=e[14],p=e[3],m=e[7],h=e[11],g=e[15],_=s*f-c*d,v=o*f-c*u,y=o*d-s*u,b=a*f-c*l,x=a*d-s*l,S=a*u-o*l;return t*(m*_-h*v+g*y)-n*(p*_-h*b+g*x)+r*(p*v-m*b+g*S)-i*(p*y-m*x+h*S)}determinantAffine(){let e=this.elements,t=e[0],n=e[4],r=e[8],i=e[1],a=e[5],o=e[9],s=e[2],c=e[6],l=e[10];return t*(a*l-o*c)-n*(i*l-o*s)+r*(i*c-a*s)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){let r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=t,r[14]=n),this}invert(){let e=this.elements,t=e[0],n=e[1],r=e[2],i=e[3],a=e[4],o=e[5],s=e[6],c=e[7],l=e[8],u=e[9],d=e[10],f=e[11],p=e[12],m=e[13],h=e[14],g=e[15],_=t*o-n*a,v=t*s-r*a,y=t*c-i*a,b=n*s-r*o,x=n*c-i*o,S=r*c-i*s,C=l*m-u*p,w=l*h-d*p,T=l*g-f*p,E=u*h-d*m,D=u*g-f*m,O=d*g-f*h,k=_*O-v*D+y*E+b*T-x*w+S*C;if(k===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let A=1/k;return e[0]=(o*O-s*D+c*E)*A,e[1]=(r*D-n*O-i*E)*A,e[2]=(m*S-h*x+g*b)*A,e[3]=(d*x-u*S-f*b)*A,e[4]=(s*T-a*O-c*w)*A,e[5]=(t*O-r*T+i*w)*A,e[6]=(h*y-p*S-g*v)*A,e[7]=(l*S-d*y+f*v)*A,e[8]=(a*D-o*T+c*C)*A,e[9]=(n*T-t*D-i*C)*A,e[10]=(p*x-m*y+g*_)*A,e[11]=(u*y-l*x-f*_)*A,e[12]=(o*w-a*E-s*C)*A,e[13]=(t*E-n*w+r*C)*A,e[14]=(m*v-p*b-h*_)*A,e[15]=(l*b-u*v+d*_)*A,this}scale(e){let t=this.elements,n=e.x,r=e.y,i=e.z;return t[0]*=n,t[4]*=r,t[8]*=i,t[1]*=n,t[5]*=r,t[9]*=i,t[2]*=n,t[6]*=r,t[10]*=i,t[3]*=n,t[7]*=r,t[11]*=i,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,r))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let n=Math.cos(t),r=Math.sin(t),i=1-n,a=e.x,o=e.y,s=e.z,c=i*a,l=i*o;return this.set(c*a+n,c*o-r*s,c*s+r*o,0,c*o+r*s,l*o+n,l*s-r*a,0,c*s-r*o,l*s+r*a,i*s*s+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,r,i,a){return this.set(1,n,i,0,e,1,a,0,t,r,1,0,0,0,0,1),this}compose(e,t,n){let r=this.elements,i=t._x,a=t._y,o=t._z,s=t._w,c=i+i,l=a+a,u=o+o,d=i*c,f=i*l,p=i*u,m=a*l,h=a*u,g=o*u,_=s*c,v=s*l,y=s*u,b=n.x,x=n.y,S=n.z;return r[0]=(1-(m+g))*b,r[1]=(f+y)*b,r[2]=(p-v)*b,r[3]=0,r[4]=(f-y)*x,r[5]=(1-(d+g))*x,r[6]=(h+_)*x,r[7]=0,r[8]=(p+v)*S,r[9]=(h-_)*S,r[10]=(1-(d+m))*S,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,t,n){let r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];let i=this.determinantAffine();if(i===0)return n.set(1,1,1),t.identity(),this;let a=Xd.set(r[0],r[1],r[2]).length(),o=Xd.set(r[4],r[5],r[6]).length(),s=Xd.set(r[8],r[9],r[10]).length();i<0&&(a=-a),Zd.copy(this);let c=1/a,l=1/o,u=1/s;return Zd.elements[0]*=c,Zd.elements[1]*=c,Zd.elements[2]*=c,Zd.elements[4]*=l,Zd.elements[5]*=l,Zd.elements[6]*=l,Zd.elements[8]*=u,Zd.elements[9]*=u,Zd.elements[10]*=u,t.setFromRotationMatrix(Zd),n.x=a,n.y=o,n.z=s,this}makePerspective(e,t,n,r,i,a,o=ad,s=!1){let c=this.elements,l=2*i/(t-e),u=2*i/(n-r),d=(t+e)/(t-e),f=(n+r)/(n-r),p,m;if(s)p=i/(a-i),m=a*i/(a-i);else if(o===2e3)p=-(a+i)/(a-i),m=-2*a*i/(a-i);else if(o===2001)p=-a/(a-i),m=-a*i/(a-i);else throw Error(`THREE.Matrix4.makePerspective(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=d,c[12]=0,c[1]=0,c[5]=u,c[9]=f,c[13]=0,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=-1,c[15]=0,this}makeOrthographic(e,t,n,r,i,a,o=ad,s=!1){let c=this.elements,l=2/(t-e),u=2/(n-r),d=-(t+e)/(t-e),f=-(n+r)/(n-r),p,m;if(s)p=1/(a-i),m=a/(a-i);else if(o===2e3)p=-2/(a-i),m=-(a+i)/(a-i);else if(o===2001)p=-1/(a-i),m=-i/(a-i);else throw Error(`THREE.Matrix4.makeOrthographic(): Invalid coordinate system: `+o);return c[0]=l,c[4]=0,c[8]=0,c[12]=d,c[1]=0,c[5]=u,c[9]=0,c[13]=f,c[2]=0,c[6]=0,c[10]=p,c[14]=m,c[3]=0,c[7]=0,c[11]=0,c[15]=1,this}equals(e){let t=this.elements,n=e.elements;for(let e=0;e<16;e++)if(t[e]!==n[e])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){let n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}},Xd=new Y,Zd=new Yd,Qd=new Y(0,0,0),$d=new Y(1,1,1),ef=new Y,tf=new Y,nf=new Y,rf=new Yd,af=new Ed,of=class e{constructor(t=0,n=0,r=0,i=e.DEFAULT_ORDER){this.isEuler=!0,this._x=t,this._y=n,this._z=r,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,r=this._order){return this._x=e,this._y=t,this._z=n,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){let r=e.elements,i=r[0],a=r[4],o=r[8],s=r[1],c=r[5],l=r[9],u=r[2],d=r[6],f=r[10];switch(t){case`XYZ`:this._y=Math.asin(xd(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-l,f),this._z=Math.atan2(-a,i)):(this._x=Math.atan2(d,c),this._z=0);break;case`YXZ`:this._x=Math.asin(-xd(l,-1,1)),Math.abs(l)<.9999999?(this._y=Math.atan2(o,f),this._z=Math.atan2(s,c)):(this._y=Math.atan2(-u,i),this._z=0);break;case`ZXY`:this._x=Math.asin(xd(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(s,i));break;case`ZYX`:this._y=Math.asin(-xd(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(s,i)):(this._x=0,this._z=Math.atan2(-a,c));break;case`YZX`:this._z=Math.asin(xd(s,-1,1)),Math.abs(s)<.9999999?(this._x=Math.atan2(-l,c),this._y=Math.atan2(-u,i)):(this._x=0,this._y=Math.atan2(o,f));break;case`XZY`:this._z=Math.asin(-xd(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(o,i)):(this._x=Math.atan2(-l,f),this._y=0);break;default:K(`Euler: .setFromRotationMatrix() encountered an unknown order: `+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return rf.makeRotationFromQuaternion(e),this.setFromRotationMatrix(rf,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return af.setFromEuler(this),this.setFromQuaternion(af,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};of.DEFAULT_ORDER=`XYZ`;var sf=class{constructor(){this.mask=1}set(e){this.mask=1<<e>>>0}enable(e){this.mask|=1<<e}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e}disable(e){this.mask&=~(1<<e)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return!!(this.mask&1<<e)}},cf=0,lf=new Y,uf=new Ed,df=new Yd,ff=new Y,pf=new Y,mf=new Y,hf=new Ed,gf=new Y(1,0,0),_f=new Y(0,1,0),vf=new Y(0,0,1),yf={type:`added`},bf={type:`removed`},xf={type:`childadded`,child:null},Sf={type:`childremoved`,child:null},Cf=class e extends gd{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:cf++}),this.uuid=bd(),this.name=``,this.type=`Object3D`,this.parent=null,this.children=[],this.up=e.DEFAULT_UP.clone();let t=new Y,n=new of,r=new Ed,i=new Y(1,1,1);function a(){r.setFromEuler(n,!1)}function o(){n.setFromQuaternion(r,void 0,!1)}n._onChange(a),r._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:r},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Yd},normalMatrix:{value:new X}}),this.matrix=new Yd,this.matrixWorld=new Yd,this.matrixAutoUpdate=e.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=e.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new sf,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return uf.setFromAxisAngle(e,t),this.quaternion.multiply(uf),this}rotateOnWorldAxis(e,t){return uf.setFromAxisAngle(e,t),this.quaternion.premultiply(uf),this}rotateX(e){return this.rotateOnAxis(gf,e)}rotateY(e){return this.rotateOnAxis(_f,e)}rotateZ(e){return this.rotateOnAxis(vf,e)}translateOnAxis(e,t){return lf.copy(e).applyQuaternion(this.quaternion),this.position.add(lf.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(gf,e)}translateY(e){return this.translateOnAxis(_f,e)}translateZ(e){return this.translateOnAxis(vf,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(df.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?ff.copy(e):ff.set(e,t,n);let r=this.parent;this.updateWorldMatrix(!0,!1),pf.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?df.lookAt(pf,ff,this.up):df.lookAt(ff,pf,this.up),this.quaternion.setFromRotationMatrix(df),r&&(df.extractRotation(r.matrixWorld),uf.setFromRotationMatrix(df),this.quaternion.premultiply(uf.invert()))}add(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.add(arguments[e]);return this}return e===this?(q(`Object3D.add: object can't be added as a child of itself.`,e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(yf),xf.child=e,this.dispatchEvent(xf),xf.child=null):q(`Object3D.add: object not an instance of THREE.Object3D.`,e),this)}remove(e){if(arguments.length>1){for(let e=0;e<arguments.length;e++)this.remove(arguments[e]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(bf),Sf.child=e,this.dispatchEvent(Sf),Sf.child=null),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),df.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),df.multiply(e.parent.matrixWorld)),e.applyMatrix4(df),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(yf),xf.child=e,this.dispatchEvent(xf),xf.child=null,this}getObjectById(e){return this.getObjectByProperty(`id`,e)}getObjectByName(e){return this.getObjectByProperty(`name`,e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,r=this.children.length;n<r;n++){let r=this.children[n].getObjectByProperty(e,t);if(r!==void 0)return r}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);let r=this.children;for(let i=0,a=r.length;i<a;i++)r[i].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(pf,e,mf),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(pf,hf,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}intersectsFrustum(){}traverse(e){e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);let e=this.pivot;if(e!==null){let t=e.x,n=e.y,r=e.z,i=this.matrix.elements;i[12]+=t-i[0]*t-i[4]*n-i[8]*r,i[13]+=n-i[1]*t-i[5]*n-i[9]*r,i[14]+=r-i[2]*t-i[6]*n-i[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let n=0,r=t.length;n<r;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t,n=!1){let r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||n)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,n=!0),t===!0){let e=this.children;for(let t=0,r=e.length;t<r;t++)e[t].updateWorldMatrix(!1,!0,n)}}toJSON(e){let t=e===void 0||typeof e==`string`,n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.7,type:`Object`,generator:`Object3D.toJSON`});let r={};r.uuid=this.uuid,r.type=this.type,r.name=this.name,r.castShadow=this.castShadow,r.receiveShadow=this.receiveShadow,r.visible=this.visible,r.frustumCulled=this.frustumCulled,r.renderOrder=this.renderOrder,r.static=this.static,r.matrixAutoUpdate=this.matrixAutoUpdate,Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type=`InstancedMesh`,r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type=`BatchedMesh`,r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(e=>({...e,boundingBox:e.boundingBox?e.boundingBox.toJSON():void 0,boundingSphere:e.boundingSphere?e.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(e=>({...e})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function i(t,n){return t[n.uuid]===void 0&&(t[n.uuid]=n.toJSON(e)),n.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=i(e.geometries,this.geometry);let t=this.geometry.parameters;if(t!==void 0&&t.shapes!==void 0){let n=t.shapes;if(Array.isArray(n))for(let t=0,r=n.length;t<r;t++){let r=n[t];i(e.shapes,r)}else i(e.shapes,n)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(i(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0){if(Array.isArray(this.material)){let t=[];for(let n=0,r=this.material.length;n<r;n++)t.push(i(e.materials,this.material[n]));r.material=t}else r.material=i(e.materials,this.material)}if(this.children.length>0){r.children=[];for(let t=0;t<this.children.length;t++)r.children.push(this.children[t].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let t=0;t<this.animations.length;t++){let n=this.animations[t];r.animations.push(i(e.animations,n))}}if(t){let t=a(e.geometries),r=a(e.materials),i=a(e.textures),o=a(e.images),s=a(e.shapes),c=a(e.skeletons),l=a(e.animations),u=a(e.nodes);t.length>0&&(n.geometries=t),r.length>0&&(n.materials=r),i.length>0&&(n.textures=i),o.length>0&&(n.images=o),s.length>0&&(n.shapes=s),c.length>0&&(n.skeletons=c),l.length>0&&(n.animations=l),u.length>0&&(n.nodes=u)}return n.object=r,n;function a(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot===null?null:e.pivot.clone(),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let t=0;t<e.children.length;t++){let n=e.children[t];this.add(n.clone())}return this}dispose(){this.dispatchEvent({type:`dispose`})}};Cf.DEFAULT_UP=new Y(0,1,0),Cf.DEFAULT_MATRIX_AUTO_UPDATE=!0,Cf.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var wf=class extends Cf{constructor(){super(),this.isGroup=!0,this.type=`Group`}},Tf={type:`move`},Ef=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new wf,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new wf,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new Y,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new Y),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new wf,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new Y,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new Y,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:`connected`,data:e}),this}disconnect(e){return this.dispatchEvent({type:`disconnected`,data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let r=null,i=null,a=null,o=this._targetRay,s=this._grip,c=this._hand;if(e&&t.session.visibilityState!==`visible-blurred`){if(c&&e.hand){a=!0;for(let r of e.hand.values()){let e=t.getJointPose(r,n),i=this._getHandJoint(c,r);e!==null&&(i.matrix.fromArray(e.transform.matrix),i.matrix.decompose(i.position,i.rotation,i.scale),i.matrixWorldNeedsUpdate=!0,i.jointRadius=e.radius),i.visible=e!==null}let r=c.joints[`index-finger-tip`],i=c.joints[`thumb-tip`],o=r.position.distanceTo(i.position);c.inputState.pinching&&o>.025?(c.inputState.pinching=!1,this.dispatchEvent({type:`pinchend`,handedness:e.handedness,target:this})):!c.inputState.pinching&&o<=.015&&(c.inputState.pinching=!0,this.dispatchEvent({type:`pinchstart`,handedness:e.handedness,target:this}))}else s!==null&&e.gripSpace&&(i=t.getPose(e.gripSpace,n),i!==null&&(s.matrix.fromArray(i.transform.matrix),s.matrix.decompose(s.position,s.rotation,s.scale),s.matrixWorldNeedsUpdate=!0,i.linearVelocity?(s.hasLinearVelocity=!0,s.linearVelocity.copy(i.linearVelocity)):s.hasLinearVelocity=!1,i.angularVelocity?(s.hasAngularVelocity=!0,s.angularVelocity.copy(i.angularVelocity)):s.hasAngularVelocity=!1,s.eventsEnabled&&s.dispatchEvent({type:`gripUpdated`,data:e,target:this})));o!==null&&(r=t.getPose(e.targetRaySpace,n),r===null&&i!==null&&(r=i),r!==null&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(Tf)))}return o!==null&&(o.visible=r!==null),s!==null&&(s.visible=i!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let n=new wf;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}},Df={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Of={h:0,s:0,l:0},kf={h:0,s:0,l:0};function Af(e,t,n){return n<0&&(n+=1),n>1&&--n,n<1/6?e+(t-e)*6*n:n<1/2?t:n<2/3?e+(t-e)*6*(2/3-n):e}var Z=class{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){let t=e;t&&t.isColor?this.copy(t):typeof t==`number`?this.setHex(t):typeof t==`string`&&this.setStyle(t)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=$u){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Nd.colorSpaceToWorking(this,t),this}setRGB(e,t,n,r=Nd.workingColorSpace){return this.r=e,this.g=t,this.b=n,Nd.colorSpaceToWorking(this,r),this}setHSL(e,t,n,r=Nd.workingColorSpace){if(e=Sd(e,1),t=xd(t,0,1),n=xd(n,0,1),t===0)this.r=this.g=this.b=n;else{let r=n<=.5?n*(1+t):n+t-n*t,i=2*n-r;this.r=Af(i,r,e+1/3),this.g=Af(i,r,e),this.b=Af(i,r,e-1/3)}return Nd.colorSpaceToWorking(this,r),this}setStyle(e,t=$u){function n(t){t!==void 0&&parseFloat(t)<1&&K(`Color: Alpha component of `+e+` will be ignored.`)}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let i,a=r[1],o=r[2];switch(a){case`rgb`:case`rgba`:if(i=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(255,parseInt(i[1],10))/255,Math.min(255,parseInt(i[2],10))/255,Math.min(255,parseInt(i[3],10))/255,t);if(i=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setRGB(Math.min(100,parseInt(i[1],10))/100,Math.min(100,parseInt(i[2],10))/100,Math.min(100,parseInt(i[3],10))/100,t);break;case`hsl`:case`hsla`:if(i=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return n(i[4]),this.setHSL(parseFloat(i[1])/360,parseFloat(i[2])/100,parseFloat(i[3])/100,t);break;default:K(`Color: Unknown color model `+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){let n=r[1],i=n.length;if(i===3)return this.setRGB(parseInt(n.charAt(0),16)/15,parseInt(n.charAt(1),16)/15,parseInt(n.charAt(2),16)/15,t);if(i===6)return this.setHex(parseInt(n,16),t);K(`Color: Invalid hex color `+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=$u){let n=Df[e.toLowerCase()];return n===void 0?K(`Color: Unknown color `+e):this.setHex(n,t),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Pd(e.r),this.g=Pd(e.g),this.b=Pd(e.b),this}copyLinearToSRGB(e){return this.r=Fd(e.r),this.g=Fd(e.g),this.b=Fd(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=$u){return Nd.workingToColorSpace(jf.copy(this),e),Math.round(xd(jf.r*255,0,255))*65536+Math.round(xd(jf.g*255,0,255))*256+Math.round(xd(jf.b*255,0,255))}getHexString(e=$u){return(`000000`+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=Nd.workingColorSpace){Nd.workingToColorSpace(jf.copy(this),t);let n=jf.r,r=jf.g,i=jf.b,a=Math.max(n,r,i),o=Math.min(n,r,i),s,c,l=(o+a)/2;if(o===a)s=0,c=0;else{let e=a-o;switch(c=l<=.5?e/(a+o):e/(2-a-o),a){case n:s=(r-i)/e+(r<i?6:0);break;case r:s=(i-n)/e+2;break;case i:s=(n-r)/e+4}s/=6}return e.h=s,e.s=c,e.l=l,e}getRGB(e,t=Nd.workingColorSpace){return Nd.workingToColorSpace(jf.copy(this),t),e.r=jf.r,e.g=jf.g,e.b=jf.b,e}getStyle(e=$u){Nd.workingToColorSpace(jf.copy(this),e);let t=jf.r,n=jf.g,r=jf.b;return e===`srgb`?`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(r*255)})`:`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${r.toFixed(3)})`}offsetHSL(e,t,n){return this.getHSL(Of),this.setHSL(Of.h+e,Of.s+t,Of.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Of),e.getHSL(kf);let n=Cd(Of.h,kf.h,t),r=Cd(Of.s,kf.s,t),i=Cd(Of.l,kf.l,t);return this.setHSL(n,r,i),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,n=this.g,r=this.b,i=e.elements;return this.r=i[0]*t+i[3]*n+i[6]*r,this.g=i[1]*t+i[4]*n+i[7]*r,this.b=i[2]*t+i[5]*n+i[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},jf=new Z;Z.NAMES=Df;var Mf=class e{constructor(e,t=1,n=1e3){this.isFog=!0,this.name=``,this.color=new Z(e),this.near=t,this.far=n}clone(){return new e(this.color,this.near,this.far)}toJSON(){return{type:`Fog`,name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}},Nf=class extends Cf{constructor(){super(),this.isScene=!0,this.type=`Scene`,this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new of,this.environmentIntensity=1,this.environmentRotation=new of,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),t.object.backgroundBlurriness=this.backgroundBlurriness,t.object.backgroundIntensity=this.backgroundIntensity,t.object.backgroundRotation=this.backgroundRotation.toArray(),t.object.environmentIntensity=this.environmentIntensity,t.object.environmentRotation=this.environmentRotation.toArray(),t}},Pf=new Y,Ff=new Y,If=new Y,Lf=new Y,Rf=new Y,zf=new Y,Bf=new Y,Vf=new Y,Hf=new Y,Uf=new Y,Wf=new Wd,Gf=new Wd,Kf=new Wd,qf=class e{constructor(e=new Y,t=new Y,n=new Y){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,r){r.subVectors(n,t),Pf.subVectors(e,t),r.cross(Pf);let i=r.lengthSq();return i>0?r.multiplyScalar(1/Math.sqrt(i)):r.set(0,0,0)}static getBarycoord(e,t,n,r,i){Pf.subVectors(r,t),Ff.subVectors(n,t),If.subVectors(e,t);let a=Pf.dot(Pf),o=Pf.dot(Ff),s=Pf.dot(If),c=Ff.dot(Ff),l=Ff.dot(If),u=a*c-o*o;if(u===0)return i.set(0,0,0),null;let d=1/u,f=(c*s-o*l)*d,p=(a*l-o*s)*d;return i.set(1-f-p,p,f)}static containsPoint(e,t,n,r){return this.getBarycoord(e,t,n,r,Lf)!==null&&Lf.x>=0&&Lf.y>=0&&Lf.x+Lf.y<=1}static getInterpolation(e,t,n,r,i,a,o,s){return this.getBarycoord(e,t,n,r,Lf)===null?(s.x=0,s.y=0,`z`in s&&(s.z=0),`w`in s&&(s.w=0),null):(s.setScalar(0),s.addScaledVector(i,Lf.x),s.addScaledVector(a,Lf.y),s.addScaledVector(o,Lf.z),s)}static getInterpolatedAttribute(e,t,n,r,i,a){return Wf.setScalar(0),Gf.setScalar(0),Kf.setScalar(0),Wf.fromBufferAttribute(e,t),Gf.fromBufferAttribute(e,n),Kf.fromBufferAttribute(e,r),a.setScalar(0),a.addScaledVector(Wf,i.x),a.addScaledVector(Gf,i.y),a.addScaledVector(Kf,i.z),a}static isFrontFacing(e,t,n,r){return Pf.subVectors(n,t),Ff.subVectors(e,t),Pf.cross(Ff).dot(r)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,r){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,t,n,r){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Pf.subVectors(this.c,this.b),Ff.subVectors(this.a,this.b),Pf.cross(Ff).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(t){return e.getNormal(this.a,this.b,this.c,t)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(t,n){return e.getBarycoord(t,this.a,this.b,this.c,n)}getInterpolation(t,n,r,i,a){return e.getInterpolation(t,this.a,this.b,this.c,n,r,i,a)}containsPoint(t){return e.containsPoint(t,this.a,this.b,this.c)}isFrontFacing(t){return e.isFrontFacing(this.a,this.b,this.c,t)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let n=this.a,r=this.b,i=this.c,a,o;Rf.subVectors(r,n),zf.subVectors(i,n),Vf.subVectors(e,n);let s=Rf.dot(Vf),c=zf.dot(Vf);if(s<=0&&c<=0)return t.copy(n);Hf.subVectors(e,r);let l=Rf.dot(Hf),u=zf.dot(Hf);if(l>=0&&u<=l)return t.copy(r);let d=s*u-l*c;if(d<=0&&s>=0&&l<=0)return a=s/(s-l),t.copy(n).addScaledVector(Rf,a);Uf.subVectors(e,i);let f=Rf.dot(Uf),p=zf.dot(Uf);if(p>=0&&f<=p)return t.copy(i);let m=f*c-s*p;if(m<=0&&c>=0&&p<=0)return o=c/(c-p),t.copy(n).addScaledVector(zf,o);let h=l*p-f*u;if(h<=0&&u-l>=0&&f-p>=0)return Bf.subVectors(i,r),o=(u-l)/(u-l+(f-p)),t.copy(r).addScaledVector(Bf,o);let g=1/(h+m+d);return a=m*g,o=d*g,t.copy(n).addScaledVector(Rf,a).addScaledVector(zf,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},Jf=class{constructor(e=new Y(1/0,1/0,1/0),t=new Y(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Xf.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Xf.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let n=Xf.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let n=e.geometry;if(n!==void 0){let r=n.getAttribute(`position`);if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let t=0,n=r.count;t<n;t++)e.isMesh===!0?e.getVertexPosition(t,Xf):Xf.fromBufferAttribute(r,t),Xf.applyMatrix4(e.matrixWorld),this.expandByPoint(Xf);else e.boundingBox===void 0?(n.boundingBox===null&&n.computeBoundingBox(),Zf.copy(n.boundingBox)):(e.boundingBox===null&&e.computeBoundingBox(),Zf.copy(e.boundingBox)),Zf.applyMatrix4(e.matrixWorld),this.union(Zf)}let r=e.children;for(let e=0,n=r.length;e<n;e++)this.expandByObject(r[e],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Xf),Xf.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(ip),ap.subVectors(this.max,ip),Qf.subVectors(e.a,ip),$f.subVectors(e.b,ip),ep.subVectors(e.c,ip),tp.subVectors($f,Qf),np.subVectors(ep,$f),rp.subVectors(Qf,ep);let t=[0,-tp.z,tp.y,0,-np.z,np.y,0,-rp.z,rp.y,tp.z,0,-tp.x,np.z,0,-np.x,rp.z,0,-rp.x,-tp.y,tp.x,0,-np.y,np.x,0,-rp.y,rp.x,0];return!cp(t,Qf,$f,ep,ap)||(t=[1,0,0,0,1,0,0,0,1],!cp(t,Qf,$f,ep,ap))?!1:(op.crossVectors(tp,np),t=[op.x,op.y,op.z],cp(t,Qf,$f,ep,ap))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Xf).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Xf).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()||(Yf[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Yf[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Yf[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Yf[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Yf[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Yf[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Yf[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Yf[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Yf)),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}},Yf=[new Y,new Y,new Y,new Y,new Y,new Y,new Y,new Y],Xf=new Y,Zf=new Jf,Qf=new Y,$f=new Y,ep=new Y,tp=new Y,np=new Y,rp=new Y,ip=new Y,ap=new Y,op=new Y,sp=new Y;function cp(e,t,n,r,i){for(let a=0,o=e.length-3;a<=o;a+=3){sp.fromArray(e,a);let o=i.x*Math.abs(sp.x)+i.y*Math.abs(sp.y)+i.z*Math.abs(sp.z),s=t.dot(sp),c=n.dot(sp),l=r.dot(sp);if(Math.max(-Math.max(s,c,l),Math.min(s,c,l))>o)return!1}return!0}var lp=new Y,up=new J,dp=0,fp=class extends gd{constructor(e,t,n=!1){if(super(),Array.isArray(e))throw TypeError(`THREE.BufferAttribute: array should be a Typed Array.`);this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:dp++}),this.name=``,this.array=e,this.itemSize=t,this.count=e===void 0?0:e.length/t,this.normalized=n,this.usage=id,this.updateRanges=[],this.gpuType=Kl,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let r=0,i=this.itemSize;r<i;r++)this.array[e+r]=t.array[n+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)up.fromBufferAttribute(this,t),up.applyMatrix3(e),this.setXY(t,up.x,up.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)lp.fromBufferAttribute(this,t),lp.applyMatrix3(e),this.setXYZ(t,lp.x,lp.y,lp.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)lp.fromBufferAttribute(this,t),lp.applyMatrix4(e),this.setXYZ(t,lp.x,lp.y,lp.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)lp.fromBufferAttribute(this,t),lp.applyNormalMatrix(e),this.setXYZ(t,lp.x,lp.y,lp.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)lp.fromBufferAttribute(this,t),lp.transformDirection(e),this.setXYZ(t,lp.x,lp.y,lp.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=wd(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=Td(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=wd(t,this.array)),t}setX(e,t){return this.normalized&&(t=Td(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=wd(t,this.array)),t}setY(e,t){return this.normalized&&(t=Td(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=wd(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Td(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=wd(t,this.array)),t}setW(e,t){return this.normalized&&(t=Td(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=Td(t,this.array),n=Td(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,r){return e*=this.itemSize,this.normalized&&(t=Td(t,this.array),n=Td(n,this.array),r=Td(r,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this}setXYZW(e,t,n,r,i){return e*=this.itemSize,this.normalized&&(t=Td(t,this.array),n=Td(n,this.array),r=Td(r,this.array),i=Td(i,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=r,this.array[e+3]=i,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return e.name=this.name,e.usage=this.usage,e.gpuType=this.gpuType,e}dispose(){this.dispatchEvent({type:`dispose`})}},pp=class extends fp{constructor(e,t,n){super(new Uint16Array(e),t,n)}},mp=class extends fp{constructor(e,t,n){super(new Uint32Array(e),t,n)}},hp=class extends fp{constructor(e,t,n){super(new Float32Array(e),t,n)}},gp=new Jf,_p=new Y,vp=new Y,yp=class{constructor(e=new Y,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let n=this.center;t===void 0?gp.setFromPoints(e).getCenter(n):n.copy(t);let r=0;for(let t=0,i=e.length;t<i;t++)r=Math.max(r,n.distanceToSquared(e[t]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius*=e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;_p.subVectors(e,this.center);let t=_p.lengthSq();if(t>this.radius*this.radius){let e=Math.sqrt(t),n=(e-this.radius)*.5;this.center.addScaledVector(_p,n/e),this.radius+=n}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(vp.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(_p.copy(e.center).add(vp)),this.expandByPoint(_p.copy(e.center).sub(vp))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}},bp=0,xp=new Yd,Sp=new Cf,Cp=new Y,wp=new Jf,Tp=new Jf,Ep=new Y,Dp=class e extends gd{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:bp++}),this.uuid=bd(),this.name=``,this.type=`BufferGeometry`,this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={},this._transformed=!1}getIndex(){return this.index}setIndex(e){return this.index=Array.isArray(e)?new(od(e)?mp:pp)(e,1):e,this}setIndirect(e,t=0){return this.indirect=e,this.indirectOffset=t,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let n=this.attributes.normal;if(n!==void 0){let t=new X().getNormalMatrix(e);n.applyNormalMatrix(t),n.needsUpdate=!0}let r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this._transformed=!0,this}applyQuaternion(e){return xp.makeRotationFromQuaternion(e),this.applyMatrix4(xp),this}rotateX(e){return xp.makeRotationX(e),this.applyMatrix4(xp),this}rotateY(e){return xp.makeRotationY(e),this.applyMatrix4(xp),this}rotateZ(e){return xp.makeRotationZ(e),this.applyMatrix4(xp),this}translate(e,t,n){return xp.makeTranslation(e,t,n),this.applyMatrix4(xp),this}scale(e,t,n){return xp.makeScale(e,t,n),this.applyMatrix4(xp),this}lookAt(e){return Sp.lookAt(e),Sp.updateMatrix(),this.applyMatrix4(Sp.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Cp).negate(),this.translate(Cp.x,Cp.y,Cp.z),this}setFromPoints(e){let t=this.getAttribute(`position`);if(t===void 0){let t=[];for(let n=0,r=e.length;n<r;n++){let r=e[n];t.push(r.x,r.y,r.z||0)}this.setAttribute(`position`,new hp(t,3))}else{let n=Math.min(e.length,t.count);for(let r=0;r<n;r++){let n=e[r];t.setXYZ(r,n.x,n.y,n.z||0)}e.length>t.count&&K(`BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry.`),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Jf);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)q(`BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.`,this),this.boundingBox.set(new Y(-1/0,-1/0,-1/0),new Y(1/0,1/0,1/0));else{if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];wp.setFromBufferAttribute(n),this.morphTargetsRelative?(Ep.addVectors(this.boundingBox.min,wp.min),this.boundingBox.expandByPoint(Ep),Ep.addVectors(this.boundingBox.max,wp.max),this.boundingBox.expandByPoint(Ep)):(this.boundingBox.expandByPoint(wp.min),this.boundingBox.expandByPoint(wp.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&q(`BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.`,this)}}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new yp);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)q(`BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.`,this),this.boundingSphere.set(new Y,1/0);else if(e){let n=this.boundingSphere.center;if(wp.setFromBufferAttribute(e),t)for(let e=0,n=t.length;e<n;e++){let n=t[e];Tp.setFromBufferAttribute(n),this.morphTargetsRelative?(Ep.addVectors(wp.min,Tp.min),wp.expandByPoint(Ep),Ep.addVectors(wp.max,Tp.max),wp.expandByPoint(Ep)):(wp.expandByPoint(Tp.min),wp.expandByPoint(Tp.max))}wp.getCenter(n);let r=0;for(let t=0,i=e.count;t<i;t++)Ep.fromBufferAttribute(e,t),r=Math.max(r,n.distanceToSquared(Ep));if(t)for(let i=0,a=t.length;i<a;i++){let a=t[i],o=this.morphTargetsRelative;for(let t=0,i=a.count;t<i;t++)Ep.fromBufferAttribute(a,t),o&&(Cp.fromBufferAttribute(e,t),Ep.add(Cp)),r=Math.max(r,n.distanceToSquared(Ep))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&q(`BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.`,this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){q(`BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)`);return}let n=t.position,r=t.normal,i=t.uv,a=this.getAttribute(`tangent`);(a===void 0||a.count!==n.count)&&(a=new fp(new Float32Array(4*n.count),4),this.setAttribute(`tangent`,a));let o=[],s=[];for(let e=0;e<n.count;e++)o[e]=new Y,s[e]=new Y;let c=new Y,l=new Y,u=new Y,d=new J,f=new J,p=new J,m=new Y,h=new Y;function g(e,t,r){c.fromBufferAttribute(n,e),l.fromBufferAttribute(n,t),u.fromBufferAttribute(n,r),d.fromBufferAttribute(i,e),f.fromBufferAttribute(i,t),p.fromBufferAttribute(i,r),l.sub(c),u.sub(c),f.sub(d),p.sub(d);let a=1/(f.x*p.y-p.x*f.y);isFinite(a)&&(m.copy(l).multiplyScalar(p.y).addScaledVector(u,-f.y).multiplyScalar(a),h.copy(u).multiplyScalar(f.x).addScaledVector(l,-p.x).multiplyScalar(a),o[e].add(m),o[t].add(m),o[r].add(m),s[e].add(h),s[t].add(h),s[r].add(h))}let _=this.groups;_.length===0&&(_=[{start:0,count:e.count}]);for(let t=0,n=_.length;t<n;++t){let n=_[t],r=n.start,i=n.count;for(let t=r,n=r+i;t<n;t+=3)g(e.getX(t+0),e.getX(t+1),e.getX(t+2))}let v=new Y,y=new Y,b=new Y,x=new Y;function S(e){b.fromBufferAttribute(r,e),x.copy(b);let t=o[e];v.copy(t),v.sub(b.multiplyScalar(b.dot(t))).normalize(),y.crossVectors(x,t);let n=y.dot(s[e])<0?-1:1;a.setXYZW(e,v.x,v.y,v.z,n)}for(let t=0,n=_.length;t<n;++t){let n=_[t],r=n.start,i=n.count;for(let t=r,n=r+i;t<n;t+=3)S(e.getX(t+0)),S(e.getX(t+1)),S(e.getX(t+2))}this._transformed=!0}computeVertexNormals(){let e=this.index,t=this.getAttribute(`position`);if(t!==void 0){let n=this.getAttribute(`normal`);if(n===void 0||n.count!==t.count)n=new fp(new Float32Array(t.count*3),3),this.setAttribute(`normal`,n);else for(let e=0,t=n.count;e<t;e++)n.setXYZ(e,0,0,0);let r=new Y,i=new Y,a=new Y,o=new Y,s=new Y,c=new Y,l=new Y,u=new Y;if(e)for(let d=0,f=e.count;d<f;d+=3){let f=e.getX(d+0),p=e.getX(d+1),m=e.getX(d+2);r.fromBufferAttribute(t,f),i.fromBufferAttribute(t,p),a.fromBufferAttribute(t,m),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),o.fromBufferAttribute(n,f),s.fromBufferAttribute(n,p),c.fromBufferAttribute(n,m),o.add(l),s.add(l),c.add(l),n.setXYZ(f,o.x,o.y,o.z),n.setXYZ(p,s.x,s.y,s.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let e=0,o=t.count;e<o;e+=3)r.fromBufferAttribute(t,e+0),i.fromBufferAttribute(t,e+1),a.fromBufferAttribute(t,e+2),l.subVectors(a,i),u.subVectors(r,i),l.cross(u),n.setXYZ(e+0,l.x,l.y,l.z),n.setXYZ(e+1,l.x,l.y,l.z),n.setXYZ(e+2,l.x,l.y,l.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)Ep.fromBufferAttribute(e,t),Ep.normalize(),e.setXYZ(t,Ep.x,Ep.y,Ep.z)}toNonIndexed(){function t(e,t){let n=e.array,r=e.itemSize,i=e.normalized,a=new n.constructor(t.length*r),o=0,s=0;for(let i=0,c=t.length;i<c;i++){o=e.isInterleavedBufferAttribute?t[i]*e.data.stride+e.offset:t[i]*r;for(let e=0;e<r;e++)a[s++]=n[o++]}return new fp(a,r,i)}if(this.index===null)return K(`BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed.`),this;let n=new e,r=this.index.array,i=this.attributes;for(let e in i){let a=i[e],o=t(a,r);n.setAttribute(e,o)}let a=this.morphAttributes;for(let e in a){let i=[],o=a[e];for(let e=0,n=o.length;e<n;e++){let n=o[e],a=t(n,r);i.push(a)}n.morphAttributes[e]=i}n.morphTargetsRelative=this.morphTargetsRelative;let o=this.groups;for(let e=0,t=o.length;e<t;e++){let t=o[e];n.addGroup(t.start,t.count,t.materialIndex)}return n}toJSON(){let e={metadata:{version:4.7,type:`BufferGeometry`,generator:`BufferGeometry.toJSON`}};if(e.uuid=this.uuid,e.type=this.parameters!==void 0&&this._transformed===!0?`BufferGeometry`:this.type,e.name=this.name,Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0&&this._transformed!==!0){let t=this.parameters;for(let n in t)t[n]!==void 0&&(e[n]=t[n]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let n=this.attributes;for(let t in n){let r=n[t];e.data.attributes[t]=r.toJSON(e.data)}let r={},i=!1;for(let t in this.morphAttributes){let n=this.morphAttributes[t],a=[];for(let t=0,r=n.length;t<r;t++){let r=n[t];a.push(r.toJSON(e.data))}a.length>0&&(r[t]=a,i=!0)}i&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere=o.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let n=e.index;n!==null&&this.setIndex(n.clone());let r=e.attributes;for(let e in r){let n=r[e];this.setAttribute(e,n.clone(t))}let i=e.morphAttributes;for(let e in i){let n=[],r=i[e];for(let e=0,i=r.length;e<i;e++)n.push(r[e].clone(t));this.morphAttributes[e]=n}this.morphTargetsRelative=e.morphTargetsRelative;let a=e.groups;for(let e=0,t=a.length;e<t;e++){let t=a[e];this.addGroup(t.start,t.count,t.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let s=e.boundingSphere;return s!==null&&(this.boundingSphere=s.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this._transformed=e._transformed,this}dispose(){this.dispatchEvent({type:`dispose`})}},Op=new Y,kp=new Y,Ap=new X,jp=class{constructor(e=new Y(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,r){return this.normal.set(e,t,n),this.constant=r,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){let r=Op.subVectors(n,t).cross(kp.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t,n=!0){let r=e.delta(Op),i=this.normal.dot(r);if(i===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let a=-(e.start.dot(this.normal)+this.constant)/i;return n===!0&&(a<0||a>1)?null:t.copy(e.start).addScaledVector(r,a)}intersectsLine(e){let t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let n=t||Ap.getNormalMatrix(e),r=this.coplanarPoint(Op).applyMatrix4(e),i=this.normal.applyMatrix3(n).normalize();return this.constant=-r.dot(i),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}toJSON(){return{normal:this.normal.toArray(),constant:this.constant}}fromJSON(e){return this.normal.fromArray(e.normal),this.constant=e.constant,this}},Mp=0,Np=class extends gd{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:Mp++}),this.uuid=bd(),this.name=``,this.type=`Material`,this.blending=1,this.side=0,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=204,this.blendDst=205,this.blendEquation=100,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Z(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=rd,this.stencilZFail=rd,this.stencilZPass=rd,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let n=e[t];if(n===void 0){K(`Material: parameter '${t}' has value of undefined.`);continue}let r=this[t];r===void 0?K(`Material: '${t}' is not a property of THREE.${this.type}.`):r&&r.isColor?r.set(n):r&&r.isVector2&&n&&n.isVector2||r&&r.isEuler&&n&&n.isEuler||r&&r.isVector3&&n&&n.isVector3?r.copy(n):this[t]=n}}toJSON(e){let t=e===void 0||typeof e==`string`;t&&(e={textures:{},images:{}});let n={metadata:{version:4.7,type:`Material`,generator:`Material.toJSON`}};n.uuid=this.uuid,n.type=this.type,n.blending=this.blending,n.side=this.side,n.shadowSide=this.shadowSide,n.vertexColors=this.vertexColors,n.opacity=this.opacity,n.transparent=this.transparent,n.blendSrc=this.blendSrc,n.blendDst=this.blendDst,n.blendEquation=this.blendEquation,n.blendSrcAlpha=this.blendSrcAlpha,n.blendDstAlpha=this.blendDstAlpha,n.blendEquationAlpha=this.blendEquationAlpha,n.blendColor=this.blendColor.getHex(),n.blendAlpha=this.blendAlpha,n.depthFunc=this.depthFunc,n.depthTest=this.depthTest,n.depthWrite=this.depthWrite,n.colorWrite=this.colorWrite,n.clipIntersection=this.clipIntersection,n.clipShadows=this.clipShadows,n.stencilWriteMask=this.stencilWriteMask,n.stencilFunc=this.stencilFunc,n.stencilRef=this.stencilRef,n.stencilFuncMask=this.stencilFuncMask,n.stencilFail=this.stencilFail,n.stencilZFail=this.stencilZFail,n.stencilZPass=this.stencilZPass,n.stencilWrite=this.stencilWrite,n.polygonOffset=this.polygonOffset,n.polygonOffsetFactor=this.polygonOffsetFactor,n.polygonOffsetUnits=this.polygonOffsetUnits,n.dithering=this.dithering,n.alphaTest=this.alphaTest,n.alphaHash=this.alphaHash,n.alphaToCoverage=this.alphaToCoverage,n.premultipliedAlpha=this.premultipliedAlpha,n.forceSinglePass=this.forceSinglePass,n.allowOverride=this.allowOverride,n.visible=this.visible,n.toneMapped=this.toneMapped,n.name=this.name,this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(n.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(n.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.retroreflectivity!==void 0&&(n.retroreflectivity=this.retroreflectivity),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),Array.isArray(this.clippingPlanes)&&this.clippingPlanes.length>0&&(n.clippingPlanes=this.clippingPlanes.map(e=>e.toJSON())),this.rotation!==void 0&&(n.rotation=this.rotation),this.depthPacking!==void 0&&(n.depthPacking=this.depthPacking),this.linewidth!==void 0&&(n.linewidth=this.linewidth),this.linecap!==void 0&&(n.linecap=this.linecap),this.linejoin!==void 0&&(n.linejoin=this.linejoin),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.wireframe!==void 0&&(n.wireframe=this.wireframe),this.wireframeLinewidth!==void 0&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!==void 0&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!==void 0&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading!==void 0&&(n.flatShading=this.flatShading),this.fog!==void 0&&(n.fog=this.fog),Object.keys(this.userData).length>0&&(n.userData=this.userData);function r(e){let t=[];for(let n in e){let r=e[n];delete r.metadata,t.push(r)}return t}if(t){let t=r(e.textures),i=r(e.images);t.length>0&&(n.textures=t),i.length>0&&(n.images=i)}return n}fromJSON(e,t){if(e.uuid!==void 0&&(this.uuid=e.uuid),e.name!==void 0&&(this.name=e.name),e.color!==void 0&&this.color!==void 0&&this.color.setHex(e.color),e.roughness!==void 0&&(this.roughness=e.roughness),e.metalness!==void 0&&(this.metalness=e.metalness),e.sheen!==void 0&&(this.sheen=e.sheen),e.sheenColor!==void 0&&(this.sheenColor=new Z().setHex(e.sheenColor)),e.sheenRoughness!==void 0&&(this.sheenRoughness=e.sheenRoughness),e.emissive!==void 0&&this.emissive!==void 0&&this.emissive.setHex(e.emissive),e.specular!==void 0&&this.specular!==void 0&&this.specular.setHex(e.specular),e.specularIntensity!==void 0&&(this.specularIntensity=e.specularIntensity),e.specularColor!==void 0&&this.specularColor!==void 0&&this.specularColor.setHex(e.specularColor),e.shininess!==void 0&&(this.shininess=e.shininess),e.clearcoat!==void 0&&(this.clearcoat=e.clearcoat),e.clearcoatRoughness!==void 0&&(this.clearcoatRoughness=e.clearcoatRoughness),e.dispersion!==void 0&&(this.dispersion=e.dispersion),e.retroreflectivity!==void 0&&(this.retroreflectivity=e.retroreflectivity),e.iridescence!==void 0&&(this.iridescence=e.iridescence),e.iridescenceIOR!==void 0&&(this.iridescenceIOR=e.iridescenceIOR),e.iridescenceThicknessRange!==void 0&&(this.iridescenceThicknessRange=e.iridescenceThicknessRange),e.transmission!==void 0&&(this.transmission=e.transmission),e.thickness!==void 0&&(this.thickness=e.thickness),e.attenuationDistance!==void 0&&(this.attenuationDistance=e.attenuationDistance),e.attenuationColor!==void 0&&this.attenuationColor!==void 0&&this.attenuationColor.setHex(e.attenuationColor),e.anisotropy!==void 0&&(this.anisotropy=e.anisotropy),e.anisotropyRotation!==void 0&&(this.anisotropyRotation=e.anisotropyRotation),e.fog!==void 0&&(this.fog=e.fog),e.flatShading!==void 0&&(this.flatShading=e.flatShading),e.blending!==void 0&&(this.blending=e.blending),e.combine!==void 0&&(this.combine=e.combine),e.side!==void 0&&(this.side=e.side),e.shadowSide!==void 0&&(this.shadowSide=e.shadowSide),e.opacity!==void 0&&(this.opacity=e.opacity),e.transparent!==void 0&&(this.transparent=e.transparent),e.alphaTest!==void 0&&(this.alphaTest=e.alphaTest),e.alphaHash!==void 0&&(this.alphaHash=e.alphaHash),e.depthFunc!==void 0&&(this.depthFunc=e.depthFunc),e.depthTest!==void 0&&(this.depthTest=e.depthTest),e.depthWrite!==void 0&&(this.depthWrite=e.depthWrite),e.colorWrite!==void 0&&(this.colorWrite=e.colorWrite),e.clippingPlanes!==void 0&&(this.clippingPlanes=e.clippingPlanes.map(e=>new jp().fromJSON(e))),e.clipIntersection!==void 0&&(this.clipIntersection=e.clipIntersection),e.clipShadows!==void 0&&(this.clipShadows=e.clipShadows),e.depthPacking!==void 0&&(this.depthPacking=e.depthPacking),e.blendSrc!==void 0&&(this.blendSrc=e.blendSrc),e.blendDst!==void 0&&(this.blendDst=e.blendDst),e.blendEquation!==void 0&&(this.blendEquation=e.blendEquation),e.blendSrcAlpha!==void 0&&(this.blendSrcAlpha=e.blendSrcAlpha),e.blendDstAlpha!==void 0&&(this.blendDstAlpha=e.blendDstAlpha),e.blendEquationAlpha!==void 0&&(this.blendEquationAlpha=e.blendEquationAlpha),e.blendColor!==void 0&&this.blendColor!==void 0&&this.blendColor.setHex(e.blendColor),e.blendAlpha!==void 0&&(this.blendAlpha=e.blendAlpha),e.stencilWriteMask!==void 0&&(this.stencilWriteMask=e.stencilWriteMask),e.stencilFunc!==void 0&&(this.stencilFunc=e.stencilFunc),e.stencilRef!==void 0&&(this.stencilRef=e.stencilRef),e.stencilFuncMask!==void 0&&(this.stencilFuncMask=e.stencilFuncMask),e.stencilFail!==void 0&&(this.stencilFail=e.stencilFail),e.stencilZFail!==void 0&&(this.stencilZFail=e.stencilZFail),e.stencilZPass!==void 0&&(this.stencilZPass=e.stencilZPass),e.stencilWrite!==void 0&&(this.stencilWrite=e.stencilWrite),e.wireframe!==void 0&&(this.wireframe=e.wireframe),e.wireframeLinewidth!==void 0&&(this.wireframeLinewidth=e.wireframeLinewidth),e.wireframeLinecap!==void 0&&(this.wireframeLinecap=e.wireframeLinecap),e.wireframeLinejoin!==void 0&&(this.wireframeLinejoin=e.wireframeLinejoin),e.rotation!==void 0&&(this.rotation=e.rotation),e.linewidth!==void 0&&(this.linewidth=e.linewidth),e.linecap!==void 0&&(this.linecap=e.linecap),e.linejoin!==void 0&&(this.linejoin=e.linejoin),e.dashSize!==void 0&&(this.dashSize=e.dashSize),e.gapSize!==void 0&&(this.gapSize=e.gapSize),e.scale!==void 0&&(this.scale=e.scale),e.polygonOffset!==void 0&&(this.polygonOffset=e.polygonOffset),e.polygonOffsetFactor!==void 0&&(this.polygonOffsetFactor=e.polygonOffsetFactor),e.polygonOffsetUnits!==void 0&&(this.polygonOffsetUnits=e.polygonOffsetUnits),e.dithering!==void 0&&(this.dithering=e.dithering),e.alphaToCoverage!==void 0&&(this.alphaToCoverage=e.alphaToCoverage),e.premultipliedAlpha!==void 0&&(this.premultipliedAlpha=e.premultipliedAlpha),e.forceSinglePass!==void 0&&(this.forceSinglePass=e.forceSinglePass),e.allowOverride!==void 0&&(this.allowOverride=e.allowOverride),e.visible!==void 0&&(this.visible=e.visible),e.toneMapped!==void 0&&(this.toneMapped=e.toneMapped),e.userData!==void 0&&(this.userData=e.userData),e.vertexColors!==void 0&&(this.vertexColors=typeof e.vertexColors==`number`?e.vertexColors>0:e.vertexColors),e.size!==void 0&&(this.size=e.size),e.sizeAttenuation!==void 0&&(this.sizeAttenuation=e.sizeAttenuation),e.map!==void 0&&(this.map=t[e.map]||null),e.matcap!==void 0&&(this.matcap=t[e.matcap]||null),e.alphaMap!==void 0&&(this.alphaMap=t[e.alphaMap]||null),e.bumpMap!==void 0&&(this.bumpMap=t[e.bumpMap]||null),e.bumpScale!==void 0&&(this.bumpScale=e.bumpScale),e.normalMap!==void 0&&(this.normalMap=t[e.normalMap]||null),e.normalMapType!==void 0&&(this.normalMapType=e.normalMapType),e.normalScale!==void 0){let t=e.normalScale;Array.isArray(t)===!1&&(t=[t,t]),this.normalScale=new J().fromArray(t)}return e.displacementMap!==void 0&&(this.displacementMap=t[e.displacementMap]||null),e.displacementScale!==void 0&&(this.displacementScale=e.displacementScale),e.displacementBias!==void 0&&(this.displacementBias=e.displacementBias),e.roughnessMap!==void 0&&(this.roughnessMap=t[e.roughnessMap]||null),e.metalnessMap!==void 0&&(this.metalnessMap=t[e.metalnessMap]||null),e.emissiveMap!==void 0&&(this.emissiveMap=t[e.emissiveMap]||null),e.emissiveIntensity!==void 0&&(this.emissiveIntensity=e.emissiveIntensity),e.specularMap!==void 0&&(this.specularMap=t[e.specularMap]||null),e.specularIntensityMap!==void 0&&(this.specularIntensityMap=t[e.specularIntensityMap]||null),e.specularColorMap!==void 0&&(this.specularColorMap=t[e.specularColorMap]||null),e.envMap!==void 0&&(this.envMap=t[e.envMap]||null),e.envMapRotation!==void 0&&this.envMapRotation.fromArray(e.envMapRotation),e.envMapIntensity!==void 0&&(this.envMapIntensity=e.envMapIntensity),e.reflectivity!==void 0&&(this.reflectivity=e.reflectivity),e.refractionRatio!==void 0&&(this.refractionRatio=e.refractionRatio),e.lightMap!==void 0&&(this.lightMap=t[e.lightMap]||null),e.lightMapIntensity!==void 0&&(this.lightMapIntensity=e.lightMapIntensity),e.aoMap!==void 0&&(this.aoMap=t[e.aoMap]||null),e.aoMapIntensity!==void 0&&(this.aoMapIntensity=e.aoMapIntensity),e.gradientMap!==void 0&&(this.gradientMap=t[e.gradientMap]||null),e.clearcoatMap!==void 0&&(this.clearcoatMap=t[e.clearcoatMap]||null),e.clearcoatRoughnessMap!==void 0&&(this.clearcoatRoughnessMap=t[e.clearcoatRoughnessMap]||null),e.clearcoatNormalMap!==void 0&&(this.clearcoatNormalMap=t[e.clearcoatNormalMap]||null),e.clearcoatNormalScale!==void 0&&(this.clearcoatNormalScale=new J().fromArray(e.clearcoatNormalScale)),e.iridescenceMap!==void 0&&(this.iridescenceMap=t[e.iridescenceMap]||null),e.iridescenceThicknessMap!==void 0&&(this.iridescenceThicknessMap=t[e.iridescenceThicknessMap]||null),e.transmissionMap!==void 0&&(this.transmissionMap=t[e.transmissionMap]||null),e.thicknessMap!==void 0&&(this.thicknessMap=t[e.thicknessMap]||null),e.anisotropyMap!==void 0&&(this.anisotropyMap=t[e.anisotropyMap]||null),e.sheenColorMap!==void 0&&(this.sheenColorMap=t[e.sheenColorMap]||null),e.sheenRoughnessMap!==void 0&&(this.sheenRoughnessMap=t[e.sheenRoughnessMap]||null),this}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,n=null;if(t!==null){let e=t.length;n=Array(e);for(let r=0;r!==e;++r)n[r]=t[r].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:`dispose`})}set needsUpdate(e){e===!0&&this.version++}},Pp=new Y,Fp=new Y,Ip=new Y,Lp=new Y,Rp=class{constructor(e=new Y,t=new Y(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Pp)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=Pp.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Pp.copy(this.origin).addScaledVector(this.direction,t),Pp.distanceToSquared(e))}distanceSqToSegment(e,t,n,r){Fp.copy(e).add(t).multiplyScalar(.5),Ip.copy(t).sub(e).normalize(),Lp.copy(this.origin).sub(Fp);let i=e.distanceTo(t)*.5,a=-this.direction.dot(Ip),o=Lp.dot(this.direction),s=-Lp.dot(Ip),c=Lp.lengthSq(),l=Math.abs(1-a*a),u,d,f,p;if(l>0){if(u=a*s-o,d=a*o-s,p=i*l,u>=0){if(d>=-p){if(d<=p){let e=1/l;u*=e,d*=e,f=u*(u+a*d+2*o)+d*(a*u+d+2*s)+c}else d=i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c}else d=-i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c}else d<=-p?(u=Math.max(0,-(-a*i+o)),d=u>0?-i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c):d<=p?(u=0,d=Math.min(Math.max(-i,-s),i),f=d*(d+2*s)+c):(u=Math.max(0,-(a*i+o)),d=u>0?i:Math.min(Math.max(-i,-s),i),f=-u*u+d*(d+2*s)+c)}else d=a>0?-i:i,u=Math.max(0,-(a*d+o)),f=-u*u+d*(d+2*s)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),r&&r.copy(Fp).addScaledVector(Ip,d),f}intersectSphere(e,t){if(e.radius<0)return null;Pp.subVectors(e.center,this.origin);let n=Pp.dot(this.direction),r=Pp.dot(Pp)-n*n,i=e.radius*e.radius;if(r>i)return null;let a=Math.sqrt(i-r),o=n-a,s=n+a;return s<0?null:o<0?this.at(s,t):this.at(o,t)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){let n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,r,i,a,o,s,c=1/this.direction.x,l=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,r=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,r=(e.min.x-d.x)*c),l>=0?(i=(e.min.y-d.y)*l,a=(e.max.y-d.y)*l):(i=(e.max.y-d.y)*l,a=(e.min.y-d.y)*l),n>a||i>r||((i>n||isNaN(n))&&(n=i),(a<r||isNaN(r))&&(r=a),u>=0?(o=(e.min.z-d.z)*u,s=(e.max.z-d.z)*u):(o=(e.max.z-d.z)*u,s=(e.min.z-d.z)*u),n>s||o>r)||((o>n||n!==n)&&(n=o),(s<r||r!==r)&&(r=s),r<0)?null:this.at(n>=0?n:r,t)}intersectsBox(e){return this.intersectBox(e,Pp)!==null}intersectTriangle(e,t,n,r,i){let a=this.origin,o=this.direction,s=o.x,c=o.y,l=o.z,u=e.x-a.x,d=e.y-a.y,f=e.z-a.z,p=t.x-a.x,m=t.y-a.y,h=t.z-a.z,g=n.x-a.x,_=n.y-a.y,v=n.z-a.z,y=Math.abs(s),b=Math.abs(c),x=Math.abs(l),S,C,w,T,E,D,O,k,A,j,ee,M;if(y>=b&&y>=x?(w=s,D=u,A=p,M=g,s>=0?(S=c,C=l,T=d,E=f,O=m,k=h,j=_,ee=v):(S=l,C=c,T=f,E=d,O=h,k=m,j=v,ee=_)):b>=x?(w=c,D=d,A=m,M=_,c>=0?(S=l,C=s,T=f,E=u,O=h,k=p,j=v,ee=g):(S=s,C=l,T=u,E=f,O=p,k=h,j=g,ee=v)):(w=l,D=f,A=h,M=v,l>=0?(S=s,C=c,T=u,E=d,O=p,k=m,j=g,ee=_):(S=c,C=s,T=d,E=u,O=m,k=p,j=_,ee=g)),w===0)return null;let te=S/w,ne=C/w,re=1/w,N=T-te*D,ie=E-ne*D,P=O-te*A,ae=k-ne*A,oe=j-te*M,F=ee-ne*M,I=oe*ae-F*P,se=N*F-ie*oe,L=P*ie-ae*N;if(r){if(I<0||se<0||L<0)return null}else if((I<0||se<0||L<0)&&(I>0||se>0||L>0))return null;let R=I+se+L;if(R===0)return null;let ce=re*(I*D+se*A+L*M);return(R>0?ce<0:ce>0)?null:this.at(ce/R,i)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},zp=class extends Np{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type=`MeshBasicMaterial`,this.color=new Z(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new of,this.combine=0,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},Bp=new Yd,Vp=new Rp,Hp=new yp,Up=new Y,Wp=new Y,Gp=new Y,Kp=new Y,qp=new Y,Jp=new Y,Yp=new Y,Xp=new Y,Zp=class extends Cf{constructor(e=new Dp,t=new zp){super(),this.isMesh=!0,this.type=`Mesh`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}getVertexPosition(e,t){let n=this.geometry,r=n.attributes.position,i=n.morphAttributes.position,a=n.morphTargetsRelative;t.fromBufferAttribute(r,e);let o=this.morphTargetInfluences;if(i&&o){Jp.set(0,0,0);for(let n=0,r=i.length;n<r;n++){let r=o[n],s=i[n];r!==0&&(qp.fromBufferAttribute(s,e),a?Jp.addScaledVector(qp,r):Jp.addScaledVector(qp.sub(t),r))}t.add(Jp)}return t}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.material,i=this.matrixWorld;r!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),Hp.copy(n.boundingSphere),Hp.applyMatrix4(i),Vp.copy(e.ray).recast(e.near),!(Hp.containsPoint(Vp.origin)===!1&&(Vp.intersectSphere(Hp,Up)===null||Vp.origin.distanceToSquared(Up)>(e.far-e.near)**2))&&(Bp.copy(i).invert(),Vp.copy(e.ray).applyMatrix4(Bp),(n.boundingBox===null||Vp.intersectsBox(n.boundingBox)!==!1)&&this._computeIntersections(e,t,Vp)))}_computeIntersections(e,t,n){let r,i=this.geometry,a=this.material,o=i.index,s=i.attributes.position,c=i.attributes.uv,l=i.attributes.uv1,u=i.attributes.normal,d=i.groups,f=i.drawRange;if(o!==null){if(Array.isArray(a))for(let i=0,s=d.length;i<s;i++){let s=d[i],p=a[s.materialIndex],m=Math.max(s.start,f.start),h=Math.min(o.count,Math.min(s.start+s.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=o.getX(i),d=o.getX(i+1),f=o.getX(i+2);r=$p(this,p,e,n,c,l,u,a,d,f),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=s.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),s=Math.min(o.count,f.start+f.count);for(let d=i,f=s;d<f;d+=3){let i=o.getX(d),s=o.getX(d+1),f=o.getX(d+2);r=$p(this,a,e,n,c,l,u,i,s,f),r&&(r.faceIndex=Math.floor(d/3),t.push(r))}}}else if(s!==void 0){if(Array.isArray(a))for(let i=0,o=d.length;i<o;i++){let o=d[i],p=a[o.materialIndex],m=Math.max(o.start,f.start),h=Math.min(s.count,Math.min(o.start+o.count,f.start+f.count));for(let i=m,a=h;i<a;i+=3){let a=i,s=i+1,d=i+2;r=$p(this,p,e,n,c,l,u,a,s,d),r&&(r.faceIndex=Math.floor(i/3),r.face.materialIndex=o.materialIndex,t.push(r))}}else{let i=Math.max(0,f.start),o=Math.min(s.count,f.start+f.count);for(let s=i,d=o;s<d;s+=3){let i=s,o=s+1,d=s+2;r=$p(this,a,e,n,c,l,u,i,o,d),r&&(r.faceIndex=Math.floor(s/3),t.push(r))}}}}};function Qp(e,t,n,r,i,a,o,s){let c;if(c=t.side===1?r.intersectTriangle(o,a,i,!0,s):r.intersectTriangle(i,a,o,t.side===0,s),c===null)return null;Xp.copy(s),Xp.applyMatrix4(e.matrixWorld);let l=n.ray.origin.distanceTo(Xp);return l<n.near||l>n.far?null:{distance:l,point:Xp.clone(),object:e}}function $p(e,t,n,r,i,a,o,s,c,l){e.getVertexPosition(s,Wp),e.getVertexPosition(c,Gp),e.getVertexPosition(l,Kp);let u=Qp(e,t,n,r,Wp,Gp,Kp,Yp);if(u){let e=new Y;qf.getBarycoord(Yp,Wp,Gp,Kp,e),i&&(u.uv=qf.getInterpolatedAttribute(i,s,c,l,e,new J)),a&&(u.uv1=qf.getInterpolatedAttribute(a,s,c,l,e,new J)),o&&(u.normal=qf.getInterpolatedAttribute(o,s,c,l,e,new Y),u.normal.dot(r.direction)>0&&u.normal.multiplyScalar(-1));let t={a:s,b:c,c:l,normal:new Y,materialIndex:0};qf.getNormal(Wp,Gp,Kp,t.normal),u.face=t,u.barycoord=e}return u}var em=class extends Ud{constructor(e=null,t=1,n=1,r,i,a,o,s,c=Pl,l=Pl,u,d){super(null,a,o,s,c,l,r,i,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},tm=class extends fp{constructor(e,t,n,r=1){super(e,t,n),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=r}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},nm=new Yd,rm=new Yd,im=[],am=new Jf,om=new Yd,sm=new Zp,cm=new yp,lm=class extends Zp{constructor(e,t,n){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new tm(new Float32Array(n*16),16),this.instanceColor=null,this.morphTexture=null,this.count=n,this.boundingBox=null,this.boundingSphere=null;for(let e=0;e<n;e++)this.setMatrixAt(e,om)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new Jf),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,nm),am.copy(e.boundingBox).applyMatrix4(nm),this.boundingBox.union(am)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new yp),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let n=0;n<t;n++)this.getMatrixAt(n,nm),cm.copy(e.boundingSphere).applyMatrix4(nm),this.boundingSphere.union(cm)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){return this.instanceColor===null?t.setRGB(1,1,1):t.fromArray(this.instanceColor.array,e*3)}getMatrixAt(e,t){return t.fromArray(this.instanceMatrix.array,e*16)}getMorphAt(e,t){let n=t.morphTargetInfluences,r=this.morphTexture.source.data.data,i=e*(n.length+1)+1;for(let e=0;e<n.length;e++)n[e]=r[i+e]}raycast(e,t){let n=this.matrixWorld,r=this.count;if(sm.geometry=this.geometry,sm.material=this.material,sm.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),cm.copy(this.boundingSphere),cm.applyMatrix4(n),e.ray.intersectsSphere(cm)!==!1))for(let i=0;i<r;i++){this.getMatrixAt(i,nm),rm.multiplyMatrices(n,nm),sm.matrixWorld=rm,sm.raycast(e,im);for(let e=0,n=im.length;e<n;e++){let n=im[e];n.instanceId=i,n.object=this,t.push(n)}im.length=0}}setColorAt(e,t){return this.instanceColor===null&&(this.instanceColor=new tm(new Float32Array(this.instanceMatrix.count*3).fill(1),3)),t.toArray(this.instanceColor.array,e*3),this}setMatrixAt(e,t){return t.toArray(this.instanceMatrix.array,e*16),this}setMorphAt(e,t){let n=t.morphTargetInfluences,r=n.length+1;this.morphTexture===null&&(this.morphTexture=new em(new Float32Array(r*this.count),r,this.count,iu,Kl));let i=this.morphTexture.source.data.data,a=0;for(let e=0;e<n.length;e++)a+=n[e];let o=this.geometry.morphTargetsRelative?1:1-a,s=r*e;return i[s]=o,i.set(n,s+1),this}updateMorphTargets(){}dispose(){super.dispose(),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null)}},um=new yp,dm=new J(.5,.5),fm=new Y,pm=class{constructor(e=new jp,t=new jp,n=new jp,r=new jp,i=new jp,a=new jp){this.planes=[e,t,n,r,i,a]}set(e,t,n,r,i,a){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(n),o[3].copy(r),o[4].copy(i),o[5].copy(a),this}copy(e){let t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=ad,n=!1){let r=this.planes,i=e.elements,a=i[0],o=i[1],s=i[2],c=i[3],l=i[4],u=i[5],d=i[6],f=i[7],p=i[8],m=i[9],h=i[10],g=i[11],_=i[12],v=i[13],y=i[14],b=i[15];if(r[0].setComponents(c-a,f-l,g-p,b-_).normalize(),r[1].setComponents(c+a,f+l,g+p,b+_).normalize(),r[2].setComponents(c+o,f+u,g+m,b+v).normalize(),r[3].setComponents(c-o,f-u,g-m,b-v).normalize(),n)r[4].setComponents(s,d,h,y).normalize(),r[5].setComponents(c-s,f-d,g-h,b-y).normalize();else if(r[4].setComponents(c-s,f-d,g-h,b-y).normalize(),t===2e3)r[5].setComponents(c+s,f+d,g+h,b+y).normalize();else if(t===2001)r[5].setComponents(s,d,h,y).normalize();else throw Error(`THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: `+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),um.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),um.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(um)}intersectsSprite(e){return um.center.set(0,0,0),um.radius=.7071067811865476+dm.distanceTo(e.center),um.applyMatrix4(e.matrixWorld),this.intersectsSphere(um)}intersectsSphere(e){let t=this.planes,n=e.center,r=-e.radius;for(let e=0;e<6;e++)if(t[e].distanceToPoint(n)<r)return!1;return!0}intersectsBox(e){let t=this.planes;for(let n=0;n<6;n++){let r=t[n];if(fm.x=r.normal.x>0?e.max.x:e.min.x,fm.y=r.normal.y>0?e.max.y:e.min.y,fm.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(fm)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}},mm=class extends Np{constructor(e){super(),this.isLineBasicMaterial=!0,this.type=`LineBasicMaterial`,this.color=new Z(16777215),this.map=null,this.linewidth=1,this.linecap=`round`,this.linejoin=`round`,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},hm=new Y,gm=new Y,_m=new Yd,vm=new Rp,ym=new yp,bm=new Y,xm=new Y,Sm=class extends Cf{constructor(e=new Dp,t=new mm){super(),this.isLine=!0,this.type=`Line`,this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[0];for(let e=1,r=t.count;e<r;e++)hm.fromBufferAttribute(t,e-1),gm.fromBufferAttribute(t,e),n[e]=n[e-1],n[e]+=hm.distanceTo(gm);e.setAttribute(`lineDistance`,new hp(n,1))}else K(`Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}intersectsFrustum(e){return e.intersectsObject(this)}raycast(e,t){let n=this.geometry,r=this.matrixWorld,i=e.params.Line.threshold,a=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),ym.copy(n.boundingSphere),ym.applyMatrix4(r),ym.radius+=i,e.ray.intersectsSphere(ym)===!1)return;_m.copy(r).invert(),vm.copy(e.ray).applyMatrix4(_m);let o=i/((this.scale.x+this.scale.y+this.scale.z)/3),s=o*o,c=this.isLineSegments?2:1,l=n.index,u=n.attributes.position;if(l!==null){let n=Math.max(0,a.start),r=Math.min(l.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=l.getX(i),r=l.getX(i+1),a=Cm(this,e,vm,s,n,r,i);a&&t.push(a)}if(this.isLineLoop){let i=l.getX(r-1),a=l.getX(n),o=Cm(this,e,vm,s,i,a,r-1);o&&t.push(o)}}else{let n=Math.max(0,a.start),r=Math.min(u.count,a.start+a.count);for(let i=n,a=r-1;i<a;i+=c){let n=Cm(this,e,vm,s,i,i+1,i);n&&t.push(n)}if(this.isLineLoop){let i=Cm(this,e,vm,s,r-1,n,r-1);i&&t.push(i)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let n=e[t[0]];if(n!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let e=0,t=n.length;e<t;e++){let t=n[e].name||String(e);this.morphTargetInfluences.push(0),this.morphTargetDictionary[t]=e}}}}};function Cm(e,t,n,r,i,a,o){let s=e.geometry.attributes.position;if(hm.fromBufferAttribute(s,i),gm.fromBufferAttribute(s,a),n.distanceSqToSegment(hm,gm,bm,xm)>r)return;bm.applyMatrix4(e.matrixWorld);let c=t.ray.origin.distanceTo(bm);if(!(c<t.near||c>t.far))return{distance:c,point:xm.clone().applyMatrix4(e.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:e}}var wm=new Y,Tm=new Y,Em=class extends Sm{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type=`LineSegments`}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,n=[];for(let e=0,r=t.count;e<r;e+=2)wm.fromBufferAttribute(t,e),Tm.fromBufferAttribute(t,e+1),n[e]=e===0?0:n[e-1],n[e+1]=n[e]+wm.distanceTo(Tm);e.setAttribute(`lineDistance`,new hp(n,1))}else K(`LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.`);return this}},Dm=class extends Ud{constructor(e=[],t=301,n,r,i,a,o,s,c,l){super(e,t,n,r,i,a,o,s,c,l),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},Om=class extends Ud{constructor(e,t,n,r,i,a,o,s,c){super(e,t,n,r,i,a,o,s,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},km=class extends Ud{constructor(e,t,n=Gl,r,i,a,o=Pl,s=Pl,c,l=nu,u=1){if(l!==1026&&l!==1027)throw Error(`THREE.DepthTexture: format must be either THREE.DepthFormat or THREE.DepthStencilFormat`);super({width:e,height:t,depth:u},r,i,a,o,s,l,n,c),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new zd(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return t.compareFunction=this.compareFunction,t}},Am=class extends km{constructor(e,t=Gl,n=301,r,i,a=Pl,o=Pl,s,c=nu){let l={width:e,height:e,depth:1},u=[l,l,l,l,l,l];super(e,e,t,n,r,i,a,o,s,c),this.image=u,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}},jm=class extends Ud{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}},Mm=class e extends Dp{constructor(e=1,t=1,n=1,r=1,i=1,a=1){super(),this.type=`BoxGeometry`,this.parameters={width:e,height:t,depth:n,widthSegments:r,heightSegments:i,depthSegments:a};let o=this;r=Math.floor(r),i=Math.floor(i),a=Math.floor(a);let s=[],c=[],l=[],u=[],d=0,f=0;p(`z`,`y`,`x`,-1,-1,n,t,e,a,i,0),p(`z`,`y`,`x`,1,-1,n,t,-e,a,i,1),p(`x`,`z`,`y`,1,1,e,n,t,r,a,2),p(`x`,`z`,`y`,1,-1,e,n,-t,r,a,3),p(`x`,`y`,`z`,1,-1,e,t,n,r,i,4),p(`x`,`y`,`z`,-1,-1,e,t,-n,r,i,5),this.setIndex(s),this.setAttribute(`position`,new hp(c,3)),this.setAttribute(`normal`,new hp(l,3)),this.setAttribute(`uv`,new hp(u,2));function p(e,t,n,r,i,a,p,m,h,g,_){let v=a/h,y=p/g,b=a/2,x=p/2,S=m/2,C=h+1,w=g+1,T=0,E=0,D=new Y;for(let a=0;a<w;a++){let o=a*y-x;for(let s=0;s<C;s++)D[e]=(s*v-b)*r,D[t]=o*i,D[n]=S,c.push(D.x,D.y,D.z),D[e]=0,D[t]=0,D[n]=m>0?1:-1,l.push(D.x,D.y,D.z),u.push(s/h),u.push(1-a/g),T+=1}for(let e=0;e<g;e++)for(let t=0;t<h;t++){let n=d+t+C*e,r=d+t+C*(e+1),i=d+(t+1)+C*(e+1),a=d+(t+1)+C*e;s.push(n,r,a),s.push(r,i,a),E+=6}o.addGroup(f,E,_),f+=E,d+=T}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)}},Nm=class e extends Dp{constructor(e=1,t=1,n=1,r=32,i=1,a=!1,o=0,s=Math.PI*2){super(),this.type=`CylinderGeometry`,this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:r,heightSegments:i,openEnded:a,thetaStart:o,thetaLength:s};let c=this;r=Math.floor(r),i=Math.floor(i);let l=[],u=[],d=[],f=[],p=0,m=[],h=n/2,g=0;_(),a===!1&&(e>0&&v(!0),t>0&&v(!1)),this.setIndex(l),this.setAttribute(`position`,new hp(u,3)),this.setAttribute(`normal`,new hp(d,3)),this.setAttribute(`uv`,new hp(f,2));function _(){let a=new Y,_=new Y,v=0,y=(t-e)/n;for(let c=0;c<=i;c++){let l=[],g=c/i,v=g*(t-e)+e;for(let e=0;e<=r;e++){let t=e/r,i=t*s+o,c=Math.sin(i),m=Math.cos(i);_.x=v*c,_.y=-g*n+h,_.z=v*m,u.push(_.x,_.y,_.z),a.set(c,y,m).normalize(),d.push(a.x,a.y,a.z),f.push(t,1-g),l.push(p++)}m.push(l)}for(let n=0;n<r;n++)for(let r=0;r<i;r++){let a=m[r][n],o=m[r+1][n],s=m[r+1][n+1],c=m[r][n+1];(e>0||r!==0)&&(l.push(a,o,c),v+=3),(t>0||r!==i-1)&&(l.push(o,s,c),v+=3)}c.addGroup(g,v,0),g+=v}function v(n){let i=p,a=new J,m=new Y,_=0,v=n===!0?e:t,y=n===!0?1:-1;for(let e=1;e<=r;e++)u.push(0,h*y,0),d.push(0,y,0),f.push(.5,.5),p++;let b=p;for(let e=0;e<=r;e++){let t=e/r*s+o,n=Math.cos(t),i=Math.sin(t);m.x=v*i,m.y=h*y,m.z=v*n,u.push(m.x,m.y,m.z),d.push(0,y,0),a.x=n*.5+.5,a.y=i*.5*y+.5,f.push(a.x,a.y),p++}for(let e=0;e<r;e++){let t=i+e,r=b+e;n===!0?l.push(r,r+1,t):l.push(r+1,r,t),_+=3}c.addGroup(g,_,n===!0?1:2),g+=_}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Pm=class e extends Nm{constructor(e=1,t=1,n=32,r=1,i=!1,a=0,o=Math.PI*2){super(0,e,t,n,r,i,a,o),this.type=`ConeGeometry`,this.parameters={radius:e,height:t,radialSegments:n,heightSegments:r,openEnded:i,thetaStart:a,thetaLength:o}}static fromJSON(t){return new e(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)}},Fm=class e extends Dp{constructor(e=[],t=[],n=1,r=0){super(),this.type=`PolyhedronGeometry`,this.parameters={vertices:e,indices:t,radius:n,detail:r};let i=[],a=[];o(r),c(n),l(),this.setAttribute(`position`,new hp(i,3)),this.setAttribute(`normal`,new hp(i.slice(),3)),this.setAttribute(`uv`,new hp(a,2)),r===0?this.computeVertexNormals():this.normalizeNormals();function o(e){let n=new Y,r=new Y,i=new Y;for(let a=0;a<t.length;a+=3)f(t[a+0],n),f(t[a+1],r),f(t[a+2],i),s(n,r,i,e)}function s(e,t,n,r){let i=r+1,a=[];for(let r=0;r<=i;r++){a[r]=[];let o=e.clone().lerp(n,r/i),s=t.clone().lerp(n,r/i),c=i-r;for(let e=0;e<=c;e++)e===0&&r===i?a[r][e]=o:a[r][e]=o.clone().lerp(s,e/c)}for(let e=0;e<i;e++)for(let t=0;t<2*(i-e)-1;t++){let n=Math.floor(t/2);t%2==0?(d(a[e][n+1]),d(a[e+1][n]),d(a[e][n])):(d(a[e][n+1]),d(a[e+1][n+1]),d(a[e+1][n]))}}function c(e){let t=new Y;for(let n=0;n<i.length;n+=3)t.x=i[n+0],t.y=i[n+1],t.z=i[n+2],t.normalize().multiplyScalar(e),i[n+0]=t.x,i[n+1]=t.y,i[n+2]=t.z}function l(){let e=new Y;for(let t=0;t<i.length;t+=3){e.x=i[t+0],e.y=i[t+1],e.z=i[t+2];let n=h(e)/2/Math.PI+.5,r=g(e)/Math.PI+.5;a.push(n,1-r)}p(),u()}function u(){for(let e=0;e<a.length;e+=6){let t=a[e+0],n=a[e+2],r=a[e+4];Math.max(t,n,r)>.9&&Math.min(t,n,r)<.1&&(t<.2&&(a[e+0]+=1),n<.2&&(a[e+2]+=1),r<.2&&(a[e+4]+=1))}}function d(e){i.push(e.x,e.y,e.z)}function f(t,n){let r=t*3;n.x=e[r+0],n.y=e[r+1],n.z=e[r+2]}function p(){let e=new Y,t=new Y,n=new Y,r=new Y,o=new J,s=new J,c=new J;for(let l=0,u=0;l<i.length;l+=9,u+=6){e.set(i[l+0],i[l+1],i[l+2]),t.set(i[l+3],i[l+4],i[l+5]),n.set(i[l+6],i[l+7],i[l+8]),o.set(a[u+0],a[u+1]),s.set(a[u+2],a[u+3]),c.set(a[u+4],a[u+5]),r.copy(e).add(t).add(n).divideScalar(3);let d=h(r);m(o,u+0,e,d),m(s,u+2,t,d),m(c,u+4,n,d)}}function m(e,t,n,r){r<0&&e.x===1&&(a[t]=e.x-1),n.x===0&&n.z===0&&(a[t]=r/2/Math.PI+.5)}function h(e){return Math.atan2(e.z,-e.x)}function g(e){return Math.atan2(-e.y,Math.sqrt(e.x*e.x+e.z*e.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.vertices,t.indices,t.radius,t.detail)}},Im=class e extends Fm{constructor(e=1,t=0){let n=(1+Math.sqrt(5))/2,r=[-1,n,0,1,n,0,-1,-n,0,1,-n,0,0,-1,n,0,1,n,0,-1,-n,0,1,-n,n,0,-1,n,0,1,-n,0,-1,-n,0,1];super(r,[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1],e,t),this.type=`IcosahedronGeometry`,this.parameters={radius:e,detail:t}}static fromJSON(t){return new e(t.radius,t.detail)}},Lm=class e extends Fm{constructor(e=1,t=0){super([1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2],e,t),this.type=`OctahedronGeometry`,this.parameters={radius:e,detail:t}}static fromJSON(t){return new e(t.radius,t.detail)}},Rm=class e extends Dp{constructor(e=1,t=1,n=1,r=1){super(),this.type=`PlaneGeometry`,this.parameters={width:e,height:t,widthSegments:n,heightSegments:r};let i=e/2,a=t/2,o=Math.floor(n),s=Math.floor(r),c=o+1,l=s+1,u=e/o,d=t/s,f=[],p=[],m=[],h=[];for(let e=0;e<l;e++){let t=e*d-a;for(let n=0;n<c;n++){let r=n*u-i;p.push(r,-t,0),m.push(0,0,1),h.push(n/o),h.push(1-e/s)}}for(let e=0;e<s;e++)for(let t=0;t<o;t++){let n=t+c*e,r=t+c*(e+1),i=t+1+c*(e+1),a=t+1+c*e;f.push(n,r,a),f.push(r,i,a)}this.setIndex(f),this.setAttribute(`position`,new hp(p,3)),this.setAttribute(`normal`,new hp(m,3)),this.setAttribute(`uv`,new hp(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.width,t.height,t.widthSegments,t.heightSegments)}},zm=class e extends Dp{constructor(e=1,t=32,n=16,r=0,i=Math.PI*2,a=0,o=Math.PI){super(),this.type=`SphereGeometry`,this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:r,phiLength:i,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));let s=Math.min(a+o,Math.PI),c=0,l=[],u=new Y,d=new Y,f=[],p=[],m=[],h=[];for(let f=0;f<=n;f++){let g=[],_=f/n,v=a+_*o,y=e*Math.cos(v),b=Math.sqrt(e*e-y*y),x=0;f===0&&a===0?x=.5/t:f===n&&s===Math.PI&&(x=-.5/t);for(let e=0;e<=t;e++){let n=e/t,a=r+n*i;u.x=-b*Math.cos(a),u.y=y,u.z=b*Math.sin(a),p.push(u.x,u.y,u.z),d.copy(u).normalize(),m.push(d.x,d.y,d.z),h.push(n+x,1-_),g.push(c++)}l.push(g)}for(let e=0;e<n;e++)for(let r=0;r<t;r++){let t=l[e][r+1],i=l[e][r],o=l[e+1][r],c=l[e+1][r+1];(e!==0||a>0)&&f.push(t,i,c),(e!==n-1||s<Math.PI)&&f.push(i,o,c)}this.setIndex(f),this.setAttribute(`position`,new hp(p,3)),this.setAttribute(`normal`,new hp(m,3)),this.setAttribute(`uv`,new hp(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)}},Bm=class e extends Fm{constructor(e=1,t=0){super([1,1,1,-1,-1,1,-1,1,-1,1,-1,-1],[2,1,0,0,3,2,1,3,0,2,3,1],e,t),this.type=`TetrahedronGeometry`,this.parameters={radius:e,detail:t}}static fromJSON(t){return new e(t.radius,t.detail)}},Vm=class e extends Dp{constructor(e=1,t=.4,n=12,r=48,i=Math.PI*2,a=0,o=Math.PI*2){super(),this.type=`TorusGeometry`,this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:r,arc:i,thetaStart:a,thetaLength:o},n=Math.floor(n),r=Math.floor(r);let s=[],c=[],l=[],u=[],d=new Y,f=new Y,p=new Y;for(let s=0;s<=n;s++){let m=a+s/n*o;for(let a=0;a<=r;a++){let o=a/r*i;f.x=(e+t*Math.cos(m))*Math.cos(o),f.y=(e+t*Math.cos(m))*Math.sin(o),f.z=t*Math.sin(m),c.push(f.x,f.y,f.z),d.x=e*Math.cos(o),d.y=e*Math.sin(o),p.subVectors(f,d).normalize(),l.push(p.x,p.y,p.z),u.push(a/r),u.push(s/n)}}for(let e=1;e<=n;e++)for(let t=1;t<=r;t++){let n=(r+1)*e+t-1,i=(r+1)*(e-1)+t-1,a=(r+1)*(e-1)+t,o=(r+1)*e+t;s.push(n,i,o),s.push(i,a,o)}this.setIndex(s),this.setAttribute(`position`,new hp(c,3)),this.setAttribute(`normal`,new hp(l,3)),this.setAttribute(`uv`,new hp(u,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(t){return new e(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc,t.thetaStart,t.thetaLength)}};function Hm(e){let t={};for(let n in e){t[n]={};for(let r in e[n]){let i=e[n][r];if(Wm(i))i.isRenderTargetTexture?(K(`UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms().`),t[n][r]=null):t[n][r]=i.clone();else if(Array.isArray(i)){if(Wm(i[0])){let e=[];for(let t=0,n=i.length;t<n;t++)e[t]=i[t].clone();t[n][r]=e}else t[n][r]=i.slice()}else t[n][r]=i}}return t}function Um(e){let t={};for(let n=0;n<e.length;n++){let r=Hm(e[n]);for(let e in r)t[e]=r[e]}return t}function Wm(e){return e&&(e.isColor||e.isMatrix3||e.isMatrix4||e.isVector2||e.isVector3||e.isVector4||e.isTexture||e.isQuaternion)}function Gm(e){let t=[];for(let n=0;n<e.length;n++)t.push(e[n].clone());return t}function Km(e){let t=e.getRenderTarget();return t===null?e.outputColorSpace:t.isXRRenderTarget===!0?t.texture.colorSpace:Nd.workingColorSpace}var qm={clone:Hm,merge:Um},Jm=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Ym=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,Xm=class extends Np{constructor(e){super(),this.isShaderMaterial=!0,this.type=`ShaderMaterial`,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=Jm,this.fragmentShader=Ym,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Hm(e.uniforms),this.uniformsGroups=Gm(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let n in this.uniforms){let r=this.uniforms[n].value;r&&r.isTexture?t.uniforms[n]={type:`t`,value:r.toJSON(e).uuid}:r&&r.isColor?t.uniforms[n]={type:`c`,value:r.getHex()}:r&&r.isVector2?t.uniforms[n]={type:`v2`,value:r.toArray()}:r&&r.isVector3?t.uniforms[n]={type:`v3`,value:r.toArray()}:r&&r.isVector4?t.uniforms[n]={type:`v4`,value:r.toArray()}:r&&r.isMatrix3?t.uniforms[n]={type:`m3`,value:r.toArray()}:r&&r.isMatrix4?t.uniforms[n]={type:`m4`,value:r.toArray()}:t.uniforms[n]={value:r}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let n={};for(let e in this.extensions)this.extensions[e]===!0&&(n[e]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}fromJSON(e,t){if(super.fromJSON(e,t),e.uniforms!==void 0)for(let n in e.uniforms){let r=e.uniforms[n];switch(this.uniforms[n]={},r.type){case`t`:this.uniforms[n].value=t[r.value]||null;break;case`c`:this.uniforms[n].value=new Z().setHex(r.value);break;case`v2`:this.uniforms[n].value=new J().fromArray(r.value);break;case`v3`:this.uniforms[n].value=new Y().fromArray(r.value);break;case`v4`:this.uniforms[n].value=new Wd().fromArray(r.value);break;case`m3`:this.uniforms[n].value=new X().fromArray(r.value);break;case`m4`:this.uniforms[n].value=new Yd().fromArray(r.value);break;default:this.uniforms[n].value=r.value}}if(e.defines!==void 0&&(this.defines=e.defines),e.vertexShader!==void 0&&(this.vertexShader=e.vertexShader),e.fragmentShader!==void 0&&(this.fragmentShader=e.fragmentShader),e.glslVersion!==void 0&&(this.glslVersion=e.glslVersion),e.extensions!==void 0)for(let t in e.extensions)this.extensions[t]=e.extensions[t];return e.lights!==void 0&&(this.lights=e.lights),e.clipping!==void 0&&(this.clipping=e.clipping),this}},Zm=class extends Xm{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type=`RawShaderMaterial`}},Qm=class extends Np{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type=`MeshLambertMaterial`,this.color=new Z(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Z(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new J(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new of,this.combine=0,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap=`round`,this.wireframeLinejoin=`round`,this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.envMapIntensity=e.envMapIntensity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}},$m=class extends Np{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type=`MeshDepthMaterial`,this.depthPacking=Qu,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},eh=class extends Np{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type=`MeshDistanceMaterial`,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}};function th(e,t){return!e||e.constructor===t?e:typeof t.BYTES_PER_ELEMENT==`number`?new t(e):Array.prototype.slice.call(e)}function nh(e){return e!==void 0&&e.inTangents!==void 0&&e.outTangents!==void 0}var rh=class{constructor(e,t,n,r){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=r===void 0?new t.constructor(n):r,this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,n=this._cachedIndex,r=t[n],i=t[n-1];validate_interval:{seek:{let a;linear_scan:{forward_scan:if(!(e<r)){for(let a=n+2;;){if(r===void 0){if(e<i)break forward_scan;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(i=r,r=t[++n],e<r)break seek}a=t.length;break linear_scan}if(!(e>=i)){let o=t[1];e<o&&(n=2,i=o);for(let a=n-2;;){if(i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===a)break;if(r=i,i=t[--n-1],e>=i)break seek}a=n,n=0;break linear_scan}break validate_interval}for(;n<a;){let r=n+a>>>1;e<t[r]?a=r:n=r+1}if(r=t[n],i=t[n-1],i===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(r===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,i,r)}return this.interpolate_(n,i,e,r)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,n=this.sampleValues,r=this.valueSize,i=e*r;for(let e=0;e!==r;++e)t[e]=n[i+e];return t}interpolate_(){throw Error(`THREE.Interpolant: Call to abstract method.`)}intervalChanged_(){}},ih=class extends rh{constructor(e,t,n,r){super(e,t,n,r),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Yu,endingEnd:Yu}}intervalChanged_(e,t,n){let r=this.parameterPositions,i=e-2,a=e+1,o=r[i],s=r[a];if(o===void 0)switch(this.getSettings_().endingStart){case Xu:i=e,o=2*t-n;break;case Zu:i=r.length-2,o=t+r[i]-r[i+1];break;default:i=e,o=n}if(s===void 0)switch(this.getSettings_().endingEnd){case Xu:a=e,s=2*n-t;break;case Zu:a=1,s=n+r[1]-r[0];break;default:a=e-1,s=t}let c=(n-t)*.5,l=this.valueSize;this._weightPrev=c/(t-o),this._weightNext=c/(s-n),this._offsetPrev=i*l,this._offsetNext=a*l}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,p=(n-t)/(r-t),m=p*p,h=m*p,g=-d*h+2*d*m-d*p,_=(1+d)*h+(-1.5-2*d)*m+(-.5+d)*p+1,v=(-1-f)*h+(1.5+f)*m+.5*p,y=f*h-f*m;for(let e=0;e!==o;++e)i[e]=g*a[l+e]+_*a[c+e]+v*a[s+e]+y*a[u+e];return i}},ah=class extends rh{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=(n-t)/(r-t),u=1-l;for(let e=0;e!==o;++e)i[e]=a[c+e]*u+a[s+e]*l;return i}},oh=class extends rh{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e){return this.copySampleValue_(e-1)}},sh=class extends rh{interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=e*o,c=s-o,l=this.inTangents,u=this.outTangents;if(!l||!u){let e=(n-t)/(r-t),l=1-e;for(let t=0;t!==o;++t)i[t]=a[c+t]*l+a[s+t]*e;return i}let d=o*2,f=e-1;for(let p=0;p!==o;++p){let o=a[c+p],m=a[s+p],h=f*d+p*2,g=u[h],_=u[h+1],v=e*d+p*2,y=l[v],b=l[v+1],x=uh(n,t,g,y,r);i[p]=ch(x,o,_,b,m)}return i}};function ch(e,t,n,r,i){let a=1-e;return a*a*a*t+3*a*a*e*n+3*a*e*e*r+e*e*e*i}function lh(e,t,n,r,i){let a=1-e;return 3*a*a*(n-t)+6*a*e*(r-n)+3*e*e*(i-r)}function uh(e,t,n,r,i){let a=(e-t)/(i-t);for(let o=0;o<8;o++){let o=ch(a,t,n,r,i)-e;if(Math.abs(o)<1e-10)break;let s=lh(a,t,n,r,i);if(Math.abs(s)<1e-10)break;a=Math.max(0,Math.min(1,a-o/s))}return a}var dh=class{constructor(e,t,n,r){if(e===void 0)throw Error(`THREE.KeyframeTrack: track name is undefined`);if(t===void 0||t.length===0)throw Error(`THREE.KeyframeTrack: no keyframes in track named `+e);this.name=e,this.times=th(t,this.TimeBufferType),this.values=th(n,this.ValueBufferType),this.setInterpolation(r||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:th(e.times,Array),values:th(e.values,Array)};let t=e.getInterpolation();t!==e.DefaultInterpolation&&(n.interpolation=t),nh(e.settings)&&(n.settings={inTangents:th(e.settings.inTangents,Array),outTangents:th(e.settings.outTangents,Array)})}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new oh(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new ah(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new ih(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodBezier(e){let t=new sh(this.times,this.values,this.getValueSize(),e);return this.settings&&(t.inTangents=this.settings.inTangents,t.outTangents=this.settings.outTangents),t}setInterpolation(e){let t;switch(e){case Gu:t=this.InterpolantFactoryMethodDiscrete;break;case Ku:t=this.InterpolantFactoryMethodLinear;break;case qu:t=this.InterpolantFactoryMethodSmooth;break;case Ju:t=this.InterpolantFactoryMethodBezier}if(t===void 0){let t=`unsupported interpolation for `+this.ValueTypeName+` keyframe track named `+this.name;if(this.createInterpolant===void 0){if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw Error(t)}return K(`KeyframeTrack:`,t),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return Gu;case this.InterpolantFactoryMethodLinear:return Ku;case this.InterpolantFactoryMethodSmooth:return qu;case this.InterpolantFactoryMethodBezier:return Ju}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let n=0,r=t.length;n!==r;++n)t[n]*=e;nh(this.settings)&&(fh(this.settings.inTangents,e),fh(this.settings.outTangents,e))}return this}trim(e,t){let n=this.times,r=n.length,i=0,a=r-1;for(;i!==r&&n[i]<e;)++i;for(;a!==-1&&n[a]>t;)--a;if(++a,i!==0||a!==r){i>=a&&(a=Math.max(a,1),i=a-1);let e=this.getValueSize();this.times=n.slice(i,a),this.values=this.values.slice(i*e,a*e)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!==0&&(q(`KeyframeTrack: Invalid value size in track.`,this),e=!1);let n=this.times,r=this.values,i=n.length;i===0&&(q(`KeyframeTrack: Track is empty.`,this),e=!1);let a=null;for(let t=0;t!==i;t++){let r=n[t];if(typeof r==`number`&&isNaN(r)){q(`KeyframeTrack: Time is not a valid number.`,this,t,r),e=!1;break}if(a!==null&&a>r){q(`KeyframeTrack: Out of order keys.`,this,t,r,a),e=!1;break}a=r}if(r!==void 0&&sd(r))for(let t=0,n=r.length;t!==n;++t){let n=r[t];if(isNaN(n)){q(`KeyframeTrack: Value is not a valid number.`,this,t,n),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),r=this.getInterpolation()===qu,i=e.length-1,a=1;for(let o=1;o<i;++o){let i=!1,s=e[o];if(s!==e[o+1]&&(o!==1||s!==e[0])){if(r)i=!0;else{let e=o*n,r=e-n,a=e+n;for(let o=0;o!==n;++o){let n=t[e+o];if(n!==t[r+o]||n!==t[a+o]){i=!0;break}}}}if(i){if(o!==a){e[a]=e[o];let r=o*n,i=a*n;for(let e=0;e!==n;++e)t[i+e]=t[r+e]}++a}}if(i>0){e[a]=e[i];for(let e=i*n,r=a*n,o=0;o!==n;++o)t[r+o]=t[e+o];++a}return a===e.length?(this.times=e,this.values=t):(this.times=e.slice(0,a),this.values=t.slice(0,a*n)),this}clone(){let e=this.times.slice(),t=this.values.slice(),n=this.constructor,r=new n(this.name,e,t);return r.createInterpolant=this.createInterpolant,nh(this.settings)&&(r.settings={inTangents:this.settings.inTangents.slice(),outTangents:this.settings.outTangents.slice()}),r}};function fh(e,t){for(let n=0,r=e.length;n!==r;n+=2)e[n]*=t}dh.prototype.ValueTypeName=``,dh.prototype.TimeBufferType=Float32Array,dh.prototype.ValueBufferType=Float32Array,dh.prototype.DefaultInterpolation=Ku;var ph=class extends dh{constructor(e,t,n){super(e,t,n)}};ph.prototype.ValueTypeName=`bool`,ph.prototype.ValueBufferType=Array,ph.prototype.DefaultInterpolation=Gu,ph.prototype.InterpolantFactoryMethodLinear=void 0,ph.prototype.InterpolantFactoryMethodSmooth=void 0;var mh=class extends dh{constructor(e,t,n,r){super(e,t,n,r)}};mh.prototype.ValueTypeName=`color`;var hh=class extends dh{constructor(e,t,n,r){super(e,t,n,r)}};hh.prototype.ValueTypeName=`number`;var gh=class extends rh{constructor(e,t,n,r){super(e,t,n,r)}interpolate_(e,t,n,r){let i=this.resultBuffer,a=this.sampleValues,o=this.valueSize,s=(n-t)/(r-t),c=e*o;for(let e=c+o;c!==e;c+=4)Ed.slerpFlat(i,0,a,c-o,a,c,s);return i}},_h=class extends dh{constructor(e,t,n,r){super(e,t,n,r)}InterpolantFactoryMethodLinear(e){return new gh(this.times,this.values,this.getValueSize(),e)}};_h.prototype.ValueTypeName=`quaternion`,_h.prototype.InterpolantFactoryMethodSmooth=void 0;var vh=class extends dh{constructor(e,t,n){super(e,t,n)}};vh.prototype.ValueTypeName=`string`,vh.prototype.ValueBufferType=Array,vh.prototype.DefaultInterpolation=Gu,vh.prototype.InterpolantFactoryMethodLinear=void 0,vh.prototype.InterpolantFactoryMethodSmooth=void 0;var yh=class extends dh{constructor(e,t,n,r){super(e,t,n,r)}};yh.prototype.ValueTypeName=`vector`;var bh=class extends Cf{constructor(e,t=1){super(),this.isLight=!0,this.type=`Light`,this.color=new Z(e),this.intensity=t}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,t}},xh=new Yd,Sh=new Y,Ch=new Y,wh=class{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new J(512,512),this.mapType=Bl,this.map=null,this.mapPass=null,this.matrix=new Yd,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new pm,this._frameExtents=new J(1,1),this._viewportCount=1,this._viewports=[new Wd(0,0,1,1)]}getViewportCount(){return this._viewportCount}getCamera(){return this.camera}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera;Sh.setFromMatrixPosition(e.matrixWorld),t.position.copy(Sh),Ch.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Ch),t.updateMatrixWorld(),this._updateMatrix(t,this.matrix,this._frustum)}_updateMatrix(e,t,n,r){xh.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),n.setFromProjectionMatrix(xh,e.coordinateSystem,e.reversedDepth);let i=this._frameExtents,a=r?r.z/i.x:1,o=r?r.w/i.y:1,s=r?r.x/i.x:0,c=r?r.y/i.y:0;e.coordinateSystem===2001||e.reversedDepth?t.set(.5*a,0,0,.5*a+s,0,.5*o,0,.5*o+c,0,0,1,0,0,0,0,1):t.set(.5*a,0,0,.5*a+s,0,.5*o,0,.5*o+c,0,0,.5,.5,0,0,0,1),t.multiply(xh)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this.biasNode=e.biasNode,this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return e.intensity=this.intensity,e.bias=this.bias,e.normalBias=this.normalBias,e.radius=this.radius,e.blurSamples=this.blurSamples,e.mapSize=this.mapSize.toArray(),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}},Th=new Y,Eh=new Ed,Dh=new Y,Oh=class extends Cf{constructor(){super(),this.isCamera=!0,this.type=`Camera`,this.matrixWorldInverse=new Yd,this.projectionMatrix=new Yd,this.projectionMatrixInverse=new Yd,this.coordinateSystem=ad,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Th,Eh,Dh),Dh.x===1&&Dh.y===1&&Dh.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Th,Eh,Dh.set(1,1,1)).invert()}updateWorldMatrix(e,t,n=!1){super.updateWorldMatrix(e,t,n),this.matrixWorld.decompose(Th,Eh,Dh),Dh.x===1&&Dh.y===1&&Dh.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Th,Eh,Dh.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}},kh=new Y,Ah=new J,jh=new J,Mh=class extends Oh{constructor(e=50,t=1,n=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type=`PerspectiveCamera`,this.fov=e,this.zoom=1,this.near=n,this.far=r,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=yd*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(vd*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return yd*2*Math.atan(Math.tan(vd*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){kh.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(kh.x,kh.y).multiplyScalar(-e/kh.z),kh.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(kh.x,kh.y).multiplyScalar(-e/kh.z)}getViewSize(e,t){return this.getViewBounds(e,Ah,jh),t.subVectors(jh,Ah)}setViewOffset(e,t,n,r,i,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(vd*.5*this.fov)/this.zoom,n=2*t,r=this.aspect*n,i=-.5*r,a=this.view;if(this.view!==null&&this.view.enabled){let e=a.fullWidth,o=a.fullHeight;i+=a.offsetX*r/e,t-=a.offsetY*n/o,r*=a.width/e,n*=a.height/o}let o=this.filmOffset;o!==0&&(i+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(i,i+r,t,t-n,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},Nh=class extends wh{constructor(){super(new Mh(90,1,.5,500)),this.isPointLightShadow=!0}},Ph=class extends bh{constructor(e,t,n=0,r=2){super(e,t),this.isPointLight=!0,this.type=`PointLight`,this.distance=n,this.decay=r,this.shadow=new Nh}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){super.dispose(),this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}toJSON(e){let t=super.toJSON(e);return t.object.distance=this.distance,t.object.decay=this.decay,t.object.shadow=this.shadow.toJSON(),t}},Fh=class extends Oh{constructor(e=-1,t=1,n=1,r=-1,i=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type=`OrthographicCamera`,this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=r,this.near=i,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,r,i,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=r,this.view.width=i,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,r=(this.top+this.bottom)/2,i=n-e,a=n+e,o=r+t,s=r-t;if(this.view!==null&&this.view.enabled){let e=(this.right-this.left)/this.view.fullWidth/this.zoom,t=(this.top-this.bottom)/this.view.fullHeight/this.zoom;i+=e*this.view.offsetX,a=i+e*this.view.width,o-=t*this.view.offsetY,s=o-t*this.view.height}this.projectionMatrix.makeOrthographic(i,a,o,s,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},Ih=class extends bh{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type=`AmbientLight`}},Lh=-90,Rh=1,zh=class extends Cf{constructor(e,t,n){super(),this.type=`CubeCamera`,this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;let r=new Mh(Lh,Rh,e,t);r.layers=this.layers,this.add(r);let i=new Mh(Lh,Rh,e,t);i.layers=this.layers,this.add(i);let a=new Mh(Lh,Rh,e,t);a.layers=this.layers,this.add(a);let o=new Mh(Lh,Rh,e,t);o.layers=this.layers,this.add(o);let s=new Mh(Lh,Rh,e,t);s.layers=this.layers,this.add(s);let c=new Mh(Lh,Rh,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[n,r,i,a,o,s]=t;for(let e of t)this.remove(e);if(e===2e3)n.up.set(0,1,0),n.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),i.up.set(0,0,-1),i.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),s.up.set(0,1,0),s.lookAt(0,0,-1);else if(e===2001)n.up.set(0,-1,0),n.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),i.up.set(0,0,1),i.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),s.up.set(0,-1,0),s.lookAt(0,0,-1);else throw Error(`THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: `+e);for(let e of t)this.add(e),e.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:n,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[i,a,o,s,c,l]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),p=e.xr.enabled;e.xr.enabled=!1;let m=n.texture.generateMipmaps;n.texture.generateMipmaps=!1;let h=!1;h=e.isWebGLRenderer===!0?e.state.buffers.depth.getReversed():e.reversedDepthBuffer,e.setRenderTarget(n,0,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,i),e.setRenderTarget(n,1,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,a),e.setRenderTarget(n,2,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,o),e.setRenderTarget(n,3,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,s),e.setRenderTarget(n,4,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,c),n.texture.generateMipmaps=m,e.setRenderTarget(n,5,r),h&&e.autoClear===!1&&e.clearDepth(),e.render(t,l),e.setRenderTarget(u,d,f),e.xr.enabled=p,n.texture.needsPMREMUpdate=!0}},Bh=class extends Mh{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}},Vh=`\\[\\]\\.:\\/`,Hh=RegExp(`[\\[\\]\\.:\\/]`,`g`),Uh=`[^\\[\\]\\.:\\/]`,Wh=`[^`+Vh.replace(`\\.`,``)+`]`,Gh=`((?:WC+[\\/:])*)`.replace(`WC`,Uh),Kh=`(WCOD+)?`.replace(`WCOD`,Wh),qh=`(?:\\.(WC+)(?:\\[(.+)\\])?)?`.replace(`WC`,Uh),Jh=`\\.(WC+)(?:\\[(.+)\\])?`.replace(`WC`,Uh),Yh=RegExp(`^`+Gh+Kh+qh+Jh+`$`),Xh=[`material`,`materials`,`bones`,`map`],Zh=class{constructor(e,t,n){let r=n||Qh.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,r)}getValue(e,t){this.bind();let n=this._targetGroup.nCachedObjects_,r=this._bindings[n];r!==void 0&&r.getValue(e,t)}setValue(e,t){let n=this._bindings;for(let r=this._targetGroup.nCachedObjects_,i=n.length;r!==i;++r)n[r].setValue(e,t)}bind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){let e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}},Qh=class e{constructor(t,n,r){this.path=n,this.parsedPath=r||e.parseTrackName(n),this.node=e.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(t,n,r){return t&&t.isAnimationObjectGroup?new e.Composite(t,n,r):new e(t,n,r)}static sanitizeNodeName(e){return e.replace(/\s/g,`_`).replace(Hh,``)}static parseTrackName(e){let t=Yh.exec(e);if(t===null)throw Error(`THREE.PropertyBinding: Cannot parse trackName: `+e);let n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},r=n.nodeName&&n.nodeName.lastIndexOf(`.`);if(r!==void 0&&r!==-1){let e=n.nodeName.substring(r+1);Xh.indexOf(e)!==-1&&(n.nodeName=n.nodeName.substring(0,r),n.objectName=e)}if(n.propertyName===null||n.propertyName.length===0)throw Error(`THREE.PropertyBinding: can not parse propertyName from trackName: `+e);return n}static findNode(e,t){if(t===void 0||t===``||t===`.`||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){let n=function(e){for(let r=0;r<e.length;r++){let i=e[r];if(i.name===t||i.uuid===t)return i;let a=n(i.children);if(a)return a}return null},r=n(e.children);if(r)return r}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)e[t++]=n[r]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let n=this.resolvedProperty;for(let r=0,i=n.length;r!==i;++r)n[r]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let t=this.node,n=this.parsedPath,r=n.objectName,i=n.propertyName,a=n.propertyIndex;if(t||(t=e.findNode(this.rootNode,n.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t){K(`PropertyBinding: No target node found for track: `+this.path+`.`);return}if(r){let e=n.objectIndex;switch(r){case`materials`:if(!t.material){q(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.materials){q(`PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.`,this);return}t=t.material.materials;break;case`bones`:if(!t.skeleton){q(`PropertyBinding: Can not bind to bones as node does not have a skeleton.`,this);return}t=t.skeleton.bones;for(let n=0;n<t.length;n++)if(t[n].name===e){e=n;break}break;case`map`:if(`map`in t){t=t.map;break}if(!t.material){q(`PropertyBinding: Can not bind to material as node does not have a material.`,this);return}if(!t.material.map){q(`PropertyBinding: Can not bind to material.map as node.material does not have a map.`,this);return}t=t.material.map;break;default:if(t[r]===void 0){q(`PropertyBinding: Can not bind to objectName of node undefined.`,this);return}t=t[r]}if(e!==void 0){if(t[e]===void 0){q(`PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.`,this,t);return}t=t[e]}}let o=t[i];if(o===void 0){let e=n.nodeName;q(`PropertyBinding: Trying to update property for track: `+e+`.`+i+` but it wasn't found.`,t);return}let s=this.Versioning.None;this.targetObject=t,t.isMaterial===!0?s=this.Versioning.NeedsUpdate:t.isObject3D===!0&&(s=this.Versioning.MatrixWorldNeedsUpdate);let c=this.BindingType.Direct;if(a!==void 0){if(i===`morphTargetInfluences`){if(!t.geometry){q(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.`,this);return}if(!t.geometry.morphAttributes){q(`PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.`,this);return}t.morphTargetDictionary[a]!==void 0&&(a=t.morphTargetDictionary[a])}c=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=a}else o.fromArray!==void 0&&o.toArray!==void 0?(c=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(c=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=i;this.getValue=this.GetterByBindingType[c],this.setValue=this.SetterByBindingTypeAndVersioning[c][s]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};Qh.Composite=Zh,Qh.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},Qh.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},Qh.prototype.GetterByBindingType=[Qh.prototype._getValue_direct,Qh.prototype._getValue_array,Qh.prototype._getValue_arrayElement,Qh.prototype._getValue_toArray],Qh.prototype.SetterByBindingTypeAndVersioning=[[Qh.prototype._setValue_direct,Qh.prototype._setValue_direct_setNeedsUpdate,Qh.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Qh.prototype._setValue_array,Qh.prototype._setValue_array_setNeedsUpdate,Qh.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Qh.prototype._setValue_arrayElement,Qh.prototype._setValue_arrayElement_setNeedsUpdate,Qh.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Qh.prototype._setValue_fromArray,Qh.prototype._setValue_fromArray_setNeedsUpdate,Qh.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]],class e{static{e.prototype.isMatrix2=!0}constructor(e,t,n,r){this.elements=[1,0,0,1],e!==void 0&&this.set(e,t,n,r)}identity(){return this.set(1,0,0,1),this}fromArray(e,t=0){for(let n=0;n<4;n++)this.elements[n]=e[n+t];return this}set(e,t,n,r){let i=this.elements;return i[0]=e,i[2]=t,i[1]=n,i[3]=r,this}};function $h(e,t,n,r){let i=eg(r);switch(n){case $l:return e*t;case iu:return e*t/i.components*i.byteLength;case au:return e*t/i.components*i.byteLength;case ou:return e*t*2/i.components*i.byteLength;case su:return e*t*2/i.components*i.byteLength;case eu:return e*t*3/i.components*i.byteLength;case tu:return e*t*4/i.components*i.byteLength;case cu:return e*t*4/i.components*i.byteLength;case lu:case uu:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case du:case fu:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case mu:case gu:return Math.max(e,16)*Math.max(t,8)/4;case pu:case hu:return Math.max(e,8)*Math.max(t,8)/2;case _u:case vu:case bu:case xu:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*8;case yu:case Su:case Cu:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case wu:return Math.floor((e+3)/4)*Math.floor((t+3)/4)*16;case Tu:return Math.floor((e+4)/5)*Math.floor((t+3)/4)*16;case Eu:return Math.floor((e+4)/5)*Math.floor((t+4)/5)*16;case Du:return Math.floor((e+5)/6)*Math.floor((t+4)/5)*16;case Ou:return Math.floor((e+5)/6)*Math.floor((t+5)/6)*16;case ku:return Math.floor((e+7)/8)*Math.floor((t+4)/5)*16;case Au:return Math.floor((e+7)/8)*Math.floor((t+5)/6)*16;case ju:return Math.floor((e+7)/8)*Math.floor((t+7)/8)*16;case Mu:return Math.floor((e+9)/10)*Math.floor((t+4)/5)*16;case Nu:return Math.floor((e+9)/10)*Math.floor((t+5)/6)*16;case Pu:return Math.floor((e+9)/10)*Math.floor((t+7)/8)*16;case Fu:return Math.floor((e+9)/10)*Math.floor((t+9)/10)*16;case Iu:return Math.floor((e+11)/12)*Math.floor((t+9)/10)*16;case Lu:return Math.floor((e+11)/12)*Math.floor((t+11)/12)*16;case Ru:case zu:case Bu:return Math.ceil(e/4)*Math.ceil(t/4)*16;case Vu:case Hu:return Math.ceil(e/4)*Math.ceil(t/4)*8;case Uu:case Wu:return Math.ceil(e/4)*Math.ceil(t/4)*16}throw Error(`Unable to determine texture byte length for ${n} format.`)}function eg(e){switch(e){case Bl:case Vl:return{byteLength:1,components:1};case Ul:case Hl:case ql:return{byteLength:2,components:1};case Jl:case Yl:return{byteLength:2,components:4};case Gl:case Wl:case Kl:return{byteLength:4,components:1};case Zl:case Ql:return{byteLength:4,components:3}}throw Error(`THREE.TextureUtils: Unknown texture type ${e}.`)}typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`register`,{detail:{revision:`186`}})),typeof window<`u`&&(window.__THREE__?K(`WARNING: Multiple instances of Three.js being imported.`):window.__THREE__=`186`);function tg(){let e=null,t=!1,n=null,r=null;function i(t,a){r=e.requestAnimationFrame(i),n(t,a)}return{start:function(){t!==!0&&n!==null&&e!==null&&(r=e.requestAnimationFrame(i),t=!0)},stop:function(){e!==null&&e.cancelAnimationFrame(r),t=!1},setAnimationLoop:function(e){n=e},setContext:function(t){e=t}}}function ng(e){let t=new WeakMap;function n(t,n){let r=t.array,i=t.usage,a=r.byteLength,o=e.createBuffer();e.bindBuffer(n,o),e.bufferData(n,r,i),t.onUploadCallback();let s;if(r instanceof Float32Array)s=e.FLOAT;else if(typeof Float16Array<`u`&&r instanceof Float16Array)s=e.HALF_FLOAT;else if(r instanceof Uint16Array)s=t.isFloat16BufferAttribute?e.HALF_FLOAT:e.UNSIGNED_SHORT;else if(r instanceof Int16Array)s=e.SHORT;else if(r instanceof Uint32Array)s=e.UNSIGNED_INT;else if(r instanceof Int32Array)s=e.INT;else if(r instanceof Int8Array)s=e.BYTE;else if(r instanceof Uint8Array)s=e.UNSIGNED_BYTE;else if(r instanceof Uint8ClampedArray)s=e.UNSIGNED_BYTE;else throw Error(`THREE.WebGLAttributes: Unsupported buffer data format: `+r);return{buffer:o,type:s,bytesPerElement:r.BYTES_PER_ELEMENT,version:t.version,size:a}}function r(t,n,r){let i=n.array,a=n.updateRanges;if(e.bindBuffer(r,t),a.length===0)e.bufferSubData(r,0,i);else{a.sort((e,t)=>e.start-t.start);let t=0;for(let e=1;e<a.length;e++){let n=a[t],r=a[e];r.start<=n.start+n.count+1?n.count=Math.max(n.count,r.start+r.count-n.start):(++t,a[t]=r)}a.length=t+1;for(let t=0,n=a.length;t<n;t++){let n=a[t];e.bufferSubData(r,n.start*i.BYTES_PER_ELEMENT,i,n.start,n.count)}n.clearUpdateRanges()}n.onUploadCallback()}function i(e){return e.isInterleavedBufferAttribute&&(e=e.data),t.get(e)}function a(n){n.isInterleavedBufferAttribute&&(n=n.data);let r=t.get(n);r&&(e.deleteBuffer(r.buffer),t.delete(n))}function o(e,i){if(e.isInterleavedBufferAttribute&&(e=e.data),e.isGLBufferAttribute){let n=t.get(e);(!n||n.version<e.version)&&t.set(e,{buffer:e.buffer,type:e.type,bytesPerElement:e.elementSize,version:e.version});return}let a=t.get(e);if(a===void 0)t.set(e,n(e,i));else if(a.version<e.version){if(a.size!==e.array.byteLength)throw Error(`THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.`);r(a.buffer,e,i),a.version=e.version}}return{get:i,remove:a,update:o}}var Q={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
#define inverseTransformDirection transformDirectionByInverseViewMatrix
vec3 transformNormalByInverseViewMatrix( in vec3 normal, in mat4 viewMatrix ) {
	return normalize( ( vec4( normal, 0.0 ) * viewMatrix ).xyz );
}
vec3 transformDirectionByInverseViewMatrix( in vec3 dir, in mat4 viewMatrix ) {
	return normalize( ( vec4( dir, 0.0 ) * viewMatrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment:`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:`gl_FragColor = linearToOutputTexel( gl_FragColor );`,colorspace_pars_fragment:`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = transformDirectionByInverseViewMatrix( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_RETROREFLECTION
		vec3 getIBLRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 retroVec = normalize( mix( viewDir, normal, pow4( roughness ) ) );
				retroVec = transformDirectionByInverseViewMatrix( retroVec, viewMatrix );
				vec4 envMapColor = textureCubeUV( envMap, envMapRotation * retroVec, roughness );
				return envMapColor.rgb * envMapIntensity;
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
		#ifdef USE_RETROREFLECTION
			vec3 getIBLAnisotropyRetroRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
				#ifdef ENVMAP_TYPE_CUBE_UV
					vec3 bentNormal = cross( bitangent, viewDir );
					bentNormal = normalize( cross( bentNormal, bitangent ) );
					bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
					return getIBLRetroRadiance( viewDir, bentNormal, roughness );
				#else
					return vec3( 0.0 );
				#endif
			}
		#endif
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_SUN_LIGHTS > 0
	struct SunLight {
		vec3 direction;
		vec3 color;
	};
	uniform SunLight sunLights[ NUM_SUN_LIGHTS ];
	void getSunLightInfo( const in SunLight sunLight, out IncidentLight light ) {
		light.color = sunLight.color;
		light.direction = sunLight.direction;
		light.visible = true;
	}
#endif
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_RETROREFLECTION
	material.retroreflectivity = retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	vec2 dfg;
	vec3 multiScatteringCompensation;
	#ifdef USE_RETROREFLECTION
		float retroreflectivity;
	#endif
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0Dielectric;
		vec3 iridescenceF0Metallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec2 fab, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec2 fab, const in vec3 specularColor, const in float specularF90, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	vec3 specularBRDF = BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	#ifdef USE_RETROREFLECTION
		vec3 retroViewDir = reflect( - geometryViewDir, geometryNormal );
		vec3 retroSpecularBRDF = BRDF_GGX( directLight.direction, retroViewDir, geometryNormal, material );
		specularBRDF = mix( specularBRDF, retroSpecularBRDF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directSpecular += irradiance * specularBRDF * material.multiScatteringCompensation;
	vec3 halfDir = normalize( directLight.direction + geometryViewDir );
	float dotVH = saturate( dot( geometryViewDir, halfDir ) );
	vec3 F = F_Schlick( material.specularColor, material.specularF90, dotVH );
	#ifdef USE_RETROREFLECTION
		vec3 retroHalfDir = normalize( directLight.direction + retroViewDir );
		float dotRetroVH = saturate( dot( retroViewDir, retroHalfDir ) );
		vec3 retroF = F_Schlick( material.specularColor, material.specularF90, dotRetroVH );
		F = mix( F, retroF, saturate( material.retroreflectivity ) );
	#endif
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - F );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScattering, multiScattering );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScattering, multiScattering );
	#endif
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution ) * ( 1.0 - singleScattering - multiScattering );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		sheenSpecularIndirect += irradiance * material.sheenColor * sheenAlbedo * RECIPROCAL_PI;
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( material.dfg, material.specularColor, material.specularF90, material.iridescence, material.iridescenceF0Dielectric, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( material.dfg, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceF0Metallic, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( material.dfg, material.specularColor, material.specularF90, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( material.dfg, material.diffuseColor, material.specularF90, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		vec3 iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		vec3 iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( iridescenceFresnelDielectric, iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0Dielectric = Schlick_to_F0( iridescenceFresnelDielectric, 1.0, dotNVi );
		material.iridescenceF0Metallic = Schlick_to_F0( iridescenceFresnelMetallic, 1.0, dotNVi );
	}
#endif
#ifdef STANDARD
	float dotNVms = saturate( dot( geometryNormal, geometryViewDir ) );
	material.dfg = texture2D( dfgLUT, vec2( material.roughness, dotNVms ) ).rg;
	#if ( NUM_SUN_LIGHTS > 0 || NUM_DIR_LIGHTS > 0 || NUM_POINT_LIGHTS > 0 || NUM_SPOT_LIGHTS > 0 )
		float EssMs = material.dfg.x + material.dfg.y;
		material.multiScatteringCompensation = 1.0 + material.specularColorBlended * ( 1.0 / EssMs - 1.0 );
	#endif
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SUN_LIGHTS > 0 ) && defined( RE_Direct )
	SunLight sunLight;
	#if defined( USE_SHADOWMAP ) && NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHTS; i ++ ) {
		sunLight = sunLights[ i ];
		getSunLightInfo( sunLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SUN_LIGHT_SHADOWS )
		sunLightShadow = sunLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getSunShadow( sunShadowMap[ i ], sunLightShadow, UNROLLED_LOOP_INDEX ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = transformNormalByInverseViewMatrix( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		vec3 iblRadiance = getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		vec3 iblRadiance = getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_RETROREFLECTION
		#ifdef USE_ANISOTROPY
			vec3 retroIBLRadiance = getIBLAnisotropyRetroRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
		#else
			vec3 retroIBLRadiance = getIBLRetroRadiance( geometryViewDir, geometryNormal, material.roughness );
		#endif
		iblRadiance = mix( iblRadiance, retroIBLRadiance, saturate( material.retroreflectivity ) );
	#endif
	radiance += iblRadiance;
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,lightprobes_pars_fragment:`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphinstance_vertex:`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#ifdef DOUBLE_SIDED
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#ifdef DOUBLE_SIDED
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
		#ifdef FLIP_SIDED
			vBitangent = - vBitangent;
		#endif
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		#define SUN_LIGHT_CASCADES 2
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#else
			uniform sampler2D sunShadowMap[ NUM_SUN_LIGHT_SHADOWS ];
		#endif
		uniform mat4 sunShadowMatrix[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		uniform vec4 sunShadowCascade[ NUM_SUN_LIGHT_SHADOWS * SUN_LIGHT_CASCADES ];
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
		struct SunLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SunLightShadow sunLightShadows[ NUM_SUN_LIGHT_SHADOWS ];
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_SUN_LIGHT_SHADOWS > 0
		float getSunShadow(
			#if defined( SHADOWMAP_TYPE_PCF )
				sampler2DShadow shadowMap,
			#else
				sampler2D shadowMap,
			#endif
			SunLightShadow sunLightShadow,
			int shadowIndex
		) {
			vec4 shadowWorldPosition = vec4( vSunShadowWorldPosition.xyz + vSunShadowWorldNormal * sunLightShadow.shadowNormalBias, 1.0 );
			float viewDepth = vSunShadowWorldPosition.w;
			int cascadeOffset = shadowIndex * SUN_LIGHT_CASCADES;
			float shadow = 1.0;
			for ( int i = SUN_LIGHT_CASCADES - 1; i >= 0; i -- ) {
				vec4 cascade = sunShadowCascade[ cascadeOffset + i ];
				if ( viewDepth >= cascade.x && viewDepth < cascade.y ) {
					float cascadeShadow = getShadow(
						shadowMap,
						sunLightShadow.shadowMapSize,
						sunLightShadow.shadowIntensity,
						sunLightShadow.shadowBias,
						sunLightShadow.shadowRadius,
						sunShadowMatrix[ cascadeOffset + i ] * shadowWorldPosition
					);
					shadow = mix( cascadeShadow, shadow, smoothstep( cascade.z, cascade.y, viewDepth ) );
				}
			}
			return shadow;
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
		varying vec4 vSunShadowWorldPosition;
		varying vec3 vSunShadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_SUN_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = transformNormalByInverseViewMatrix( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_SUN_LIGHT_SHADOWS > 0
		vSunShadowWorldPosition = vec4( worldPosition.xyz, - mvPosition.z );
		vSunShadowWorldNormal = shadowWorldNormal;
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_SUN_LIGHT_SHADOWS > 0
	SunLightShadow sunLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SUN_LIGHT_SHADOWS; i ++ ) {
		sunLight = sunLightShadows[ i ];
		shadow *= receiveShadow ? getSunShadow( sunShadowMap[ i ], sunLight, UNROLLED_LOOP_INDEX ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = transformNormalByInverseViewMatrix( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,distance_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distance_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_RETROREFLECTION
	uniform float retroreflectivity;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},$={common:{diffuse:{value:new Z(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new X},alphaMap:{value:null},alphaMapTransform:{value:new X},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new X}},envmap:{envMap:{value:null},envMapRotation:{value:new X},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new X}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new X}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new X},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new X},normalScale:{value:new J(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new X},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new X}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new X}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new X}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Z(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},sunLights:{value:[],properties:{direction:{},color:{}}},sunLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},sunShadowMatrix:{value:[]},sunShadowCascade:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new Y},probesMax:{value:new Y},probesResolution:{value:new Y}},points:{diffuse:{value:new Z(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new X},alphaTest:{value:0},uvTransform:{value:new X}},sprite:{diffuse:{value:new Z(16777215)},opacity:{value:1},center:{value:new J(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new X},alphaMap:{value:null},alphaMapTransform:{value:new X},alphaTest:{value:0}}},rg={basic:{uniforms:Um([$.common,$.specularmap,$.envmap,$.aomap,$.lightmap,$.fog]),vertexShader:Q.meshbasic_vert,fragmentShader:Q.meshbasic_frag},lambert:{uniforms:Um([$.common,$.specularmap,$.envmap,$.aomap,$.lightmap,$.emissivemap,$.bumpmap,$.normalmap,$.displacementmap,$.fog,$.lights,{emissive:{value:new Z(0)},envMapIntensity:{value:1}}]),vertexShader:Q.meshlambert_vert,fragmentShader:Q.meshlambert_frag},phong:{uniforms:Um([$.common,$.specularmap,$.envmap,$.aomap,$.lightmap,$.emissivemap,$.bumpmap,$.normalmap,$.displacementmap,$.fog,$.lights,{emissive:{value:new Z(0)},specular:{value:new Z(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Q.meshphong_vert,fragmentShader:Q.meshphong_frag},standard:{uniforms:Um([$.common,$.envmap,$.aomap,$.lightmap,$.emissivemap,$.bumpmap,$.normalmap,$.displacementmap,$.roughnessmap,$.metalnessmap,$.fog,$.lights,{emissive:{value:new Z(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Q.meshphysical_vert,fragmentShader:Q.meshphysical_frag},toon:{uniforms:Um([$.common,$.aomap,$.lightmap,$.emissivemap,$.bumpmap,$.normalmap,$.displacementmap,$.gradientmap,$.fog,$.lights,{emissive:{value:new Z(0)}}]),vertexShader:Q.meshtoon_vert,fragmentShader:Q.meshtoon_frag},matcap:{uniforms:Um([$.common,$.bumpmap,$.normalmap,$.displacementmap,$.fog,{matcap:{value:null}}]),vertexShader:Q.meshmatcap_vert,fragmentShader:Q.meshmatcap_frag},points:{uniforms:Um([$.points,$.fog]),vertexShader:Q.points_vert,fragmentShader:Q.points_frag},dashed:{uniforms:Um([$.common,$.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Q.linedashed_vert,fragmentShader:Q.linedashed_frag},depth:{uniforms:Um([$.common,$.displacementmap]),vertexShader:Q.depth_vert,fragmentShader:Q.depth_frag},normal:{uniforms:Um([$.common,$.bumpmap,$.normalmap,$.displacementmap,{opacity:{value:1}}]),vertexShader:Q.meshnormal_vert,fragmentShader:Q.meshnormal_frag},sprite:{uniforms:Um([$.sprite,$.fog]),vertexShader:Q.sprite_vert,fragmentShader:Q.sprite_frag},background:{uniforms:{uvTransform:{value:new X},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Q.background_vert,fragmentShader:Q.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new X}},vertexShader:Q.backgroundCube_vert,fragmentShader:Q.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Q.cube_vert,fragmentShader:Q.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Q.equirect_vert,fragmentShader:Q.equirect_frag},distance:{uniforms:Um([$.common,$.displacementmap,{referencePosition:{value:new Y},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Q.distance_vert,fragmentShader:Q.distance_frag},shadow:{uniforms:Um([$.lights,$.fog,{color:{value:new Z(0)},opacity:{value:1}}]),vertexShader:Q.shadow_vert,fragmentShader:Q.shadow_frag}};rg.physical={uniforms:Um([rg.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new X},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new X},clearcoatNormalScale:{value:new J(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new X},dispersion:{value:0},retroreflectivity:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new X},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new X},sheen:{value:0},sheenColor:{value:new Z(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new X},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new X},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new X},transmissionSamplerSize:{value:new J},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new X},attenuationDistance:{value:0},attenuationColor:{value:new Z(0)},specularColor:{value:new Z(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new X},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new X},anisotropyVector:{value:new J},anisotropyMap:{value:null},anisotropyMapTransform:{value:new X}}]),vertexShader:Q.meshphysical_vert,fragmentShader:Q.meshphysical_frag};var ig={r:0,b:0,g:0},ag=new Yd,og=new X;og.set(-1,0,0,0,1,0,0,0,1);function sg(e,t,n,r,i,a){let o=new Z(0),s=i===!0?0:1,c,l,u=null,d=0,f=null;function p(e){let n=e.isScene===!0?e.background:null;if(n&&n.isTexture){let r=e.backgroundBlurriness>0;n=t.get(n,r)}return n}function m(t){let r=!1,i=p(t);i===null?g(o,s):i&&i.isColor&&(g(i,1),r=!0);let c=e.xr.getEnvironmentBlendMode();c===`additive`?n.buffers.color.setClear(0,0,0,1,a):c===`alpha-blend`&&n.buffers.color.setClear(0,0,0,0,a),(e.autoClear||r)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil))}function h(t,n){let i=p(n);i&&(i.isCubeTexture||i.mapping===306)?(l===void 0&&(l=new Zp(new Mm(1,1,1),new Xm({name:`BackgroundCubeMaterial`,uniforms:Hm(rg.backgroundCube.uniforms),vertexShader:rg.backgroundCube.vertexShader,fragmentShader:rg.backgroundCube.fragmentShader,side:1,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),l.geometry.deleteAttribute(`normal`),l.geometry.deleteAttribute(`uv`),l.onBeforeRender=function(e,t,n){this.matrixWorld.copyPosition(n.matrixWorld)},Object.defineProperty(l.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),r.update(l)),l.material.uniforms.envMap.value=i,l.material.uniforms.backgroundBlurriness.value=n.backgroundBlurriness,l.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,l.material.uniforms.backgroundRotation.value.setFromMatrix4(ag.makeRotationFromEuler(n.backgroundRotation)).transpose(),i.isCubeTexture&&i.isRenderTargetTexture===!1&&l.material.uniforms.backgroundRotation.value.premultiply(og),l.material.toneMapped=Nd.getTransfer(i.colorSpace)!==nd,(u!==i||d!==i.version||f!==e.toneMapping)&&(l.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),l.layers.enableAll(),t.unshift(l,l.geometry,l.material,0,0,null)):i&&i.isTexture&&(c===void 0&&(c=new Zp(new Rm(2,2),new Xm({name:`BackgroundMaterial`,uniforms:Hm(rg.background.uniforms),vertexShader:rg.background.vertexShader,fragmentShader:rg.background.fragmentShader,side:0,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),c.geometry.deleteAttribute(`normal`),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),r.update(c)),c.material.uniforms.t2D.value=i,c.material.uniforms.backgroundIntensity.value=n.backgroundIntensity,c.material.toneMapped=Nd.getTransfer(i.colorSpace)!==nd,i.matrixAutoUpdate===!0&&i.updateMatrix(),c.material.uniforms.uvTransform.value.copy(i.matrix),(u!==i||d!==i.version||f!==e.toneMapping)&&(c.material.needsUpdate=!0,u=i,d=i.version,f=e.toneMapping),c.layers.enableAll(),t.unshift(c,c.geometry,c.material,0,0,null))}function g(t,r){t.getRGB(ig,Km(e)),n.buffers.color.setClear(ig.r,ig.g,ig.b,r,a)}function _(){l!==void 0&&(l.geometry.dispose(),l.material.dispose(),l=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return o},setClearColor:function(e,t=1){o.set(e),s=t,g(o,s)},getClearAlpha:function(){return s},setClearAlpha:function(e){s=e,g(o,s)},render:m,addToRenderList:h,dispose:_}}function cg(e,t){let n=e.getParameter(e.MAX_VERTEX_ATTRIBS),r={},i=f(null),a=i,o=!1;function s(n,r,i,s,c){let u=!1,f=d(n,s,i,r);a!==f&&(a=f,l(a.object)),u=p(n,s,i,c),u&&m(n,s,i,c),c!==null&&t.update(c,e.ELEMENT_ARRAY_BUFFER),(u||o)&&(o=!1,b(n,r,i,s),c!==null&&e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,t.get(c).buffer))}function c(){return e.createVertexArray()}function l(t){return e.bindVertexArray(t)}function u(t){return e.deleteVertexArray(t)}function d(e,t,n,i){let a=i.wireframe===!0,o=r[t.id];o===void 0&&(o={},r[t.id]=o);let s=e.isInstancedMesh===!0?e.id:0,l=o[s];l===void 0&&(l={},o[s]=l);let u=l[n.id];u===void 0&&(u={},l[n.id]=u);let d=u[a];return d===void 0&&(d=f(c()),u[a]=d),d}function f(e){let t=[],r=[],i=[];for(let e=0;e<n;e++)t[e]=0,r[e]=0,i[e]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:t,enabledAttributes:r,attributeDivisors:i,object:e,attributes:{},index:null}}function p(e,t,n,r){let i=a.attributes,o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=i[t],r=o[t];if(r===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(r=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(r=e.instanceColor)),n===void 0||n.attribute!==r||r&&n.data!==r.data)return!0;s++}return a.attributesNum!==s||a.index!==r}function m(e,t,n,r){let i={},o=t.attributes,s=0,c=n.getAttributes();for(let t in c)if(c[t].location>=0){let n=o[t];n===void 0&&(t===`instanceMatrix`&&e.instanceMatrix&&(n=e.instanceMatrix),t===`instanceColor`&&e.instanceColor&&(n=e.instanceColor));let r={};r.attribute=n,n&&n.data&&(r.data=n.data),i[t]=r,s++}a.attributes=i,a.attributesNum=s,a.index=r}function h(){let e=a.newAttributes;for(let t=0,n=e.length;t<n;t++)e[t]=0}function g(e){_(e,0)}function _(t,n){let r=a.newAttributes,i=a.enabledAttributes,o=a.attributeDivisors;r[t]=1,i[t]===0&&(e.enableVertexAttribArray(t),i[t]=1),o[t]!==n&&(e.vertexAttribDivisor(t,n),o[t]=n)}function v(){let t=a.newAttributes,n=a.enabledAttributes;for(let r=0,i=n.length;r<i;r++)n[r]!==t[r]&&(e.disableVertexAttribArray(r),n[r]=0)}function y(t,n,r,i,a,o,s){s===!0?e.vertexAttribIPointer(t,n,r,a,o):e.vertexAttribPointer(t,n,r,i,a,o)}function b(n,r,i,a){h();let o=a.attributes,s=i.getAttributes(),c=r.defaultAttributeValues;for(let r in s){let i=s[r];if(i.location>=0){let s=o[r];if(s===void 0&&(r===`instanceMatrix`&&n.instanceMatrix&&(s=n.instanceMatrix),r===`instanceColor`&&n.instanceColor&&(s=n.instanceColor)),s!==void 0){let r=s.normalized,o=s.itemSize,c=t.get(s);if(c===void 0)continue;let l=c.buffer,u=c.type,d=c.bytesPerElement,f=u===e.INT||u===e.UNSIGNED_INT||s.gpuType===1013;if(s.isInterleavedBufferAttribute){let t=s.data,c=t.stride,p=s.offset;if(t.isInstancedInterleavedBuffer){for(let e=0;e<i.locationSize;e++)_(i.location+e,t.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=t.meshPerAttribute*t.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,c*d,(p+o/i.locationSize*e)*d,f)}else{if(s.isInstancedBufferAttribute){for(let e=0;e<i.locationSize;e++)_(i.location+e,s.meshPerAttribute);n.isInstancedMesh!==!0&&a._maxInstanceCount===void 0&&(a._maxInstanceCount=s.meshPerAttribute*s.count)}else for(let e=0;e<i.locationSize;e++)g(i.location+e);e.bindBuffer(e.ARRAY_BUFFER,l);for(let e=0;e<i.locationSize;e++)y(i.location+e,o/i.locationSize,u,r,o*d,o/i.locationSize*e*d,f)}}else if(c!==void 0){let t=c[r];if(t!==void 0)switch(t.length){case 2:e.vertexAttrib2fv(i.location,t);break;case 3:e.vertexAttrib3fv(i.location,t);break;case 4:e.vertexAttrib4fv(i.location,t);break;default:e.vertexAttrib1fv(i.location,t)}}}}v()}function x(){T();for(let e in r){let t=r[e];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e]}}function S(e){if(r[e.id]===void 0)return;let t=r[e.id];for(let e in t){let n=t[e];for(let e in n){let t=n[e];for(let e in t)u(t[e].object),delete t[e];delete n[e]}}delete r[e.id]}function C(e){for(let t in r){let n=r[t];for(let t in n){let r=n[t];if(r[e.id]===void 0)continue;let i=r[e.id];for(let e in i)u(i[e].object),delete i[e];delete r[e.id]}}}function w(e){for(let t in r){let n=r[t],i=e.isInstancedMesh===!0?e.id:0,a=n[i];if(a!==void 0){for(let e in a){let t=a[e];for(let e in t)u(t[e].object),delete t[e];delete a[e]}delete n[i],Object.keys(n).length===0&&delete r[t]}}}function T(){E(),o=!0,a!==i&&(a=i,l(a.object))}function E(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:s,reset:T,resetDefaultState:E,dispose:x,releaseStatesOfGeometry:S,releaseStatesOfObject:w,releaseStatesOfProgram:C,initAttributes:h,enableAttribute:g,disableUnusedAttributes:v}}function lg(e,t,n){let r;function i(e){r=e}function a(t,i){e.drawArrays(r,t,i),n.update(i,r,1)}function o(t,i,a){a!==0&&(e.drawArraysInstanced(r,t,i,a),n.update(i,r,a))}function s(e,i,a){if(a===0)return;t.get(`WEBGL_multi_draw`).multiDrawArraysWEBGL(r,e,0,i,0,a);let o=0;for(let e=0;e<a;e++)o+=i[e];n.update(o,r,1)}this.setMode=i,this.render=a,this.renderInstances=o,this.renderMultiDraw=s}function ug(e,t,n,r){let i;function a(){if(i!==void 0)return i;if(t.has(`EXT_texture_filter_anisotropic`)===!0){let n=t.get(`EXT_texture_filter_anisotropic`);i=e.getParameter(n.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(t){return t===1023||r.convert(t)===e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT)}function s(n){let i=n===1016&&(t.has(`EXT_color_buffer_half_float`)||t.has(`EXT_color_buffer_float`));return!(n!==1009&&n!==1015&&!i&&r.convert(n)!==e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE))}function c(t){if(t===`highp`){if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)return`highp`;t=`mediump`}return t===`mediump`&&e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0?`mediump`:`lowp`}let l=n.precision===void 0?`highp`:n.precision,u=c(l);u!==l&&(K(`WebGLRenderer:`,l,`not supported, using`,u,`instead.`),l=u);let d=n.logarithmicDepthBuffer===!0,f=n.reversedDepthBuffer===!0&&t.has(`EXT_clip_control`);n.reversedDepthBuffer===!0&&f===!1&&K(`WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.`);let p=e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),m=e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),h=e.getParameter(e.MAX_TEXTURE_SIZE),g=e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),_=e.getParameter(e.MAX_VERTEX_ATTRIBS),v=e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),y=e.getParameter(e.MAX_VARYING_VECTORS),b=e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),x=e.getParameter(e.MAX_SAMPLES),S=e.getParameter(e.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:a,getMaxPrecision:c,textureFormatReadable:o,textureTypeReadable:s,precision:l,logarithmicDepthBuffer:d,reversedDepthBuffer:f,maxTextures:p,maxVertexTextures:m,maxTextureSize:h,maxCubemapSize:g,maxAttributes:_,maxVertexUniforms:v,maxVaryings:y,maxFragmentUniforms:b,maxSamples:x,samples:S}}function dg(e){let t=this,n=null,r=0,i=!1,a=!1,o=new jp,s=new X,c={value:null,needsUpdate:!1};this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(e,t){let n=e.length!==0||t||r!==0||i;return i=t,r=e.length,n},this.beginShadows=function(){a=!0,u(null)},this.endShadows=function(){a=!1},this.setGlobalState=function(e,t){n=u(e,t,0)},this.setState=function(t,o,s){let d=t.clippingPlanes,f=t.clipIntersection,p=t.clipShadows,m=e.get(t);if(!i||d===null||d.length===0||a&&!p)a?u(null):l();else{let e=a?0:r,t=e*4,i=m.clippingState||null;c.value=i,i=u(d,o,t,s);for(let e=0;e!==t;++e)i[e]=n[e];m.clippingState=i,this.numIntersection=f?this.numPlanes:0,this.numPlanes+=e}};function l(){c.value!==n&&(c.value=n,c.needsUpdate=r>0),t.numPlanes=r,t.numIntersection=0}function u(e,n,r,i){let a=e===null?0:e.length,l=null;if(a!==0){if(l=c.value,i!==!0||l===null){let t=r+a*4,i=n.matrixWorldInverse;s.getNormalMatrix(i),(l===null||l.length<t)&&(l=new Float32Array(t));for(let t=0,n=r;t!==a;++t,n+=4)o.copy(e[t]).applyMatrix4(i,s),o.normal.toArray(l,n),l[n+3]=o.constant}c.value=l,c.needsUpdate=!0}return t.numPlanes=a,t.numIntersection=0,l}}var fg=4,pg=6,mg=20,hg=256,gg=new Fh,_g=new Z,vg=null,yg=0,bg=0,xg=!1,Sg=new Y,Cg=new Y,wg=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,t=0,n=.1,r=100,i={}){let{size:a=256,position:o=Sg}=i;vg=this._renderer.getRenderTarget(),yg=this._renderer.getActiveCubeFace(),bg=this._renderer.getActiveMipmapLevel(),xg=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);let s=this._allocateTargets();return s.depthBuffer=!0,this._sceneToCubeUV(e,n,r,s,o),t>0&&this._blur(s,0,0,t),this._applyPMREM(s),this._cleanup(s),s}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=jg(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Ag(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=2**this._lodMax}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(vg,yg,bg),this._renderer.xr.enabled=xg,e.scissorTest=!1,Dg(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===301||e.mapping===302?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),vg=this._renderer.getRenderTarget(),yg=this._renderer.getActiveCubeFace(),bg=this._renderer.getActiveMipmapLevel(),xg=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:Ll,minFilter:Ll,generateMipmaps:!1,type:ql,format:tu,colorSpace:ed,depthBuffer:!1},r=Eg(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Eg(e,t,n);let{_lodMax:r}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods}=Tg(r)),this._blurMaterial=kg(r,e,t),this._ggxMaterial=Og(r,e,t)}return r}_compileMaterial(e){let t=new Zp(new Dp,e);this._renderer.compile(t,gg)}_sceneToCubeUV(e,t,n,r,i){let a=new Mh(90,1,t,n),o=[1,-1,1,1,1,1],s=[1,1,1,-1,-1,-1],c=this._renderer,l=c.autoClear,u=c.toneMapping;c.getClearColor(_g),c.toneMapping=0,c.autoClear=!1,c.state.buffers.depth.getReversed()&&(c.setRenderTarget(r),c.clearDepth(),c.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new Zp(new Mm,new zp({name:`PMREM.Background`,side:1,depthWrite:!1,depthTest:!1})));let d=this._backgroundBox,f=d.material,p=!1,m=e.background;m?m.isColor&&(f.color.copy(m),e.background=null,p=!0):(f.color.copy(_g),p=!0);for(let t=0;t<6;t++){let n=t%3;n===0?(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x+s[t],i.y,i.z)):n===1?(a.up.set(0,0,o[t]),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y+s[t],i.z)):(a.up.set(0,o[t],0),a.position.set(i.x,i.y,i.z),a.lookAt(i.x,i.y,i.z+s[t]));let l=this._cubeSize;Dg(r,n*l,t>2?l:0,l,l),c.setRenderTarget(r),p&&c.render(d,a),c.render(e,a)}c.toneMapping=u,c.autoClear=l,e.background=m}_textureToCubeUV(e,t){let n=this._renderer,r=e.mapping===301||e.mapping===302;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=jg()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Ag());let i=r?this._cubemapMaterial:this._equirectMaterial,a=this._lodMeshes[0];a.material=i;let o=i.uniforms;o.envMap.value=e;let s=this._cubeSize;Dg(t,0,0,3*s,2*s),n.setRenderTarget(t),n.render(a,gg)}_applyPMREM(e){let t=this._renderer,n=t.autoClear;t.autoClear=!1;let r=this._lodMeshes.length;for(let t=1;t<r;t++)this._applyGGXFilter(e,t-1,t);t.autoClear=n}_applyGGXFilter(e,t,n){let r=this._renderer,i=this._pingPongRenderTarget,a=this._ggxMaterial,o=this._lodMeshes[n];o.material=a;let s=a.uniforms,c=n/(this._lodMeshes.length-1),l=t/(this._lodMeshes.length-1),u=Math.sqrt(c*c-l*l)*(c*1.25),{_lodMax:d}=this,f=this._sizeLods[n],p=3*f*(n>d-fg?n-d+fg:0),m=4*(this._cubeSize-f);s.envMap.value=e.texture,s.roughness.value=u,s.mipInt.value=d-t,Dg(i,p,m,3*f,2*f),r.setRenderTarget(i),r.render(o,gg),s.envMap.value=i.texture,s.roughness.value=0,s.mipInt.value=d-n,Dg(e,p,m,3*f,2*f),r.setRenderTarget(e),r.render(o,gg)}_blur(e,t,n,r){let i=this._pingPongRenderTarget,a=Math.min(r,Math.PI)/Math.SQRT2;this._blurPass(e,i,t,n,a),this._blurPass(i,e,n,n,a)}_blurPass(e,t,n,r,i){let a=this._renderer,o=this._blurMaterial,s=this._lodMeshes[r];s.material=o;let c=o.uniforms;c.envMap.value=e.texture,c.sigma.value=i,c.mipInt.value=this._lodMax-n;let l=this._sizeLods[r];Dg(t,3*l*(r>this._lodMax-fg?r-this._lodMax+fg:0),4*(this._cubeSize-l),3*l,2*l),a.setRenderTarget(t),a.render(s,gg)}};function Tg(e){let t=[],n=[],r=e,i=e-fg+1+pg;for(let e=0;e<i;e++){let e=2**r;t.push(e);let i=1/(e-2),a=-i,o=1+i,s=[a,a,o,a,o,o,a,a,o,o,a,o],c=new Float32Array(108),l=new Float32Array(108);for(let e=0;e<6;e++){let t=e%3*2/3-1,n=e>2?0:-1,r=[t,n,0,t+2/3,n,0,t+2/3,n+1,0,t,n,0,t+2/3,n+1,0,t,n+1,0];c.set(r,18*e);for(let t=0;t<6;t++){let n=s[t*2]*2-1,r=s[t*2+1]*2-1;e===0?Cg.set(1,r,n):e===1?Cg.set(-n,1,-r):e===2?Cg.set(-n,r,1):e===3?Cg.set(-1,r,-n):e===4?Cg.set(-n,-1,r):Cg.set(n,r,-1),Cg.toArray(l,(e*6+t)*3)}}let u=new Dp;u.setAttribute(`position`,new fp(c,3)),u.setAttribute(`outputDirection`,new fp(l,3)),n.push(new Zp(u,null)),r>fg&&r--}return{lodMeshes:n,sizeLods:t}}function Eg(e,t,n){let r=new Kd(e,t,n);return r.texture.mapping=306,r.texture.name=`PMREM.cubeUv`,r.scissorTest=!0,r}function Dg(e,t,n,r,i){e.viewport.set(t,n,r,i),e.scissor.set(t,n,r,i)}function Og(e,t,n){return new Xm({name:`PMREMGGXConvolution`,defines:{GGX_SAMPLES:hg,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:Mg(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function kg(e,t,n){return new Xm({name:`SphericalGaussianBlur`,defines:{SAMPLES:mg,CUBEUV_TEXEL_WIDTH:1/t,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${e}.0`},uniforms:{envMap:{value:null},sigma:{value:0},mipInt:{value:0}},vertexShader:Mg(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float sigma;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359
			#define GOLDEN_ANGLE 2.39996322973

			void main() {

				if ( sigma == 0.0 ) {

					gl_FragColor = vec4( bilinearCubeUV( envMap, vOutputDirection, mipInt ), 1.0 );
					return;

				}

				vec3 outputDirection = normalize( vOutputDirection );

				vec3 up = abs( outputDirection.z ) < 0.999 ? vec3( 0.0, 0.0, 1.0 ) : vec3( 1.0, 0.0, 0.0 );
				vec3 tangent = normalize( cross( up, outputDirection ) );
				vec3 bitangent = cross( outputDirection, tangent );

				// Truncate the kernel at three standard deviations or at the antipode.
				float thetaMax = min( 3.0 * sigma, PI );
				float truncation = 1.0 - exp( - 0.5 * thetaMax * thetaMax / ( sigma * sigma ) );

				vec3 accumColor = vec3( 0.0 );
				float accumWeight = 0.0;

				for ( int i = 0; i < SAMPLES; i ++ ) {

					// Stratified inverse-CDF sampling of the Gaussian, placed on a golden-angle spiral.
					float stratum = ( float( i ) + 0.5 ) / float( SAMPLES );
					float theta = sigma * sqrt( - 2.0 * log( 1.0 - stratum * truncation ) );
					float phi = float( i ) * GOLDEN_ANGLE;

					vec3 offset = cos( phi ) * tangent + sin( phi ) * bitangent;
					vec3 sampleDirection = cos( theta ) * outputDirection + sin( theta ) * offset;

					// Correct the planar sample density to solid angle.
					float weight = sin( theta ) / theta;

					accumColor += weight * bilinearCubeUV( envMap, sampleDirection, mipInt );
					accumWeight += weight;

				}

				gl_FragColor = vec4( accumColor / accumWeight, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Ag(){return new Xm({name:`EquirectangularToCubeUV`,uniforms:{envMap:{value:null}},vertexShader:Mg(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function jg(){return new Xm({name:`CubemapToCubeUV`,uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Mg(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Mg(){return`

		precision mediump float;
		precision mediump int;

		attribute vec3 outputDirection;

		varying vec3 vOutputDirection;

		void main() {

			vOutputDirection = outputDirection;
			gl_Position = vec4( position, 1.0 );

		}
	`}var Ng=class extends Kd{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let n={width:e,height:e,depth:1},r=[n,n,n,n,n,n];this.texture=new Dm(r),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new Mm(5,5,5),i=new Xm({name:`CubemapFromEquirect`,uniforms:Hm(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:1,blending:0});i.uniforms.tEquirect.value=t;let a=new Zp(r,i),o=t.minFilter;return t.minFilter===1008&&(t.minFilter=Ll),new zh(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t=!0,n=!0,r=!0){let i=e.getRenderTarget();for(let i=0;i<6;i++)e.setRenderTarget(this,i),e.clear(t,n,r);e.setRenderTarget(i)}};function Pg(e){let t=new WeakMap,n=new WeakMap,r=null;function i(e,t=!1){return e==null?null:t?o(e):a(e)}function a(n){if(n&&n.isTexture){let r=n.mapping;if(r===303||r===304){if(t.has(n)){let e=t.get(n).texture;return s(e,n.mapping)}{let r=n.image;if(r&&r.height>0){let i=new Ng(r.height);return i.fromEquirectangularTexture(e,n),t.set(n,i),n.addEventListener(`dispose`,l),s(i.texture,n.mapping)}return null}}}return n}function o(t){if(t&&t.isTexture){let i=t.mapping,a=i===303||i===304,o=i===301||i===302;if(a||o){let i=n.get(t),s=i===void 0?0:i.texture.pmremVersion;if(t.isRenderTargetTexture&&t.pmremVersion!==s)return r===null&&(r=new wg(e)),i=a?r.fromEquirectangular(t,i):r.fromCubemap(t,i),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),i.texture;if(i!==void 0)return i.texture;{let s=t.image;return a&&s&&s.height>0||o&&s&&c(s)?(r===null&&(r=new wg(e)),i=a?r.fromEquirectangular(t):r.fromCubemap(t),i.texture.pmremVersion=t.pmremVersion,n.set(t,i),t.addEventListener(`dispose`,u),i.texture):null}}}return t}function s(e,t){return t===303?e.mapping=301:t===304&&(e.mapping=302),e}function c(e){let t=0;for(let n=0;n<6;n++)e[n]!==void 0&&t++;return t===6}function l(e){let n=e.target;n.removeEventListener(`dispose`,l);let r=t.get(n);r!==void 0&&(t.delete(n),r.dispose())}function u(e){let t=e.target;t.removeEventListener(`dispose`,u);let r=n.get(t);r!==void 0&&(n.delete(t),r.dispose())}function d(){t=new WeakMap,n=new WeakMap,r!==null&&(r.dispose(),r=null)}return{get:i,dispose:d}}function Fg(e){let t={};function n(n){if(t[n]!==void 0)return t[n];let r=e.getExtension(n);return t[n]=r,r}return{has:function(e){return n(e)!==null},init:function(){n(`EXT_color_buffer_float`),n(`WEBGL_clip_cull_distance`),n(`OES_texture_float_linear`),n(`EXT_color_buffer_half_float`),n(`WEBGL_multisampled_render_to_texture`),n(`WEBGL_render_shared_exponent`)},get:function(e){let t=n(e);return t===null&&pd(`WebGLRenderer: `+e+` extension not supported.`),t}}}function Ig(e,t,n,r){let i={},a=new WeakMap;function o(e){let s=e.target;s.index!==null&&t.remove(s.index);for(let e in s.attributes)t.remove(s.attributes[e]);s.removeEventListener(`dispose`,o),delete i[s.id];let c=a.get(s);c&&(t.remove(c),a.delete(s)),r.releaseStatesOfGeometry(s),s.isInstancedBufferGeometry===!0&&delete s._maxInstanceCount,n.memory.geometries--}function s(e,t){return i[t.id]===!0||(t.addEventListener(`dispose`,o),i[t.id]=!0,n.memory.geometries++),t}function c(n){let r=n.attributes;for(let n in r)t.update(r[n],e.ARRAY_BUFFER)}function l(e){let n=[],r=e.index,i=e.attributes.position,o=0;if(i===void 0)return;if(r!==null){let e=r.array;o=r.version;for(let t=0,r=e.length;t<r;t+=3){let r=e[t+0],i=e[t+1],a=e[t+2];n.push(r,i,i,a,a,r)}}else{let e=i.array;o=i.version;for(let t=0,r=e.length/3-1;t<r;t+=3){let e=t+0,r=t+1,i=t+2;n.push(e,r,r,i,i,e)}}let s=new(i.count>=65535?mp:pp)(n,1);s.version=o;let c=a.get(e);c&&t.remove(c),a.set(e,s)}function u(e){let t=a.get(e);if(t){let n=e.index;n!==null&&t.version<n.version&&l(e)}else l(e);return a.get(e)}return{get:s,update:c,getWireframeAttribute:u}}function Lg(e,t,n){let r;function i(e){r=e}let a,o;function s(e){a=e.type,o=e.bytesPerElement}function c(t,i){e.drawElements(r,i,a,t*o),n.update(i,r,1)}function l(t,i,s){s!==0&&(e.drawElementsInstanced(r,i,a,t*o,s),n.update(i,r,s))}function u(e,i,o){if(o===0)return;t.get(`WEBGL_multi_draw`).multiDrawElementsWEBGL(r,i,0,a,e,0,o);let s=0;for(let e=0;e<o;e++)s+=i[e];n.update(s,r,1)}this.setMode=i,this.setIndex=s,this.render=c,this.renderInstances=l,this.renderMultiDraw=u}function Rg(e){let t={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function r(t,r,i){switch(n.calls++,r){case e.TRIANGLES:n.triangles+=t/3*i;break;case e.LINES:n.lines+=t/2*i;break;case e.LINE_STRIP:n.lines+=i*(t-1);break;case e.LINE_LOOP:n.lines+=i*t;break;case e.POINTS:n.points+=i*t;break;default:q(`WebGLInfo: Unknown draw mode:`,r)}}function i(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:t,render:n,programs:null,autoReset:!0,reset:i,update:r}}function zg(e,t,n){let r=new WeakMap,i=new Wd;function a(a,o,s){let c=a.morphTargetInfluences,l=o.morphAttributes.position||o.morphAttributes.normal||o.morphAttributes.color,u=l===void 0?0:l.length,d=r.get(o);if(d===void 0||d.count!==u){d!==void 0&&d.texture.dispose();let e=o.morphAttributes.position!==void 0,n=o.morphAttributes.normal!==void 0,a=o.morphAttributes.color!==void 0,s=o.morphAttributes.position||[],c=o.morphAttributes.normal||[],l=o.morphAttributes.color||[],f=0;e===!0&&(f=1),n===!0&&(f=2),a===!0&&(f=3);let p=o.attributes.position.count*f,m=1;p>t.maxTextureSize&&(m=Math.ceil(p/t.maxTextureSize),p=t.maxTextureSize);let h=new Float32Array(p*m*4*u),g=new qd(h,p,m,u);g.type=Kl,g.needsUpdate=!0;let _=f*4;for(let t=0;t<u;t++){let r=s[t],o=c[t],u=l[t],d=p*m*4*t;for(let t=0;t<r.count;t++){let s=t*_;e===!0&&(i.fromBufferAttribute(r,t),h[d+s+0]=i.x,h[d+s+1]=i.y,h[d+s+2]=i.z,h[d+s+3]=0),n===!0&&(i.fromBufferAttribute(o,t),h[d+s+4]=i.x,h[d+s+5]=i.y,h[d+s+6]=i.z,h[d+s+7]=0),a===!0&&(i.fromBufferAttribute(u,t),h[d+s+8]=i.x,h[d+s+9]=i.y,h[d+s+10]=i.z,h[d+s+11]=u.itemSize===4?i.w:1)}}d={count:u,texture:g,size:new J(p,m)},r.set(o,d);function v(){g.dispose(),r.delete(o),o.removeEventListener(`dispose`,v)}o.addEventListener(`dispose`,v)}if(a.isInstancedMesh===!0&&a.morphTexture!==null)s.getUniforms().setValue(e,`morphTexture`,a.morphTexture,n);else{let t=0;for(let e=0;e<c.length;e++)t+=c[e];let n=o.morphTargetsRelative?1:1-t;s.getUniforms().setValue(e,`morphTargetBaseInfluence`,n),s.getUniforms().setValue(e,`morphTargetInfluences`,c)}s.getUniforms().setValue(e,`morphTargetsTexture`,d.texture,n),s.getUniforms().setValue(e,`morphTargetsTextureSize`,d.size)}return{update:a}}function Bg(e,t,n,r,i){let a=new WeakMap;function o(r){let o=i.render.frame,s=r.geometry,l=t.get(r,s);if(a.get(l)!==o&&(t.update(l),a.set(l,o)),r.isInstancedMesh&&(r.hasEventListener(`dispose`,c)===!1&&r.addEventListener(`dispose`,c),a.get(r)!==o&&(n.update(r.instanceMatrix,e.ARRAY_BUFFER),r.instanceColor!==null&&n.update(r.instanceColor,e.ARRAY_BUFFER),a.set(r,o))),r.isSkinnedMesh){let e=r.skeleton;a.get(e)!==o&&(e.update(),a.set(e,o))}return l}function s(){a=new WeakMap}function c(e){let t=e.target;t.removeEventListener(`dispose`,c),r.releaseStatesOfObject(t),n.remove(t.instanceMatrix),t.instanceColor!==null&&n.remove(t.instanceColor)}return{update:o,dispose:s}}var Vg={1:`LINEAR_TONE_MAPPING`,2:`REINHARD_TONE_MAPPING`,3:`CINEON_TONE_MAPPING`,4:`ACES_FILMIC_TONE_MAPPING`,6:`AGX_TONE_MAPPING`,7:`NEUTRAL_TONE_MAPPING`,5:`CUSTOM_TONE_MAPPING`};function Hg(e,t,n,r,i,a){let o=new Kd(t,n,{type:e,depthBuffer:i,stencilBuffer:a,samples:r?4:0,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,resolveDepthBuffer:!1,resolveStencilBuffer:!1}),s=null,c=null,l=new Dp;l.setAttribute(`position`,new hp([-1,3,0,-1,-1,0,3,-1,0],3)),l.setAttribute(`uv`,new hp([0,2,0,0,2,0],2));let u=new Zm({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),d=new Zp(l,u),f=new Fh(-1,1,1,-1,0,1),p=null,m=null,h=!1,g,_=null,v=[],y=!1;this.setSize=function(e,t){o.setSize(e,t),s!==null&&s.setSize(e,t),c!==null&&c.setSize(e,t);for(let n=0;n<v.length;n++){let r=v[n];r.setSize&&r.setSize(e,t)}},this.setEffects=function(e){v=e,y=v.length>0&&v[0].isRenderPass===!0;let t=o.width,n=o.height;v.length>0&&s===null&&(s=new Kd(t,n,{type:ql,depthBuffer:!1,stencilBuffer:!1}),c=new Kd(t,n,{type:ql,depthBuffer:!1,stencilBuffer:!1}));for(let e=0;e<v.length;e++){let r=v[e];r.setSize&&r.setSize(t,n)}},this.begin=function(e,t){if(h||e.toneMapping===0&&v.length===0)return!1;if(_=t,t!==null){let e=t.width,n=t.height;(o.width!==e||o.height!==n)&&this.setSize(e,n)}return y===!1&&e.setRenderTarget(o),g=e.toneMapping,e.toneMapping=0,!0},this.hasRenderPass=function(){return y},this.end=function(e,t){e.toneMapping=g,h=!0;let n=o,r=s;for(let i=0;i<v.length;i++){let a=v[i];a.enabled!==!1&&(a.render(e,r,n,t),a.needsSwap!==!1&&(n=r,r=r===s?c:s))}if(p!==e.outputColorSpace||m!==e.toneMapping){p=e.outputColorSpace,m=e.toneMapping,u.defines={},Nd.getTransfer(p)===`srgb`&&(u.defines.SRGB_TRANSFER=``);let t=Vg[m];t&&(u.defines[t]=``),u.needsUpdate=!0}u.uniforms.tDiffuse.value=n.texture,e.setRenderTarget(_),e.render(d,f),_=null,h=!1},this.isCompositing=function(){return h},this.dispose=function(){o.dispose(),s!==null&&s.dispose(),c!==null&&c.dispose(),l.dispose(),u.dispose()}}var Ug=new Ud,Wg=new km(1,1),Gg=new qd,Kg=new Jd,qg=new Dm,Jg=[],Yg=[],Xg=new Float32Array(16),Zg=new Float32Array(9),Qg=new Float32Array(4);function $g(e,t,n){let r=e[0];if(r<=0||r>0)return e;let i=t*n,a=Jg[i];if(a===void 0&&(a=new Float32Array(i),Jg[i]=a),t!==0){r.toArray(a,0);for(let r=1,i=0;r!==t;++r)i+=n,e[r].toArray(a,i)}return a}function e_(e,t){if(e.length!==t.length)return!1;for(let n=0,r=e.length;n<r;n++)if(e[n]!==t[n])return!1;return!0}function t_(e,t){for(let n=0,r=t.length;n<r;n++)e[n]=t[n]}function n_(e,t){let n=Yg[t];n===void 0&&(n=new Int32Array(t),Yg[t]=n);for(let r=0;r!==t;++r)n[r]=e.allocateTextureUnit();return n}function r_(e,t){let n=this.cache;n[0]!==t&&(e.uniform1f(this.addr,t),n[0]=t)}function i_(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2f(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(e_(n,t))return;e.uniform2fv(this.addr,t),t_(n,t)}}function a_(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3f(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else if(t.r!==void 0)(n[0]!==t.r||n[1]!==t.g||n[2]!==t.b)&&(e.uniform3f(this.addr,t.r,t.g,t.b),n[0]=t.r,n[1]=t.g,n[2]=t.b);else{if(e_(n,t))return;e.uniform3fv(this.addr,t),t_(n,t)}}function o_(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4f(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(e_(n,t))return;e.uniform4fv(this.addr,t),t_(n,t)}}function s_(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(e_(n,t))return;e.uniformMatrix2fv(this.addr,!1,t),t_(n,t)}else{if(e_(n,r))return;Qg.set(r),e.uniformMatrix2fv(this.addr,!1,Qg),t_(n,r)}}function c_(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(e_(n,t))return;e.uniformMatrix3fv(this.addr,!1,t),t_(n,t)}else{if(e_(n,r))return;Zg.set(r),e.uniformMatrix3fv(this.addr,!1,Zg),t_(n,r)}}function l_(e,t){let n=this.cache,r=t.elements;if(r===void 0){if(e_(n,t))return;e.uniformMatrix4fv(this.addr,!1,t),t_(n,t)}else{if(e_(n,r))return;Xg.set(r),e.uniformMatrix4fv(this.addr,!1,Xg),t_(n,r)}}function u_(e,t){let n=this.cache;n[0]!==t&&(e.uniform1i(this.addr,t),n[0]=t)}function d_(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2i(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(e_(n,t))return;e.uniform2iv(this.addr,t),t_(n,t)}}function f_(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3i(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(e_(n,t))return;e.uniform3iv(this.addr,t),t_(n,t)}}function p_(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4i(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(e_(n,t))return;e.uniform4iv(this.addr,t),t_(n,t)}}function m_(e,t){let n=this.cache;n[0]!==t&&(e.uniform1ui(this.addr,t),n[0]=t)}function h_(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y)&&(e.uniform2ui(this.addr,t.x,t.y),n[0]=t.x,n[1]=t.y);else{if(e_(n,t))return;e.uniform2uiv(this.addr,t),t_(n,t)}}function g_(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z)&&(e.uniform3ui(this.addr,t.x,t.y,t.z),n[0]=t.x,n[1]=t.y,n[2]=t.z);else{if(e_(n,t))return;e.uniform3uiv(this.addr,t),t_(n,t)}}function __(e,t){let n=this.cache;if(t.x!==void 0)(n[0]!==t.x||n[1]!==t.y||n[2]!==t.z||n[3]!==t.w)&&(e.uniform4ui(this.addr,t.x,t.y,t.z,t.w),n[0]=t.x,n[1]=t.y,n[2]=t.z,n[3]=t.w);else{if(e_(n,t))return;e.uniform4uiv(this.addr,t),t_(n,t)}}function v_(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i);let a;this.type===e.SAMPLER_2D_SHADOW?(Wg.compareFunction=n.isReversedDepthBuffer()?518:515,a=Wg):a=Ug,n.setTexture2D(t||a,i)}function y_(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture3D(t||Kg,i)}function b_(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTextureCube(t||qg,i)}function x_(e,t,n){let r=this.cache,i=n.allocateTextureUnit();r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),n.setTexture2DArray(t||Gg,i)}function S_(e){switch(e){case 5126:return r_;case 35664:return i_;case 35665:return a_;case 35666:return o_;case 35674:return s_;case 35675:return c_;case 35676:return l_;case 5124:case 35670:return u_;case 35667:case 35671:return d_;case 35668:case 35672:return f_;case 35669:case 35673:return p_;case 5125:return m_;case 36294:return h_;case 36295:return g_;case 36296:return __;case 35678:case 36198:case 36298:case 36306:case 35682:return v_;case 35679:case 36299:case 36307:return y_;case 35680:case 36300:case 36308:case 36293:return b_;case 36289:case 36303:case 36311:case 36292:return x_}}function C_(e,t){e.uniform1fv(this.addr,t)}function w_(e,t){let n=$g(t,this.size,2);e.uniform2fv(this.addr,n)}function T_(e,t){let n=$g(t,this.size,3);e.uniform3fv(this.addr,n)}function E_(e,t){let n=$g(t,this.size,4);e.uniform4fv(this.addr,n)}function D_(e,t){let n=$g(t,this.size,4);e.uniformMatrix2fv(this.addr,!1,n)}function O_(e,t){let n=$g(t,this.size,9);e.uniformMatrix3fv(this.addr,!1,n)}function k_(e,t){let n=$g(t,this.size,16);e.uniformMatrix4fv(this.addr,!1,n)}function A_(e,t){e.uniform1iv(this.addr,t)}function j_(e,t){e.uniform2iv(this.addr,t)}function M_(e,t){e.uniform3iv(this.addr,t)}function N_(e,t){e.uniform4iv(this.addr,t)}function P_(e,t){e.uniform1uiv(this.addr,t)}function F_(e,t){e.uniform2uiv(this.addr,t)}function I_(e,t){e.uniform3uiv(this.addr,t)}function L_(e,t){e.uniform4uiv(this.addr,t)}function R_(e,t,n){let r=this.cache,i=t.length,a=n_(n,i);e_(r,a)||(e.uniform1iv(this.addr,a),t_(r,a));let o;o=this.type===e.SAMPLER_2D_SHADOW?Wg:Ug;for(let e=0;e!==i;++e)n.setTexture2D(t[e]||o,a[e])}function z_(e,t,n){let r=this.cache,i=t.length,a=n_(n,i);e_(r,a)||(e.uniform1iv(this.addr,a),t_(r,a));for(let e=0;e!==i;++e)n.setTexture3D(t[e]||Kg,a[e])}function B_(e,t,n){let r=this.cache,i=t.length,a=n_(n,i);e_(r,a)||(e.uniform1iv(this.addr,a),t_(r,a));for(let e=0;e!==i;++e)n.setTextureCube(t[e]||qg,a[e])}function V_(e,t,n){let r=this.cache,i=t.length,a=n_(n,i);e_(r,a)||(e.uniform1iv(this.addr,a),t_(r,a));for(let e=0;e!==i;++e)n.setTexture2DArray(t[e]||Gg,a[e])}function H_(e){switch(e){case 5126:return C_;case 35664:return w_;case 35665:return T_;case 35666:return E_;case 35674:return D_;case 35675:return O_;case 35676:return k_;case 5124:case 35670:return A_;case 35667:case 35671:return j_;case 35668:case 35672:return M_;case 35669:case 35673:return N_;case 5125:return P_;case 36294:return F_;case 36295:return I_;case 36296:return L_;case 35678:case 36198:case 36298:case 36306:case 35682:return R_;case 35679:case 36299:case 36307:return z_;case 35680:case 36300:case 36308:case 36293:return B_;case 36289:case 36303:case 36311:case 36292:return V_}}var U_=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=S_(t.type)}},W_=class{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=H_(t.type)}},G_=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){let r=this.seq;for(let i=0,a=r.length;i!==a;++i){let a=r[i];a.setValue(e,t[a.id],n)}}},K_=/(\w+)(\])?(\[|\.)?/g;function q_(e,t){e.seq.push(t),e.map[t.id]=t}function J_(e,t,n){let r=e.name,i=r.length;for(K_.lastIndex=0;;){let a=K_.exec(r),o=K_.lastIndex,s=a[1],c=a[2]===`]`,l=a[3];if(c&&(s|=0),l===void 0||l===`[`&&o+2===i){q_(n,l===void 0?new U_(s,e,t):new W_(s,e,t));break}{let e=n.map[s];e===void 0&&(e=new G_(s),q_(n,e)),n=e}}}var Y_=class{constructor(e,t){this.seq=[],this.map={};let n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let r=0;r<n;++r){let n=e.getActiveUniform(t,r);J_(n,e.getUniformLocation(t,n.name),this)}let r=[],i=[];for(let t of this.seq)t.type===e.SAMPLER_2D_SHADOW||t.type===e.SAMPLER_CUBE_SHADOW||t.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(t):i.push(t);r.length>0&&(this.seq=r.concat(i))}setValue(e,t,n,r){let i=this.map[t];i!==void 0&&i.setValue(e,n,r)}setOptional(e,t,n){let r=t[n];r!==void 0&&this.setValue(e,n,r)}static upload(e,t,n,r){for(let i=0,a=t.length;i!==a;++i){let a=t[i],o=n[a.id];o.needsUpdate!==!1&&a.setValue(e,o.value,r)}}static seqWithValue(e,t){let n=[];for(let r=0,i=e.length;r!==i;++r){let i=e[r];i.id in t&&n.push(i)}return n}};function X_(e,t,n){let r=e.createShader(t);return e.shaderSource(r,n),e.compileShader(r),r}var Z_=37297,Q_=0;function $_(e,t){let n=e.split(`
`),r=[],i=Math.max(t-6,0),a=Math.min(t+6,n.length);for(let e=i;e<a;e++){let i=e+1;r.push(`${i===t?`>`:` `} ${i}: ${n[e]}`)}return r.join(`
`)}var ev=new X;function tv(e){Nd._getMatrix(ev,Nd.workingColorSpace,e);let t=`mat3( ${ev.elements.map(e=>e.toFixed(4))} )`;switch(Nd.getTransfer(e)){case td:return[t,`LinearTransferOETF`];case nd:return[t,`sRGBTransferOETF`];default:return K(`WebGLProgram: Unsupported color space: `,e),[t,`LinearTransferOETF`]}}function nv(e,t,n){let r=e.getShaderParameter(t,e.COMPILE_STATUS),i=(e.getShaderInfoLog(t)||``).trim();if(r&&i===``)return``;let a=/ERROR: 0:(\d+)/.exec(i);if(a){let r=parseInt(a[1]);return n.toUpperCase()+`

`+i+`

`+$_(e.getShaderSource(t),r)}return i}function rv(e,t){let n=tv(t);return[`vec4 ${e}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,`}`].join(`
`)}var iv={1:`Linear`,2:`Reinhard`,3:`Cineon`,4:`ACESFilmic`,6:`AgX`,7:`Neutral`,5:`Custom`};function av(e,t){let n=iv[t];return n===void 0?(K(`WebGLProgram: Unsupported toneMapping:`,t),`vec3 `+e+`( vec3 color ) { return LinearToneMapping( color ); }`):`vec3 `+e+`( vec3 color ) { return `+n+`ToneMapping( color ); }`}var ov=new Y;function sv(){return Nd.getLuminanceCoefficients(ov),[`float luminance( const in vec3 rgb ) {`,`	const vec3 weights = vec3( ${ov.x.toFixed(4)}, ${ov.y.toFixed(4)}, ${ov.z.toFixed(4)} );`,`	return dot( weights, rgb );`,`}`].join(`
`)}function cv(e){return[e.extensionClipCullDistance?`#extension GL_ANGLE_clip_cull_distance : require`:``,e.extensionMultiDraw?`#extension GL_ANGLE_multi_draw : require`:``].filter(dv).join(`
`)}function lv(e){let t=[];for(let n in e){let r=e[n];r!==!1&&t.push(`#define `+n+` `+r)}return t.join(`
`)}function uv(e,t){let n={},r=e.getProgramParameter(t,e.ACTIVE_ATTRIBUTES);for(let i=0;i<r;i++){let r=e.getActiveAttrib(t,i),a=r.name,o=1;r.type===e.FLOAT_MAT2&&(o=2),r.type===e.FLOAT_MAT3&&(o=3),r.type===e.FLOAT_MAT4&&(o=4),n[a]={type:r.type,location:e.getAttribLocation(t,a),locationSize:o}}return n}function dv(e){return e!==``}function fv(e,t){let n=t.numSpotLightShadows+t.numSpotLightMaps-t.numSpotLightShadowsWithMaps;return e.replace(/NUM_SUN_LIGHTS/g,t.numSunLights).replace(/NUM_DIR_LIGHTS/g,t.numDirLights).replace(/NUM_SPOT_LIGHTS/g,t.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,t.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,t.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,t.numPointLights).replace(/NUM_HEMI_LIGHTS/g,t.numHemiLights).replace(/NUM_SUN_LIGHT_SHADOWS/g,t.numSunLightShadows).replace(/NUM_DIR_LIGHT_SHADOWS/g,t.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,t.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,t.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,t.numPointLightShadows)}function pv(e,t){return e.replace(/NUM_CLIPPING_PLANES/g,t.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,t.numClippingPlanes-t.numClipIntersection)}var mv=/^[ \t]*#include +<([\w\d./]+)>/gm;function hv(e){return e.replace(mv,_v)}var gv=new Map;function _v(e,t){let n=Q[t];if(n===void 0){let e=gv.get(t);if(e!==void 0)n=Q[e],K(`WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.`,t,e);else throw Error(`THREE.WebGLProgram: Can not resolve #include <`+t+`>`)}return hv(n)}var vv=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function yv(e){return e.replace(vv,bv)}function bv(e,t,n,r){let i=``;for(let e=parseInt(t);e<parseInt(n);e++)i+=r.replace(/\[\s*i\s*\]/g,`[ `+e+` ]`).replace(/UNROLLED_LOOP_INDEX/g,e);return i}function xv(e){let t=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;return e.precision===`highp`?t+=`
#define HIGH_PRECISION`:e.precision===`mediump`?t+=`
#define MEDIUM_PRECISION`:e.precision===`lowp`&&(t+=`
#define LOW_PRECISION`),t}var Sv={1:`SHADOWMAP_TYPE_PCF`,3:`SHADOWMAP_TYPE_VSM`};function Cv(e){return Sv[e.shadowMapType]||`SHADOWMAP_TYPE_BASIC`}var wv={301:`ENVMAP_TYPE_CUBE`,302:`ENVMAP_TYPE_CUBE`,306:`ENVMAP_TYPE_CUBE_UV`};function Tv(e){return e.envMap===!1?`ENVMAP_TYPE_CUBE`:wv[e.envMapMode]||`ENVMAP_TYPE_CUBE`}var Ev={302:`ENVMAP_MODE_REFRACTION`};function Dv(e){return e.envMap===!1?`ENVMAP_MODE_REFLECTION`:Ev[e.envMapMode]||`ENVMAP_MODE_REFLECTION`}var Ov={0:`ENVMAP_BLENDING_MULTIPLY`,1:`ENVMAP_BLENDING_MIX`,2:`ENVMAP_BLENDING_ADD`};function kv(e){return e.envMap===!1?`ENVMAP_BLENDING_NONE`:Ov[e.combine]||`ENVMAP_BLENDING_NONE`}function Av(e){let t=e.envMapCubeUVHeight;if(t===null)return null;let n=Math.log2(t)-2,r=1/t;return{texelWidth:1/(3*Math.max(2**n,112)),texelHeight:r,maxMip:n}}function jv(e,t,n,r){let i=e.getContext(),a=n.defines,o=n.vertexShader,s=n.fragmentShader,c=Cv(n),l=Tv(n),u=Dv(n),d=kv(n),f=Av(n),p=cv(n),m=lv(a),h=i.createProgram(),g,_,v=n.glslVersion?`#version `+n.glslVersion+`
`:``;n.isRawShaderMaterial?(g=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(dv).join(`
`),g.length>0&&(g+=`
`),_=[`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m].filter(dv).join(`
`),_.length>0&&(_+=`
`)):(g=[xv(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.extensionClipCullDistance?`#define USE_CLIP_DISTANCE`:``,n.batching?`#define USE_BATCHING`:``,n.batchingColor?`#define USE_BATCHING_COLOR`:``,n.instancing?`#define USE_INSTANCING`:``,n.instancingColor?`#define USE_INSTANCING_COLOR`:``,n.instancingMorph?`#define USE_INSTANCING_MORPH`:``,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.map?`#define USE_MAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+u:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.displacementMap?`#define USE_DISPLACEMENTMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.mapUv?`#define MAP_UV `+n.mapUv:``,n.alphaMapUv?`#define ALPHAMAP_UV `+n.alphaMapUv:``,n.lightMapUv?`#define LIGHTMAP_UV `+n.lightMapUv:``,n.aoMapUv?`#define AOMAP_UV `+n.aoMapUv:``,n.emissiveMapUv?`#define EMISSIVEMAP_UV `+n.emissiveMapUv:``,n.bumpMapUv?`#define BUMPMAP_UV `+n.bumpMapUv:``,n.normalMapUv?`#define NORMALMAP_UV `+n.normalMapUv:``,n.displacementMapUv?`#define DISPLACEMENTMAP_UV `+n.displacementMapUv:``,n.metalnessMapUv?`#define METALNESSMAP_UV `+n.metalnessMapUv:``,n.roughnessMapUv?`#define ROUGHNESSMAP_UV `+n.roughnessMapUv:``,n.anisotropyMapUv?`#define ANISOTROPYMAP_UV `+n.anisotropyMapUv:``,n.clearcoatMapUv?`#define CLEARCOATMAP_UV `+n.clearcoatMapUv:``,n.clearcoatNormalMapUv?`#define CLEARCOAT_NORMALMAP_UV `+n.clearcoatNormalMapUv:``,n.clearcoatRoughnessMapUv?`#define CLEARCOAT_ROUGHNESSMAP_UV `+n.clearcoatRoughnessMapUv:``,n.iridescenceMapUv?`#define IRIDESCENCEMAP_UV `+n.iridescenceMapUv:``,n.iridescenceThicknessMapUv?`#define IRIDESCENCE_THICKNESSMAP_UV `+n.iridescenceThicknessMapUv:``,n.sheenColorMapUv?`#define SHEEN_COLORMAP_UV `+n.sheenColorMapUv:``,n.sheenRoughnessMapUv?`#define SHEEN_ROUGHNESSMAP_UV `+n.sheenRoughnessMapUv:``,n.specularMapUv?`#define SPECULARMAP_UV `+n.specularMapUv:``,n.specularColorMapUv?`#define SPECULAR_COLORMAP_UV `+n.specularColorMapUv:``,n.specularIntensityMapUv?`#define SPECULAR_INTENSITYMAP_UV `+n.specularIntensityMapUv:``,n.transmissionMapUv?`#define TRANSMISSIONMAP_UV `+n.transmissionMapUv:``,n.thicknessMapUv?`#define THICKNESSMAP_UV `+n.thicknessMapUv:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexNormals?`#define HAS_NORMAL`:``,n.vertexColors?`#define USE_COLOR`:``,n.vertexAlphas?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.flatShading?`#define FLAT_SHADED`:``,n.skinning?`#define USE_SKINNING`:``,n.morphTargets?`#define USE_MORPHTARGETS`:``,n.morphNormals&&n.flatShading===!1?`#define USE_MORPHNORMALS`:``,n.morphColors?`#define USE_MORPHCOLORS`:``,n.morphTargetsCount>0?`#define MORPHTARGETS_TEXTURE_STRIDE `+n.morphTextureStride:``,n.morphTargetsCount>0?`#define MORPHTARGETS_COUNT `+n.morphTargetsCount:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.sizeAttenuation?`#define USE_SIZEATTENUATION`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 modelMatrix;`,`uniform mat4 modelViewMatrix;`,`uniform mat4 projectionMatrix;`,`uniform mat4 viewMatrix;`,`uniform mat3 normalMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,`#ifdef USE_INSTANCING`,`	attribute mat4 instanceMatrix;`,`#endif`,`#ifdef USE_INSTANCING_COLOR`,`	attribute vec3 instanceColor;`,`#endif`,`#ifdef USE_INSTANCING_MORPH`,`	uniform sampler2D morphTexture;`,`#endif`,`attribute vec3 position;`,`attribute vec3 normal;`,`attribute vec2 uv;`,`#ifdef USE_UV1`,`	attribute vec2 uv1;`,`#endif`,`#ifdef USE_UV2`,`	attribute vec2 uv2;`,`#endif`,`#ifdef USE_UV3`,`	attribute vec2 uv3;`,`#endif`,`#ifdef USE_TANGENT`,`	attribute vec4 tangent;`,`#endif`,`#if defined( USE_COLOR_ALPHA )`,`	attribute vec4 color;`,`#elif defined( USE_COLOR )`,`	attribute vec3 color;`,`#endif`,`#ifdef USE_SKINNING`,`	attribute vec4 skinIndex;`,`	attribute vec4 skinWeight;`,`#endif`,`
`].filter(dv).join(`
`),_=[xv(n),`#define SHADER_TYPE `+n.shaderType,`#define SHADER_NAME `+n.shaderName,m,n.useFog&&n.fog?`#define USE_FOG`:``,n.useFog&&n.fogExp2?`#define FOG_EXP2`:``,n.alphaToCoverage?`#define ALPHA_TO_COVERAGE`:``,n.map?`#define USE_MAP`:``,n.matcap?`#define USE_MATCAP`:``,n.envMap?`#define USE_ENVMAP`:``,n.envMap?`#define `+l:``,n.envMap?`#define `+u:``,n.envMap?`#define `+d:``,f?`#define CUBEUV_TEXEL_WIDTH `+f.texelWidth:``,f?`#define CUBEUV_TEXEL_HEIGHT `+f.texelHeight:``,f?`#define CUBEUV_MAX_MIP `+f.maxMip+`.0`:``,n.lightMap?`#define USE_LIGHTMAP`:``,n.aoMap?`#define USE_AOMAP`:``,n.bumpMap?`#define USE_BUMPMAP`:``,n.normalMap?`#define USE_NORMALMAP`:``,n.normalMapObjectSpace?`#define USE_NORMALMAP_OBJECTSPACE`:``,n.normalMapTangentSpace?`#define USE_NORMALMAP_TANGENTSPACE`:``,n.packedNormalMap?`#define USE_PACKED_NORMALMAP`:``,n.emissiveMap?`#define USE_EMISSIVEMAP`:``,n.anisotropy?`#define USE_ANISOTROPY`:``,n.anisotropyMap?`#define USE_ANISOTROPYMAP`:``,n.clearcoat?`#define USE_CLEARCOAT`:``,n.clearcoatMap?`#define USE_CLEARCOATMAP`:``,n.clearcoatRoughnessMap?`#define USE_CLEARCOAT_ROUGHNESSMAP`:``,n.clearcoatNormalMap?`#define USE_CLEARCOAT_NORMALMAP`:``,n.dispersion?`#define USE_DISPERSION`:``,n.retroreflection?`#define USE_RETROREFLECTION`:``,n.iridescence?`#define USE_IRIDESCENCE`:``,n.iridescenceMap?`#define USE_IRIDESCENCEMAP`:``,n.iridescenceThicknessMap?`#define USE_IRIDESCENCE_THICKNESSMAP`:``,n.specularMap?`#define USE_SPECULARMAP`:``,n.specularColorMap?`#define USE_SPECULAR_COLORMAP`:``,n.specularIntensityMap?`#define USE_SPECULAR_INTENSITYMAP`:``,n.roughnessMap?`#define USE_ROUGHNESSMAP`:``,n.metalnessMap?`#define USE_METALNESSMAP`:``,n.alphaMap?`#define USE_ALPHAMAP`:``,n.alphaTest?`#define USE_ALPHATEST`:``,n.alphaHash?`#define USE_ALPHAHASH`:``,n.sheen?`#define USE_SHEEN`:``,n.sheenColorMap?`#define USE_SHEEN_COLORMAP`:``,n.sheenRoughnessMap?`#define USE_SHEEN_ROUGHNESSMAP`:``,n.transmission?`#define USE_TRANSMISSION`:``,n.transmissionMap?`#define USE_TRANSMISSIONMAP`:``,n.thicknessMap?`#define USE_THICKNESSMAP`:``,n.vertexTangents&&n.flatShading===!1?`#define USE_TANGENT`:``,n.vertexColors||n.instancingColor?`#define USE_COLOR`:``,n.vertexAlphas||n.batchingColor?`#define USE_COLOR_ALPHA`:``,n.vertexUv1s?`#define USE_UV1`:``,n.vertexUv2s?`#define USE_UV2`:``,n.vertexUv3s?`#define USE_UV3`:``,n.pointsUvs?`#define USE_POINTS_UV`:``,n.gradientMap?`#define USE_GRADIENTMAP`:``,n.flatShading?`#define FLAT_SHADED`:``,n.doubleSided?`#define DOUBLE_SIDED`:``,n.flipSided?`#define FLIP_SIDED`:``,n.shadowMapEnabled?`#define USE_SHADOWMAP`:``,n.shadowMapEnabled?`#define `+c:``,n.premultipliedAlpha?`#define PREMULTIPLIED_ALPHA`:``,n.numLightProbes>0?`#define USE_LIGHT_PROBES`:``,n.numLightProbeGrids>0?`#define USE_LIGHT_PROBES_GRID`:``,n.decodeVideoTexture?`#define DECODE_VIDEO_TEXTURE`:``,n.decodeVideoTextureEmissive?`#define DECODE_VIDEO_TEXTURE_EMISSIVE`:``,n.logarithmicDepthBuffer?`#define USE_LOGARITHMIC_DEPTH_BUFFER`:``,n.reversedDepthBuffer?`#define USE_REVERSED_DEPTH_BUFFER`:``,`uniform mat4 viewMatrix;`,`uniform vec3 cameraPosition;`,`uniform bool isOrthographic;`,n.toneMapping===0?``:`#define TONE_MAPPING`,n.toneMapping===0?``:Q.tonemapping_pars_fragment,n.toneMapping===0?``:av(`toneMapping`,n.toneMapping),n.dithering?`#define DITHERING`:``,n.opaque?`#define OPAQUE`:``,Q.colorspace_pars_fragment,rv(`linearToOutputTexel`,n.outputColorSpace),sv(),n.useDepthPacking?`#define DEPTH_PACKING `+n.depthPacking:``,`
`].filter(dv).join(`
`)),o=hv(o),o=fv(o,n),o=pv(o,n),s=hv(s),s=fv(s,n),s=pv(s,n),o=yv(o),s=yv(s),n.isRawShaderMaterial!==!0&&(v=`#version 300 es
`,g=[p,`#define attribute in`,`#define varying out`,`#define texture2D texture`].join(`
`)+`
`+g,_=[`#define varying in`,n.glslVersion===`300 es`?``:`layout(location = 0) out highp vec4 pc_fragColor;`,n.glslVersion===`300 es`?``:`#define gl_FragColor pc_fragColor`,`#define gl_FragDepthEXT gl_FragDepth`,`#define texture2D texture`,`#define textureCube texture`,`#define texture2DProj textureProj`,`#define texture2DLodEXT textureLod`,`#define texture2DProjLodEXT textureProjLod`,`#define textureCubeLodEXT textureLod`,`#define texture2DGradEXT textureGrad`,`#define texture2DProjGradEXT textureProjGrad`,`#define textureCubeGradEXT textureGrad`].join(`
`)+`
`+_);let y=v+g+o,b=v+_+s,x=X_(i,i.VERTEX_SHADER,y),S=X_(i,i.FRAGMENT_SHADER,b);i.attachShader(h,x),i.attachShader(h,S),n.index0AttributeName===void 0?n.hasPositionAttribute===!0&&i.bindAttribLocation(h,0,`position`):i.bindAttribLocation(h,0,n.index0AttributeName),i.linkProgram(h);function C(t){if(e.debug.checkShaderErrors){let n=i.getProgramInfoLog(h)||``,r=i.getShaderInfoLog(x)||``,a=i.getShaderInfoLog(S)||``,o=n.trim(),s=r.trim(),c=a.trim(),l=!0,u=!0;if(i.getProgramParameter(h,i.LINK_STATUS)===!1){if(l=!1,typeof e.debug.onShaderError==`function`)e.debug.onShaderError(i,h,x,S);else{let e=nv(i,x,`vertex`),n=nv(i,S,`fragment`);q(`WebGLProgram: Shader Error `+i.getError()+` - VALIDATE_STATUS `+i.getProgramParameter(h,i.VALIDATE_STATUS)+`

Material Name: `+t.name+`
Material Type: `+t.type+`

Program Info Log: `+o+`
`+e+`
`+n)}}else o===``?(s===``||c===``)&&(u=!1):K(`WebGLProgram: Program Info Log:`,o);u&&(t.diagnostics={runnable:l,programLog:o,vertexShader:{log:s,prefix:g},fragmentShader:{log:c,prefix:_}})}i.deleteShader(x),i.deleteShader(S),w=new Y_(i,h),T=uv(i,h)}let w;this.getUniforms=function(){return w===void 0&&C(this),w};let T;this.getAttributes=function(){return T===void 0&&C(this),T};let E=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return E===!1&&(E=i.getProgramParameter(h,Z_)),E},this.destroy=function(){r.releaseStatesOfProgram(this),i.deleteProgram(h),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=Q_++,this.cacheKey=t,this.usedTimes=1,this.program=h,this.vertexShader=x,this.fragmentShader=S,this}var Mv=0,Nv=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e,t,n){let r=this._getShaderCacheForMaterial(e);return r.has(t)===!1&&(r.add(t),t.usedTimes++),r.has(n)===!1&&(r.add(n),n.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let e of t)e.usedTimes--,e.usedTimes===0&&this.shaderCache.delete(e.code);return this.materialCache.delete(e),this}getVertexShaderStage(e){return this._getShaderStage(e.vertexShader)}getFragmentShaderStage(e){return this._getShaderStage(e.fragmentShader)}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){let t=this.shaderCache,n=t.get(e);return n===void 0&&(n=new Pv(e),t.set(e,n)),n}},Pv=class{constructor(e){this.id=Mv++,this.code=e,this.usedTimes=0}};function Fv(e){return e===1030||e===37490||e===36285}function Iv(e,t,n,r,i,a){let o=new sf,s=new Nv,c=new Set,l=[],u=new Map,d=r.logarithmicDepthBuffer,f=r.precision,p={MeshDepthMaterial:`depth`,MeshDistanceMaterial:`distance`,MeshNormalMaterial:`normal`,MeshBasicMaterial:`basic`,MeshLambertMaterial:`lambert`,MeshPhongMaterial:`phong`,MeshToonMaterial:`toon`,MeshStandardMaterial:`physical`,MeshPhysicalMaterial:`physical`,MeshMatcapMaterial:`matcap`,LineBasicMaterial:`basic`,LineDashedMaterial:`dashed`,PointsMaterial:`points`,ShadowMaterial:`shadow`,SpriteMaterial:`sprite`};function m(e){return c.add(e),e===0?`uv`:`uv${e}`}function h(i,o,l,u,h,g){let _=u.fog,v=h.geometry,y=i.isMeshStandardMaterial||i.isMeshLambertMaterial||i.isMeshPhongMaterial?u.environment:null,b=i.isMeshStandardMaterial||i.isMeshLambertMaterial&&!i.envMap||i.isMeshPhongMaterial&&!i.envMap,x=t.get(i.envMap||y,b),S=x&&x.mapping===306?x.image.height:null,C=p[i.type];i.precision!==null&&(f=r.getMaxPrecision(i.precision),f!==i.precision&&K(`WebGLProgram.getParameters:`,i.precision,`not supported, using`,f,`instead.`));let w=v.morphAttributes.position||v.morphAttributes.normal||v.morphAttributes.color,T=w===void 0?0:w.length,E=0;v.morphAttributes.position!==void 0&&(E=1),v.morphAttributes.normal!==void 0&&(E=2),v.morphAttributes.color!==void 0&&(E=3);let D,O,k,A;if(C){let e=rg[C];D=e.vertexShader,O=e.fragmentShader}else{D=i.vertexShader,O=i.fragmentShader;let e=s.getVertexShaderStage(i),t=s.getFragmentShaderStage(i);s.update(i,e,t),k=e.id,A=t.id}let j=e.getRenderTarget(),ee=e.state.buffers.depth.getReversed(),M=h.isInstancedMesh===!0,te=h.isBatchedMesh===!0,ne=!!i.map,re=!!i.matcap,N=!!x,ie=!!i.aoMap,P=!!i.lightMap,ae=!!i.bumpMap&&i.wireframe===!1,oe=!!i.normalMap,F=!!i.displacementMap,I=!!i.emissiveMap,se=!!i.metalnessMap,L=!!i.roughnessMap,R=i.anisotropy>0,ce=i.clearcoat>0,le=i.dispersion>0,ue=i.retroreflectivity>0,de=i.iridescence>0,fe=i.sheen>0,pe=i.transmission>0,me=R&&!!i.anisotropyMap,he=ce&&!!i.clearcoatMap,ge=ce&&!!i.clearcoatNormalMap,z=ce&&!!i.clearcoatRoughnessMap,_e=de&&!!i.iridescenceMap,B=de&&!!i.iridescenceThicknessMap,ve=fe&&!!i.sheenColorMap,ye=fe&&!!i.sheenRoughnessMap,be=!!i.specularMap,V=!!i.specularColorMap,H=!!i.specularIntensityMap,U=pe&&!!i.transmissionMap,W=pe&&!!i.thicknessMap,xe=!!i.gradientMap,Se=!!i.alphaMap,Ce=i.alphaTest>0,we=!!i.alphaHash,Te=!!i.extensions,Ee=0;i.toneMapped&&(j===null||j.isXRRenderTarget===!0)&&(Ee=e.toneMapping);let De={shaderID:C,shaderType:i.type,shaderName:i.name,vertexShader:D,fragmentShader:O,defines:i.defines,customVertexShaderID:k,customFragmentShaderID:A,isRawShaderMaterial:i.isRawShaderMaterial===!0,glslVersion:i.glslVersion,precision:f,batching:te,batchingColor:te&&h._colorsTexture!==null,instancing:M,instancingColor:M&&h.instanceColor!==null,instancingMorph:M&&h.morphTexture!==null,outputColorSpace:j===null?e.outputColorSpace:j.isXRRenderTarget===!0?j.texture.colorSpace:Nd.workingColorSpace,alphaToCoverage:!!i.alphaToCoverage,map:ne,matcap:re,envMap:N,envMapMode:N&&x.mapping,envMapCubeUVHeight:S,aoMap:ie,lightMap:P,bumpMap:ae,normalMap:oe,displacementMap:F,emissiveMap:I,normalMapObjectSpace:oe&&i.normalMapType===1,normalMapTangentSpace:oe&&i.normalMapType===0,packedNormalMap:oe&&i.normalMapType===0&&Fv(i.normalMap.format),metalnessMap:se,roughnessMap:L,anisotropy:R,anisotropyMap:me,clearcoat:ce,clearcoatMap:he,clearcoatNormalMap:ge,clearcoatRoughnessMap:z,dispersion:le,retroreflection:ue,iridescence:de,iridescenceMap:_e,iridescenceThicknessMap:B,sheen:fe,sheenColorMap:ve,sheenRoughnessMap:ye,specularMap:be,specularColorMap:V,specularIntensityMap:H,transmission:pe,transmissionMap:U,thicknessMap:W,gradientMap:xe,opaque:i.transparent===!1&&i.blending===1&&i.alphaToCoverage===!1,alphaMap:Se,alphaTest:Ce,alphaHash:we,combine:i.combine,mapUv:ne&&m(i.map.channel),aoMapUv:ie&&m(i.aoMap.channel),lightMapUv:P&&m(i.lightMap.channel),bumpMapUv:ae&&m(i.bumpMap.channel),normalMapUv:oe&&m(i.normalMap.channel),displacementMapUv:F&&m(i.displacementMap.channel),emissiveMapUv:I&&m(i.emissiveMap.channel),metalnessMapUv:se&&m(i.metalnessMap.channel),roughnessMapUv:L&&m(i.roughnessMap.channel),anisotropyMapUv:me&&m(i.anisotropyMap.channel),clearcoatMapUv:he&&m(i.clearcoatMap.channel),clearcoatNormalMapUv:ge&&m(i.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:z&&m(i.clearcoatRoughnessMap.channel),iridescenceMapUv:_e&&m(i.iridescenceMap.channel),iridescenceThicknessMapUv:B&&m(i.iridescenceThicknessMap.channel),sheenColorMapUv:ve&&m(i.sheenColorMap.channel),sheenRoughnessMapUv:ye&&m(i.sheenRoughnessMap.channel),specularMapUv:be&&m(i.specularMap.channel),specularColorMapUv:V&&m(i.specularColorMap.channel),specularIntensityMapUv:H&&m(i.specularIntensityMap.channel),transmissionMapUv:U&&m(i.transmissionMap.channel),thicknessMapUv:W&&m(i.thicknessMap.channel),alphaMapUv:Se&&m(i.alphaMap.channel),vertexTangents:!!v.attributes.tangent&&(oe||R),vertexNormals:!!v.attributes.normal,vertexColors:i.vertexColors,vertexAlphas:i.vertexColors===!0&&!!v.attributes.color&&v.attributes.color.itemSize===4,pointsUvs:h.isPoints===!0&&!!v.attributes.uv&&(ne||Se),fog:!!_,useFog:i.fog===!0,fogExp2:!!_&&_.isFogExp2,flatShading:i.wireframe===!1&&(i.flatShading===!0||v.attributes.normal===void 0&&oe===!1&&(i.isMeshLambertMaterial||i.isMeshPhongMaterial||i.isMeshStandardMaterial||i.isMeshPhysicalMaterial)),sizeAttenuation:i.sizeAttenuation===!0,logarithmicDepthBuffer:d,reversedDepthBuffer:ee,skinning:h.isSkinnedMesh===!0,hasPositionAttribute:v.attributes.position!==void 0,morphTargets:v.morphAttributes.position!==void 0,morphNormals:v.morphAttributes.normal!==void 0,morphColors:v.morphAttributes.color!==void 0,morphTargetsCount:T,morphTextureStride:E,numSunLights:o.sun.length,numDirLights:o.directional.length,numPointLights:o.point.length,numSpotLights:o.spot.length,numSpotLightMaps:o.spotLightMap.length,numRectAreaLights:o.rectArea.length,numHemiLights:o.hemi.length,numSunLightShadows:o.sunShadowMap.length,numDirLightShadows:o.directionalShadowMap.length,numPointLightShadows:o.pointShadowMap.length,numSpotLightShadows:o.spotShadowMap.length,numSpotLightShadowsWithMaps:o.numSpotLightShadowsWithMaps,numLightProbes:o.numLightProbes,numLightProbeGrids:g.length,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:i.dithering,shadowMapEnabled:e.shadowMap.enabled&&l.length>0,shadowMapType:e.shadowMap.type,toneMapping:Ee,decodeVideoTexture:ne&&i.map.isVideoTexture===!0&&Nd.getTransfer(i.map.colorSpace)===`srgb`,decodeVideoTextureEmissive:I&&i.emissiveMap.isVideoTexture===!0&&Nd.getTransfer(i.emissiveMap.colorSpace)===`srgb`,premultipliedAlpha:i.premultipliedAlpha,doubleSided:i.side===2,flipSided:i.side===1,useDepthPacking:i.depthPacking>=0,depthPacking:i.depthPacking||0,index0AttributeName:i.index0AttributeName,extensionClipCullDistance:Te&&i.extensions.clipCullDistance===!0&&n.has(`WEBGL_clip_cull_distance`),extensionMultiDraw:(Te&&i.extensions.multiDraw===!0||te)&&n.has(`WEBGL_multi_draw`),rendererExtensionParallelShaderCompile:n.has(`KHR_parallel_shader_compile`),customProgramCacheKey:i.customProgramCacheKey()};return De.vertexUv1s=c.has(1),De.vertexUv2s=c.has(2),De.vertexUv3s=c.has(3),c.clear(),De}function g(t){let n=[];if(t.shaderID?n.push(t.shaderID):(n.push(t.customVertexShaderID),n.push(t.customFragmentShaderID)),t.defines!==void 0)for(let e in t.defines)n.push(e),n.push(t.defines[e]);return t.isRawShaderMaterial===!1&&(_(n,t),v(n,t),n.push(e.outputColorSpace)),n.push(t.customProgramCacheKey),n.join()}function _(e,t){e.push(t.precision),e.push(t.outputColorSpace),e.push(t.envMapMode),e.push(t.envMapCubeUVHeight),e.push(t.mapUv),e.push(t.alphaMapUv),e.push(t.lightMapUv),e.push(t.aoMapUv),e.push(t.bumpMapUv),e.push(t.normalMapUv),e.push(t.displacementMapUv),e.push(t.emissiveMapUv),e.push(t.metalnessMapUv),e.push(t.roughnessMapUv),e.push(t.anisotropyMapUv),e.push(t.clearcoatMapUv),e.push(t.clearcoatNormalMapUv),e.push(t.clearcoatRoughnessMapUv),e.push(t.iridescenceMapUv),e.push(t.iridescenceThicknessMapUv),e.push(t.sheenColorMapUv),e.push(t.sheenRoughnessMapUv),e.push(t.specularMapUv),e.push(t.specularColorMapUv),e.push(t.specularIntensityMapUv),e.push(t.transmissionMapUv),e.push(t.thicknessMapUv),e.push(t.combine),e.push(t.fogExp2),e.push(t.sizeAttenuation),e.push(t.morphTargetsCount),e.push(t.morphAttributeCount),e.push(t.numSunLights),e.push(t.numDirLights),e.push(t.numPointLights),e.push(t.numSpotLights),e.push(t.numSpotLightMaps),e.push(t.numHemiLights),e.push(t.numRectAreaLights),e.push(t.numSunLightShadows),e.push(t.numDirLightShadows),e.push(t.numPointLightShadows),e.push(t.numSpotLightShadows),e.push(t.numSpotLightShadowsWithMaps),e.push(t.numLightProbes),e.push(t.shadowMapType),e.push(t.toneMapping),e.push(t.numClippingPlanes),e.push(t.numClipIntersection),e.push(t.depthPacking)}function v(e,t){o.disableAll(),t.instancing&&o.enable(0),t.instancingColor&&o.enable(1),t.instancingMorph&&o.enable(2),t.matcap&&o.enable(3),t.envMap&&o.enable(4),t.normalMapObjectSpace&&o.enable(5),t.normalMapTangentSpace&&o.enable(6),t.clearcoat&&o.enable(7),t.iridescence&&o.enable(8),t.alphaTest&&o.enable(9),t.vertexColors&&o.enable(10),t.vertexAlphas&&o.enable(11),t.vertexUv1s&&o.enable(12),t.vertexUv2s&&o.enable(13),t.vertexUv3s&&o.enable(14),t.vertexTangents&&o.enable(15),t.anisotropy&&o.enable(16),t.alphaHash&&o.enable(17),t.batching&&o.enable(18),t.dispersion&&o.enable(19),t.retroreflection&&o.enable(24),t.batchingColor&&o.enable(20),t.gradientMap&&o.enable(21),t.packedNormalMap&&o.enable(22),t.vertexNormals&&o.enable(23),e.push(o.mask),o.disableAll(),t.fog&&o.enable(0),t.useFog&&o.enable(1),t.flatShading&&o.enable(2),t.logarithmicDepthBuffer&&o.enable(3),t.reversedDepthBuffer&&o.enable(4),t.skinning&&o.enable(5),t.morphTargets&&o.enable(6),t.morphNormals&&o.enable(7),t.morphColors&&o.enable(8),t.premultipliedAlpha&&o.enable(9),t.shadowMapEnabled&&o.enable(10),t.doubleSided&&o.enable(11),t.flipSided&&o.enable(12),t.useDepthPacking&&o.enable(13),t.dithering&&o.enable(14),t.transmission&&o.enable(15),t.sheen&&o.enable(16),t.opaque&&o.enable(17),t.pointsUvs&&o.enable(18),t.decodeVideoTexture&&o.enable(19),t.decodeVideoTextureEmissive&&o.enable(20),t.alphaToCoverage&&o.enable(21),t.numLightProbeGrids>0&&o.enable(22),t.hasPositionAttribute&&o.enable(23),e.push(o.mask)}function y(e){let t=p[e.type],n;if(t){let e=rg[t];n=qm.clone(e.uniforms)}else n=e.uniforms;return n}function b(t,n){let r=u.get(n);return r===void 0?(r=new jv(e,n,t,i),l.push(r),u.set(n,r)):++r.usedTimes,r}function x(e){if(--e.usedTimes===0){let t=l.indexOf(e);l[t]=l[l.length-1],l.pop(),u.delete(e.cacheKey),e.destroy()}}function S(e){s.remove(e)}function C(){s.dispose()}return{getParameters:h,getProgramCacheKey:g,getUniforms:y,acquireProgram:b,releaseProgram:x,releaseShaderCache:S,programs:l,dispose:C}}function Lv(){let e=new WeakMap;function t(t){return e.has(t)}function n(t){let n=e.get(t);return n===void 0&&(n={},e.set(t,n)),n}function r(t){e.delete(t)}function i(t,n,r){e.get(t)[n]=r}function a(){e=new WeakMap}return{has:t,get:n,remove:r,update:i,dispose:a}}function Rv(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.material.id===t.material.id?e.materialVariant===t.materialVariant?e.z===t.z?e.id-t.id:e.z-t.z:e.materialVariant-t.materialVariant:e.material.id-t.material.id:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function zv(e,t){return e.groupOrder===t.groupOrder?e.renderOrder===t.renderOrder?e.z===t.z?e.id-t.id:t.z-e.z:e.renderOrder-t.renderOrder:e.groupOrder-t.groupOrder}function Bv(){let e=[],t=0,n=[],r=[],i=[];function a(){t=0,n.length=0,r.length=0,i.length=0}function o(e){let t=0;return e.isInstancedMesh&&(t+=2),e.isSkinnedMesh&&(t+=1),t}function s(n,r,i,a,s,c){let l=e[t];return l===void 0?(l={id:n.id,object:n,geometry:r,material:i,materialVariant:o(n),groupOrder:a,renderOrder:n.renderOrder,z:s,group:c},e[t]=l):(l.id=n.id,l.object=n,l.geometry=r,l.material=i,l.materialVariant=o(n),l.groupOrder=a,l.renderOrder=n.renderOrder,l.z=s,l.group=c),t++,l}function c(e,t,a,o,c,l,u){u.reversedDepth===!0&&(c=-c);let d=s(e,t,a,o,c,l);a.transmission>0?r.push(d):a.transparent===!0?i.push(d):n.push(d)}function l(e,t,a,o,c,l){let u=s(e,t,a,o,c,l);a.transmission>0?r.unshift(u):a.transparent===!0?i.unshift(u):n.unshift(u)}function u(e,t){n.length>1&&n.sort(e||Rv),r.length>1&&r.sort(t||zv),i.length>1&&i.sort(t||zv)}function d(){for(let n=t,r=e.length;n<r;n++){let t=e[n];if(t.id===null)break;t.id=null,t.object=null,t.geometry=null,t.material=null,t.group=null}}return{opaque:n,transmissive:r,transparent:i,init:a,push:c,unshift:l,finish:d,sort:u}}function Vv(){let e=new WeakMap;function t(t,n){let r=e.get(t),i;return r===void 0?(i=new Bv,e.set(t,[i])):n>=r.length?(i=new Bv,r.push(i)):i=r[n],i}function n(){e=new WeakMap}return{get:t,dispose:n}}function Hv(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`SunLight`:case`DirectionalLight`:n={direction:new Y,color:new Z};break;case`SpotLight`:n={position:new Y,direction:new Y,color:new Z,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case`PointLight`:n={position:new Y,color:new Z,distance:0,decay:0};break;case`HemisphereLight`:n={direction:new Y,skyColor:new Z,groundColor:new Z};break;case`RectAreaLight`:n={color:new Z,position:new Y,halfWidth:new Y,halfHeight:new Y}}return e[t.id]=n,n}}}function Uv(){let e={};return{get:function(t){if(e[t.id]!==void 0)return e[t.id];let n;switch(t.type){case`SunLight`:case`DirectionalLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new J};break;case`SpotLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new J};break;case`PointLight`:n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new J,shadowCameraNear:1,shadowCameraFar:1e3}}return e[t.id]=n,n}}}var Wv=0;function Gv(e,t){return(t.castShadow?2:0)-(e.castShadow?2:0)+ +!!t.map-!!e.map}function Kv(e){let t=new Hv,n=Uv(),r={version:0,hash:{sunLength:-1,directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numSunShadows:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],sun:[],sunShadow:[],sunShadowMap:[],sunShadowMatrix:[],sunShadowCascade:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let e=0;e<9;e++)r.probe.push(new Y);let i=new Y,a=new Yd,o=new Yd;function s(i){let a=0,o=0,s=0;for(let e=0;e<9;e++)r.probe[e].set(0,0,0);let c=0,l=0,u=0,d=0,f=0,p=0,m=0,h=0,g=0,_=0,v=0,y=0,b=0,x=0;i.sort(Gv);for(let e=0,S=i.length;e<S;e++){let S=i[e],C=S.color,w=S.intensity,T=S.distance,E=null;if(S.shadow&&S.shadow.map&&(E=S.shadow.map.texture.format===1030?S.shadow.map.texture:S.shadow.map.depthTexture||S.shadow.map.texture),S.isAmbientLight)a+=C.r*w,o+=C.g*w,s+=C.b*w;else if(S.isLightProbe){for(let e=0;e<9;e++)r.probe[e].addScaledVector(S.sh.coefficients[e],w);x++}else if(S.isSunLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize.copy(e.mapSize).multiply(e.getFrameExtents()),r.sunShadow[l]=t,r.sunShadowMap[l]=E;let i=e.getViewportCount();for(let t=0;t<i;t++)r.sunShadowMatrix[u+t]=e.getMatrix(t),r.sunShadowCascade[u+t]=e._cascadeData[t];u+=i,l++}r.sun[c]=e,c++}else if(S.isDirectionalLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,r.directionalShadow[d]=t,r.directionalShadowMap[d]=E,r.directionalShadowMatrix[d]=S.shadow.matrix,g++}r.directional[d]=e,d++}else if(S.isSpotLight){let e=t.get(S);e.position.setFromMatrixPosition(S.matrixWorld),e.color.copy(C).multiplyScalar(w),e.distance=T,e.coneCos=Math.cos(S.angle),e.penumbraCos=Math.cos(S.angle*(1-S.penumbra)),e.decay=S.decay,r.spot[p]=e;let i=S.shadow;if(S.map&&(r.spotLightMap[y]=S.map,y++,i.updateMatrices(S),S.castShadow&&b++),r.spotLightMatrix[p]=i.matrix,S.castShadow){let e=n.get(S);e.shadowIntensity=i.intensity,e.shadowBias=i.bias,e.shadowNormalBias=i.normalBias,e.shadowRadius=i.radius,e.shadowMapSize=i.mapSize,r.spotShadow[p]=e,r.spotShadowMap[p]=E,v++}p++}else if(S.isRectAreaLight){let e=t.get(S);e.color.copy(C).multiplyScalar(w),e.halfWidth.set(S.width*.5,0,0),e.halfHeight.set(0,S.height*.5,0),r.rectArea[m]=e,m++}else if(S.isPointLight){let e=t.get(S);if(e.color.copy(S.color).multiplyScalar(S.intensity),e.distance=S.distance,e.decay=S.decay,S.castShadow){let e=S.shadow,t=n.get(S);t.shadowIntensity=e.intensity,t.shadowBias=e.bias,t.shadowNormalBias=e.normalBias,t.shadowRadius=e.radius,t.shadowMapSize=e.mapSize,t.shadowCameraNear=e.camera.near,t.shadowCameraFar=e.camera.far,r.pointShadow[f]=t,r.pointShadowMap[f]=E,r.pointShadowMatrix[f]=S.shadow.matrix,_++}r.point[f]=e,f++}else if(S.isHemisphereLight){let e=t.get(S);e.skyColor.copy(S.color).multiplyScalar(w),e.groundColor.copy(S.groundColor).multiplyScalar(w),r.hemi[h]=e,h++}}m>0&&(e.has(`OES_texture_float_linear`)===!0?(r.rectAreaLTC1=$.LTC_FLOAT_1,r.rectAreaLTC2=$.LTC_FLOAT_2):(r.rectAreaLTC1=$.LTC_HALF_1,r.rectAreaLTC2=$.LTC_HALF_2)),r.ambient[0]=a,r.ambient[1]=o,r.ambient[2]=s;let S=r.hash;(S.sunLength!==c||S.directionalLength!==d||S.pointLength!==f||S.spotLength!==p||S.rectAreaLength!==m||S.hemiLength!==h||S.numSunShadows!==l||S.numDirectionalShadows!==g||S.numPointShadows!==_||S.numSpotShadows!==v||S.numSpotMaps!==y||S.numLightProbes!==x)&&(r.sun.length=c,r.directional.length=d,r.spot.length=p,r.rectArea.length=m,r.point.length=f,r.hemi.length=h,r.sunShadow.length=l,r.sunShadowMap.length=l,r.sunShadowMatrix.length=u,r.sunShadowCascade.length=u,r.directionalShadow.length=g,r.directionalShadowMap.length=g,r.directionalShadowMatrix.length=g,r.pointShadow.length=_,r.pointShadowMap.length=_,r.pointShadowMatrix.length=_,r.spotShadow.length=v,r.spotShadowMap.length=v,r.spotLightMatrix.length=v+y-b,r.spotLightMap.length=y,r.numSpotLightShadowsWithMaps=b,r.numLightProbes=x,S.sunLength=c,S.directionalLength=d,S.pointLength=f,S.spotLength=p,S.rectAreaLength=m,S.hemiLength=h,S.numSunShadows=l,S.numDirectionalShadows=g,S.numPointShadows=_,S.numSpotShadows=v,S.numSpotMaps=y,S.numLightProbes=x,r.version=Wv++)}function c(e,t){let n=0,s=0,c=0,l=0,u=0,d=0,f=t.matrixWorldInverse;for(let t=0,p=e.length;t<p;t++){let p=e[t];if(p.isSunLight){let e=r.sun[n];e.direction.setFromMatrixPosition(p.matrixWorld),e.direction.transformDirection(f),n++}else if(p.isDirectionalLight){let e=r.directional[s];e.direction.setFromMatrixPosition(p.matrixWorld),i.setFromMatrixPosition(p.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(f),s++}else if(p.isSpotLight){let e=r.spot[l];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),e.direction.setFromMatrixPosition(p.matrixWorld),i.setFromMatrixPosition(p.target.matrixWorld),e.direction.sub(i),e.direction.transformDirection(f),l++}else if(p.isRectAreaLight){let e=r.rectArea[u];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),o.identity(),a.copy(p.matrixWorld),a.premultiply(f),o.extractRotation(a),e.halfWidth.set(p.width*.5,0,0),e.halfHeight.set(0,p.height*.5,0),e.halfWidth.applyMatrix4(o),e.halfHeight.applyMatrix4(o),u++}else if(p.isPointLight){let e=r.point[c];e.position.setFromMatrixPosition(p.matrixWorld),e.position.applyMatrix4(f),c++}else if(p.isHemisphereLight){let e=r.hemi[d];e.direction.setFromMatrixPosition(p.matrixWorld),e.direction.transformDirection(f),d++}}}return{setup:s,setupView:c,state:r}}function qv(e){let t=new Kv(e),n=[],r=[],i=[];function a(e){d.camera=e,n.length=0,r.length=0,i.length=0}function o(e){n.push(e)}function s(e){r.push(e)}function c(e){i.push(e)}function l(){t.setup(n)}function u(e){t.setupView(n,e)}let d={lightsArray:n,shadowsArray:r,lightProbeGridArray:i,camera:null,lights:t,transmissionRenderTarget:{},textureUnits:0};return{init:a,state:d,setupLights:l,setupLightsView:u,pushLight:o,pushShadow:s,pushLightProbeGrid:c}}function Jv(e){let t=new WeakMap;function n(n,r=0){let i=t.get(n),a;return i===void 0?(a=new qv(e),t.set(n,[a])):r>=i.length?(a=new qv(e),i.push(a)):a=i[r],a}function r(){t=new WeakMap}return{get:n,dispose:r}}var Yv=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Xv=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,Zv=[new Y(1,0,0),new Y(-1,0,0),new Y(0,1,0),new Y(0,-1,0),new Y(0,0,1),new Y(0,0,-1)],Qv=[new Y(0,-1,0),new Y(0,-1,0),new Y(0,0,1),new Y(0,0,-1),new Y(0,-1,0),new Y(0,-1,0)],$v=new Yd,ey=new Y,ty=new Y;function ny(e,t,n){let r=new pm,i=new J,a=new J,o=new Wd,s=new $m,c=new eh,l={},u=n.maxTextureSize,d={0:1,1:0,2:2},f=new Xm({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new J},radius:{value:4}},vertexShader:Yv,fragmentShader:Xv}),p=f.clone();p.defines.HORIZONTAL_PASS=1;let m=new Dp;m.setAttribute(`position`,new fp(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let h=new Zp(m,f),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=1;let _=this.type;this.render=function(t,n,s){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||t.length===0)return;this.type===2&&(K(`WebGLShadowMap: PCFSoftShadowMap has been removed. Using PCFShadowMap instead.`),this.type=1);let c=e.getRenderTarget(),l=e.getActiveCubeFace(),d=e.getActiveMipmapLevel(),f=e.state;f.setBlending(0),f.buffers.depth.getReversed()===!0?f.buffers.color.setClear(0,0,0,0):f.buffers.color.setClear(1,1,1,1),f.buffers.depth.setTest(!0),f.setScissorTest(!1);let p=_!==this.type;p&&n.traverse(function(e){e.material&&(Array.isArray(e.material)?e.material.forEach(e=>e.needsUpdate=!0):e.material.needsUpdate=!0)});for(let c=0,l=t.length;c<l;c++){let l=t[c],d=l.shadow;if(d===void 0){K(`WebGLShadowMap:`,l,`has no shadow.`);continue}if(d.autoUpdate===!1&&d.needsUpdate===!1)continue;i.copy(d.mapSize);let m=d.getFrameExtents();i.multiply(m),a.copy(d.mapSize),(i.x>u||i.y>u)&&(i.x>u&&(a.x=Math.floor(u/m.x),i.x=a.x*m.x,d.mapSize.x=a.x),i.y>u&&(a.y=Math.floor(u/m.y),i.y=a.y*m.y,d.mapSize.y=a.y));let h=e.state.buffers.depth.getReversed();if(d.camera._reversedDepth=h,d.map===null||p===!0){if(d.map!==null&&(d.map.depthTexture!==null&&(d.map.depthTexture.dispose(),d.map.depthTexture=null),d.map.dispose()),this.type===3){if(l.isPointLight){K(`WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.`);continue}d.map=new Kd(i.x,i.y,{format:ou,type:ql,minFilter:Ll,magFilter:Ll,generateMipmaps:!1}),d.map.texture.name=l.name+`.shadowMap`,d.map.depthTexture=new km(i.x,i.y,Kl),d.map.depthTexture.name=l.name+`.shadowMapDepth`,d.map.depthTexture.format=nu,d.map.depthTexture.compareFunction=null,d.map.depthTexture.minFilter=Pl,d.map.depthTexture.magFilter=Pl}else l.isPointLight?(d.map=new Ng(i.x),d.map.depthTexture=new Am(i.x,Gl)):(d.map=new Kd(i.x,i.y),d.map.depthTexture=new km(i.x,i.y,Gl)),d.map.depthTexture.name=l.name+`.shadowMap`,d.map.depthTexture.format=nu,this.type===1?(d.map.depthTexture.compareFunction=h?518:515,d.map.depthTexture.minFilter=Ll,d.map.depthTexture.magFilter=Ll):(d.map.depthTexture.compareFunction=null,d.map.depthTexture.minFilter=Pl,d.map.depthTexture.magFilter=Pl);d.camera.updateProjectionMatrix()}d.map.isWebGLCubeRenderTarget!==!0&&(d.map.width!==i.x||d.map.height!==i.y)&&d.map.setSize(i.x,i.y);let g=d.map.isWebGLCubeRenderTarget?6:d.getViewportCount();l.isPointLight!==!0&&d.updateMatrices(l,s);for(let t=0;t<g;t++){let i=d.getCamera(t);if(l.isPointLight){let e=d.camera,n=d.matrix,r=l.distance||e.far;r!==e.far&&(e.far=r,e.updateProjectionMatrix()),ey.setFromMatrixPosition(l.matrixWorld),e.position.copy(ey),ty.copy(e.position),ty.add(Zv[t]),e.up.copy(Qv[t]),e.lookAt(ty),e.updateMatrixWorld(),n.makeTranslation(-ey.x,-ey.y,-ey.z),$v.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),d._frustum.setFromProjectionMatrix($v,e.coordinateSystem,e.reversedDepth)}if(d.map.isWebGLCubeRenderTarget)e.setRenderTarget(d.map,t),e.clear();else{t===0&&(e.setRenderTarget(d.map),e.clear());let n=d.getViewport(t);o.set(a.x*n.x,a.y*n.y,a.x*n.z,a.y*n.w),f.viewport(o)}r=d.getFrustum(t),b(n,s,i,l,this.type)}d.isPointLightShadow!==!0&&this.type===3&&v(d,s),d.needsUpdate=!1}_=this.type,g.needsUpdate=!1,e.setRenderTarget(c,l,d)};function v(n,r){let a=t.update(h);f.defines.VSM_SAMPLES!==n.blurSamples&&(f.defines.VSM_SAMPLES=n.blurSamples,p.defines.VSM_SAMPLES=n.blurSamples,f.needsUpdate=!0,p.needsUpdate=!0),n.mapPass===null?n.mapPass=new Kd(i.x,i.y,{format:ou,type:ql}):(n.mapPass.width!==n.map.width||n.mapPass.height!==n.map.height)&&n.mapPass.setSize(n.map.width,n.map.height),f.uniforms.shadow_pass.value=n.map.depthTexture,f.uniforms.resolution.value.set(n.map.width,n.map.height),f.uniforms.radius.value=n.radius,e.setRenderTarget(n.mapPass),e.clear(),e.renderBufferDirect(r,null,a,f,h,null),p.uniforms.shadow_pass.value=n.mapPass.texture,p.uniforms.resolution.value.set(n.map.width,n.map.height),p.uniforms.radius.value=n.radius,e.setRenderTarget(n.map),e.clear(),e.renderBufferDirect(r,null,a,p,h,null)}function y(t,n,r,i){let a=null,o=r.isPointLight===!0?t.customDistanceMaterial:t.customDepthMaterial;if(o!==void 0)a=o;else if(a=r.isPointLight===!0?c:s,e.localClippingEnabled&&n.clipShadows===!0&&Array.isArray(n.clippingPlanes)&&n.clippingPlanes.length!==0||n.displacementMap&&n.displacementScale!==0||n.alphaMap&&n.alphaTest>0||n.map&&n.alphaTest>0||n.alphaToCoverage===!0){let e=a.uuid,t=n.uuid,r=l[e];r===void 0&&(r={},l[e]=r);let i=r[t];i===void 0&&(i=a.clone(),r[t]=i,n.addEventListener(`dispose`,x)),a=i}if(a.visible=n.visible,a.wireframe=n.wireframe,i===3?a.side=n.shadowSide===null?n.side:n.shadowSide:a.side=n.shadowSide===null?d[n.side]:n.shadowSide,a.alphaMap=n.alphaMap,a.alphaTest=n.alphaToCoverage===!0?.5:n.alphaTest,a.map=n.map,a.clipShadows=n.clipShadows,a.clippingPlanes=n.clippingPlanes,a.clipIntersection=n.clipIntersection,a.displacementMap=n.displacementMap,a.displacementScale=n.displacementScale,a.displacementBias=n.displacementBias,a.wireframeLinewidth=n.wireframeLinewidth,a.linewidth=n.linewidth,r.isPointLight===!0&&a.isMeshDistanceMaterial===!0){let t=e.properties.get(a);t.light=r}return a}function b(n,i,a,o,s){if(n.visible===!1)return;if(n.layers.test(i.layers)&&(n.isMesh||n.isLine||n.isPoints)&&(n.castShadow||n.receiveShadow&&s===3)&&(!n.frustumCulled||n.intersectsFrustum(r))){n.modelViewMatrix.multiplyMatrices(a.matrixWorldInverse,n.matrixWorld);let r=t.update(n),c=n.material;if(Array.isArray(c)){let t=r.groups;for(let l=0,u=t.length;l<u;l++){let u=t[l],d=c[u.materialIndex];if(d&&d.visible){let t=y(n,d,o,s);n.onBeforeShadow(e,n,i,a,r,t,u),e.renderBufferDirect(a,null,r,t,n,u),n.onAfterShadow(e,n,i,a,r,t,u)}}}else if(c.visible){let t=y(n,c,o,s);n.onBeforeShadow(e,n,i,a,r,t,null),e.renderBufferDirect(a,null,r,t,n,null),n.onAfterShadow(e,n,i,a,r,t,null)}}let c=n.children;for(let e=0,t=c.length;e<t;e++)b(c[e],i,a,o,s)}function x(e){e.target.removeEventListener(`dispose`,x);for(let t in l){let n=l[t],r=e.target.uuid;r in n&&(n[r].dispose(),delete n[r])}}}function ry(e,t){function n(){let t=!1,n=new Wd,r=null,i=new Wd(0,0,0,0);return{setMask:function(n){r!==n&&!t&&(e.colorMask(n,n,n,n),r=n)},setLocked:function(e){t=e},setClear:function(t,r,a,o,s){s===!0&&(t*=o,r*=o,a*=o),n.set(t,r,a,o),i.equals(n)===!1&&(e.clearColor(t,r,a,o),i.copy(n))},reset:function(){t=!1,r=null,i.set(-1,0,0,0)}}}function r(){let n=!1,r=!1,i=null,a=null,o=null;return{setReversed:function(e){if(r!==e){let n=t.get(`EXT_clip_control`);e?n.clipControlEXT(n.LOWER_LEFT_EXT,n.ZERO_TO_ONE_EXT):n.clipControlEXT(n.LOWER_LEFT_EXT,n.NEGATIVE_ONE_TO_ONE_EXT),r=e;let i=o;o=null,this.setClear(i)}},getReversed:function(){return r},setTest:function(t){t?se(e.DEPTH_TEST):L(e.DEPTH_TEST)},setMask:function(t){i!==t&&!n&&(e.depthMask(t),i=t)},setFunc:function(t){if(r&&(t=hd[t]),a!==t){switch(t){case 0:e.depthFunc(e.NEVER);break;case 1:e.depthFunc(e.ALWAYS);break;case 2:e.depthFunc(e.LESS);break;case 3:e.depthFunc(e.LEQUAL);break;case 4:e.depthFunc(e.EQUAL);break;case 5:e.depthFunc(e.GEQUAL);break;case 6:e.depthFunc(e.GREATER);break;case 7:e.depthFunc(e.NOTEQUAL);break;default:e.depthFunc(e.LEQUAL)}a=t}},setLocked:function(e){n=e},setClear:function(t){o!==t&&(o=t,r&&(t=1-t),e.clearDepth(t))},reset:function(){n=!1,i=null,a=null,o=null,r=!1}}}function i(){let t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null;return{setTest:function(n){t||(n?se(e.STENCIL_TEST):L(e.STENCIL_TEST))},setMask:function(r){n!==r&&!t&&(e.stencilMask(r),n=r)},setFunc:function(t,n,o){(r!==t||i!==n||a!==o)&&(e.stencilFunc(t,n,o),r=t,i=n,a=o)},setOp:function(t,n,r){(o!==t||s!==n||c!==r)&&(e.stencilOp(t,n,r),o=t,s=n,c=r)},setLocked:function(e){t=e},setClear:function(t){l!==t&&(e.clearStencil(t),l=t)},reset:function(){t=!1,n=null,r=null,i=null,a=null,o=null,s=null,c=null,l=null}}}let a=new n,o=new r,s=new i,c=new WeakMap,l=new WeakMap,u={},d={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new Z(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,j=null,ee=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),M=!1,te=0,ne=e.getParameter(e.VERSION);ne.indexOf(`WebGL`)===-1?ne.indexOf(`OpenGL ES`)!==-1&&(te=parseFloat(/^OpenGL ES (\d)/.exec(ne)[1]),M=te>=2):(te=parseFloat(/^WebGL (\d)/.exec(ne)[1]),M=te>=1);let re=null,N={},ie=e.getParameter(e.SCISSOR_BOX),P=e.getParameter(e.VIEWPORT),ae=new Wd().fromArray(ie),oe=new Wd().fromArray(P);function F(t,n,r,i){let a=new Uint8Array(4),o=e.createTexture();e.bindTexture(t,o),e.texParameteri(t,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(t,e.TEXTURE_MAG_FILTER,e.NEAREST);for(let o=0;o<r;o++)t===e.TEXTURE_3D||t===e.TEXTURE_2D_ARRAY?e.texImage3D(n,0,e.RGBA,1,1,i,0,e.RGBA,e.UNSIGNED_BYTE,a):e.texImage2D(n+o,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,a);return o}let I={};I[e.TEXTURE_2D]=F(e.TEXTURE_2D,e.TEXTURE_2D,1),I[e.TEXTURE_CUBE_MAP]=F(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),I[e.TEXTURE_2D_ARRAY]=F(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),I[e.TEXTURE_3D]=F(e.TEXTURE_3D,e.TEXTURE_3D,1,1),a.setClear(0,0,0,1),o.setClear(1),s.setClear(0),se(e.DEPTH_TEST),o.setFunc(3),me(!1),he(1),se(e.CULL_FACE),fe(0);function se(t){u[t]!==!0&&(e.enable(t),u[t]=!0)}function L(t){u[t]!==!1&&(e.disable(t),u[t]=!1)}function R(t,n){return f[t]!==n&&(e.bindFramebuffer(t,n),f[t]=n,t===e.DRAW_FRAMEBUFFER&&(f[e.FRAMEBUFFER]=n),t===e.FRAMEBUFFER&&(f[e.DRAW_FRAMEBUFFER]=n),!0)}function ce(t,n){let r=m,i=!1;if(t){r=p.get(n),r===void 0&&(r=[],p.set(n,r));let a=t.textures;if(r.length!==a.length||r[0]!==e.COLOR_ATTACHMENT0){for(let t=0,n=a.length;t<n;t++)r[t]=e.COLOR_ATTACHMENT0+t;r.length=a.length,i=!0}}else r[0]!==e.BACK&&(r[0]=e.BACK,i=!0);i&&e.drawBuffers(r)}function le(t){return h!==t&&(e.useProgram(t),h=t,!0)}let ue={100:e.FUNC_ADD,101:e.FUNC_SUBTRACT,102:e.FUNC_REVERSE_SUBTRACT};ue[103]=e.MIN,ue[104]=e.MAX;let de={200:e.ZERO,201:e.ONE,202:e.SRC_COLOR,204:e.SRC_ALPHA,210:e.SRC_ALPHA_SATURATE,208:e.DST_COLOR,206:e.DST_ALPHA,203:e.ONE_MINUS_SRC_COLOR,205:e.ONE_MINUS_SRC_ALPHA,209:e.ONE_MINUS_DST_COLOR,207:e.ONE_MINUS_DST_ALPHA,211:e.CONSTANT_COLOR,212:e.ONE_MINUS_CONSTANT_COLOR,213:e.CONSTANT_ALPHA,214:e.ONE_MINUS_CONSTANT_ALPHA};function fe(t,n,r,i,a,o,s,c,l,u){if(t===0)g===!0&&(L(e.BLEND),g=!1);else if(g===!1&&(se(e.BLEND),g=!0),t!==5){if(t!==_||u!==E){if((v!==100||x!==100)&&(e.blendEquation(e.FUNC_ADD),v=100,x=100),u)switch(t){case 1:e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFunc(e.ONE,e.ONE);break;case 3:e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);break;case 4:e.blendFuncSeparate(e.DST_COLOR,e.ONE_MINUS_SRC_ALPHA,e.ZERO,e.ONE);break;default:q(`WebGLState: Invalid blending: `,t)}else switch(t){case 1:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);break;case 2:e.blendFuncSeparate(e.SRC_ALPHA,e.ONE,e.ONE,e.ONE);break;case 3:q(`WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true`);break;case 4:q(`WebGLState: MultiplyBlending requires material.premultipliedAlpha = true`);break;default:q(`WebGLState: Invalid blending: `,t)}y=null,b=null,S=null,C=null,w.set(0,0,0),T=0,_=t,E=u}}else a||=n,o||=r,s||=i,(n!==v||a!==x)&&(e.blendEquationSeparate(ue[n],ue[a]),v=n,x=a),(r!==y||i!==b||o!==S||s!==C)&&(e.blendFuncSeparate(de[r],de[i],de[o],de[s]),y=r,b=i,S=o,C=s),(c.equals(w)===!1||l!==T)&&(e.blendColor(c.r,c.g,c.b,l),w.copy(c),T=l),_=t,E=!1}function pe(t,n){t.side===2?L(e.CULL_FACE):se(e.CULL_FACE);let r=t.side===1;n&&(r=!r),me(r),t.blending===1&&t.transparent===!1?fe(0):fe(t.blending,t.blendEquation,t.blendSrc,t.blendDst,t.blendEquationAlpha,t.blendSrcAlpha,t.blendDstAlpha,t.blendColor,t.blendAlpha,t.premultipliedAlpha),o.setFunc(t.depthFunc),o.setTest(t.depthTest),o.setMask(t.depthWrite),a.setMask(t.colorWrite);let i=t.stencilWrite;s.setTest(i),i&&(s.setMask(t.stencilWriteMask),s.setFunc(t.stencilFunc,t.stencilRef,t.stencilFuncMask),s.setOp(t.stencilFail,t.stencilZFail,t.stencilZPass)),z(t.polygonOffset,t.polygonOffsetFactor,t.polygonOffsetUnits),t.alphaToCoverage===!0?se(e.SAMPLE_ALPHA_TO_COVERAGE):L(e.SAMPLE_ALPHA_TO_COVERAGE)}function me(t){D!==t&&(t?e.frontFace(e.CW):e.frontFace(e.CCW),D=t)}function he(t){t===0?L(e.CULL_FACE):(se(e.CULL_FACE),t!==O&&(t===1?e.cullFace(e.BACK):t===2?e.cullFace(e.FRONT):e.cullFace(e.FRONT_AND_BACK))),O=t}function ge(t){t!==k&&(M&&e.lineWidth(t),k=t)}function z(t,n,r){t?(se(e.POLYGON_OFFSET_FILL),(A!==n||j!==r)&&(A=n,j=r,o.getReversed()&&(n=-n),e.polygonOffset(n,r))):L(e.POLYGON_OFFSET_FILL)}function _e(t){t?se(e.SCISSOR_TEST):L(e.SCISSOR_TEST)}function B(t){t===void 0&&(t=e.TEXTURE0+ee-1),re!==t&&(e.activeTexture(t),re=t)}function ve(t,n,r){r===void 0&&(r=re===null?e.TEXTURE0+ee-1:re);let i=N[r];i===void 0&&(i={type:void 0,texture:void 0},N[r]=i),(i.type!==t||i.texture!==n)&&(re!==r&&(e.activeTexture(r),re=r),e.bindTexture(t,n||I[t]),i.type=t,i.texture=n)}function ye(){let t=N[re];t!==void 0&&t.type!==void 0&&(e.bindTexture(t.type,null),t.type=void 0,t.texture=void 0)}function be(){try{e.compressedTexImage2D(...arguments)}catch(e){q(`WebGLState:`,e)}}function V(){try{e.compressedTexImage3D(...arguments)}catch(e){q(`WebGLState:`,e)}}function H(){try{e.texSubImage2D(...arguments)}catch(e){q(`WebGLState:`,e)}}function U(){try{e.texSubImage3D(...arguments)}catch(e){q(`WebGLState:`,e)}}function W(){try{e.compressedTexSubImage2D(...arguments)}catch(e){q(`WebGLState:`,e)}}function xe(){try{e.compressedTexSubImage3D(...arguments)}catch(e){q(`WebGLState:`,e)}}function Se(){try{e.texStorage2D(...arguments)}catch(e){q(`WebGLState:`,e)}}function Ce(){try{e.texStorage3D(...arguments)}catch(e){q(`WebGLState:`,e)}}function we(){try{e.texImage2D(...arguments)}catch(e){q(`WebGLState:`,e)}}function Te(){try{e.texImage3D(...arguments)}catch(e){q(`WebGLState:`,e)}}function Ee(t){return d[t]===void 0?e.getParameter(t):d[t]}function De(t,n){d[t]!==n&&(e.pixelStorei(t,n),d[t]=n)}function Oe(t){ae.equals(t)===!1&&(e.scissor(t.x,t.y,t.z,t.w),ae.copy(t))}function ke(t){oe.equals(t)===!1&&(e.viewport(t.x,t.y,t.z,t.w),oe.copy(t))}function Ae(t,n){let r=l.get(n);r===void 0&&(r=new WeakMap,l.set(n,r));let i=r.get(t);i===void 0&&(i=e.getUniformBlockIndex(n,t.name),r.set(t,i))}function je(t,n){let r=l.get(n).get(t);c.get(n)!==r&&(e.uniformBlockBinding(n,r,t.__bindingPointIndex),c.set(n,r))}function Me(){e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),o.setReversed(!1),e.clearDepth(1),e.stencilMask(4294967295),e.stencilFunc(e.ALWAYS,0,4294967295),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),e.pixelStorei(e.PACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,e.BROWSER_DEFAULT_WEBGL),e.pixelStorei(e.PACK_ROW_LENGTH,0),e.pixelStorei(e.PACK_SKIP_PIXELS,0),e.pixelStorei(e.PACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_ROW_LENGTH,0),e.pixelStorei(e.UNPACK_IMAGE_HEIGHT,0),e.pixelStorei(e.UNPACK_SKIP_PIXELS,0),e.pixelStorei(e.UNPACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_SKIP_IMAGES,0),u={},d={},re=null,N={},f={},p=new WeakMap,m=[],h=null,g=!1,_=null,v=null,y=null,b=null,x=null,S=null,C=null,w=new Z(0,0,0),T=0,E=!1,D=null,O=null,k=null,A=null,j=null,ae.set(0,0,e.canvas.width,e.canvas.height),oe.set(0,0,e.canvas.width,e.canvas.height),a.reset(),o.reset(),s.reset()}return{buffers:{color:a,depth:o,stencil:s},enable:se,disable:L,bindFramebuffer:R,drawBuffers:ce,useProgram:le,setBlending:fe,setMaterial:pe,setFlipSided:me,setCullFace:he,setLineWidth:ge,setPolygonOffset:z,setScissorTest:_e,activeTexture:B,bindTexture:ve,unbindTexture:ye,compressedTexImage2D:be,compressedTexImage3D:V,texImage2D:we,texImage3D:Te,pixelStorei:De,getParameter:Ee,updateUBOMapping:Ae,uniformBlockBinding:je,texStorage2D:Se,texStorage3D:Ce,texSubImage2D:H,texSubImage3D:U,compressedTexSubImage2D:W,compressedTexSubImage3D:xe,scissor:Oe,viewport:ke,reset:Me}}function iy(e,t,n,r,i,a,o){let s=t.has(`WEBGL_multisampled_render_to_texture`)?t.get(`WEBGL_multisampled_render_to_texture`):null,c=typeof navigator>`u`?!1:/OculusBrowser/g.test(navigator.userAgent),l=new J,u=new WeakMap,d=new Set,f,p=new WeakMap,m=!1;try{m=typeof OffscreenCanvas<`u`&&new OffscreenCanvas(1,1).getContext(`2d`)!==null}catch{}function h(e,t){return m?new OffscreenCanvas(e,t):cd(`canvas`)}function g(e,t,n){let r=1,i=be(e);if((i.width>n||i.height>n)&&(r=n/Math.max(i.width,i.height)),r<1){if(typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<`u`&&e instanceof HTMLCanvasElement||typeof ImageBitmap<`u`&&e instanceof ImageBitmap||typeof VideoFrame<`u`&&e instanceof VideoFrame){let n=Math.floor(r*i.width),a=Math.floor(r*i.height);f===void 0&&(f=h(n,a));let o=t?h(n,a):f;return o.width=n,o.height=a,o.getContext(`2d`).drawImage(e,0,0,n,a),K(`WebGLRenderer: Texture has been resized from (`+i.width+`x`+i.height+`) to (`+n+`x`+a+`).`),o}return`data`in e&&K(`WebGLRenderer: Image in DataTexture is too big (`+i.width+`x`+i.height+`).`),e}return e}function _(e){return e.generateMipmaps}function v(t){e.generateMipmap(t)}function y(t){return t.isWebGLCubeRenderTarget?e.TEXTURE_CUBE_MAP:t.isWebGL3DRenderTarget?e.TEXTURE_3D:t.isWebGLArrayRenderTarget||t.isCompressedArrayTexture?e.TEXTURE_2D_ARRAY:e.TEXTURE_2D}function b(n,r,i,a,o,s=!1){if(n!==null){if(e[n]!==void 0)return e[n];K(`WebGLRenderer: Attempt to use non-existing WebGL internal format '`+n+`'`)}let c;a&&(c=t.get(`EXT_texture_norm16`),c||K(`WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension`));let l=r;if(r===e.RED&&(i===e.FLOAT&&(l=e.R32F),i===e.HALF_FLOAT&&(l=e.R16F),i===e.UNSIGNED_BYTE&&(l=e.R8),i===e.UNSIGNED_SHORT&&c&&(l=c.R16_EXT),i===e.SHORT&&c&&(l=c.R16_SNORM_EXT)),r===e.RED_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.R8UI),i===e.UNSIGNED_SHORT&&(l=e.R16UI),i===e.UNSIGNED_INT&&(l=e.R32UI),i===e.BYTE&&(l=e.R8I),i===e.SHORT&&(l=e.R16I),i===e.INT&&(l=e.R32I)),r===e.RG&&(i===e.FLOAT&&(l=e.RG32F),i===e.HALF_FLOAT&&(l=e.RG16F),i===e.UNSIGNED_BYTE&&(l=e.RG8),i===e.UNSIGNED_SHORT&&c&&(l=c.RG16_EXT),i===e.SHORT&&c&&(l=c.RG16_SNORM_EXT)),r===e.RG_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RG8UI),i===e.UNSIGNED_SHORT&&(l=e.RG16UI),i===e.UNSIGNED_INT&&(l=e.RG32UI),i===e.BYTE&&(l=e.RG8I),i===e.SHORT&&(l=e.RG16I),i===e.INT&&(l=e.RG32I)),r===e.RGB_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RGB8UI),i===e.UNSIGNED_SHORT&&(l=e.RGB16UI),i===e.UNSIGNED_INT&&(l=e.RGB32UI),i===e.BYTE&&(l=e.RGB8I),i===e.SHORT&&(l=e.RGB16I),i===e.INT&&(l=e.RGB32I)),r===e.RGBA_INTEGER&&(i===e.UNSIGNED_BYTE&&(l=e.RGBA8UI),i===e.UNSIGNED_SHORT&&(l=e.RGBA16UI),i===e.UNSIGNED_INT&&(l=e.RGBA32UI),i===e.BYTE&&(l=e.RGBA8I),i===e.SHORT&&(l=e.RGBA16I),i===e.INT&&(l=e.RGBA32I)),r===e.RGB&&(i===e.UNSIGNED_SHORT&&c&&(l=c.RGB16_EXT),i===e.SHORT&&c&&(l=c.RGB16_SNORM_EXT),i===e.UNSIGNED_INT_5_9_9_9_REV&&(l=e.RGB9_E5),i===e.UNSIGNED_INT_10F_11F_11F_REV&&(l=e.R11F_G11F_B10F)),r===e.RGBA){let t=s?td:Nd.getTransfer(o);i===e.FLOAT&&(l=e.RGBA32F),i===e.HALF_FLOAT&&(l=e.RGBA16F),i===e.UNSIGNED_BYTE&&(l=t===`srgb`?e.SRGB8_ALPHA8:e.RGBA8),i===e.UNSIGNED_SHORT&&c&&(l=c.RGBA16_EXT),i===e.SHORT&&c&&(l=c.RGBA16_SNORM_EXT),i===e.UNSIGNED_SHORT_4_4_4_4&&(l=e.RGBA4),i===e.UNSIGNED_SHORT_5_5_5_1&&(l=e.RGB5_A1)}return(l===e.R16F||l===e.R32F||l===e.RG16F||l===e.RG32F||l===e.RGBA16F||l===e.RGBA32F)&&t.get(`EXT_color_buffer_float`),l}function x(t,n){let r;return t?n===null||n===1014||n===1020?r=e.DEPTH24_STENCIL8:n===1015?r=e.DEPTH32F_STENCIL8:n===1012&&(r=e.DEPTH24_STENCIL8,K(`DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.`)):n===null||n===1014||n===1020?r=e.DEPTH_COMPONENT24:n===1015?r=e.DEPTH_COMPONENT32F:n===1012&&(r=e.DEPTH_COMPONENT16),r}function S(e,t){return _(e)===!0||e.isFramebufferTexture&&e.minFilter!==1003&&e.minFilter!==1006?Math.log2(Math.max(t.width,t.height))+1:e.mipmaps!==void 0&&e.mipmaps.length>0?e.mipmaps.length:e.isCompressedTexture&&Array.isArray(e.image)?t.mipmaps.length:1}function C(e){let t=e.target;t.removeEventListener(`dispose`,C),T(t),t.isVideoTexture&&u.delete(t),t.isHTMLTexture&&d.delete(t)}function w(e){let t=e.target;t.removeEventListener(`dispose`,w),D(t)}function T(e){let t=r.get(e);if(t.__webglInit===void 0)return;let n=e.source,i=p.get(n);if(i){let r=i[t.__cacheKey];r.usedTimes--,r.usedTimes===0&&E(e),Object.keys(i).length===0&&p.delete(n)}r.remove(e)}function E(t){let n=r.get(t);e.deleteTexture(n.__webglTexture);let i=t.source,a=p.get(i);delete a[n.__cacheKey],o.memory.textures--}function D(t){let n=r.get(t);if(t.depthTexture&&(t.depthTexture.dispose(),r.remove(t.depthTexture)),t.isWebGLCubeRenderTarget)for(let t=0;t<6;t++){if(Array.isArray(n.__webglFramebuffer[t]))for(let r=0;r<n.__webglFramebuffer[t].length;r++)e.deleteFramebuffer(n.__webglFramebuffer[t][r]);else e.deleteFramebuffer(n.__webglFramebuffer[t]);n.__webglDepthbuffer&&e.deleteRenderbuffer(n.__webglDepthbuffer[t])}else{if(Array.isArray(n.__webglFramebuffer))for(let t=0;t<n.__webglFramebuffer.length;t++)e.deleteFramebuffer(n.__webglFramebuffer[t]);else e.deleteFramebuffer(n.__webglFramebuffer);if(n.__webglDepthbuffer&&e.deleteRenderbuffer(n.__webglDepthbuffer),n.__webglMultisampledFramebuffer&&e.deleteFramebuffer(n.__webglMultisampledFramebuffer),n.__webglColorRenderbuffer)for(let t=0;t<n.__webglColorRenderbuffer.length;t++)n.__webglColorRenderbuffer[t]&&e.deleteRenderbuffer(n.__webglColorRenderbuffer[t]);n.__webglDepthRenderbuffer&&e.deleteRenderbuffer(n.__webglDepthRenderbuffer)}let i=t.textures;for(let t=0,n=i.length;t<n;t++){let n=r.get(i[t]);n.__webglTexture&&(e.deleteTexture(n.__webglTexture),o.memory.textures--),r.remove(i[t])}r.remove(t)}let O=0;function k(){O=0}function A(){return O}function j(e){O=e}function ee(){let e=O;return e>=i.maxTextures&&K(`WebGLTextures: Trying to use `+(e+1)+` texture units while this GPU supports only `+i.maxTextures),O+=1,e}function M(e){let t=[];return t.push(e.wrapS),t.push(e.wrapT),t.push(e.wrapR||0),t.push(e.magFilter),t.push(e.minFilter),t.push(e.anisotropy),t.push(e.internalFormat),t.push(e.format),t.push(e.type),t.push(e.generateMipmaps),t.push(e.premultiplyAlpha),t.push(e.flipY),t.push(e.unpackAlignment),t.push(e.colorSpace),t.join()}function te(t,i){let a=r.get(t);if(t.isVideoTexture&&ve(t),t.isRenderTargetTexture===!1&&t.isExternalTexture!==!0&&t.version>0&&a.__version!==t.version){let e=t.image;if(e===null)K(`WebGLRenderer: Texture marked for update but no image data found.`);else if(e.complete===!1)K(`WebGLRenderer: Texture marked for update but image is incomplete`);else{L(a,t,i);return}}else t.isExternalTexture&&(a.__webglTexture=t.sourceTexture?t.sourceTexture:null);n.bindTexture(e.TEXTURE_2D,a.__webglTexture,e.TEXTURE0+i)}function ne(t,i){let a=r.get(t);t.isRenderTargetTexture===!1&&t.version>0&&a.__version!==t.version?L(a,t,i):(t.isExternalTexture&&(a.__webglTexture=t.sourceTexture?t.sourceTexture:null),n.bindTexture(e.TEXTURE_2D_ARRAY,a.__webglTexture,e.TEXTURE0+i))}function re(t,i){let a=r.get(t);t.isRenderTargetTexture===!1&&t.version>0&&a.__version!==t.version?L(a,t,i):n.bindTexture(e.TEXTURE_3D,a.__webglTexture,e.TEXTURE0+i)}function N(t,i){let a=r.get(t);t.isCubeDepthTexture!==!0&&t.version>0&&a.__version!==t.version?R(a,t,i):n.bindTexture(e.TEXTURE_CUBE_MAP,a.__webglTexture,e.TEXTURE0+i)}let ie={[jl]:e.REPEAT,[Ml]:e.CLAMP_TO_EDGE,[Nl]:e.MIRRORED_REPEAT},P={[Pl]:e.NEAREST,[Fl]:e.NEAREST_MIPMAP_NEAREST,[Il]:e.NEAREST_MIPMAP_LINEAR,[Ll]:e.LINEAR,[Rl]:e.LINEAR_MIPMAP_NEAREST,[zl]:e.LINEAR_MIPMAP_LINEAR},ae={512:e.NEVER,519:e.ALWAYS,513:e.LESS,515:e.LEQUAL,514:e.EQUAL,518:e.GEQUAL,516:e.GREATER,517:e.NOTEQUAL};function oe(n,a){if(a.type===1015&&t.has(`OES_texture_float_linear`)===!1&&(a.magFilter===1006||a.magFilter===1007||a.magFilter===1005||a.magFilter===1008||a.minFilter===1006||a.minFilter===1007||a.minFilter===1005||a.minFilter===1008)&&K(`WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device.`),e.texParameteri(n,e.TEXTURE_WRAP_S,ie[a.wrapS]),e.texParameteri(n,e.TEXTURE_WRAP_T,ie[a.wrapT]),(n===e.TEXTURE_3D||n===e.TEXTURE_2D_ARRAY)&&e.texParameteri(n,e.TEXTURE_WRAP_R,ie[a.wrapR]),e.texParameteri(n,e.TEXTURE_MAG_FILTER,P[a.magFilter]),e.texParameteri(n,e.TEXTURE_MIN_FILTER,P[a.minFilter]),a.compareFunction&&(e.texParameteri(n,e.TEXTURE_COMPARE_MODE,e.COMPARE_REF_TO_TEXTURE),e.texParameteri(n,e.TEXTURE_COMPARE_FUNC,ae[a.compareFunction])),t.has(`EXT_texture_filter_anisotropic`)===!0){if(a.magFilter===1003||a.minFilter!==1005&&a.minFilter!==1008||a.type===1015&&t.has(`OES_texture_float_linear`)===!1)return;if(a.anisotropy>1||r.get(a).__currentAnisotropy){let o=t.get(`EXT_texture_filter_anisotropic`);e.texParameterf(n,o.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(a.anisotropy,i.getMaxAnisotropy())),r.get(a).__currentAnisotropy=a.anisotropy}}}function F(t,n){let r=!1;t.__webglInit===void 0&&(t.__webglInit=!0,n.addEventListener(`dispose`,C));let i=n.source,a=p.get(i);a===void 0&&(a={},p.set(i,a));let s=M(n);if(s!==t.__cacheKey){a[s]===void 0&&(a[s]={texture:e.createTexture(),usedTimes:0},o.memory.textures++,r=!0),a[s].usedTimes++;let i=a[t.__cacheKey];i!==void 0&&(a[t.__cacheKey].usedTimes--,i.usedTimes===0&&E(n)),t.__cacheKey=s,t.__webglTexture=a[s].texture}return r}function I(e,t,n){return Math.floor(Math.floor(e/n)/t)}function se(t,r,i,a){let o=t.updateRanges;if(o.length===0)n.texSubImage2D(e.TEXTURE_2D,0,0,0,r.width,r.height,i,a,r.data);else{o.sort((e,t)=>e.start-t.start);let s=0;for(let e=1;e<o.length;e++){let t=o[s],n=o[e],i=t.start+t.count,a=I(n.start,r.width,4),c=I(t.start,r.width,4);n.start<=i+1&&a===c&&I(n.start+n.count-1,r.width,4)===a?t.count=Math.max(t.count,n.start+n.count-t.start):(++s,o[s]=n)}o.length=s+1;let c=n.getParameter(e.UNPACK_ROW_LENGTH),l=n.getParameter(e.UNPACK_SKIP_PIXELS),u=n.getParameter(e.UNPACK_SKIP_ROWS);n.pixelStorei(e.UNPACK_ROW_LENGTH,r.width);for(let t=0,s=o.length;t<s;t++){let s=o[t],c=Math.floor(s.start/4),l=Math.ceil(s.count/4),u=c%r.width,d=Math.floor(c/r.width),f=l;n.pixelStorei(e.UNPACK_SKIP_PIXELS,u),n.pixelStorei(e.UNPACK_SKIP_ROWS,d),n.texSubImage2D(e.TEXTURE_2D,0,u,d,f,1,i,a,r.data)}t.clearUpdateRanges(),n.pixelStorei(e.UNPACK_ROW_LENGTH,c),n.pixelStorei(e.UNPACK_SKIP_PIXELS,l),n.pixelStorei(e.UNPACK_SKIP_ROWS,u)}}function L(t,o,s){let c=e.TEXTURE_2D;(o.isDataArrayTexture||o.isCompressedArrayTexture)&&(c=e.TEXTURE_2D_ARRAY),o.isData3DTexture&&(c=e.TEXTURE_3D);let l=F(t,o),u=o.source;n.bindTexture(c,t.__webglTexture,e.TEXTURE0+s);let f=r.get(u);if(u.version!==f.__version||l===!0){if(n.activeTexture(e.TEXTURE0+s),!(typeof ImageBitmap<`u`&&o.image instanceof ImageBitmap)){let t=Nd.getPrimaries(Nd.workingColorSpace),r=o.colorSpace===``?null:Nd.getPrimaries(o.colorSpace),i=o.colorSpace===``||t===r?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,o.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,o.premultiplyAlpha),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,i)}n.pixelStorei(e.UNPACK_ALIGNMENT,o.unpackAlignment);let t=g(o.image,!1,i.maxTextureSize);t=ye(o,t);let r=a.convert(o.format,o.colorSpace),p=a.convert(o.type),m=b(o.internalFormat,r,p,o.normalized,o.colorSpace,o.isVideoTexture);oe(c,o);let h,y=o.mipmaps,C=o.isVideoTexture!==!0,w=f.__version===void 0||l===!0,T=u.dataReady,E=S(o,t);if(o.isDepthTexture)m=x(o.format===ru,o.type),w&&(C?n.texStorage2D(e.TEXTURE_2D,1,m,t.width,t.height):n.texImage2D(e.TEXTURE_2D,0,m,t.width,t.height,0,r,p,null));else if(o.isDataTexture){if(y.length>0){C&&w&&n.texStorage2D(e.TEXTURE_2D,E,m,y[0].width,y[0].height);for(let t=0,i=y.length;t<i;t++)h=y[t],C?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,p,h.data):n.texImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,r,p,h.data);o.generateMipmaps=!1}else C?(w&&n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height),T&&se(o,t,r,p)):n.texImage2D(e.TEXTURE_2D,0,m,t.width,t.height,0,r,p,t.data)}else if(o.isCompressedTexture){if(o.isCompressedArrayTexture){C&&w&&n.texStorage3D(e.TEXTURE_2D_ARRAY,E,m,y[0].width,y[0].height,t.depth);for(let i=0,a=y.length;i<a;i++)if(h=y[i],o.format!==1023){if(r!==null){if(C){if(T){if(o.layerUpdates.size>0){let t=$h(h.width,h.height,o.format,o.type);for(let a of o.layerUpdates){let o=h.data.subarray(a*t/h.data.BYTES_PER_ELEMENT,(a+1)*t/h.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,a,h.width,h.height,1,r,o)}}else n.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,0,h.width,h.height,t.depth,r,h.data)}}else n.compressedTexImage3D(e.TEXTURE_2D_ARRAY,i,m,h.width,h.height,t.depth,0,h.data,0,0)}else K(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`)}else C?T&&n.texSubImage3D(e.TEXTURE_2D_ARRAY,i,0,0,0,h.width,h.height,t.depth,r,p,h.data):n.texImage3D(e.TEXTURE_2D_ARRAY,i,m,h.width,h.height,t.depth,0,r,p,h.data);o.layerUpdates.size>0&&o.clearLayerUpdates()}else{C&&w&&n.texStorage2D(e.TEXTURE_2D,E,m,y[0].width,y[0].height);for(let t=0,i=y.length;t<i;t++)h=y[t],o.format===1023?C?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,p,h.data):n.texImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,r,p,h.data):r===null?K(`WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()`):C?T&&n.compressedTexSubImage2D(e.TEXTURE_2D,t,0,0,h.width,h.height,r,h.data):n.compressedTexImage2D(e.TEXTURE_2D,t,m,h.width,h.height,0,h.data)}}else if(o.isDataArrayTexture){if(C){if(w&&n.texStorage3D(e.TEXTURE_2D_ARRAY,E,m,t.width,t.height,t.depth),T){if(o.layerUpdates.size>0){let i=$h(t.width,t.height,o.format,o.type);for(let a of o.layerUpdates){let o=t.data.subarray(a*i/t.data.BYTES_PER_ELEMENT,(a+1)*i/t.data.BYTES_PER_ELEMENT);n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,a,t.width,t.height,1,r,p,o)}o.clearLayerUpdates()}else n.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,0,t.width,t.height,t.depth,r,p,t.data)}}else n.texImage3D(e.TEXTURE_2D_ARRAY,0,m,t.width,t.height,t.depth,0,r,p,t.data)}else if(o.isData3DTexture)C?(w&&n.texStorage3D(e.TEXTURE_3D,E,m,t.width,t.height,t.depth),T&&n.texSubImage3D(e.TEXTURE_3D,0,0,0,0,t.width,t.height,t.depth,r,p,t.data)):n.texImage3D(e.TEXTURE_3D,0,m,t.width,t.height,t.depth,0,r,p,t.data);else if(o.isFramebufferTexture){if(w){if(C)n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height);else{let i=t.width,a=t.height;for(let t=0;t<E;t++)n.texImage2D(e.TEXTURE_2D,t,m,i,a,0,r,p,null),i>>=1,a>>=1}}}else if(o.isHTMLTexture){if(`texElementImage2D`in e){let n=e.canvas;if(n.hasAttribute(`layoutsubtree`)||n.setAttribute(`layoutsubtree`,`true`),t.parentNode!==n){n.appendChild(t),d.add(o),n.onpaint=e=>{let t=e.changedElements;for(let e of d)t.includes(e.image)&&(e.needsUpdate=!0)},n.requestPaint();return}if(e.texElementImage2D.length===3)e.texElementImage2D(e.TEXTURE_2D,e.RGBA8,t);else{let n=e.RGBA,r=e.RGBA,i=e.UNSIGNED_BYTE;e.texElementImage2D(e.TEXTURE_2D,0,n,r,i,t)}e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE)}}else if(y.length>0){if(C&&w){let t=be(y[0]);n.texStorage2D(e.TEXTURE_2D,E,m,t.width,t.height)}for(let t=0,i=y.length;t<i;t++)h=y[t],C?T&&n.texSubImage2D(e.TEXTURE_2D,t,0,0,r,p,h):n.texImage2D(e.TEXTURE_2D,t,m,r,p,h);o.generateMipmaps=!1}else if(C){if(w){let r=be(t);n.texStorage2D(e.TEXTURE_2D,E,m,r.width,r.height)}T&&n.texSubImage2D(e.TEXTURE_2D,0,0,0,r,p,t)}else n.texImage2D(e.TEXTURE_2D,0,m,r,p,t);_(o)&&v(c),f.__version=u.version,o.onUpdate&&o.onUpdate(o)}t.__version=o.version}function R(t,o,s){if(o.image.length!==6)return;let c=F(t,o),l=o.source;n.bindTexture(e.TEXTURE_CUBE_MAP,t.__webglTexture,e.TEXTURE0+s);let u=r.get(l);if(l.version!==u.__version||c===!0){n.activeTexture(e.TEXTURE0+s);let t=Nd.getPrimaries(Nd.workingColorSpace),r=o.colorSpace===``?null:Nd.getPrimaries(o.colorSpace),d=o.colorSpace===``||t===r?e.NONE:e.BROWSER_DEFAULT_WEBGL;n.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,o.flipY),n.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,o.premultiplyAlpha),n.pixelStorei(e.UNPACK_ALIGNMENT,o.unpackAlignment),n.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,d);let f=o.isCompressedTexture||o.image[0].isCompressedTexture,p=o.image[0]&&o.image[0].isDataTexture,m=[];for(let e=0;e<6;e++)!f&&!p?m[e]=g(o.image[e],!0,i.maxCubemapSize):m[e]=p?o.image[e].image:o.image[e],m[e]=ye(o,m[e]);let h=m[0],y=a.convert(o.format,o.colorSpace),x=a.convert(o.type),C=b(o.internalFormat,y,x,o.normalized,o.colorSpace),w=o.isVideoTexture!==!0,T=u.__version===void 0||c===!0,E=l.dataReady,D=S(o,h);oe(e.TEXTURE_CUBE_MAP,o);let O;if(f){w&&T&&n.texStorage2D(e.TEXTURE_CUBE_MAP,D,C,h.width,h.height);for(let t=0;t<6;t++){O=m[t].mipmaps;for(let r=0;r<O.length;r++){let i=O[r];o.format===1023?w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,0,0,i.width,i.height,y,x,i.data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,C,i.width,i.height,0,y,x,i.data):y===null?K(`WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()`):w?E&&n.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,0,0,i.width,i.height,y,i.data):n.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r,C,i.width,i.height,0,i.data)}}}else{if(O=o.mipmaps,w&&T){O.length>0&&D++;let t=be(m[0]);n.texStorage2D(e.TEXTURE_CUBE_MAP,D,C,t.width,t.height)}for(let t=0;t<6;t++)if(p){w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,0,0,m[t].width,m[t].height,y,x,m[t].data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,C,m[t].width,m[t].height,0,y,x,m[t].data);for(let r=0;r<O.length;r++){let i=O[r].image[t].image;w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,0,0,i.width,i.height,y,x,i.data):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,C,i.width,i.height,0,y,x,i.data)}}else{w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,0,0,y,x,m[t]):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,0,C,y,x,m[t]);for(let r=0;r<O.length;r++){let i=O[r];w?E&&n.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,0,0,y,x,i.image[t]):n.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+t,r+1,C,y,x,i.image[t])}}}_(o)&&v(e.TEXTURE_CUBE_MAP),u.__version=l.version,o.onUpdate&&o.onUpdate(o)}t.__version=o.version}function ce(t,i,o,c,l,u){let d=a.convert(o.format,o.colorSpace),f=a.convert(o.type),p=b(o.internalFormat,d,f,o.normalized,o.colorSpace),m=r.get(i),h=r.get(o);if(h.__renderTarget=i,!m.__hasExternalTextures){let t=Math.max(1,i.width>>u),r=Math.max(1,i.height>>u);l===e.TEXTURE_3D||l===e.TEXTURE_2D_ARRAY?n.texImage3D(l,u,p,t,r,i.depth,0,d,f,null):n.texImage2D(l,u,p,t,r,0,d,f,null)}n.bindFramebuffer(e.FRAMEBUFFER,t),B(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,c,l,h.__webglTexture,0,_e(i)):(l===e.TEXTURE_2D||l>=e.TEXTURE_CUBE_MAP_POSITIVE_X&&l<=e.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&e.framebufferTexture2D(e.FRAMEBUFFER,c,l,h.__webglTexture,u),n.bindFramebuffer(e.FRAMEBUFFER,null)}function le(t,n,r){if(e.bindRenderbuffer(e.RENDERBUFFER,t),n.depthBuffer){let i=n.depthTexture,a=i&&i.isDepthTexture?i.type:null,o=x(n.stencilBuffer,a),c=n.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;B(n)?s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,_e(n),o,n.width,n.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,_e(n),o,n.width,n.height):e.renderbufferStorage(e.RENDERBUFFER,o,n.width,n.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,c,e.RENDERBUFFER,t)}else{let t=n.textures;for(let i=0;i<t.length;i++){let o=t[i],c=a.convert(o.format,o.colorSpace),l=a.convert(o.type),u=b(o.internalFormat,c,l,o.normalized,o.colorSpace);B(n)?s.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,_e(n),u,n.width,n.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,_e(n),u,n.width,n.height):e.renderbufferStorage(e.RENDERBUFFER,u,n.width,n.height)}}e.bindRenderbuffer(e.RENDERBUFFER,null)}function ue(t,i,o){let c=i.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(e.FRAMEBUFFER,t),!(i.depthTexture&&i.depthTexture.isDepthTexture))throw Error(`THREE.WebGLTextures: renderTarget.depthTexture must be an instance of THREE.DepthTexture.`);let l=r.get(i.depthTexture);if(l.__renderTarget=i,(!l.__webglTexture||i.depthTexture.image.width!==i.width||i.depthTexture.image.height!==i.height)&&(i.depthTexture.image.width=i.width,i.depthTexture.image.height=i.height,i.depthTexture.needsUpdate=!0),c){if(l.__webglInit===void 0&&(l.__webglInit=!0,i.depthTexture.addEventListener(`dispose`,C)),l.__webglTexture===void 0){l.__webglTexture=e.createTexture(),n.bindTexture(e.TEXTURE_CUBE_MAP,l.__webglTexture),oe(e.TEXTURE_CUBE_MAP,i.depthTexture);let t=a.convert(i.depthTexture.format),r=a.convert(i.depthTexture.type),o;i.depthTexture.format===1026?o=e.DEPTH_COMPONENT24:i.depthTexture.format===1027&&(o=e.DEPTH24_STENCIL8);for(let n=0;n<6;n++)e.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0,o,i.width,i.height,0,t,r,null)}}else te(i.depthTexture,0);let u=l.__webglTexture,d=_e(i),f=c?e.TEXTURE_CUBE_MAP_POSITIVE_X+o:e.TEXTURE_2D,p=i.depthTexture.format===1027?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;if(i.depthTexture.format===1026)B(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,p,f,u,0,d):e.framebufferTexture2D(e.FRAMEBUFFER,p,f,u,0);else if(i.depthTexture.format===1027)B(i)?s.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,p,f,u,0,d):e.framebufferTexture2D(e.FRAMEBUFFER,p,f,u,0);else throw Error(`THREE.WebGLTextures: Unknown depthTexture format.`)}function de(t){let i=r.get(t),a=t.isWebGLCubeRenderTarget===!0;if(i.__boundDepthTexture!==t.depthTexture){let e=t.depthTexture;if(i.__depthDisposeCallback&&i.__depthDisposeCallback(),e){let t=()=>{delete i.__boundDepthTexture,delete i.__depthDisposeCallback,e.removeEventListener(`dispose`,t)};e.addEventListener(`dispose`,t),i.__depthDisposeCallback=t}i.__boundDepthTexture=e}if(t.depthTexture&&!i.__autoAllocateDepthBuffer){if(a)for(let e=0;e<6;e++)ue(i.__webglFramebuffer[e],t,e);else{let e=t.texture.mipmaps;e&&e.length>0?ue(i.__webglFramebuffer[0],t,0):ue(i.__webglFramebuffer,t,0)}}else if(a){i.__webglDepthbuffer=[];for(let r=0;r<6;r++)if(n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer[r]),i.__webglDepthbuffer[r]===void 0)i.__webglDepthbuffer[r]=e.createRenderbuffer(),le(i.__webglDepthbuffer[r],t,!1);else{let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,a=i.__webglDepthbuffer[r];e.bindRenderbuffer(e.RENDERBUFFER,a),e.framebufferRenderbuffer(e.FRAMEBUFFER,n,e.RENDERBUFFER,a)}}else{let r=t.texture.mipmaps;if(r&&r.length>0?n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer[0]):n.bindFramebuffer(e.FRAMEBUFFER,i.__webglFramebuffer),i.__webglDepthbuffer===void 0)i.__webglDepthbuffer=e.createRenderbuffer(),le(i.__webglDepthbuffer,t,!1);else{let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,r=i.__webglDepthbuffer;e.bindRenderbuffer(e.RENDERBUFFER,r),e.framebufferRenderbuffer(e.FRAMEBUFFER,n,e.RENDERBUFFER,r)}}n.bindFramebuffer(e.FRAMEBUFFER,null)}function fe(t,n,i){let a=r.get(t);n!==void 0&&ce(a.__webglFramebuffer,t,t.texture,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,0),i!==void 0&&de(t)}function pe(t){let i=t.texture,s=r.get(t),c=r.get(i);t.addEventListener(`dispose`,w);let l=t.textures,u=t.isWebGLCubeRenderTarget===!0,d=l.length>1;if(d||(c.__webglTexture===void 0&&(c.__webglTexture=e.createTexture()),c.__version=i.version,o.memory.textures++),u){s.__webglFramebuffer=[];for(let t=0;t<6;t++)if(i.mipmaps&&i.mipmaps.length>0){s.__webglFramebuffer[t]=[];for(let n=0;n<i.mipmaps.length;n++)s.__webglFramebuffer[t][n]=e.createFramebuffer()}else s.__webglFramebuffer[t]=e.createFramebuffer()}else{if(i.mipmaps&&i.mipmaps.length>0){s.__webglFramebuffer=[];for(let t=0;t<i.mipmaps.length;t++)s.__webglFramebuffer[t]=e.createFramebuffer()}else s.__webglFramebuffer=e.createFramebuffer();if(d)for(let t=0,n=l.length;t<n;t++){let n=r.get(l[t]);n.__webglTexture===void 0&&(n.__webglTexture=e.createTexture(),o.memory.textures++)}if(t.samples>0&&B(t)===!1){s.__webglMultisampledFramebuffer=e.createFramebuffer(),s.__webglColorRenderbuffer=[],n.bindFramebuffer(e.FRAMEBUFFER,s.__webglMultisampledFramebuffer);for(let n=0;n<l.length;n++){let r=l[n];s.__webglColorRenderbuffer[n]=e.createRenderbuffer(),e.bindRenderbuffer(e.RENDERBUFFER,s.__webglColorRenderbuffer[n]);let i=a.convert(r.format,r.colorSpace),o=a.convert(r.type),c=b(r.internalFormat,i,o,r.normalized,r.colorSpace,t.isXRRenderTarget===!0),u=_e(t);e.renderbufferStorageMultisample(e.RENDERBUFFER,u,c,t.width,t.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+n,e.RENDERBUFFER,s.__webglColorRenderbuffer[n])}e.bindRenderbuffer(e.RENDERBUFFER,null),t.depthBuffer&&(s.__webglDepthRenderbuffer=e.createRenderbuffer(),le(s.__webglDepthRenderbuffer,t,!0)),n.bindFramebuffer(e.FRAMEBUFFER,null)}}if(u){n.bindTexture(e.TEXTURE_CUBE_MAP,c.__webglTexture),oe(e.TEXTURE_CUBE_MAP,i);for(let n=0;n<6;n++)if(i.mipmaps&&i.mipmaps.length>0)for(let r=0;r<i.mipmaps.length;r++)ce(s.__webglFramebuffer[n][r],t,i,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+n,r);else ce(s.__webglFramebuffer[n],t,i,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0);_(i)&&v(e.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(d){for(let i=0,a=l.length;i<a;i++){let a=l[i],o=r.get(a),c=e.TEXTURE_2D;(t.isWebGL3DRenderTarget||t.isWebGLArrayRenderTarget)&&(c=t.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),n.bindTexture(c,o.__webglTexture),oe(c,a),ce(s.__webglFramebuffer,t,a,e.COLOR_ATTACHMENT0+i,c,0),_(a)&&v(c)}n.unbindTexture()}else{let r=e.TEXTURE_2D;if((t.isWebGL3DRenderTarget||t.isWebGLArrayRenderTarget)&&(r=t.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),n.bindTexture(r,c.__webglTexture),oe(r,i),i.mipmaps&&i.mipmaps.length>0)for(let n=0;n<i.mipmaps.length;n++)ce(s.__webglFramebuffer[n],t,i,e.COLOR_ATTACHMENT0,r,n);else ce(s.__webglFramebuffer,t,i,e.COLOR_ATTACHMENT0,r,0);_(i)&&v(r),n.unbindTexture()}t.depthBuffer&&de(t)}function me(e){let t=e.textures;for(let i=0,a=t.length;i<a;i++){let a=t[i];if(_(a)){let t=y(e),i=r.get(a).__webglTexture;n.bindTexture(t,i),v(t),n.unbindTexture()}}}let he=[],ge=[];function z(t){if(t.samples>0){if(B(t)===!1){let i=t.textures,a=t.width,o=t.height,s=e.COLOR_BUFFER_BIT,l=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,u=r.get(t),d=i.length>1;if(d)for(let t=0;t<i.length;t++)n.bindFramebuffer(e.FRAMEBUFFER,u.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.RENDERBUFFER,null),n.bindFramebuffer(e.FRAMEBUFFER,u.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.TEXTURE_2D,null,0);n.bindFramebuffer(e.READ_FRAMEBUFFER,u.__webglMultisampledFramebuffer);let f=t.texture.mipmaps;f&&f.length>0?n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglFramebuffer[0]):n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglFramebuffer);for(let n=0;n<i.length;n++){if(t.resolveDepthBuffer&&(t.depthBuffer&&(s|=e.DEPTH_BUFFER_BIT),t.stencilBuffer&&t.resolveStencilBuffer&&(s|=e.STENCIL_BUFFER_BIT)),d){e.framebufferRenderbuffer(e.READ_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.RENDERBUFFER,u.__webglColorRenderbuffer[n]);let t=r.get(i[n]).__webglTexture;e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,t,0)}e.blitFramebuffer(0,0,a,o,0,0,a,o,s,e.NEAREST),c===!0&&(he.length=0,ge.length=0,he.push(e.COLOR_ATTACHMENT0+n),t.depthBuffer&&t.storeMultisampledDepthBuffer===!1&&(he.push(l),ge.push(l),e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,ge)),e.invalidateFramebuffer(e.READ_FRAMEBUFFER,he))}if(n.bindFramebuffer(e.READ_FRAMEBUFFER,null),n.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),d)for(let t=0;t<i.length;t++){n.bindFramebuffer(e.FRAMEBUFFER,u.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.RENDERBUFFER,u.__webglColorRenderbuffer[t]);let a=r.get(i[t]).__webglTexture;n.bindFramebuffer(e.FRAMEBUFFER,u.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.TEXTURE_2D,a,0)}n.bindFramebuffer(e.DRAW_FRAMEBUFFER,u.__webglMultisampledFramebuffer)}else if(t.depthBuffer&&t.storeMultisampledDepthBuffer===!1&&c){let n=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,[n])}}}function _e(e){return Math.min(i.maxSamples,e.samples)}function B(e){let n=r.get(e);return e.samples>0&&t.has(`WEBGL_multisampled_render_to_texture`)===!0&&n.__useRenderToTexture!==!1}function ve(e){let t=o.render.frame;u.get(e)!==t&&(u.set(e,t),e.update())}function ye(e,t){let n=e.colorSpace,r=e.format,i=e.type;return e.isCompressedTexture===!0||e.isVideoTexture===!0||n!==`srgb-linear`&&n!==``&&(Nd.getTransfer(n)===`srgb`?(r!==1023||i!==1009)&&K(`WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.`):q(`WebGLTextures: Unsupported texture color space:`,n)),t}function be(e){return typeof HTMLImageElement<`u`&&e instanceof HTMLImageElement?(l.width=e.naturalWidth||e.width,l.height=e.naturalHeight||e.height):typeof VideoFrame<`u`&&e instanceof VideoFrame?(l.width=e.displayWidth,l.height=e.displayHeight):(l.width=e.width,l.height=e.height),l}this.allocateTextureUnit=ee,this.resetTextureUnits=k,this.getTextureUnits=A,this.setTextureUnits=j,this.setTexture2D=te,this.setTexture2DArray=ne,this.setTexture3D=re,this.setTextureCube=N,this.rebindTextures=fe,this.setupRenderTarget=pe,this.updateRenderTargetMipmap=me,this.updateMultisampleRenderTarget=z,this.setupDepthRenderbuffer=de,this.setupFrameBufferTexture=ce,this.useMultisampledRTT=B,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function ay(e,t){function n(n,r=``){let i,a=Nd.getTransfer(r);if(n===1009)return e.UNSIGNED_BYTE;if(n===1017)return e.UNSIGNED_SHORT_4_4_4_4;if(n===1018)return e.UNSIGNED_SHORT_5_5_5_1;if(n===35902)return e.UNSIGNED_INT_5_9_9_9_REV;if(n===35899)return e.UNSIGNED_INT_10F_11F_11F_REV;if(n===1010)return e.BYTE;if(n===1011)return e.SHORT;if(n===1012)return e.UNSIGNED_SHORT;if(n===1013)return e.INT;if(n===1014)return e.UNSIGNED_INT;if(n===1015)return e.FLOAT;if(n===1016)return e.HALF_FLOAT;if(n===1021)return e.ALPHA;if(n===1022)return e.RGB;if(n===1023)return e.RGBA;if(n===1026)return e.DEPTH_COMPONENT;if(n===1027)return e.DEPTH_STENCIL;if(n===1028)return e.RED;if(n===1029)return e.RED_INTEGER;if(n===1030)return e.RG;if(n===1031)return e.RG_INTEGER;if(n===1033)return e.RGBA_INTEGER;if(n===33776||n===33777||n===33778||n===33779){if(a===`srgb`){if(i=t.get(`WEBGL_compressed_texture_s3tc_srgb`),i!==null){if(n===33776)return i.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null}else if(i=t.get(`WEBGL_compressed_texture_s3tc`),i!==null){if(n===33776)return i.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===33777)return i.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===33778)return i.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===33779)return i.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null}if(n===35840||n===35841||n===35842||n===35843){if(i=t.get(`WEBGL_compressed_texture_pvrtc`),i!==null){if(n===35840)return i.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===35841)return i.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===35842)return i.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===35843)return i.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null}if(n===36196||n===37492||n===37496||n===37488||n===37489||n===37490||n===37491){if(i=t.get(`WEBGL_compressed_texture_etc`),i!==null){if(n===36196||n===37492)return a===`srgb`?i.COMPRESSED_SRGB8_ETC2:i.COMPRESSED_RGB8_ETC2;if(n===37496)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:i.COMPRESSED_RGBA8_ETC2_EAC;if(n===37488)return i.COMPRESSED_R11_EAC;if(n===37489)return i.COMPRESSED_SIGNED_R11_EAC;if(n===37490)return i.COMPRESSED_RG11_EAC;if(n===37491)return i.COMPRESSED_SIGNED_RG11_EAC}else return null}if(n===37808||n===37809||n===37810||n===37811||n===37812||n===37813||n===37814||n===37815||n===37816||n===37817||n===37818||n===37819||n===37820||n===37821){if(i=t.get(`WEBGL_compressed_texture_astc`),i!==null){if(n===37808)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:i.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===37809)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:i.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===37810)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:i.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===37811)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:i.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===37812)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:i.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===37813)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:i.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===37814)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:i.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===37815)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:i.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===37816)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:i.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===37817)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:i.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===37818)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:i.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===37819)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:i.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===37820)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:i.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===37821)return a===`srgb`?i.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:i.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null}if(n===36492||n===36494||n===36495){if(i=t.get(`EXT_texture_compression_bptc`),i!==null){if(n===36492)return a===`srgb`?i.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:i.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===36494)return i.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===36495)return i.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null}if(n===36283||n===36284||n===36285||n===36286){if(i=t.get(`EXT_texture_compression_rgtc`),i!==null){if(n===36283)return i.COMPRESSED_RED_RGTC1_EXT;if(n===36284)return i.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===36285)return i.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===36286)return i.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null}return n===1020?e.UNSIGNED_INT_24_8:e[n]===void 0?null:e[n]}return{convert:n}}var oy=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,sy=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,cy=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t){if(this.texture===null){let n=new jm(e.texture);(e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,n=new Xm({vertexShader:oy,fragmentShader:sy,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new Zp(new Rm(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},ly=class extends gd{constructor(e,t){super();let n=this,r=null,i=1,a=null,o=`local-floor`,s=1,c=null,l=null,u=null,d=null,f=null,p=null,m=typeof XRWebGLBinding<`u`,h=new cy,g={},_=t.getContextAttributes(),v=null,y=null,b=[],x=[],S=new J,C=null,w=null,T=new Mh;T.viewport=new Wd;let E=new Mh;E.viewport=new Wd;let D=[T,E],O=new Bh,k=null,A=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(e){let t=b[e];return t===void 0&&(t=new Ef,b[e]=t),t.getTargetRaySpace()},this.getControllerGrip=function(e){let t=b[e];return t===void 0&&(t=new Ef,b[e]=t),t.getGripSpace()},this.getHand=function(e){let t=b[e];return t===void 0&&(t=new Ef,b[e]=t),t.getHandSpace()};function j(e){let t=x.indexOf(e.inputSource);if(t===-1)return;let n=b[t];n!==void 0&&(n.update(e.inputSource,e.frame,c||a),n.dispatchEvent({type:e.type,data:e.inputSource}))}function ee(){r.removeEventListener(`select`,j),r.removeEventListener(`selectstart`,j),r.removeEventListener(`selectend`,j),r.removeEventListener(`squeeze`,j),r.removeEventListener(`squeezestart`,j),r.removeEventListener(`squeezeend`,j),r.removeEventListener(`end`,ee),r.removeEventListener(`inputsourceschange`,M);for(let e=0;e<b.length;e++){let t=x[e];t!==null&&(x[e]=null,b[e].disconnect(t))}k=null,A=null,h.reset();for(let e in g)delete g[e];if(e.setRenderTarget(v),f=null,d=null,u=null,r=null,y=null,oe.stop(),n.isPresenting=!1,e.setPixelRatio(C),e.setSize(S.width,S.height,!1),w!==null){let e=w.camera;e.fov=w.fov,e.zoom=w.zoom,e.updateProjectionMatrix(),w=null}n.dispatchEvent({type:`sessionend`})}this.setFramebufferScaleFactor=function(e){i=e,n.isPresenting===!0&&K(`WebXRManager: Cannot change framebuffer scale while presenting.`)},this.setReferenceSpaceType=function(e){o=e,n.isPresenting===!0&&K(`WebXRManager: Cannot change reference space type while presenting.`)},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(e){c=e},this.getBaseLayer=function(){return d===null?f:d},this.getBinding=function(){return u===null&&m&&(u=new XRWebGLBinding(r,t)),u},this.getFrame=function(){return p},this.getSession=function(){return r},this.setSession=async function(l){if(r=l,r!==null){if(v=e.getRenderTarget(),r.addEventListener(`select`,j),r.addEventListener(`selectstart`,j),r.addEventListener(`selectend`,j),r.addEventListener(`squeeze`,j),r.addEventListener(`squeezestart`,j),r.addEventListener(`squeezeend`,j),r.addEventListener(`end`,ee),r.addEventListener(`inputsourceschange`,M),_.xrCompatible!==!0&&await t.makeXRCompatible(),C=e.getPixelRatio(),e.getSize(S),m&&`createProjectionLayer`in XRWebGLBinding.prototype){let n=null,a=null,o=null;_.depth&&(o=_.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,n=_.stencil?ru:nu,a=_.stencil?Xl:Gl);let s={colorFormat:t.RGBA8,depthFormat:o,scaleFactor:i};u=this.getBinding(),d=u.createProjectionLayer(s),r.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),y=new Kd(d.textureWidth,d.textureHeight,{format:tu,type:Bl,depthTexture:new km(d.textureWidth,d.textureHeight,a,void 0,void 0,void 0,void 0,void 0,void 0,n),stencilBuffer:_.stencil,colorSpace:e.outputColorSpace,samples:_.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1,storeMultisampledDepthBuffer:d.ignoreDepthValues===!1,storeMultisampledStencilBuffer:d.ignoreDepthValues===!1})}else{let n={antialias:_.antialias,alpha:!0,depth:_.depth,stencil:_.stencil,framebufferScaleFactor:i};f=new XRWebGLLayer(r,t,n),r.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),y=new Kd(f.framebufferWidth,f.framebufferHeight,{format:tu,type:Bl,colorSpace:e.outputColorSpace,stencilBuffer:_.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1,storeMultisampledDepthBuffer:f.ignoreDepthValues===!1,storeMultisampledStencilBuffer:f.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(s),c=null,a=await r.requestReferenceSpace(o),oe.setContext(r),oe.start(),n.isPresenting=!0,n.dispatchEvent({type:`sessionstart`})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return h.getDepthTexture()};function M(e){for(let t=0;t<e.removed.length;t++){let n=e.removed[t],r=x.indexOf(n);r>=0&&(x[r]=null,b[r].disconnect(n))}for(let t=0;t<e.added.length;t++){let n=e.added[t],r=x.indexOf(n);if(r===-1){for(let e=0;e<b.length;e++)if(e>=x.length){x.push(n),r=e;break}else if(x[e]===null){x[e]=n,r=e;break}if(r===-1)break}let i=b[r];i&&i.connect(n)}}let te=new Y,ne=new Y;function re(e,t,n){te.setFromMatrixPosition(t.matrixWorld),ne.setFromMatrixPosition(n.matrixWorld);let r=te.distanceTo(ne),i=t.projectionMatrix.elements,a=n.projectionMatrix.elements,o=i[14]/(i[10]-1),s=i[14]/(i[10]+1),c=(i[9]+1)/i[5],l=(i[9]-1)/i[5],u=(i[8]-1)/i[0],d=(a[8]+1)/a[0],f=o*u,p=o*d,m=r/(-u+d),h=m*-u;if(t.matrixWorld.decompose(e.position,e.quaternion,e.scale),e.translateX(h),e.translateZ(m),e.matrixWorld.compose(e.position,e.quaternion,e.scale),e.matrixWorldInverse.copy(e.matrixWorld).invert(),i[10]===-1)e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse);else{let t=o+m,n=s+m,i=f-h,a=p+(r-h),u=c*s/n*t,d=l*s/n*t;e.projectionMatrix.makePerspective(i,a,u,d,t,n),e.projectionMatrixInverse.copy(e.projectionMatrix).invert()}}function N(e,t){t===null?e.matrixWorld.copy(e.matrix):e.matrixWorld.multiplyMatrices(t.matrixWorld,e.matrix),e.matrixWorldInverse.copy(e.matrixWorld).invert()}this.updateCamera=function(e){if(r===null)return;let t=e.near,n=e.far;h.texture!==null&&(h.depthNear>0&&(t=h.depthNear),h.depthFar>0&&(n=h.depthFar)),O.near=E.near=T.near=t,O.far=E.far=T.far=n,(k!==O.near||A!==O.far)&&(r.updateRenderState({depthNear:O.near,depthFar:O.far}),k=O.near,A=O.far),O.layers.mask=e.layers.mask|6,T.layers.mask=O.layers.mask&-5,E.layers.mask=O.layers.mask&-3;let i=e.parent,a=O.cameras;N(O,i);for(let e=0;e<a.length;e++)N(a[e],i);a.length===2?re(O,T,E):O.projectionMatrix.copy(T.projectionMatrix),w===null&&e.isPerspectiveCamera&&(w={camera:e,fov:e.fov,zoom:e.zoom}),ie(e,O,i)};function ie(e,t,n){n===null?e.matrix.copy(t.matrixWorld):(e.matrix.copy(n.matrixWorld),e.matrix.invert(),e.matrix.multiply(t.matrixWorld)),e.matrix.decompose(e.position,e.quaternion,e.scale),e.updateMatrixWorld(!0),e.projectionMatrix.copy(t.projectionMatrix),e.projectionMatrixInverse.copy(t.projectionMatrixInverse),e.isPerspectiveCamera&&(e.fov=yd*2*Math.atan(1/e.projectionMatrix.elements[5]),e.zoom=1)}this.getCamera=function(){return O},this.getFoveation=function(){if(d!==null||f!==null)return s},this.setFoveation=function(e){s=e,d!==null&&(d.fixedFoveation=e),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=e)},this.hasDepthSensing=function(){return h.texture!==null},this.getDepthSensingMesh=function(){return h.getMesh(O)},this.getCameraTexture=function(e){return g[e]};let P=null;function ae(t,i){if(l=i.getViewerPose(c||a),p=i,l!==null){let t=l.views;f!==null&&(e.setRenderTargetFramebuffer(y,f.framebuffer),e.setRenderTarget(y));let i=!1;t.length!==O.cameras.length&&(O.cameras.length=0,i=!0);for(let n=0;n<t.length;n++){let r=t[n],a=null;if(f!==null)a=f.getViewport(r);else{let t=u.getViewSubImage(d,r);a=t.viewport,n===0&&(e.setRenderTargetTextures(y,t.colorTexture,t.depthStencilTexture),e.setRenderTarget(y))}let o=D[n];o===void 0&&(o=new Mh,o.layers.enable(n),o.viewport=new Wd,D[n]=o),o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.quaternion,o.scale),o.projectionMatrix.fromArray(r.projectionMatrix),o.projectionMatrixInverse.copy(o.projectionMatrix).invert(),o.viewport.set(a.x,a.y,a.width,a.height),n===0&&(O.matrix.copy(o.matrix),O.matrix.decompose(O.position,O.quaternion,O.scale)),i===!0&&O.cameras.push(o)}let a=r.enabledFeatures;if(a&&a.includes(`depth-sensing`)&&r.depthUsage==`gpu-optimized`&&m){u=n.getBinding();let e=u.getDepthInformation(t[0]);e&&e.isValid&&e.texture&&h.init(e,r.renderState)}if(a&&a.includes(`camera-access`)&&m){e.state.unbindTexture(),u=n.getBinding();for(let e=0;e<t.length;e++){let n=t[e].camera;if(n){let e=g[n];e||(e=new jm,g[n]=e);let t=u.getCameraImage(n);e.sourceTexture=t}}}}for(let e=0;e<b.length;e++){let t=x[e],n=b[e];t!==null&&n!==void 0&&n.update(t,i,c||a)}P&&P(t,i),i.detectedPlanes&&n.dispatchEvent({type:`planesdetected`,data:i}),p=null}let oe=new tg;oe.setAnimationLoop(ae),this.setAnimationLoop=function(e){P=e},this.dispose=function(){}}},uy=new Yd,dy=new X;dy.set(-1,0,0,0,1,0,0,0,1);function fy(e,t){function n(e,t){e.matrixAutoUpdate===!0&&e.updateMatrix(),t.value.copy(e.matrix)}function r(t,n){n.color.getRGB(t.fogColor.value,Km(e)),n.isFog?(t.fogNear.value=n.near,t.fogFar.value=n.far):n.isFogExp2&&(t.fogDensity.value=n.density)}function i(e,t,n,r,i){t.isNodeMaterial?t.uniformsNeedUpdate=!1:t.isMeshBasicMaterial?a(e,t):t.isMeshLambertMaterial?(a(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshToonMaterial?(a(e,t),d(e,t)):t.isMeshPhongMaterial?(a(e,t),u(e,t),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)):t.isMeshStandardMaterial?(a(e,t),f(e,t),t.isMeshPhysicalMaterial&&p(e,t,i)):t.isMeshMatcapMaterial?(a(e,t),m(e,t)):t.isMeshDepthMaterial?a(e,t):t.isMeshDistanceMaterial?(a(e,t),h(e,t)):t.isMeshNormalMaterial?a(e,t):t.isLineBasicMaterial?(o(e,t),t.isLineDashedMaterial&&s(e,t)):t.isPointsMaterial?c(e,t,n,r):t.isSpriteMaterial?l(e,t):t.isShadowMaterial?(e.color.value.copy(t.color),e.opacity.value=t.opacity):t.isShaderMaterial&&(t.uniformsNeedUpdate=!1)}function a(e,r){e.opacity.value=r.opacity,r.color&&e.diffuse.value.copy(r.color),r.emissive&&e.emissive.value.copy(r.emissive).multiplyScalar(r.emissiveIntensity),r.map&&(e.map.value=r.map,n(r.map,e.mapTransform)),r.alphaMap&&(e.alphaMap.value=r.alphaMap,n(r.alphaMap,e.alphaMapTransform)),r.bumpMap&&(e.bumpMap.value=r.bumpMap,n(r.bumpMap,e.bumpMapTransform),e.bumpScale.value=r.bumpScale,r.side===1&&(e.bumpScale.value*=-1)),r.normalMap&&(e.normalMap.value=r.normalMap,n(r.normalMap,e.normalMapTransform),e.normalScale.value.copy(r.normalScale),r.side===1&&e.normalScale.value.negate()),r.displacementMap&&(e.displacementMap.value=r.displacementMap,n(r.displacementMap,e.displacementMapTransform),e.displacementScale.value=r.displacementScale,e.displacementBias.value=r.displacementBias),r.emissiveMap&&(e.emissiveMap.value=r.emissiveMap,n(r.emissiveMap,e.emissiveMapTransform)),r.specularMap&&(e.specularMap.value=r.specularMap,n(r.specularMap,e.specularMapTransform)),r.alphaTest>0&&(e.alphaTest.value=r.alphaTest);let i=t.get(r),a=i.envMap,o=i.envMapRotation;a&&(e.envMap.value=a,e.envMapRotation.value.setFromMatrix4(uy.makeRotationFromEuler(o)).transpose(),a.isCubeTexture&&a.isRenderTargetTexture===!1&&e.envMapRotation.value.premultiply(dy),e.reflectivity.value=r.reflectivity,e.ior.value=r.ior,e.refractionRatio.value=r.refractionRatio),r.lightMap&&(e.lightMap.value=r.lightMap,e.lightMapIntensity.value=r.lightMapIntensity,n(r.lightMap,e.lightMapTransform)),r.aoMap&&(e.aoMap.value=r.aoMap,e.aoMapIntensity.value=r.aoMapIntensity,n(r.aoMap,e.aoMapTransform))}function o(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform))}function s(e,t){e.dashSize.value=t.dashSize,e.totalSize.value=t.dashSize+t.gapSize,e.scale.value=t.scale}function c(e,t,r,i){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.size.value=t.size*r,e.scale.value=i*.5,t.map&&(e.map.value=t.map,n(t.map,e.uvTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function l(e,t){e.diffuse.value.copy(t.color),e.opacity.value=t.opacity,e.rotation.value=t.rotation,t.map&&(e.map.value=t.map,n(t.map,e.mapTransform)),t.alphaMap&&(e.alphaMap.value=t.alphaMap,n(t.alphaMap,e.alphaMapTransform)),t.alphaTest>0&&(e.alphaTest.value=t.alphaTest)}function u(e,t){e.specular.value.copy(t.specular),e.shininess.value=Math.max(t.shininess,1e-4)}function d(e,t){t.gradientMap&&(e.gradientMap.value=t.gradientMap)}function f(e,t){e.metalness.value=t.metalness,t.metalnessMap&&(e.metalnessMap.value=t.metalnessMap,n(t.metalnessMap,e.metalnessMapTransform)),e.roughness.value=t.roughness,t.roughnessMap&&(e.roughnessMap.value=t.roughnessMap,n(t.roughnessMap,e.roughnessMapTransform)),t.envMap&&(e.envMapIntensity.value=t.envMapIntensity)}function p(e,t,r){e.ior.value=t.ior,t.sheen>0&&(e.sheenColor.value.copy(t.sheenColor).multiplyScalar(t.sheen),e.sheenRoughness.value=t.sheenRoughness,t.sheenColorMap&&(e.sheenColorMap.value=t.sheenColorMap,n(t.sheenColorMap,e.sheenColorMapTransform)),t.sheenRoughnessMap&&(e.sheenRoughnessMap.value=t.sheenRoughnessMap,n(t.sheenRoughnessMap,e.sheenRoughnessMapTransform))),t.clearcoat>0&&(e.clearcoat.value=t.clearcoat,e.clearcoatRoughness.value=t.clearcoatRoughness,t.clearcoatMap&&(e.clearcoatMap.value=t.clearcoatMap,n(t.clearcoatMap,e.clearcoatMapTransform)),t.clearcoatRoughnessMap&&(e.clearcoatRoughnessMap.value=t.clearcoatRoughnessMap,n(t.clearcoatRoughnessMap,e.clearcoatRoughnessMapTransform)),t.clearcoatNormalMap&&(e.clearcoatNormalMap.value=t.clearcoatNormalMap,n(t.clearcoatNormalMap,e.clearcoatNormalMapTransform),e.clearcoatNormalScale.value.copy(t.clearcoatNormalScale),t.side===1&&e.clearcoatNormalScale.value.negate())),t.dispersion>0&&(e.dispersion.value=t.dispersion),t.retroreflectivity>0&&(e.retroreflectivity.value=t.retroreflectivity),t.iridescence>0&&(e.iridescence.value=t.iridescence,e.iridescenceIOR.value=t.iridescenceIOR,e.iridescenceThicknessMinimum.value=t.iridescenceThicknessRange[0],e.iridescenceThicknessMaximum.value=t.iridescenceThicknessRange[1],t.iridescenceMap&&(e.iridescenceMap.value=t.iridescenceMap,n(t.iridescenceMap,e.iridescenceMapTransform)),t.iridescenceThicknessMap&&(e.iridescenceThicknessMap.value=t.iridescenceThicknessMap,n(t.iridescenceThicknessMap,e.iridescenceThicknessMapTransform))),t.transmission>0&&(e.transmission.value=t.transmission,e.transmissionSamplerMap.value=r.texture,e.transmissionSamplerSize.value.set(r.width,r.height),t.transmissionMap&&(e.transmissionMap.value=t.transmissionMap,n(t.transmissionMap,e.transmissionMapTransform)),e.thickness.value=t.thickness,t.thicknessMap&&(e.thicknessMap.value=t.thicknessMap,n(t.thicknessMap,e.thicknessMapTransform)),e.attenuationDistance.value=t.attenuationDistance,e.attenuationColor.value.copy(t.attenuationColor)),t.anisotropy>0&&(e.anisotropyVector.value.set(t.anisotropy*Math.cos(t.anisotropyRotation),t.anisotropy*Math.sin(t.anisotropyRotation)),t.anisotropyMap&&(e.anisotropyMap.value=t.anisotropyMap,n(t.anisotropyMap,e.anisotropyMapTransform))),e.specularIntensity.value=t.specularIntensity,e.specularColor.value.copy(t.specularColor),t.specularColorMap&&(e.specularColorMap.value=t.specularColorMap,n(t.specularColorMap,e.specularColorMapTransform)),t.specularIntensityMap&&(e.specularIntensityMap.value=t.specularIntensityMap,n(t.specularIntensityMap,e.specularIntensityMapTransform))}function m(e,t){t.matcap&&(e.matcap.value=t.matcap)}function h(e,n){let r=t.get(n).light;e.referencePosition.value.setFromMatrixPosition(r.matrixWorld),e.nearDistance.value=r.shadow.camera.near,e.farDistance.value=r.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:i}}function py(e,t,n,r){let i={},a={},o=[],s=e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);function c(e,t){let n=t.program;r.uniformBlockBinding(e,n)}function l(e,n){let o=i[e.id];o===void 0&&(g(e),o=u(e),i[e.id]=o,e.addEventListener(`dispose`,v));let s=n.program;r.updateUBOMapping(e,s);let c=t.render.frame;a[e.id]!==c&&(f(e),a[e.id]=c)}function u(t){let n=d();t.__bindingPointIndex=n;let r=e.createBuffer(),i=t.__size,a=t.usage;return e.bindBuffer(e.UNIFORM_BUFFER,r),e.bufferData(e.UNIFORM_BUFFER,i,a),e.bindBuffer(e.UNIFORM_BUFFER,null),e.bindBufferBase(e.UNIFORM_BUFFER,n,r),r}function d(){for(let e=0;e<s;e++)if(o.indexOf(e)===-1)return o.push(e),e;return q(`WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached.`),0}function f(t){let n=i[t.id],r=t.uniforms,a=t.__cache;e.bindBuffer(e.UNIFORM_BUFFER,n);for(let e=0,t=r.length;e<t;e++){let t=r[e];if(Array.isArray(t))for(let n=0,r=t.length;n<r;n++)p(t[n],e,n,a);else p(t,e,0,a)}e.bindBuffer(e.UNIFORM_BUFFER,null)}function p(t,n,r,i){if(h(t,n,r,i)===!0){let n=t.__offset,r=t.value;if(Array.isArray(r)){let e=0;for(let n=0;n<r.length;n++){let i=r[n],a=_(i);m(i,t.__data,e),typeof i!=`number`&&typeof i!=`boolean`&&!i.isMatrix3&&!ArrayBuffer.isView(i)&&(e+=a.storage/Float32Array.BYTES_PER_ELEMENT)}}else m(r,t.__data,0);e.bufferSubData(e.UNIFORM_BUFFER,n,t.__data)}}function m(e,t,n){typeof e==`number`||typeof e==`boolean`?t[0]=e:e.isMatrix3?(t[0]=e.elements[0],t[1]=e.elements[1],t[2]=e.elements[2],t[3]=0,t[4]=e.elements[3],t[5]=e.elements[4],t[6]=e.elements[5],t[7]=0,t[8]=e.elements[6],t[9]=e.elements[7],t[10]=e.elements[8],t[11]=0):ArrayBuffer.isView(e)?t.set(new e.constructor(e.buffer,e.byteOffset,t.length)):e.toArray(t,n)}function h(e,t,n,r){let i=e.value,a=t+`_`+n;if(r[a]===void 0)return r[a]=typeof i==`number`||typeof i==`boolean`?i:ArrayBuffer.isView(i)?i.slice():i.clone(),!0;{let e=r[a];if(typeof i==`number`||typeof i==`boolean`){if(e!==i)return r[a]=i,!0}else if(ArrayBuffer.isView(i))return!0;else if(e.equals(i)===!1)return e.copy(i),!0}return!1}function g(e){let t=e.uniforms,n=0;for(let e=0,r=t.length;e<r;e++){let r=Array.isArray(t[e])?t[e]:[t[e]];for(let e=0,t=r.length;e<t;e++){let t=r[e],i=Array.isArray(t.value)?t.value:[t.value];for(let e=0,r=i.length;e<r;e++){let r=i[e],a=_(r),o=n%16,s=o%a.boundary,c=o+s;n+=s,c!==0&&16-c<a.storage&&(n+=16-c),t.__data=new Float32Array(a.storage/Float32Array.BYTES_PER_ELEMENT),t.__offset=n,n+=a.storage}}}let r=n%16;return r>0&&(n+=16-r),e.__size=n,e.__cache={},this}function _(e){let t={boundary:0,storage:0};return typeof e==`number`||typeof e==`boolean`?(t.boundary=4,t.storage=4):e.isVector2?(t.boundary=8,t.storage=8):e.isVector3||e.isColor?(t.boundary=16,t.storage=12):e.isVector4?(t.boundary=16,t.storage=16):e.isMatrix3?(t.boundary=48,t.storage=48):e.isMatrix4?(t.boundary=64,t.storage=64):e.isTexture?K(`WebGLRenderer: Texture samplers can not be part of an uniforms group.`):ArrayBuffer.isView(e)?(t.boundary=16,t.storage=e.byteLength):K(`WebGLRenderer: Unsupported uniform value type.`,e),t}function v(t){let n=t.target;n.removeEventListener(`dispose`,v);let r=o.indexOf(n.__bindingPointIndex);o.splice(r,1),e.deleteBuffer(i[n.id]),delete i[n.id],delete a[n.id]}function y(){for(let t in i)e.deleteBuffer(i[t]);o=[],i={},a={}}return{bind:c,update:l,dispose:y}}var my=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),hy=null;function gy(){return hy===null&&(hy=new em(my,16,16,ou,ql),hy.name=`DFG_LUT`,hy.minFilter=Ll,hy.magFilter=Ll,hy.wrapS=Ml,hy.wrapT=Ml,hy.generateMipmaps=!1,hy.needsUpdate=!0),hy}var _y=class{constructor(e={}){let{canvas:t=ld(),context:n=null,depth:r=!0,stencil:i=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:s=!0,preserveDrawingBuffer:c=!1,powerPreference:l=`default`,failIfMajorPerformanceCaveat:u=!1,reversedDepthBuffer:d=!1,outputBufferType:f=Bl}=e;this.isWebGLRenderer=!0;let p;if(n!==null){if(typeof WebGLRenderingContext<`u`&&n instanceof WebGLRenderingContext)throw Error(`THREE.WebGLRenderer: WebGL 1 is not supported since r163.`);p=n.getContextAttributes().alpha}else p=a;let m=f,h=new Set([cu,su,au]),g=new Set([Bl,Gl,Ul,Xl,Jl,Yl]),_=new Uint32Array(4),v=new Int32Array(4),y=new Y,b=null,x=null,S=[],C=[],w=null;this.domElement=t,this.debug={checkShaderErrors:!0,diagnostics:{keywords:!1},onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=0,this.toneMappingExposure=1,this.transmissionResolutionScale=1;let T=this,E=!1,D=null,O=null,k=null,A=null;this._outputColorSpace=$u;let j=0,ee=0,M=null,te=-1,ne=null,re=new Wd,N=new Wd,ie=null,P=new Z(0),ae=0,oe=t.width,F=t.height,I=1,se=null,L=null,R=new Wd(0,0,oe,F),ce=new Wd(0,0,oe,F),le=!1,ue=new pm,de=!1,fe=!1,pe=new Yd,me=new Y,he=new Wd,ge={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},z=!1;function _e(){return M===null?I:1}let B=n;function ve(e,n){return t.getContext(e,n)}let ye,be,V,H,U,W,xe,Se,Ce,we,Te,Ee,De,Oe,ke,Ae,je,Me,Ne,Pe,Fe,Ie,G;try{let e={alpha:!0,depth:r,stencil:i,antialias:o,premultipliedAlpha:s,preserveDrawingBuffer:c,powerPreference:l,failIfMajorPerformanceCaveat:u};if(`setAttribute`in t&&t.setAttribute(`data-engine`,`three.js r186`),t.addEventListener(`webglcontextlost`,ze,!1),t.addEventListener(`webglcontextrestored`,Be,!1),t.addEventListener(`webglcontextcreationerror`,Ve,!1),B===null){let t=`webgl2`;if(B=ve(t,e),B===null)throw ve(t)?Error(`THREE.WebGLRenderer: Error creating WebGL context with your selected attributes.`):Error(`THREE.WebGLRenderer: Error creating WebGL context.`)}Le()}catch(e){throw t.removeEventListener(`webglcontextlost`,ze,!1),t.removeEventListener(`webglcontextrestored`,Be,!1),t.removeEventListener(`webglcontextcreationerror`,Ve,!1),q(`WebGLRenderer: `+e.message),e}function Le(){ye=new Fg(B),ye.init(),Fe=new ay(B,ye),be=new ug(B,ye,e,Fe),V=new ry(B,ye),be.reversedDepthBuffer&&d&&V.buffers.depth.setReversed(!0),O=B.createFramebuffer(),k=B.createFramebuffer(),A=B.createFramebuffer(),H=new Rg(B),U=new Lv,W=new iy(B,ye,V,U,be,Fe,H),xe=new Pg(T),Se=new ng(B),Ie=new cg(B,Se),Ce=new Ig(B,Se,H,Ie),we=new Bg(B,Ce,Se,Ie,H),Me=new zg(B,be,W),ke=new dg(U),Te=new Iv(T,xe,ye,be,Ie,ke),Ee=new fy(T,U),De=new Vv,Oe=new Jv(ye),je=new sg(T,xe,V,we,p,s),Ae=new ny(T,we,be),G=new py(B,H,be,V),Ne=new lg(B,ye,H),Pe=new Lg(B,ye,H),H.programs=Te.programs,T.capabilities=be,T.extensions=ye,T.properties=U,T.renderLists=De,T.shadowMap=Ae,T.state=V,T.info=H}m!==1009&&(w=new Hg(m,t.width,t.height,o,r,i));let Re=new ly(T,B);this.xr=Re,this.getContext=function(){return B},this.getContextAttributes=function(){return B.getContextAttributes()},this.forceContextLoss=function(){let e=ye.get(`WEBGL_lose_context`);e&&e.loseContext()},this.forceContextRestore=function(){let e=ye.get(`WEBGL_lose_context`);e&&e.restoreContext()},this.getPixelRatio=function(){return I},this.setPixelRatio=function(e){e!==void 0&&(I=e,this.setSize(oe,F,!1))},this.getSize=function(e){return e.set(oe,F)},this.setSize=function(e,n,r=!0){Re.isPresenting?K(`WebGLRenderer: Can't change size while VR device is presenting.`):(oe=e,F=n,t.width=Math.floor(e*I),t.height=Math.floor(n*I),r===!0&&(t.style.width=e+`px`,t.style.height=n+`px`),w!==null&&w.setSize(t.width,t.height),this.setViewport(0,0,e,n))},this.getDrawingBufferSize=function(e){return e.set(oe*I,F*I).floor()},this.setDrawingBufferSize=function(e,n,r){oe=e,F=n,I=r,t.width=Math.floor(e*r),t.height=Math.floor(n*r),this.setViewport(0,0,e,n)},this.setEffects=function(e){if(m===1009)q(`WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.`);else{if(e){for(let t=0;t<e.length;t++)if(e[t].isOutputPass===!0){K(`WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.`);break}}w.setEffects(e||[])}},this.getCurrentViewport=function(e){return e.copy(re)},this.getViewport=function(e){return e.copy(R)},this.setViewport=function(e,t,n,r){e.isVector4?R.set(e.x,e.y,e.z,e.w):R.set(e,t,n,r),V.viewport(re.copy(R).multiplyScalar(I).round())},this.getScissor=function(e){return e.copy(ce)},this.setScissor=function(e,t,n,r){e.isVector4?ce.set(e.x,e.y,e.z,e.w):ce.set(e,t,n,r),V.scissor(N.copy(ce).multiplyScalar(I).round())},this.getScissorTest=function(){return le},this.setScissorTest=function(e){V.setScissorTest(le=e)},this.setOpaqueSort=function(e){se=e},this.setTransparentSort=function(e){L=e},this.getClearColor=function(e){return e.copy(je.getClearColor())},this.setClearColor=function(){je.setClearColor(...arguments)},this.getClearAlpha=function(){return je.getClearAlpha()},this.setClearAlpha=function(){je.setClearAlpha(...arguments)},this.clear=function(e=!0,t=!0,n=!0){let r=0;if(e){let e=!1;if(M!==null){let t=M.texture.format;e=h.has(t)}if(e){let e=M.texture.type,t=g.has(e),n=je.getClearColor(),r=je.getClearAlpha(),i=n.r,a=n.g,o=n.b;t?(_[0]=i,_[1]=a,_[2]=o,_[3]=r,B.clearBufferuiv(B.COLOR,0,_)):(v[0]=i,v[1]=a,v[2]=o,v[3]=r,B.clearBufferiv(B.COLOR,0,v))}else r|=B.COLOR_BUFFER_BIT}t&&(r|=B.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),n&&(r|=B.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),r!==0&&B.clear(r)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(e){e.setRenderer(this),D=e},this.dispose=function(){t.removeEventListener(`webglcontextlost`,ze,!1),t.removeEventListener(`webglcontextrestored`,Be,!1),t.removeEventListener(`webglcontextcreationerror`,Ve,!1),je.dispose(),De.dispose(),Oe.dispose(),U.dispose(),xe.dispose(),we.dispose(),Ie.dispose(),G.dispose(),Te.dispose(),Re.dispose(),Re.removeEventListener(`sessionstart`,Je),Re.removeEventListener(`sessionend`,Ye),Xe.stop()};function ze(e){e.preventDefault(),dd(`WebGLRenderer: Context Lost.`),E=!0}function Be(){dd(`WebGLRenderer: Context Restored.`),E=!1;let e=H.autoReset,t=Ae.enabled,n=Ae.autoUpdate,r=Ae.needsUpdate,i=Ae.type;Le(),H.autoReset=e,Ae.enabled=t,Ae.autoUpdate=n,Ae.needsUpdate=r,Ae.type=i}function Ve(e){q(`WebGLRenderer: A WebGL context could not be created. Reason: `,e.statusMessage)}function He(e){let t=e.target;t.removeEventListener(`dispose`,He),Ue(t)}function Ue(e){We(e),U.remove(e)}function We(e){let t=U.get(e).programs;t!==void 0&&(t.forEach(function(e){Te.releaseProgram(e)}),e.isShaderMaterial&&Te.releaseShaderCache(e))}this.renderBufferDirect=function(e,t,n,r,i,a){t===null&&(t=ge);let o=i.isMesh&&i.matrixWorld.determinantAffine()<0,s=ot(e,t,n,r,i);V.setMaterial(r,o);let c=n.index,l=1;if(r.wireframe===!0){if(c=Ce.getWireframeAttribute(n),c===void 0)return;l=2}let u=n.drawRange,d=n.attributes.position,f=u.start*l,p=(u.start+u.count)*l;a!==null&&(f=Math.max(f,a.start*l),p=Math.min(p,(a.start+a.count)*l)),c===null?d!=null&&(f=Math.max(f,0),p=Math.min(p,d.count)):(f=Math.max(f,0),p=Math.min(p,c.count));let m=p-f;if(m<0||m===1/0)return;Ie.setup(i,r,s,n,c);let h,g=Ne;if(c!==null&&(h=Se.get(c),g=Pe,g.setIndex(h)),i.isMesh)r.wireframe===!0?(V.setLineWidth(r.wireframeLinewidth*_e()),g.setMode(B.LINES)):g.setMode(B.TRIANGLES);else if(i.isLine){let e=r.linewidth;e===void 0&&(e=1),V.setLineWidth(e*_e()),i.isLineSegments?g.setMode(B.LINES):i.isLineLoop?g.setMode(B.LINE_LOOP):g.setMode(B.LINE_STRIP)}else i.isPoints?g.setMode(B.POINTS):i.isSprite&&g.setMode(B.TRIANGLES);if(i.isBatchedMesh){if(ye.get(`WEBGL_multi_draw`))g.renderMultiDraw(i._multiDrawStarts,i._multiDrawCounts,i._multiDrawCount);else{let e=i._multiDrawStarts,t=i._multiDrawCounts,n=i._multiDrawCount,a=c?Se.get(c).bytesPerElement:1,o=U.get(r).currentProgram.getUniforms();for(let r=0;r<n;r++)o.setValue(B,`_gl_DrawID`,r),g.render(e[r]/a,t[r])}}else if(i.isInstancedMesh)g.renderInstances(f,m,i.count);else if(n.isInstancedBufferGeometry){let e=n._maxInstanceCount===void 0?1/0:n._maxInstanceCount,t=Math.min(n.instanceCount,e);g.renderInstances(f,m,t)}else g.render(f,m)};function Ge(e,t,n,r){D!==null&&e.isNodeMaterial&&D.setObject(r,e),de===!0&&ke.setState(e,n,!1),e.transparent===!0&&e.side===2&&e.forceSinglePass===!1?(e.side=1,e.needsUpdate=!0,nt(e,t,r),e.side=0,e.needsUpdate=!0,nt(e,t,r),e.side=2):nt(e,t,r)}this.compile=function(e,t,n=null){n===null&&(n=e),D!==null&&D.renderStart(e,t,n),x=Oe.get(n),x.init(t),C.push(x),n.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(x.pushLight(e),e.castShadow&&x.pushShadow(e))}),e!==n&&e.traverseVisible(function(e){e.isLight&&e.layers.test(t.layers)&&(x.pushLight(e),e.castShadow&&x.pushShadow(e))}),x.setupLights(),D!==null&&D.updateLights(x.state.lightsArray),fe=this.localClippingEnabled,de=ke.init(this.clippingPlanes,fe),de===!0&&ke.setGlobalState(this.clippingPlanes,t),D!==null&&Ae.render(x.state.shadowsArray,n,t);let r=new Set;return e.traverse(function(e){if(!(e.isMesh||e.isPoints||e.isLine||e.isSprite))return;let i=e.material;if(i){if(Array.isArray(i))for(let a=0;a<i.length;a++){let o=i[a];Ge(o,n,t,e),r.add(o)}else Ge(i,n,t,e),r.add(i)}}),x=C.pop(),D!==null&&D.renderEnd(),r},this.compileAsync=function(e,t,n=null){let r=this.compile(e,t,n);return new Promise(t=>{function n(){r.forEach(function(e){let t=U.get(e).currentProgram;(t===void 0||t.isReady())&&r.delete(e)}),r.size===0?t(e):setTimeout(n,10)}ye.get(`KHR_parallel_shader_compile`)===null?setTimeout(n,10):n()})};let Ke=null;function qe(e){Ke&&Ke(e)}function Je(){Xe.stop()}function Ye(){Xe.start()}let Xe=new tg;Xe.setAnimationLoop(qe),typeof self<`u`&&Xe.setContext(self),this.setAnimationLoop=function(e){Ke=e,Re.setAnimationLoop(e),e===null?Xe.stop():Xe.start()},Re.addEventListener(`sessionstart`,Je),Re.addEventListener(`sessionend`,Ye),this.render=function(e,t){if(t!==void 0&&t.isCamera!==!0){q(`WebGLRenderer.render: camera is not an instance of THREE.Camera.`);return}if(E===!0)return;D!==null&&D.renderStart(e,t);let n=Re.enabled===!0&&Re.isPresenting===!0,r=w!==null&&(M===null||n)&&w.begin(T,M);if(e.matrixWorldAutoUpdate===!0&&e.updateMatrixWorld(),t.parent===null&&t.matrixWorldAutoUpdate===!0&&t.updateMatrixWorld(),Re.enabled===!0&&Re.isPresenting===!0&&(w===null||w.isCompositing()===!1)&&(Re.cameraAutoUpdate===!0&&Re.updateCamera(t),t=Re.getCamera()),e.isScene===!0&&e.onBeforeRender(T,e,t,M),x=Oe.get(e,C.length),x.init(t),x.state.textureUnits=W.getTextureUnits(),C.push(x),pe.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),ue.setFromProjectionMatrix(pe,ad,t.reversedDepth),fe=this.localClippingEnabled,de=ke.init(this.clippingPlanes,fe),b=De.get(e,S.length),b.init(),S.push(b),Re.enabled===!0&&Re.isPresenting===!0){let e=T.xr.getDepthSensingMesh();e!==null&&Ze(e,t,-1/0,T.sortObjects)}Ze(e,t,0,T.sortObjects),b.finish(),D!==null&&D.updateLights(x.state.lightsArray),T.sortObjects===!0&&b.sort(se,L),z=Re.enabled===!1||Re.isPresenting===!1||Re.hasDepthSensing()===!1,z&&je.addToRenderList(b,e),this.info.render.frame++,this.info.autoReset===!0&&this.info.reset(),de===!0&&ke.beginShadows();let i=x.state.shadowsArray;if(Ae.render(i,e,t),de===!0&&ke.endShadows(),(r&&w.hasRenderPass())===!1){let n=b.opaque,r=b.transmissive;if(x.setupLights(),t.isArrayCamera){let i=t.cameras;if(r.length>0)for(let t=0,a=i.length;t<a;t++){let a=i[t];$e(n,r,e,a)}z&&je.render(e);for(let t=0,n=i.length;t<n;t++){let n=i[t];Qe(b,e,n,n.viewport)}}else r.length>0&&$e(n,r,e,t),z&&je.render(e),Qe(b,e,t)}M!==null&&ee===0&&(W.updateMultisampleRenderTarget(M),W.updateRenderTargetMipmap(M)),r&&w.end(T),e.isScene===!0&&e.onAfterRender(T,e,t),Ie.resetDefaultState(),te=-1,ne=null,C.pop(),C.length>0?(x=C[C.length-1],W.setTextureUnits(x.state.textureUnits),de===!0&&ke.setGlobalState(T.clippingPlanes,x.state.camera)):x=null,S.pop(),b=S.length>0?S[S.length-1]:null,D!==null&&D.renderEnd()};function Ze(e,t,n,r){if(e.visible===!1)return;if(e.layers.test(t.layers)){if(e.isGroup)n=e.renderOrder;else if(e.isLOD)e.autoUpdate===!0&&e.update(t);else if(e.isLightProbeGrid)x.pushLightProbeGrid(e);else if(e.isLight)x.pushLight(e),e.castShadow&&x.pushShadow(e);else if(e.isSprite){if(!e.frustumCulled||e.intersectsFrustum(ue)){r&&he.setFromMatrixPosition(e.matrixWorld).applyMatrix4(pe);let i=we.update(e),a=e.material;a.visible&&b.push(e,i,a,n,he.z,null,t)}}else if((e.isMesh||e.isLine||e.isPoints)&&(!e.frustumCulled||e.intersectsFrustum(ue))){let i=we.update(e),a=e.material;if(r&&(e.boundingSphere===void 0?(i.boundingSphere===null&&i.computeBoundingSphere(),he.copy(i.boundingSphere.center)):(e.boundingSphere===null&&e.computeBoundingSphere(),he.copy(e.boundingSphere.center)),he.applyMatrix4(e.matrixWorld).applyMatrix4(pe)),Array.isArray(a)){let r=i.groups;for(let o=0,s=r.length;o<s;o++){let s=r[o],c=a[s.materialIndex];c&&c.visible&&b.push(e,i,c,n,he.z,s,t)}}else a.visible&&b.push(e,i,a,n,he.z,null,t)}}let i=e.children;for(let e=0,a=i.length;e<a;e++)Ze(i[e],t,n,r)}function Qe(e,t,n,r){let{opaque:i,transmissive:a,transparent:o}=e;x.setupLightsView(n),de===!0&&ke.setGlobalState(T.clippingPlanes,n),r&&V.viewport(re.copy(r)),i.length>0&&et(i,t,n),a.length>0&&et(a,t,n),o.length>0&&et(o,t,n),V.buffers.depth.setTest(!0),V.buffers.depth.setMask(!0),V.buffers.color.setMask(!0),V.setPolygonOffset(!1)}function $e(e,t,n,r){if((n.isScene===!0?n.overrideMaterial:null)!==null)return;if(x.state.transmissionRenderTarget[r.id]===void 0){let e=ye.has(`EXT_color_buffer_half_float`)||ye.has(`EXT_color_buffer_float`);x.state.transmissionRenderTarget[r.id]=new Kd(1,1,{generateMipmaps:!0,type:e?ql:Bl,minFilter:zl,samples:Math.max(4,be.samples),stencilBuffer:i,resolveDepthBuffer:!1,resolveStencilBuffer:!1,storeMultisampledDepthBuffer:!1,storeMultisampledStencilBuffer:!1,colorSpace:Nd.workingColorSpace})}let a=x.state.transmissionRenderTarget[r.id],o=r.viewport||re;a.setSize(o.z*T.transmissionResolutionScale,o.w*T.transmissionResolutionScale);let s=T.getRenderTarget(),c=T.getActiveCubeFace(),l=T.getActiveMipmapLevel();T.setRenderTarget(a),T.getClearColor(P),ae=T.getClearAlpha(),ae<1&&T.setClearColor(16777215,.5),T.clear(),z&&je.render(n);let u=T.toneMapping;T.toneMapping=0;let d=r.viewport;if(r.viewport!==void 0&&(r.viewport=void 0),x.setupLightsView(r),de===!0&&ke.setGlobalState(T.clippingPlanes,r),et(e,n,r),W.updateMultisampleRenderTarget(a),W.updateRenderTargetMipmap(a),ye.has(`WEBGL_multisampled_render_to_texture`)===!1){let e=!1;for(let i=0,a=t.length;i<a;i++){let{object:a,geometry:o,material:s,group:c}=t[i];if(s.side===2&&a.layers.test(r.layers)){let t=s.side;s.side=1,s.needsUpdate=!0,tt(a,n,r,o,s,c),s.side=t,s.needsUpdate=!0,e=!0}}e===!0&&(W.updateMultisampleRenderTarget(a),W.updateRenderTargetMipmap(a))}T.setRenderTarget(s,c,l),T.setClearColor(P,ae),d!==void 0&&(r.viewport=d),T.toneMapping=u}function et(e,t,n){let r=t.isScene===!0?t.overrideMaterial:null;for(let i=0,a=e.length;i<a;i++){let a=e[i],{object:o,geometry:s,group:c}=a,l=a.material;l.allowOverride===!0&&r!==null&&(l=r),o.layers.test(n.layers)&&tt(o,t,n,s,l,c)}}function tt(e,t,n,r,i,a){D!==null&&i.isNodeMaterial&&D.setObject(e,i),e.onBeforeRender(T,t,n,r,i,a),e.modelViewMatrix.multiplyMatrices(n.matrixWorldInverse,e.matrixWorld),e.normalMatrix.getNormalMatrix(e.modelViewMatrix),i.onBeforeRender(T,t,n,r,e,a),i.transparent===!0&&i.side===2&&i.forceSinglePass===!1?(i.side=1,i.needsUpdate=!0,T.renderBufferDirect(n,t,r,i,e,a),i.side=0,i.needsUpdate=!0,T.renderBufferDirect(n,t,r,i,e,a),i.side=2):T.renderBufferDirect(n,t,r,i,e,a),e.onAfterRender(T,t,n,r,i,a)}function nt(e,t,n){t.isScene!==!0&&(t=ge);let r=U.get(e),i=x.state.lights,a=x.state.shadowsArray,o=i.state.version,s=Te.getParameters(e,i.state,a,t,n,x.state.lightProbeGridArray),c=Te.getProgramCacheKey(s),l=r.programs;r.environment=e.isMeshStandardMaterial||e.isMeshLambertMaterial||e.isMeshPhongMaterial?t.environment:null,r.fog=t.fog;let u=e.isMeshStandardMaterial||e.isMeshLambertMaterial&&!e.envMap||e.isMeshPhongMaterial&&!e.envMap;r.envMap=xe.get(e.envMap||r.environment,u),r.envMapRotation=r.environment!==null&&e.envMap===null?t.environmentRotation:e.envMapRotation,l===void 0&&(e.addEventListener(`dispose`,He),l=new Map,r.programs=l);let d=l.get(c);if(d!==void 0){if(r.currentProgram===d&&r.lightsStateVersion===o)return it(e,s),d}else s.uniforms=Te.getUniforms(e),D!==null&&e.isNodeMaterial&&D.build(e,n,s),e.onBeforeCompile(s,T),d=Te.acquireProgram(s,c),l.set(c,d),r.uniforms=s.uniforms;let f=r.uniforms;return(!e.isShaderMaterial&&!e.isRawShaderMaterial||e.clipping===!0)&&(f.clippingPlanes=ke.uniform),it(e,s),r.needsLights=ct(e),r.lightsStateVersion=o,r.needsLights&&(f.ambientLightColor.value=i.state.ambient,f.lightProbe.value=i.state.probe,f.sunLights.value=i.state.sun,f.sunLightShadows.value=i.state.sunShadow,f.directionalLights.value=i.state.directional,f.directionalLightShadows.value=i.state.directionalShadow,f.spotLights.value=i.state.spot,f.spotLightShadows.value=i.state.spotShadow,f.rectAreaLights.value=i.state.rectArea,f.ltc_1.value=i.state.rectAreaLTC1,f.ltc_2.value=i.state.rectAreaLTC2,f.pointLights.value=i.state.point,f.pointLightShadows.value=i.state.pointShadow,f.hemisphereLights.value=i.state.hemi,f.sunShadowMatrix.value=i.state.sunShadowMatrix,f.sunShadowCascade.value=i.state.sunShadowCascade,f.directionalShadowMatrix.value=i.state.directionalShadowMatrix,f.spotLightMatrix.value=i.state.spotLightMatrix,f.spotLightMap.value=i.state.spotLightMap,f.pointShadowMatrix.value=i.state.pointShadowMatrix),r.lightProbeGrid=x.state.lightProbeGridArray.length>0,r.currentProgram=d,r.uniformsList=null,d}function rt(e){if(e.uniformsList===null){let t=e.currentProgram.getUniforms();e.uniformsList=Y_.seqWithValue(t.seq,e.uniforms)}return e.uniformsList}function it(e,t){let n=U.get(e);n.outputColorSpace=t.outputColorSpace,n.batching=t.batching,n.batchingColor=t.batchingColor,n.instancing=t.instancing,n.instancingColor=t.instancingColor,n.instancingMorph=t.instancingMorph,n.skinning=t.skinning,n.morphTargets=t.morphTargets,n.morphNormals=t.morphNormals,n.morphColors=t.morphColors,n.morphTargetsCount=t.morphTargetsCount,n.numClippingPlanes=t.numClippingPlanes,n.numIntersection=t.numClipIntersection,n.vertexAlphas=t.vertexAlphas,n.vertexTangents=t.vertexTangents,n.toneMapping=t.toneMapping}function at(e,t){if(e.length===0)return null;if(e.length===1)return e[0].texture===null?null:e[0];y.setFromMatrixPosition(t.matrixWorld);for(let t=0,n=e.length;t<n;t++){let n=e[t];if(n.texture!==null&&n.boundingBox.containsPoint(y))return n}return null}function ot(e,t,n,r,i){t.isScene!==!0&&(t=ge),W.resetTextureUnits();let a=t.fog,o=r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial?t.environment:null,s=M===null?T.outputColorSpace:M.isXRRenderTarget===!0?M.texture.colorSpace:Nd.workingColorSpace,c=r.isMeshStandardMaterial||r.isMeshLambertMaterial&&!r.envMap||r.isMeshPhongMaterial&&!r.envMap,l=xe.get(r.envMap||o,c),u=r.vertexColors===!0&&!!n.attributes.color&&n.attributes.color.itemSize===4,d=!!n.attributes.tangent&&(!!r.normalMap||r.anisotropy>0),f=!!n.morphAttributes.position,p=!!n.morphAttributes.normal,m=!!n.morphAttributes.color,h=0;r.toneMapped&&(M===null||M.isXRRenderTarget===!0)&&(h=T.toneMapping);let g=n.morphAttributes.position||n.morphAttributes.normal||n.morphAttributes.color,_=g===void 0?0:g.length,v=U.get(r),y=x.state.lights;if(de===!0&&(fe===!0||e!==ne)){let t=e===ne&&r.id===te;ke.setState(r,e,t)}let b=!1;r.version===v.__version?v.needsLights&&v.lightsStateVersion!==y.state.version?b=!0:v.outputColorSpace===s?i.isBatchedMesh&&v.batching===!1||!i.isBatchedMesh&&v.batching===!0||i.isBatchedMesh&&v.batchingColor===!0&&i._colorsTexture===null||i.isBatchedMesh&&v.batchingColor===!1&&i._colorsTexture!==null||i.isInstancedMesh&&v.instancing===!1||!i.isInstancedMesh&&v.instancing===!0||i.isSkinnedMesh&&v.skinning===!1||!i.isSkinnedMesh&&v.skinning===!0||i.isInstancedMesh&&v.instancingColor===!0&&i.instanceColor===null||i.isInstancedMesh&&v.instancingColor===!1&&i.instanceColor!==null||i.isInstancedMesh&&v.instancingMorph===!0&&i.morphTexture===null||i.isInstancedMesh&&v.instancingMorph===!1&&i.morphTexture!==null?b=!0:v.envMap===l?r.fog===!0&&v.fog!==a||v.numClippingPlanes!==void 0&&(v.numClippingPlanes!==ke.numPlanes||v.numIntersection!==ke.numIntersection)?b=!0:v.vertexAlphas===u&&v.vertexTangents===d&&v.morphTargets===f&&v.morphNormals===p&&v.morphColors===m&&v.toneMapping===h&&v.morphTargetsCount===_?!!v.lightProbeGrid!=x.state.lightProbeGridArray.length>0&&(b=!0):b=!0:b=!0:b=!0:(b=!0,v.__version=r.version);let S=v.currentProgram;b===!0&&(S=nt(r,t,i),D&&r.isNodeMaterial&&D.onUpdateProgram(r,S,v));let C=!1,w=!1,E=!1,O=S.getUniforms(),k=v.uniforms;if(V.useProgram(S.program)&&(C=!0,w=!0,E=!0),r.id!==te&&(te=r.id,w=!0),v.needsLights){let e=at(x.state.lightProbeGridArray,i);v.lightProbeGrid!==e&&(v.lightProbeGrid=e,w=!0)}if(C||ne!==e){V.buffers.depth.getReversed()&&e.reversedDepth!==!0&&(e._reversedDepth=!0,e.updateProjectionMatrix()),O.setValue(B,`projectionMatrix`,e.projectionMatrix),O.setValue(B,`viewMatrix`,e.matrixWorldInverse);let t=O.map.cameraPosition;t!==void 0&&t.setValue(B,me.setFromMatrixPosition(e.matrixWorld)),be.logarithmicDepthBuffer&&O.setValue(B,`logDepthBufFC`,2/(Math.log(e.far+1)/Math.LN2)),(r.isMeshPhongMaterial||r.isMeshToonMaterial||r.isMeshLambertMaterial||r.isMeshBasicMaterial||r.isMeshStandardMaterial||r.isShaderMaterial)&&O.setValue(B,`isOrthographic`,e.isOrthographicCamera===!0),ne!==e&&(ne=e,w=!0,E=!0)}if(v.needsLights&&(y.state.sunShadowMap.length>0&&O.setValue(B,`sunShadowMap`,y.state.sunShadowMap,W),y.state.directionalShadowMap.length>0&&O.setValue(B,`directionalShadowMap`,y.state.directionalShadowMap,W),y.state.spotShadowMap.length>0&&O.setValue(B,`spotShadowMap`,y.state.spotShadowMap,W),y.state.pointShadowMap.length>0&&O.setValue(B,`pointShadowMap`,y.state.pointShadowMap,W)),i.isSkinnedMesh){O.setOptional(B,i,`bindMatrix`),O.setOptional(B,i,`bindMatrixInverse`);let e=i.skeleton;e&&(e.boneTexture===null&&e.computeBoneTexture(),O.setValue(B,`boneTexture`,e.boneTexture,W))}i.isBatchedMesh&&(O.setOptional(B,i,`batchingTexture`),O.setValue(B,`batchingTexture`,i._matricesTexture,W),O.setOptional(B,i,`batchingIdTexture`),O.setValue(B,`batchingIdTexture`,i._indirectTexture,W),O.setOptional(B,i,`batchingColorTexture`),i._colorsTexture!==null&&O.setValue(B,`batchingColorTexture`,i._colorsTexture,W));let A=n.morphAttributes;if((A.position!==void 0||A.normal!==void 0||A.color!==void 0)&&Me.update(i,n,S),(w||v.receiveShadow!==i.receiveShadow)&&(v.receiveShadow=i.receiveShadow,O.setValue(B,`receiveShadow`,i.receiveShadow)),(r.isMeshStandardMaterial||r.isMeshLambertMaterial||r.isMeshPhongMaterial)&&r.envMap===null&&t.environment!==null&&(k.envMapIntensity.value=t.environmentIntensity),k.dfgLUT!==void 0&&(k.dfgLUT.value=gy()),w){if(O.setValue(B,`toneMappingExposure`,T.toneMappingExposure),v.needsLights&&st(k,E),a&&r.fog===!0&&Ee.refreshFogUniforms(k,a),Ee.refreshMaterialUniforms(k,r,I,F,x.state.transmissionRenderTarget[e.id]),v.needsLights&&v.lightProbeGrid){let e=v.lightProbeGrid;k.probesSH.value=e.texture,k.probesMin.value.copy(e.boundingBox.min),k.probesMax.value.copy(e.boundingBox.max),k.probesResolution.value.copy(e.resolution)}Y_.upload(B,rt(v),k,W)}if(r.isShaderMaterial&&r.uniformsNeedUpdate===!0&&(Y_.upload(B,rt(v),k,W),r.uniformsNeedUpdate=!1),r.isSpriteMaterial&&O.setValue(B,`center`,i.center),O.setValue(B,`modelViewMatrix`,i.modelViewMatrix),O.setValue(B,`normalMatrix`,i.normalMatrix),O.setValue(B,`modelMatrix`,i.matrixWorld),r.uniformsGroups!==void 0){let e=r.uniformsGroups;for(let t=0,n=e.length;t<n;t++){let n=e[t];G.update(n,S),G.bind(n,S)}}return S}function st(e,t){e.ambientLightColor.needsUpdate=t,e.lightProbe.needsUpdate=t,e.sunLights.needsUpdate=t,e.sunLightShadows.needsUpdate=t,e.directionalLights.needsUpdate=t,e.directionalLightShadows.needsUpdate=t,e.pointLights.needsUpdate=t,e.pointLightShadows.needsUpdate=t,e.spotLights.needsUpdate=t,e.spotLightShadows.needsUpdate=t,e.rectAreaLights.needsUpdate=t,e.hemisphereLights.needsUpdate=t}function ct(e){return e.isMeshLambertMaterial||e.isMeshToonMaterial||e.isMeshPhongMaterial||e.isMeshStandardMaterial||e.isShadowMaterial||e.isShaderMaterial&&e.lights===!0}this.getActiveCubeFace=function(){return j},this.getActiveMipmapLevel=function(){return ee},this.getRenderTarget=function(){return M},this.setRenderTargetTextures=function(e,t,n){let r=U.get(e);r.__autoAllocateDepthBuffer=e.resolveDepthBuffer===!1,r.__autoAllocateDepthBuffer===!1&&(r.__useRenderToTexture=!1),U.get(e.texture).__webglTexture=t,U.get(e.depthTexture).__webglTexture=r.__autoAllocateDepthBuffer?void 0:n,r.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(e,t){let n=U.get(e);n.__webglFramebuffer=t,n.__useDefaultFramebuffer=t===void 0},this.setRenderTarget=function(e,t=0,n=0){M=e,j=t,ee=n;let r=null,i=!1,a=!1;if(e){let o=U.get(e);if(o.__useDefaultFramebuffer!==void 0){V.bindFramebuffer(B.FRAMEBUFFER,o.__webglFramebuffer),re.copy(e.viewport),N.copy(e.scissor),ie=e.scissorTest,V.viewport(re),V.scissor(N),V.setScissorTest(ie),te=-1;return}if(o.__webglFramebuffer===void 0)W.setupRenderTarget(e);else if(o.__hasExternalTextures)W.rebindTextures(e,U.get(e.texture).__webglTexture,U.get(e.depthTexture).__webglTexture);else if(e.depthBuffer){let t=e.depthTexture;if(o.__boundDepthTexture!==t){if(t!==null&&U.has(t)&&(e.width!==t.image.width||e.height!==t.image.height))throw Error(`THREE.WebGLRenderer: Attached DepthTexture is initialized to the incorrect size.`);W.setupDepthRenderbuffer(e)}}let s=e.texture;(s.isData3DTexture||s.isDataArrayTexture||s.isCompressedArrayTexture)&&(a=!0);let c=U.get(e).__webglFramebuffer;e.isWebGLCubeRenderTarget?(r=Array.isArray(c[t])?c[t][n]:c[t],i=!0):r=e.samples>0&&W.useMultisampledRTT(e)===!1?U.get(e).__webglMultisampledFramebuffer:Array.isArray(c)?c[n]:c,re.copy(e.viewport),N.copy(e.scissor),ie=e.scissorTest}else re.copy(R).multiplyScalar(I).floor(),N.copy(ce).multiplyScalar(I).floor(),ie=le;if(n!==0&&(r=O),V.bindFramebuffer(B.FRAMEBUFFER,r)&&V.drawBuffers(e,r),V.viewport(re),V.scissor(N),V.setScissorTest(ie),i){let r=U.get(e.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_CUBE_MAP_POSITIVE_X+t,r.__webglTexture,n)}else if(a){let r=t;for(let t=0;t<e.textures.length;t++){let i=U.get(e.textures[t]);B.framebufferTextureLayer(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0+t,i.__webglTexture,n,r)}}else if(e!==null&&n!==0){let t=U.get(e.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,t.__webglTexture,n)}te=-1};function lt(e){let t=U.get(e);return(t.__readFormat!==e.format||t.__readType!==e.type)&&(t.__readFormat=e.format,t.__readType=e.type,t.__formatReadable=be.textureFormatReadable(e.format),t.__typeReadable=be.textureTypeReadable(e.type)),t}this.readRenderTargetPixels=function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget)){q(`WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);return}let c=U.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c){V.bindFramebuffer(B.FRAMEBUFFER,c);try{let o=e.textures[s],c=o.format,l=o.type;e.textures.length>1&&B.readBuffer(B.COLOR_ATTACHMENT0+s);let u=lt(o);if(u.__formatReadable===!1){q(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.`);return}if(u.__typeReadable===!1){q(`WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.`);return}t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i&&B.readPixels(t,n,r,i,Fe.convert(c),Fe.convert(l),a)}finally{let e=M===null?null:U.get(M).__webglFramebuffer;V.bindFramebuffer(B.FRAMEBUFFER,e)}}},this.readRenderTargetPixelsAsync=async function(e,t,n,r,i,a,o,s=0){if(!(e&&e.isWebGLRenderTarget))throw Error(`THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.`);let c=U.get(e).__webglFramebuffer;if(e.isWebGLCubeRenderTarget&&o!==void 0&&(c=c[o]),c){if(t>=0&&t<=e.width-r&&n>=0&&n<=e.height-i){V.bindFramebuffer(B.FRAMEBUFFER,c);let o=e.textures[s],l=o.format,u=o.type;e.textures.length>1&&B.readBuffer(B.COLOR_ATTACHMENT0+s);let d=lt(o);if(d.__formatReadable===!1)throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.`);if(d.__typeReadable===!1)throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.`);let f=B.createBuffer();B.bindBuffer(B.PIXEL_PACK_BUFFER,f),B.bufferData(B.PIXEL_PACK_BUFFER,a.byteLength,B.STREAM_READ),B.readPixels(t,n,r,i,Fe.convert(l),Fe.convert(u),0),B.bindBuffer(B.PIXEL_PACK_BUFFER,null);let p=M===null?null:U.get(M).__webglFramebuffer;V.bindFramebuffer(B.FRAMEBUFFER,p);let m=B.fenceSync(B.SYNC_GPU_COMMANDS_COMPLETE,0);return B.flush(),await md(B,m,4),B.bindBuffer(B.PIXEL_PACK_BUFFER,f),B.getBufferSubData(B.PIXEL_PACK_BUFFER,0,a),B.bindBuffer(B.PIXEL_PACK_BUFFER,null),B.deleteBuffer(f),B.deleteSync(m),a}throw Error(`THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.`)}},this.copyFramebufferToTexture=function(e,t=null,n=0){let r=2**-n,i=Math.floor(e.image.width*r),a=Math.floor(e.image.height*r),o=t===null?0:t.x,s=t===null?0:t.y;W.setTexture2D(e,0),B.copyTexSubImage2D(B.TEXTURE_2D,n,0,0,o,s,i,a),V.unbindTexture()},this.copyTextureToTexture=function(e,t,n=null,r=null,i=0,a=0){let o,s,c,l,u,d,f,p,m,h=e.isCompressedTexture?e.mipmaps[a]:e.image;if(n!==null)o=n.max.x-n.min.x,s=n.max.y-n.min.y,c=n.isBox3?n.max.z-n.min.z:1,l=n.min.x,u=n.min.y,d=n.isBox3?n.min.z:0;else{let t=2**-i;o=Math.floor(h.width*t),s=Math.floor(h.height*t),c=e.isDataArrayTexture?h.depth:e.isData3DTexture?Math.floor(h.depth*t):1,l=0,u=0,d=0}r===null?(f=0,p=0,m=0):(f=r.x,p=r.y,m=r.z);let g=Fe.convert(t.format),_=Fe.convert(t.type),v;t.isData3DTexture?(W.setTexture3D(t,0),v=B.TEXTURE_3D):t.isDataArrayTexture||t.isCompressedArrayTexture?(W.setTexture2DArray(t,0),v=B.TEXTURE_2D_ARRAY):(W.setTexture2D(t,0),v=B.TEXTURE_2D),V.activeTexture(B.TEXTURE0),V.pixelStorei(B.UNPACK_FLIP_Y_WEBGL,t.flipY),V.pixelStorei(B.UNPACK_PREMULTIPLY_ALPHA_WEBGL,t.premultiplyAlpha),V.pixelStorei(B.UNPACK_ALIGNMENT,t.unpackAlignment);let y=V.getParameter(B.UNPACK_ROW_LENGTH),b=V.getParameter(B.UNPACK_IMAGE_HEIGHT),x=V.getParameter(B.UNPACK_SKIP_PIXELS),S=V.getParameter(B.UNPACK_SKIP_ROWS),C=V.getParameter(B.UNPACK_SKIP_IMAGES);V.pixelStorei(B.UNPACK_ROW_LENGTH,h.width),V.pixelStorei(B.UNPACK_IMAGE_HEIGHT,h.height),V.pixelStorei(B.UNPACK_SKIP_PIXELS,l),V.pixelStorei(B.UNPACK_SKIP_ROWS,u),V.pixelStorei(B.UNPACK_SKIP_IMAGES,d);let w=e.isDataArrayTexture||e.isData3DTexture,T=t.isDataArrayTexture||t.isData3DTexture;if(e.isDepthTexture){let n=U.get(e),r=U.get(t),h=U.get(n.__renderTarget),g=U.get(r.__renderTarget);V.bindFramebuffer(B.READ_FRAMEBUFFER,h.__webglFramebuffer),V.bindFramebuffer(B.DRAW_FRAMEBUFFER,g.__webglFramebuffer);for(let n=0;n<c;n++)w&&(B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,U.get(e).__webglTexture,i,d+n),B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,U.get(t).__webglTexture,a,m+n)),B.blitFramebuffer(l,u,o,s,f,p,o,s,B.DEPTH_BUFFER_BIT,B.NEAREST);V.bindFramebuffer(B.READ_FRAMEBUFFER,null),V.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else if(i!==0||e.isRenderTargetTexture||U.has(e)){let n=U.get(e),r=U.get(t);V.bindFramebuffer(B.READ_FRAMEBUFFER,k),V.bindFramebuffer(B.DRAW_FRAMEBUFFER,A);for(let e=0;e<c;e++)w?B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,n.__webglTexture,i,d+e):B.framebufferTexture2D(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,n.__webglTexture,i),T?B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,r.__webglTexture,a,m+e):B.framebufferTexture2D(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,r.__webglTexture,a),i===0?T?B.copyTexSubImage3D(v,a,f,p,m+e,l,u,o,s):B.copyTexSubImage2D(v,a,f,p,l,u,o,s):B.blitFramebuffer(l,u,o,s,f,p,o,s,B.COLOR_BUFFER_BIT,B.NEAREST);V.bindFramebuffer(B.READ_FRAMEBUFFER,null),V.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else T?e.isDataTexture||e.isData3DTexture?B.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h.data):t.isCompressedArrayTexture?B.compressedTexSubImage3D(v,a,f,p,m,o,s,c,g,h.data):B.texSubImage3D(v,a,f,p,m,o,s,c,g,_,h):e.isDataTexture?B.texSubImage2D(B.TEXTURE_2D,a,f,p,o,s,g,_,h.data):e.isCompressedTexture?B.compressedTexSubImage2D(B.TEXTURE_2D,a,f,p,h.width,h.height,g,h.data):B.texSubImage2D(B.TEXTURE_2D,a,f,p,o,s,g,_,h);V.pixelStorei(B.UNPACK_ROW_LENGTH,y),V.pixelStorei(B.UNPACK_IMAGE_HEIGHT,b),V.pixelStorei(B.UNPACK_SKIP_PIXELS,x),V.pixelStorei(B.UNPACK_SKIP_ROWS,S),V.pixelStorei(B.UNPACK_SKIP_IMAGES,C),a===0&&t.generateMipmaps&&B.generateMipmap(v),V.unbindTexture()},this.initRenderTarget=function(e){U.get(e).__webglFramebuffer===void 0&&W.setupRenderTarget(e)},this.initTexture=function(e){e.isCubeTexture?W.setTextureCube(e,0):e.isData3DTexture?W.setTexture3D(e,0):e.isDataArrayTexture||e.isCompressedArrayTexture?W.setTexture2DArray(e,0):W.setTexture2D(e,0),V.unbindTexture()},this.resetState=function(){j=0,ee=0,M=null,V.reset(),Ie.reset()},typeof __THREE_DEVTOOLS__<`u`&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent(`observe`,{detail:this}))}get coordinateSystem(){return ad}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorSpace=Nd._getDrawingBufferColorSpace(e),t.unpackColorSpace=Nd._getUnpackColorSpace()}},vy=32;function yy(e,t,n=0){let r=e*374761393+t*668265263+n*2147483647|0;return r=Math.imul(r^r>>>13,1274126177),((r^r>>>16)>>>0)/4294967296}function by(e){let t=new Uint8Array(4096);for(let n=0;n<vy;n++)for(let r=0;r<vy;r++){let[i,a,o]=e(r,n),s=(n*vy+r)*4;t[s]=Math.max(0,Math.min(255,i)),t[s+1]=Math.max(0,Math.min(255,a)),t[s+2]=Math.max(0,Math.min(255,o)),t[s+3]=255}let n=new em(t,vy,vy);return n.magFilter=n.minFilter=Pl,n.wrapS=n.wrapT=jl,n.colorSpace=$u,n.needsUpdate=!0,n}var xy=(e,t)=>[e[0]*t,e[1]*t,e[2]*t],Sy=(e,t)=>{let n=[92,74,62],r=e%8,i=r===0?.45:r===1?1.35:r===2?1.15:.85;return(t===20||t===21)&&(i*=t===20?.5:1.2),i*=.85+yy(e,t,1)*.3,Math.abs(e%8-5)+Math.abs(t%16-9)<=1?xy([200,186,160],.8+yy(e,t,2)*.3):xy(n,i)},Cy=(e,t)=>{let n=e%16==0||t%16==0,r=(e+t)%4==0&&e%16>3&&e%16<13&&t%16>3&&t%16<13;return xy([58,46,42],n?.35:r?.6:.9+yy(e,t,3)*.25)},wy=(e,t)=>xy([38,30,32],(t%8<2?1.3:.7)*(.85+yy(e,t,4)*.3));function Ty(e,t){let n=Math.round(16+Math.sin(t*.35)*6+Math.sin(t*.9)*2),r=t>8&&t<26&&Math.abs(e-(n+Math.round((t-8)*.6)))<=0;return Math.abs(e-n)<=1||r}var Ey=(e,t)=>Ty(e,t)?[255,255,255]:xy(Sy(e,t),.6),Dy=(e,t)=>Ty(e,t)?[255,255,255]:[0,0,0],Oy=null;function ky(){return Oy??={wall:by(Sy),floor:by(Cy),ceil:by(wy),vein:by(Ey),glow:by(Dy)},Oy}var Ay=new WeakMap,jy=.5;P.push(e=>{for(let t of e.events)if(t.type===`hit`){let n=e.ents.find(e=>e.id===t.data);n?.enemy&&(n.enemy.data.hitAt=e.t)}else if(t.type===`kill`){let n=Ay.get(e);n||Ay.set(e,n=[]),n.push({x:t.at[0],y:t.at[1],t:e.t,type:String(t.data)})}let t=Ay.get(e);t?.length&&Ay.set(e,t.filter(t=>e.t-t.t<jy));for(let t of e.ents)t.enemy&&t.enemy.data.maxHp===void 0&&(t.enemy.data.maxHp=t.enemy.hp)});var My=e=>e.enemy?e.enemy.readyAt-(N[e.enemy.type]?.cooldown??1):-1/0;function Ny(e,t=9,n=!1){let r=e.player;return e.ents.filter(e=>e.enemy&&e.enemy.data.noticed&&R(e,r)<=t&&(n||!N[e.enemy.type]?.hidden)).sort((e,t)=>R(e,r)-R(t,r))}ao.draw.push((e,t,n,r,i)=>{let a=e.player;for(let o of e.ents){if(!o.enemy||N[o.enemy.type]?.hidden||R(o,a)>9||!j(e,a.x,a.y,o.x,o.y))continue;let s=Math.max(2,i*.7);t.fillStyle=`#000`,t.fillRect((o.x-n)*i-s-1,(o.y-r)*i-s-1,s*2+2,s*2+2),t.fillStyle=o.enemy.data.noticed?`#ff3a28`:`#a04030`,t.fillRect((o.x-n)*i-s,(o.y-r)*i-s,s*2,s*2)}});var Py=(e,t,n,r,i)=>{for(let a=Math.floor(n-r);a<=Math.ceil(n+r);a++)for(let o=Math.floor(t-r);o<=Math.ceil(t+r);o++)(o+.5-t)**2+(a+.5-n)**2<=r*r&&e(o,a,i)},Fy=(e,t,n,r,i,a)=>{for(let o=Math.floor(n-i);o<=Math.ceil(n+i);o++)for(let s=Math.floor(t-r);s<=Math.ceil(t+r);s++)((s+.5-t)/r)**2+((o+.5-n)/i)**2<=1&&e(s,o,a)},Iy=(e,t,n,r,i,a)=>{for(let o=n;o<n+i;o++)for(let n=t;n<t+r;n++)e(n,o,a)},Ly=(e,t,n,r,i,a)=>{let o=Math.max(Math.abs(r-t),Math.abs(i-n),1);for(let s=0;s<=o;s++)e(Math.round(t+(r-t)*s/o),Math.round(n+(i-n)*s/o),a)},Ry=e=>(t,n,r)=>{e(t,n,r),e(31-t,n,r)},zy={mite:{size:.6,lift:0,heat:.7,art(e,t){let n=Ry(e);for(let e=0;e<3;e++){let r=18+e*4+(t===1?e%2?1:-1:0);Ly(n,7,r+4,11,r,`#5a3424`),Ly(n,4,r+7,7,r+4,`#5a3424`)}Fy(e,16,21,8,7,`#7a4630`),Fy(e,16,19,6,4,`#a0603c`),Iy(e,15,14,2,14,`#4a2a1c`),Py(e,16,13,4.2,`#6a3a28`),n(13,12,`#ff3020`),n(14,12,`#ff9070`);let r=t===2?3:1;Ly(n,14,16,15-r,18+r,`#e0c8a0`)}},seraph:{size:.6,lift:.25,heat:1,art(e,t){Vy(e,t,[`#f0d080`,`#c08030`,`#fff0c0`,`#ffffff`,`#402010`])}},pyre:{size:.6,lift:.25,heat:1,art(e,t){Vy(e,t,[`#ff8030`,`#a02010`,`#ffd060`,`#fff4c0`,`#300808`])}},walker:{size:.85,lift:0,heat:.8,art(e,t){Hy(e,t,`#d8c8a8`,`#8a7a60`,`#ff5030`,!1)}},abbot:{size:.95,lift:0,heat:.9,art(e,t){Hy(e,t,`#e8dcc0`,`#7a5a8a`,`#c060ff`,!0)}},hum:{size:.8,lift:.15,heat:.9,art(e,t){let n=+(t===1);for(let t=0;t<7;t++)Py(e,16+Math.sin(t*2.1+n)*7,16+Math.cos(t*1.7+n)*6,5+t%3,t%2?`#241830`:`#3a2848`);Py(e,16,16,7,`#120a18`);let r=t===2?`#ffffff`:`#c080ff`;Iy(e,12,14,2,2,r),Iy(e,18,14,2,2,r)}},mimic:{size:.55,lift:0,heat:.5,art(e,t){let n=t===2?6:t===1?3:2;Iy(e,6,18,20,12,`#6a4428`),Iy(e,6,18,20,2,`#c08040`),Iy(e,6,28,20,2,`#3a2214`),Iy(e,6,18-n-8,20,8,`#7a5030`),Iy(e,6,18-n-8,20,2,`#d09050`),Iy(e,7,18-n,18,n,`#200808`);for(let t=7;t<25;t+=3)e(t,18-n,`#f0e8d0`),e(t+1,17,`#f0e8d0`);t===2&&Iy(e,14,18-n+1,4,n+2,`#d03050`),Py(e,16,18-n-4,2,`#f0e0a0`),e(16,18-n-4,`#200808`)}},warden:{size:.8,lift:0,heat:.8,art(e,t){let n=Ry(e);By(e,16,7,6,`#f0d080`);for(let e=0;e<3;e++)Ly(n,9,20+e*3+ +(t===1&&e===1),2,26+e*2,`#3a2040`);Fy(e,16,21,9,8,`#5a3070`),Fy(e,16,19,6,5,`#8a50a0`),Iy(e,15,13,2,15,`#2a1830`),Py(e,16,13,4.5,`#4a2858`),n(13,12,`#ffd040`),n(14,13,`#ffd040`);let r=t===2?4:1;Ly(n,13,16,13-r,18+r,`#f0e0c0`)}},saint:{size:.95,lift:0,heat:1,art(e,t){let n=Ry(e),r=+(t===1);for(let t=0;t<8;t++){let n=t/8*Math.PI*2+r*.3;Ly(e,16+Math.cos(n)*5,8+Math.sin(n)*5,16+Math.cos(n)*(8+t%2*2),8+Math.sin(n)*(8+t%2*2),t%2?`#ffd060`:`#ff7020`)}By(e,16,8,5,`#ffe080`),Py(e,16,8,3,`#401808`),n(15,8,t===2?`#ffffff`:`#ff9030`),Iy(e,12,12,8,14,`#702010`),Iy(e,13,12,6,12,`#a03818`),Fy(e,16,30,7+r,2,`#ff8030`);let i=t===2?-6:0;Ly(n,12,14,5,20+i,`#a03818`),Ly(n,11,14,4,20+i,`#702010`),n(4,19+i,`#ffe080`),Iy(e,14,20,4,3,`#ffd060`)}}};function By(e,t,n,r,i){for(let a=0;a<48;a++)e(Math.round(t+Math.cos(a/48*Math.PI*2)*r-.5),Math.round(n+Math.sin(a/48*Math.PI*2)*r-.5),i)}function Vy(e,t,[n,r,i,a,o]){let s=t===1?.2:0,c=t===2?15:13;for(let t=0;t<12;t++){let r=t/12*Math.PI*2+s;Ly(e,16+Math.cos(r)*6,16+Math.sin(r)*6,16+Math.cos(r)*(t%2?c-3:c),16+Math.sin(r)*(t%2?c-3:c),n)}By(e,16,16,7,r),By(e,16,16,6.4,r),Py(e,16,16,5,t===2?a:i),Py(e,16,16,2,t===2?a:o)}function Hy(e,t,n,r,i,a){let o=Ry(e),s=t===1?2:0;for(let t of[0,1])Ly(e,13+t,20,11+t-s,31,t?n:r),Ly(e,18+t,20,20+t+s,31,t?r:n);Iy(e,11,19,10,3,n),Iy(e,14,10,4,10,r),Fy(e,16,14,5,4,`#2a2018`);for(let e=0;e<4;e++)Ly(o,15,11+e*2,10+e*.5,12+e*2,n);if(t===2?(Ly(o,11,10,6,3,n),Ly(o,10,10,5,3,n),Ly(o,6,3,5,1,r)):(Ly(o,11,10,8,18,n),Ly(o,10,10,7,18,n),Ly(o,8,18,8,22,r)),Py(e,16,6,4,n),Iy(e,14,9,4,2,n),o(14,6,`#100808`),o(13,6,`#100808`),o(14,6,i),e(15,9,`#100808`),e(16,9,`#100808`),a){for(let t=0;t<4;t++)Iy(e,13+(t>>1),t-1,6-(t>>1)*2,1,r);e(16,0,`#f0d080`)}}function Uy(e){let t=[],n=[];for(let r=0;r<4;r++){let i=Array(1024).fill(0);e.art((e,t,n)=>{e=Math.round(e),t=Math.round(t),e>=0&&t>=0&&e<32&&t<32&&(i[t*32+e]=n)},r===3?0:r);let a=i.slice();for(let e=0;e<32;e++)for(let t=0;t<32;t++)i[e*32+t]||[[1,0],[-1,0],[0,1],[0,-1]].some(([n,r])=>{let a=t+n,o=e+r;return a>=0&&o>=0&&a<32&&o<32&&i[o*32+a]})&&(a[e*32+t]=`#0a0807`);let o=Wy(a,r===3?`#ffffff`:null),s=Wy(a,`#ffffff`);t.push(o),n.push(s)}return{color:t,mask:n}}function Wy(e,t){let n=document.createElement(`canvas`);n.width=n.height=32;let r=n.getContext(`2d`);for(let n=0;n<e.length;n++){let i=e[n];i&&(r.fillStyle=t??i,r.fillRect(n%32,Math.floor(n/32),1,1))}return n}function Gy(e,t){let n=Array(1024).fill(0),r=4+e*3;for(let i=0;i<24;i++){if((i+e)%(e+1))continue;let a=i/24*Math.PI*2;for(let e=0;e<2;e++){let i=Math.round(16+Math.cos(a)*(r-e)),o=Math.round(16+Math.sin(a)*(r-e)*.8);i>=0&&o>=0&&i<32&&o<32&&(n[o*32+i]=t)}}return Wy(n,null)}/[?&]still/.test(globalThis.location?.search??``)&&(globalThis.thawSheet=()=>{let e=document.createElement(`div`);e.style.cssText=`position:fixed;inset:0;z-index:99999;background:#100d0c;padding:16px;display:grid;grid-template-columns:repeat(3,1fr);gap:10px;color:#d8c8b0;font:18px VT323,monospace`;for(let[t,n]of Object.entries(zy)){let r=document.createElement(`div`);r.textContent=t;let i=document.createElement(`div`);i.style.cssText=`display:flex;gap:6px`;let a=Uy(n);for(let e of[...a.color,a.mask[0]])e.style.cssText=`width:72px;height:72px;image-rendering:pixelated;background:#2a201c`,i.append(e);r.append(i),e.append(r)}return document.body.append(e),e});var Ky=(e,t,n)=>{let r=document.createElement(`canvas`);r.width=e,r.height=t,n(r.getContext(`2d`));let i=new Om(r);return i.magFilter=i.minFilter=Pl,i.generateMipmaps=!1,i},qy=null,Jy=()=>qy??=Ky(16,16,e=>{e.fillStyle=`#fff`,e.beginPath(),e.ellipse(8,11,4,3.6,0,0,Math.PI*2),e.fill();for(let[t,n]of[[4.5,5],[7,6.5],[9.5,6],[12,4.5]])e.fillRect(t-1,9-n,2,n);e.fillRect(1,9,3,2)}),Yy=new Map;function Xy(e){let t=Yy.get(e);if(t)return t;let n=Le(G(e,5));return t=Ky(24,18,e=>{e.fillStyle=`#000`,e.fillRect(0,0,24,18),e.fillStyle=`#fff`;for(let t=0;t<2;t++)for(let r=0;r<3;r++){let i=2+r*7,a=2+t*8;e.fillRect(i+2,a,2,6);let o=n.int(0,5);o&1&&e.fillRect(i,a+n.int(0,1)*2,2,2),o&2&&e.fillRect(i+4,a+n.int(1,2)*2,2,2),(o<2||o&4)&&e.fillRect(i+(n.chance(.5)?0:4),a+4,2,2)}}),Yy.set(e,t),t}var Zy=new Rm(1,1),Qy=new Map;function $y(e,t){let n=`${e.id}:${t.toFixed(2)}`,r=Qy.get(n);return r||Qy.set(n,r=new zp({map:e,alphaTest:.5,color:new Z().setHSL(.08-t*.08,1,.1+t*.85),fog:!1,side:2,depthTest:!0})),r}var eb=null,tb=()=>eb??=Ky(8,8,e=>{e.fillStyle=`#fff`,e.fillRect(1,1,6,6)}),nb=`
  uniform float uSnap;
  varying float vDist;
  varying vec2 vUv;
  void main() {
    vUv = uv;
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vDist = -mv.z;
    gl_Position = projectionMatrix * mv;
    gl_Position.xy = floor(gl_Position.xy / gl_Position.w * uSnap + 0.5) / uSnap * gl_Position.w;
  }`,rb=null,ib=new Map,ab=new Map;function ob(e,t){let n=ib.get(t);return n||ib.set(t,n=new Xm({uniforms:{uSnap:e.snap,uMask:{value:t}},side:2,vertexShader:nb,fragmentShader:`
        uniform sampler2D uMask;
        varying vec2 vUv;
        void main() {
          vec4 m = texture2D(uMask, vUv);
          if (m.a < 0.5 || m.r < 0.5) discard;
          gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
        }`})),n}function sb(e){let t=ab.get(e);return t||ab.set(e,t=new zp({map:e,side:2,fog:!1})),t}var cb=e=>rb??=new Xm({uniforms:{uSnap:e.snap,uRange:e.range},side:2,vertexShader:nb,fragmentShader:`
      uniform float uRange;
      varying float vDist;
      void main() {
        float v = clamp(1.0 - vDist / uRange, 0.0, 1.0) * 255.0;
        gl_FragColor = vec4(floor(v) / 255.0, fract(v), 1.0, 1.0);
      }`});function lb(e,t,n,r,i,a,o){return e.scale.set(a,o,1),e.position.set(t+.5+r*.52,.5,n+.5+i*.52),e.rotation.y=Math.atan2(r,i),e}function ub(e,t,n,r,i,a){let o=e.player;for(let s of _i(e))if(!(Math.abs(s.x-o.x)>a||Math.abs(s.y-o.y)>a)){if(s.kind===`hands`&&r===`heat`&&!s.done){let n=[...s.trail,[s.x,s.y]];for(let e=0;e<s.trail.length;e++){let[r,i]=n[e],[a,c]=n[e+1],l=Math.atan2(a-r,-(c-i)),u=e%2?.16:-.16,d=new Zp(Zy,$y(Jy(),Math.round((.45+.2*e/s.trail.length)*20)/20)),f=.34*Math.max(1,Math.hypot(r+.5-o.x,i+.5-o.y)/2.5);d.scale.set(f,f,1),d.rotation.set(-Math.PI/2+.6,Math.atan2(o.x-r-.5,o.y-i-.5),0,`YXZ`),d.position.set(r+.5+Math.cos(l)*u,.1,i+.5+Math.sin(l)*u),d.renderOrder=2,t.add(d)}for(let n=0;n<s.trail.length;n++){let[r,i]=s.trail[n];for(let[a,c]of[[0,-1],[1,0],[0,1],[-1,0]]){let l=G(s.salt,r,i,a*3+c);if(l%3==0||w(e,r+a,i+c)===h.floor)continue;let u=.36*Math.max(1,Math.hypot(r+.5-o.x,i+.5-o.y)/2.5),d=lb(new Zp(Zy,$y(Jy(),Math.round((.35+.2*n/s.trail.length)*20)/20)),r+a,i+c,-a,-c,u,u);d.position.y=.22+(l>>4)%40/100,d.rotateZ(((l>>8)%90-45)/60),d.renderOrder=2,t.add(d)}}let r=new Zp(Zy,$y(tb(),Math.round((.6+.08*Math.sin(e.t*4))*20)/20));r.scale.set(.6,.6,1),r.rotation.x=-Math.PI/2,r.position.set(s.x+.5,.05,s.y+.5),r.renderOrder=2,t.add(r)}else if(s.kind===`script`&&(r===`1bit`||r===`edge`)){if(w(e,s.x,s.y)===h.floor)continue;let r=Xy(s.salt),a=n===`depth`?ob(i,r):sb(r);t.add(lb(new Zp(Zy,a),s.x,s.y,s.fx,s.fy,.92,.7))}else s.kind===`hollow`&&r===`sonar`&&!s.done&&t.add(lb(new Zp(Zy,cb(i)),s.x,s.y,s.fx,s.fy,1,1))}}var db=new Dp,fb=null,pb={value:0};function mb(e){return fb??=new Xm({uniforms:{uSnap:e.snap,uLight:pb},vertexShader:`
      uniform float uSnap;
      attribute float aK;
      varying float vDist;
      varying float vK;
      void main() {
        vK = aK;
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        vDist = -mv.z;
        gl_Position = projectionMatrix * mv;
        gl_Position.xy = floor(gl_Position.xy / gl_Position.w * uSnap + 0.5) / uSnap * gl_Position.w;
      }`,fragmentShader:`
      uniform float uLight;
      varying float vDist;
      varying float vK;
      void main() {
        float f = clamp(1.0 - vDist / 7.0, 0.0, 1.0);
        gl_FragColor = vec4(vec3(0.62, 0.48, 0.34) * vK * f * f * uLight, 1.0);
      }`}),new Em(db,fb)}function hb(e,t,n,r){let i=[],a=[],o=(e,t,n,r,o)=>{i.push(e,.003,t,n,.003,r),a.push(o,o)};for(let i=n-r;i<=n+r;i++)for(let n=t-r;n<=t+r;n++){if(w(e,n,i)!==h.floor)continue;let t=w(e,n,i-1)===h.floor,r=w(e,n-1,i)===h.floor,a=w(e,n,i+1)===h.floor,s=w(e,n+1,i)===h.floor;o(n,i,n+1,i,t?.25:.6),o(n,i,n,i+1,r?.25:.6),a||o(n,i+1,n+1,i+1,.6),s||o(n+1,i,n+1,i+1,.6)}db.setAttribute(`position`,new hp(i,3)),db.setAttribute(`aK`,new hp(a,1)),db.computeBoundingSphere()}var gb=14,_b={bone:14207144,glass:8378576,copper:13664320,ichor:12591168},vb={value:32};function yb(e){return e.onBeforeCompile=e=>{e.uniforms.uSnap=vb,e.vertexShader=e.vertexShader.replace(`void main() {`,`uniform float uSnap;
varying float vAffW;
void main() {`).replace(`#include <project_vertex>`,`#include <project_vertex>
        gl_Position.xy = floor(gl_Position.xy / gl_Position.w * uSnap + 0.5) / uSnap * gl_Position.w;
        vAffW = gl_Position.w;
        #ifdef USE_MAP
        vMapUv *= vAffW;
        #endif
        #ifdef USE_EMISSIVEMAP
        vEmissiveMapUv *= vAffW;
        #endif`),e.fragmentShader=e.fragmentShader.replace(`void main() {`,`varying float vAffW;
void main() {`).replace(`#include <map_fragment>`,`#ifdef USE_MAP
        diffuseColor *= texture2D(map, vMapUv / vAffW);
        #endif`).replace(`#include <emissivemap_fragment>`,`#ifdef USE_EMISSIVEMAP
        totalEmissiveRadiance *= texture2D(emissiveMap, vEmissiveMapUv / vAffW).rgb;
        #endif`)},e}var bb=null,xb=new Nf,Sb=new Mh(60,1,.05,40),Cb=new Mm(1,1,1),wb=new Rm(1,1),Tb=ky(),Eb=yb(new Qm({map:Tb.wall})),Db=yb(new Qm({map:Tb.floor,side:2})),Ob=yb(new Qm({map:Tb.ceil,side:2})),kb=841,Ab=new lm(Cb,Eb,kb),jb=new lm(wb,Db,kb),Mb=new lm(wb,Ob,kb),Nb={},Pb=new Ph(16763024,4,8,1),Fb=[0,1,2].map(()=>new Ph(16777215,0,1,1)),Ib=new Ih(4865094,2.6),Lb=new wf;xb.add(Ab,jb,Mb,Pb,Lb,Ib,...Fb);var Rb=mb({snap:vb});xb.add(Rb);for(let[e,t]of Object.entries(_b))Nb[e]=new lm(Cb,yb(new Qm({map:Tb.vein,color:8415336,emissive:t,emissiveMap:Tb.glow,emissiveIntensity:.55})),kb),xb.add(Nb[e]);var zb=Object.fromEntries(Object.entries(_b).map(([e,t])=>[e,new Z(8415336).lerp(new Z(t),.7).getHex()])),Bb=1577488,Vb=new Z(Bb),Hb=new Z(0),Ub=``,Wb=new Yd;function Gb(e,t,n){let r=Math.floor(t),i=Math.floor(n),a=`${e.seed}:${r},${i}:${e.chunks.size}:${T}`;if(a===Ub)return;Ub=a;let o=0,s=0,c={bone:0,glass:0,copper:0,ichor:0};for(let t=i-gb;t<=i+gb;t++)for(let n=r-gb;n<=r+gb;n++){let r=w(e,n,t);if(r===h.floor){Wb.makeRotationX(-Math.PI/2).setPosition(n+.5,0,t+.5),jb.setMatrixAt(s,Wb),Wb.makeRotationX(Math.PI/2).setPosition(n+.5,1,t+.5),Mb.setMatrixAt(s++,Wb);continue}if(![[1,0],[-1,0],[0,1],[0,-1]].some(([r,i])=>w(e,n+r,t+i)===h.floor))continue;Wb.makeTranslation(n+.5,.5,t+.5);let i=_(r);i?Nb[i].setMatrixAt(c[i]++,Wb):Ab.setMatrixAt(o++,Wb)}Ab.count=o,jb.count=Mb.count=s;for(let e of Object.keys(Nb))Nb[e].count=c[e];for(let e of[Ab,jb,Mb,...Object.values(Nb)])e.instanceMatrix.needsUpdate=!0,e.boundingSphere=null,e.boundingBox=null;hb(e,r,i,Math.min(gb,8))}var Kb={};function qb(e,t){Kb[e]=t}qb(`mite`,{geo:new Bm(.16),color:9076848,glow:5249048,y:.2,spin:6,bob:.06,heat:.7}),qb(`seraph`,{geo:new Im(.28,0),color:15786160,glow:16765040,y:.6,spin:.5,bob:.05,heat:1}),qb(`walker`,{geo:new Mm(.4,.8,.3),color:14207144,glow:2627600,y:.4,heat:.15}),qb(`mimic`,{geo:new Lm(.12),color:8413248,glow:12615744,y:.15,spin:1,heat:.5}),qb(`hum`,{geo:new zm(.2,5,3),color:0,glow:0,y:.5,heat:.9});var Jb={camera:new zm(.1,6,4),scanner:new Vm(.1,.03,3,8),lamp:new Lm(.1),gait:new Nm(.08,.08,.14,6),weapon:new Pm(.07,.24,4),power:new Nm(.06,.06,.2,5)},Yb=new Mm(.12,.12,.12),Xb=new Mm(.18,.02,.12),Zb=new Mm(.6,.9,.6),Qb=new Mm(.7,.5,.45),$b=new Lm(.12),ex=new Im(.1,0),tx={geo:ex,color:16769184,glow:16765040,y:.4,heat:1},nx={geo:ex,color:13689087,glow:10535167,y:.35,heat:.6};function rx(t){if(t.data?.shot)return t.data.foe?tx:nx;if(t.enemy)return null;if(t.kind===`printer`)return{geo:Zb,color:5917248,glow:8400912,y:.45,heat:.4};if(t.data?.altar)return{geo:Qb,color:6967368,glow:10496024,y:.25,heat:.35};let n=t.item;return n?n.kind===`res`?{geo:Yb,color:_b[n.res]??8421504,glow:_b[n.res]??0,y:.08,spin:.7,heat:n.res===`ichor`?.4:.05}:n.kind===`card`?{geo:Xb,color:15259824,glow:6311984,y:.03,heat:.05}:{geo:Jb[e[n.mod]?.family??``]??$b,color:8413248,glow:12615744,y:.15,spin:1,bob:.03,heat:.15}:null}var ix=new Map,ax=[6967360,15786176].map(e=>new zp({color:e}));function ox(e,t){let n=t===`heat`?`h${e.heat}`:`${e.color}:${e.glow}`,r=ix.get(n);return r||(r=t===`heat`?new zp({color:new Z().setHSL(.08-e.heat*.08,1,.1+e.heat*.85),depthTest:!1,fog:!1}):yb(new Qm({color:e.color,emissive:e.glow,emissiveIntensity:.6,flatShading:!0})),ix.set(n,r)),r}var sx=new Map,cx=(e,t)=>{let n=new Om(e);return n.magFilter=n.minFilter=Pl,n.generateMipmaps=!1,t&&(n.colorSpace=$u),n};function lx(e){let t=zy[e]?e:`mite`,n=sx.get(t);if(!n){let e=zy[t],r=Uy(e);n={def:e,color:r.color.map(e=>cx(e,!0)),mask:r.mask.map(e=>cx(e,!1))},sx.set(t,n)}return n}var ux=new Rm(1,1),dx=new Rm(1,1),fx=new zp({color:1050632,fog:!1}),px=new zp({color:14694440,fog:!1}),mx=new zp({color:15769680,fog:!1}),hx=new Map,gx=new Map,_x=new Map;function vx(e){let t=hx.get(e);return t||hx.set(e,t=yb(new zp({map:e,alphaTest:.5,side:2}))),t}function yx(e,t){let n=`${e.id}:${t}`,r=gx.get(n);return r||gx.set(n,r=new zp({map:e,color:new Z().setHSL(.08-t*.08,1,.1+t*.85),alphaTest:.5,depthTest:!1,fog:!1,side:2})),r}function bx(e){let t=_x.get(e);return t||(t=new Xm({uniforms:{uSnap:vb,uRange:Dx,uMask:{value:e}},side:2,vertexShader:`
        uniform float uSnap;
        varying float vDist;
        varying vec2 vUv;
        void main() {
          vUv = uv;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          vDist = -mv.z;
          gl_Position = projectionMatrix * mv;
          gl_Position.xy = floor(gl_Position.xy / gl_Position.w * uSnap + 0.5) / uSnap * gl_Position.w;
        }`,fragmentShader:`
        uniform float uRange;
        uniform sampler2D uMask;
        varying float vDist;
        varying vec2 vUv;
        void main() {
          if (texture2D(uMask, vUv).a < 0.5) discard;
          float v = clamp(1.0 - vDist / uRange, 0.0, 1.0) * 255.0;
          gl_FragColor = vec4(floor(v) / 255.0, fract(v), 0.0, 1.0);
        }`}),_x.set(e,t)),t}var xx=new Map;function Sx(e,t){let n=`${e}:${t}`,r=xx.get(n);return r||xx.set(n,r=cx(Gy(e,t?`#ffffff`:`#d8c8a8`),!t)),r}function Cx(e,t){let n=t.enemy.data;if(typeof n.hitAt==`number`&&e.t-n.hitAt<.15)return 3;if(typeof n.windup==`number`&&e.t<n.windup)return 2;let r=e.t-My(t);return r>=0&&r<.35?2:Math.floor(e.t*3+t.id*.37)%2}function wx(e,t,n,r){let i=t.enemy.type;if(N[i]?.hidden&&!r)return;let a=lx(i);if(n===`heat`&&!Mt.has(i)||n!==`heat`&&!j(e,e.player.x,e.player.y,t.x,t.y))return;let o=Cx(e,t),s=a.def.size,c=new Zp(ux,n===`heat`?yx(a.mask[o],a.def.heat):n===`depth`?bx(a.mask[o]):vx(a.color[o])),l=a.def.lift?Math.sin(e.t*3+t.id)*.04:0,u=t.enemy.data,d=typeof u.windup==`number`&&e.t<u.windup,f=d&&u.wide?1.5:1,p=d&&i===`mite`?1.3:1;if(c.scale.set(s*f,s*p,1),c.position.set(t.x,a.def.lift+s*p/2+l,t.y),c.rotation.y=-e.player.dir,c.renderOrder=n===`heat`?2:1,Lb.add(c),n!==`color`)return;let m=Number(t.enemy.data.maxHp??t.enemy.hp)||1,h=Math.max(0,Math.min(1,t.enemy.hp/m));if(h>=1&&!t.enemy.data.noticed)return;let g=Math.max(.35,s*.7),_=Math.min(a.def.lift+s+.06+l,.93),v=new Zp(dx,fx);v.scale.set(g+.04,.08,1),v.position.set(t.x,_,t.y),v.rotation.y=-e.player.dir;let y=new Zp(dx,h>=1?mx:px);y.scale.set(g*h,.05,1);let[b,x]=[Math.sin(e.player.dir),-Math.cos(e.player.dir)],[S,C]=[Math.cos(e.player.dir),Math.sin(e.player.dir)],w=-(g*(1-h))/2;y.position.set(t.x+S*w-b*.01,_,t.y+C*w-x*.01),y.rotation.y=-e.player.dir,Lb.add(v,y)}function Tx(e,t){if(t!==`depth`)for(let n of Ay.get(e)??[]){let r=Sx(Math.min(3,Math.floor((e.t-n.t)/jy*4)),t===`heat`),i=new Zp(ux,t===`heat`?yx(r,.6):vx(r)),a=(zy[n.type]?.size??.6)*1.2;i.scale.set(a,a,1),i.position.set(n.x,a/2,n.y),i.rotation.y=-e.player.dir,Lb.add(i)}}function Ex(e,t,n=!1,r=``){Lb.clear();let i=e.player;ub(e,Lb,t,r,{snap:vb,range:Dx},gb);for(let a of e.ents){if(Math.abs(a.x-i.x)>gb||Math.abs(a.y-i.y)>gb)continue;if(a.enemy){wx(e,a,t,n);continue}let o=rx(a);if(!o)continue;let s=!!a.data?.mimic&&(r===`heat`||r===`1bit`);if(s&&t===`heat`&&(o={...o,heat:.6}),t===`heat`&&o.heat<.3)continue;let c=Math.sin(e.t*2.6+a.id),l=new Zp(o.geo,t===`depth`?kx:s&&t===`color`?ax[+(c>0)]:ox(o,t));l.position.set(a.x,o.y+Math.sin(e.t*4+a.id)*(o.bob??0),a.y),s&&l.scale.setScalar(2.4+.9*c),l.rotation.y=e.t*(o.spin??0)+a.id,l.renderOrder=t===`heat`?2:0,Lb.add(l)}Tx(e,t)}var Dx={value:8},Ox=`
    #include <common>
    uniform float uSnap;
    varying float vDist;
    void main() {
      #include <begin_vertex>
      #include <project_vertex>
      vDist = -mvPosition.z;
      gl_Position.xy = floor(gl_Position.xy / gl_Position.w * uSnap + 0.5) / uSnap * gl_Position.w;
    }`,kx=new Xm({uniforms:{uSnap:vb,uRange:Dx},vertexShader:Ox,fragmentShader:`
    uniform float uRange;
    varying float vDist;
    void main() {
      float v = clamp(1.0 - vDist / uRange, 0.0, 1.0) * 255.0;
      gl_FragColor = vec4(floor(v) / 255.0, fract(v), 0.0, 1.0);
    }`}),Ax=new Xm({uniforms:{uSnap:vb},vertexShader:Ox,fragmentShader:`
    varying float vDist;
    // the target stores sRGB: undo it, so the bytes read back are the warmth itself
    void main() { float v = pow(clamp(1.0 - vDist / 5.0, 0.0, 1.0) * 0.35, 2.2); gl_FragColor = vec4(v, v, v, 1.0); }`}),jx=(e,t)=>(e[t*4]+e[t*4+1]/256)/255,Mx=new Map;function Nx(e,t){bb||(bb=new _y({antialias:!1,preserveDrawingBuffer:!1}),bb.setPixelRatio(1),bb.domElement.addEventListener(`webglcontextlost`,e=>{e.preventDefault();for(let e of Mx.values())e.dispose();Mx.clear(),bb=null,Ub=``}));let n=t.mode??`color`,r=e.player;Gb(e,r.x,r.y),Ex(e,n,!!t.hidden,t.filter);let i=ut[ft(r.x,r.y)]?.look.dark??0;Rb.visible=n===`color`&&i>0,pb.value=Math.min(1,i*2.5),vb.value=t.res/2,Dx.value=t.range,Pb.position.set(r.x,.6,r.y);let a=ee(e);Fb.forEach((t,n)=>{let i=a[n];t.intensity=i?6*re(i,e.t):0,i&&(t.color.setHex(i.color),t.distance=i.radius*1.6,t.position.set(r.x,.75,r.y))});let o=t.filter===`color`;for(let[t,n]of Object.entries(Nb)){let r=n.material;r.emissiveIntensity=o?.8+.2*Math.sin(e.t*4):.55,r.color.setHex(o?zb[t]:8415336)}xb.overrideMaterial=n===`heat`?Ax:n===`depth`?kx:null,xb.background=n===`color`?Vb:Hb,xb.fog=n===`color`?new Mf(Bb,t.range*.6,t.range*1.05):null,Sb.fov=t.fov,Sb.updateProjectionMatrix(),Sb.position.set(r.x,.5,r.y),Sb.lookAt(r.x+Math.sin(r.dir),.5,r.y-Math.cos(r.dir));let s=`${t.res}:${n===`depth`}`,c=Mx.get(s);if(c||(c=new Kd(t.res,t.res),n!==`depth`&&(c.texture.colorSpace=$u),Mx.set(s,c)),bb.setRenderTarget(c),n===`heat`){Lb.visible=!1,bb.render(xb,Sb),xb.overrideMaterial=null,xb.background=null,Lb.visible=!0;let e=[Ab,jb,Mb,...Object.values(Nb)];for(let t of e)t.visible=!1;bb.autoClear=!1,bb.render(xb,Sb),bb.autoClear=!0;for(let t of e)t.visible=!0}else if(n===`depth`){Lb.visible=!1,bb.render(xb,Sb),xb.overrideMaterial=null,xb.background=null,Lb.visible=!0;let e=[Ab,jb,Mb,...Object.values(Nb)];for(let t of e)t.visible=!1;bb.autoClear=!1,bb.render(xb,Sb),bb.autoClear=!0;for(let t of e)t.visible=!0}else bb.render(xb,Sb);xb.overrideMaterial=null;let l=new Uint8Array(t.res*t.res*4);bb.readRenderTargetPixels(c,0,0,t.res,t.res,l),bb.setRenderTarget(null);let u=new Uint8Array(l.length),d=t.res*4;for(let e=0;e<t.res;e++)u.set(l.subarray((t.res-1-e)*d,(t.res-e)*d),e*d);return u}globalThis.thawGL=()=>bb?.domElement;function Px(e,t,n){if(w(e,t,n)!==h.floor)return!1;let r=(r,i)=>w(e,t+r,n+i)!==h.floor;return r(1,0)&&r(-1,0)||r(0,1)&&r(0,-1)}function Fx(e,t){let n=e.player,r=o(t,`range`,6),i=new Set(o(t,`sees`,[`enemies`])),a=o(t,`shape`,`ring`)===`cone`,s=(e,t)=>{let i=e-n.x,o=t-n.y;if(Math.hypot(i,o)>r)return!1;if(!a||Math.hypot(i,o)<.5)return!0;let s=Math.atan2(i,-o)-n.dir;return s=Math.atan2(Math.sin(s),Math.cos(s)),Math.abs(s)<=Math.PI/4},c=[];for(let t of e.ents)if(s(t.x,t.y)){if(t.enemy){let e=N[t.enemy.type]?.hidden;i.has(`heat`)?c.push({x:t.x,y:t.y,sense:`heat`}):i.has(`flesh`)?c.push({x:t.x,y:t.y,sense:`flesh`}):i.has(`enemies`)&&!e&&c.push({x:t.x,y:t.y,sense:`enemies`})}else t.kind===`printer`||t.item&&t.item.kind!==`card`?i.has(`metal`)&&c.push({x:t.x,y:t.y,sense:`metal`}):t.item?.kind===`card`&&i.has(`cards`)&&c.push({x:t.x,y:t.y,sense:`cards`})}if(i.has(`doors`)||i.has(`veins`)){let t=Math.ceil(r);for(let r=Math.floor(n.y)-t;r<=Math.floor(n.y)+t;r++)for(let a=Math.floor(n.x)-t;a<=Math.floor(n.x)+t;a++)s(a+.5,r+.5)&&(i.has(`veins`)&&_(w(e,a,r))?c.push({x:a+.5,y:r+.5,sense:`veins`}):i.has(`doors`)&&Px(e,a,r)&&c.push({x:a+.5,y:r+.5,sense:`doors`}))}return c}var Ix={heat:`#ff7a3a`,flesh:`#e8506a`,enemies:`#f0e4c8`,metal:`#9ab8d0`,cards:`#e8d070`,doors:`#6a8a6a`,veins:`#c04070`};i(`scanner`,{status:(e,t)=>{let n=Fx(e,t);return[[n.length?`${n.length} things within ${o(t,`range`,6)} cells.`:`nothing within range.`]]}}),$a(`scanner`,(e,t)=>{let n=document.createElement(`canvas`);n.width=n.height=120,n.className=`scan`,e.append(n);let r=n.getContext(`2d`),i=[],a=-99;return{update(e){let n=t.on&&e.t>=t.readyAt;if(r.fillStyle=`#050605`,r.fillRect(0,0,120,120),!n)return;let s=o(t,`refresh`,1);e.t-a>=s&&(i=Fx(e,t),a=e.t);let c=56/o(t,`range`,6),l=e.player,u=o(t,`shape`,`ring`)===`cone`;r.save(),r.translate(60,60),r.strokeStyle=`#1c2a1c`;for(let e=1;e<=3;e++)r.beginPath(),r.arc(0,0,56*e/3,0,Math.PI*2),r.stroke();u&&(r.beginPath(),r.moveTo(0,0),r.arc(0,0,56,-Math.PI*.75,-Math.PI*.25),r.closePath(),r.stroke());let d=Math.min(1,(e.t-a)/s);r.strokeStyle=`#2e4a2e`,r.beginPath(),r.arc(0,0,56*d,0,Math.PI*2),r.stroke(),r.rotate(-l.dir);let f=1-d*.6;for(let e of i){r.globalAlpha=f,r.fillStyle=Ix[e.sense];let t=(e.x-l.x)*c,n=(e.y-l.y)*c,i=e.sense===`doors`||e.sense===`veins`?2:4;r.fillRect(Math.round(t-i/2),Math.round(n-i/2),i,i)}r.restore(),r.globalAlpha=1,r.fillStyle=`#f0e4c8`,r.fillRect(59,59,3,3)}}});var Lx={mite:`a beetle that sang in the choir once. alone it is nothing, and it is never alone: it bites up close, so hit many at once.`,seraph:`a wheel of eyes nailed to the air. it never moves; it fires slow orbs down its line of sight: step out of the line.`,pyre:`a seraph of the furnace, burning. it never moves and fires faster than its cold kin: step out of its line.`,walker:`bone that walks, slow and cold. it lifts its arm before it strikes: step back. small blows glance off it, and a heat eye never shows it.`,hum:`a knot of smoke with eyes. no clear eye shows it: only sonar and heat do, and only then can your weapons find it.`,mimic:`a reliquary that wanted to be opened. it lay as loot; a heat or black & white eye sees it breathe, sonar wakes it early.`,warden:`the choir warden: a mite grown huge and haloed, guarding a shard. fast and hard-biting: bring a second weapon, or a bell for its choir.`,abbot:`the bone abbot: guards the second shard. its arm comes down for four: never stand there when it does.`,saint:`the furnace saint: guards the last shard and the engine. it does not move; its fire crosses the room.`,altar:`an altar, stained and patient. offer what you gather for power, flesh or mending, or attune and temper a module.`,printer:`a printer of the old machines. feed it bone and glass: it prints a slot, a module, or (for copper more) one kind of module.`,shop:`a reliquary. it sells modules, rerolls its offers, and takes what you recycle.`},Rx={altar:`altar`,printer:`printer`,shop:`reliquary`},zx=e=>Rx[e]??(N[e]?.name??e).replace(/^(a|an|the) /,``),Bx=new WeakMap,Vx=e=>{let t=Bx.get(e);return t||Bx.set(e,t=[]),t};function Hx(e){return e.enemy?Lx[e.enemy.type]?e.enemy.type:null:e.kind===`printer`?e.data?.shop?`shop`:`printer`:e.data?.altar?`altar`:null}function Ux(e,t,n,r){let i=e.player,a=o(t,`filter`,`color`),s=R(n,i);if(s>r)return!1;if(n.enemy){let e=n.enemy.type;if(N[e]?.hidden&&a!==`sonar`&&a!==`heat`||a===`heat`&&!Mt.has(e))return!1}if(s>.6){let e=Math.atan2(n.x-i.x,-(n.y-i.y))-i.dir;if(Math.abs(Math.atan2(Math.sin(e),Math.cos(e)))>o(t,`fov`,60)/2*Math.PI/180)return!1}return a===`heat`||j(e,i.x,i.y,n.x,n.y)}function Wx(e,t,n){let r=Vx(e),i=!1;for(let a of e.ents){let o=Hx(a);o&&!r.includes(o)&&Ux(e,t,a,n)&&(r.push(o),i=!0,e.events.push({type:`codex`,at:[a.x,a.y],data:o}),F(e,[`◆ first sight · ${zx(o)}: ${Lx[o]}`]))}return i}U(`codex`,{help:`what your eyes have shown you so far`,when:e=>Vx(e).length>0,run(e){for(let t of Vx(e))F(e,`◆ ${zx(t)}: ${Lx[t]}`)}});var Gx=[`n`,`e`,`s`,`w`],Kx=e=>(Math.round(e/(Math.PI/2))%4+4)%4;i(`camera`,{buttons:e=>{if(!l(e,`gait`).some(e=>o(e,`go`,!1)))return[];let t=Kx(e.player.dir);return[{label:`◀ turn`,cmd:`face ${Gx[(t+3)%4]}`},{label:`▲ step`,cmd:`go ${Gx[t]} 1`},{label:`turn ▶`,cmd:`face ${Gx[(t+1)%4]}`}]}});var qx=[0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5].map(e=>(e+.5)/16-.5),Jx=(e,t,n,r)=>{let i=255/(t-1);return Math.max(0,Math.min(255,Math.round(e/i+qx[(r&3)*4+(n&3)])*i))};function Yx(e,t,n=210,r=6){let i=new Uint32Array(256);for(let n=0;n<t*t;n++)i[Math.round(e[n*4]*.3+e[n*4+1]*.59+e[n*4+2]*.11)]++;let a=0,o=255;for(let e=255;e>=0;e--)if((a+=i[e])>t*t*.08){o=e;break}let s=Math.min(r,n/Math.max(1,o));if(!(s<=1))for(let n=0;n<t*t*4;n++)(n&3)!=3&&(e[n]=Math.min(255,e[n]*s))}var Xx=[657415,14857340,8669482,6974584,3026486,12878398,5386268,15787208].map(e=>[e>>16&255,e>>8&255,e&255]),Zx={color(e,t,{colors:n}){if(!n)return Yx(e,t,200,2.5);if(Yx(e,t),n<=Xx.length){let r=Xx.slice(0,Math.max(2,n));for(let n=0;n<t*t;n++){let i=qx[(n/t&3)*4+(n%t&3)]*56,a=0,o=1/0;for(let t=0;t<r.length;t++){let s=3*(e[n*4]+i-r[t][0])**2+4*(e[n*4+1]+i-r[t][1])**2+2*(e[n*4+2]+i-r[t][2])**2;s<o&&(o=s,a=t)}for(let t=0;t<3;t++)e[n*4+t]=r[a][t]}return}let r=Math.max(2,Math.round(Math.cbrt(n))+1);for(let n=0;n<t*t;n++){let i=n%t,a=n/t|0;for(let t=0;t<3;t++)e[n*4+t]=Jx(e[n*4+t],r,i,a)}},gray(e,t,{colors:n}){let r=n||16;Yx(e,t);let i=t<48&&r>2;for(let n=0;n<t*t;n++){let a=n%t,o=n/t|0,s=e[n*4]*.3+e[n*4+1]*.59+e[n*4+2]*.11;e[n*4]=e[n*4+1]=e[n*4+2]=i?Math.round(Math.round(s/255*(r-1))*(255/(r-1))):Jx(s,Math.max(2,r),a,o)}},"1bit"(e,t,n){Zx.gray(e,t,{...n,colors:2})},heat(e,t,{colors:n}){let r=n||8;for(let n=0;n<t*t;n++){let i=n%t,a=n/t|0,[o,s,c]=eS(Jx(Math.max(e[n*4],e[n*4+1],e[n*4+2]),r,i,a)/255);e[n*4]=o,e[n*4+1]=s,e[n*4+2]=c}},sonar(e,t,{colors:n,t:r,range:i=8}){let a=n||6,o=r*5%(i+2),s=Qx(e,t,i),c=jx(e,(t>>1)*t+(t>>1)),l=c>0&&(1-c)*i<1;for(let n=0;n<t*t;n++){let c=jx(e,n);if(l&&c&&(1-c)*i<1.3&&e[n*4+2]<200){let i=Math.hypot(n%t-t/2,(n/t|0)-t/2)/t;if(Math.sin(i*38-r*10)>.35){e[n*4]=e[n*4+1]=e[n*4+2]=Math.round(Math.round(.85*(a-1))/(a-1)*255);continue}}if(!c){e[n*4]=e[n*4+1]=e[n*4+2]=0;continue}let u=(1-c)*i,d=c*c*.4;u%1<.12&&(d+=.2*c),s[n]&&(d=Math.max(d,.5+.5*c)),Math.abs(u-o)<.35&&(d=Math.min(1,d+.45)),e[n*4+2]>=200&&(d=Math.sin(r*9-u*5+(n/t|0)*.9)>0?1:.3+.3*c),d=Math.round(Math.min(1,d)*(a-1))/(a-1),e[n*4]=e[n*4+1]=e[n*4+2]=Math.round(d*255)}},edge(e,t,{range:n=8}){let r=Qx(e,t,n);for(let n=0;n<t*t;n++)e[n*4]=e[n*4+1]=e[n*4+2]=r[n]?255:0}};function Qx(e,t,n){let r=new Float32Array(t*t);for(let i=0;i<t*t;i++){let t=jx(e,i);r[i]=t?1/Math.max(.05,(1-t)*n):0}let i=(e,n)=>r[Math.min(t-1,Math.max(0,n))*t+Math.min(t-1,Math.max(0,e))],a=1/(1.3*t),o=new Uint8Array(t*t);for(let e=1;e<t-1;e++)for(let n=1;n<t-1;n++){let r=i(n,e),s=Math.abs(i(n+1,e)+i(n-1,e)-2*r),c=Math.abs(i(n,e+1)+i(n,e-1)-2*r);r>0&&Math.max(s,c)>a+r*.004&&(o[e*t+n]=1)}return o}var $x={heat:`heat`,sonar:`depth`,edge:`depth`};function eS(e){let t=[[0,0,0],[40,10,70],[170,20,30],[240,140,20],[255,250,220]],n=Math.max(0,Math.min(1,e))*(t.length-1),r=Math.min(t.length-2,Math.floor(n)),i=n-r;return[0,1,2].map(e=>Math.round(t[r][e]*(1-i)+t[r+1][e]*i))}function tS(e,t,n,r=Math.random){if(!(n<=0)){for(let i=0;i<t*t;i++){let t=(r()-.5)*n*160;for(let n=0;n<3;n++)e[i*4+n]=Math.max(0,Math.min(255,e[i*4+n]+t))}for(let i=0;i<t;i++){if(r()>n*.15)continue;let a=e.slice(i*t*4,(i+1)*t*4),o=Math.round((r()-.5)*t*n*.3)*4;for(let n=0;n<t*4;n++)e[i*t*4+n]=a[(n-o+t*400)%(t*4)]}}}function nS(e,t,n,r){if(n<=0)return;let i=Math.exp(-r/n);for(let n=0;n<e.length;n++){if((n&3)==3)continue;let r=Math.max(e[n],t[n]*i);t[n]=r,e[n]=r}}function rS(e,t,n){if(n<=0)return;let r=e.slice();for(let i=0;i<t;i++)for(let a=0;a<t;a++)for(let o=0;o<3;o++){let s=0,c=0;for(let e=-n;e<=n;e++)for(let l=-n;l<=n;l++){let n=Math.min(t-1,Math.max(0,a+l)),u=Math.min(t-1,Math.max(0,i+e));s+=r[(u*t+n)*4+o],c++}e[(i*t+a)*4+o]=s/c}}function iS(e,t,n,r=Math.random){for(let i=0;i<t*t;i++){let t=r()<.5?0:Math.round((.35+r()*.65)*255*n);e[i*4]=t,e[i*4+1]=Math.round(t*.85),e[i*4+2]=Math.round(t*.7),e[i*4+3]=255}}var aS=e=>{for(let t=0;t<e.length;t+=4)if(e[t]|e[t+1]|e[t+2])return!1;return!0};$a(`camera`,(t,n,r)=>{let i=Math.round(o(n,`res`,32)),a=document.createElement(`canvas`);a.width=a.height=i,a.className=`eye`;let s=document.createElement(`div`);s.className=`facing`;let c=document.createElement(`div`);c.style.cssText=`position:relative;line-height:0`;let l=document.createElement(`div`);l.className=`foe-arrow`,l.style.cssText=`position:absolute;display:none;color:#ff5a3c;font-size:22px;line-height:1;padding:2px 4px;background:#000a;pointer-events:none;white-space:nowrap`,c.append(a,l),t.append(s,c);let u=a.getContext(`2d`),d=u.createImageData(i,i),f=new Float32Array(i*i*4),p=0,m=!1,h=!1;return{update(t){let r=n.on&&t.t>=n.readyAt,c=n.on?r?`facing `+[`north`,`north-east`,`east`,`south-east`,`south`,`south-west`,`west`,`north-west`][(Math.round(t.player.dir/(Math.PI/4))%8+8)%8]:`warming up…`:`off`;s.textContent!==c&&(s.textContent=c);let g=t.t-t.player.hurtAt<.3,_=t.t-(n.data.flashAt??-99),v=_>=0&&_<1.5&&Math.floor(_/.25)%2==0;if(a.style.outline=g?`3px solid #e03828`:v?`3px solid #e2b47c`:``,a.style.outlineOffset=g||v?`-3px`:``,oS(t,l,o(n,`fov`,60),$x[o(n,`filter`,`color`)]===`heat`),!r){let r=e[n.mod]?.warm||1,a=n.on?.25+.5*Math.min(1,Math.max(0,1-(n.readyAt-t.t)/r)):.12;iS(d.data,i,a),u.putImageData(d,0,0),m=!1,p=0;return}if(t.t<p)return;let y=1/o(n,`fps`,1);p=t.t+y;let b=Lt(t,n),x=o(n,`filter`,`color`),S=Nx(t,{res:i,fov:o(n,`fov`,60),range:b,mode:$x[x]??`color`,hidden:x===`sonar`||x===`heat`,filter:x});if(to(t,b),Wx(t,n,b)&&(n.data.flashAt=t.t),!$x[x]&&aS(S)&&m&&!h){h=!0;return}h=!1;let C=Zx[x]??Zx.color,w=o(n,`noise`,0);$x[x]||rS(S,i,Math.round(o(n,`blur`,0))),C(S,i,{colors:o(n,`colors`,0),noise:w,t:t.t,range:b}),tS(S,i,w),nS(S,f,o(n,`lag`,0),y),d.data.set(S),u.putImageData(d,0,0),m=!0}}});function oS(e,t,n,r){let i=e.player,a=e=>{let t=Math.atan2(e.x-i.x,-(e.y-i.y))-i.dir;return Math.atan2(Math.sin(t),Math.cos(t))},o=n/2*(Math.PI/180),s=Ny(e,7,r).find(e=>Math.abs(a(e))>o),c=``,l=``;if(s){let e=a(s),t=(N[s.enemy.type]?.name??`it`).replace(/^(a|an|the) /,``).split(` `).pop();Math.abs(e)>Math.PI*.75?[c,l]=[`▼ ${t} behind`,`left:50%;bottom:4px;transform:translateX(-50%)`]:e>o?[c,l]=[`${t} ▶`,`right:4px;top:50%;transform:translateY(-50%)`]:[c,l]=[`◀ ${t}`,`left:4px;top:50%;transform:translateY(-50%)`]}let u=c+l;if(t.dataset.key!==u&&(t.dataset.key=u,t.textContent=c,t.style.display=c?`block`:`none`,t.style.left=t.style.right=t.style.top=t.style.bottom=t.style.transform=``,l))for(let e of l.split(`;`)){let[n,r]=e.split(`:`);t.style.setProperty(n,r)}}U(`conjure`,{help:`test runs only: conjure <module id>`,when:()=>/[?&]still/.test(globalThis.location?.search??``),run(t,n){let r=n.join(`-`);if(!r)return F(t,`conjure what? conjure <module id>, e.g. conjure card-reader`);if(!e[r])return F(t,`no module ${r}.`);Oe(t,{kind:`mod`,mod:r}),F(t,`conjured ${e[r].name}.`)}});function sS(t){ho(t),O(t,t.player.x,t.player.y,3);let n=t.ents.filter(e=>e.enemy).sort((e,t)=>Math.hypot(e.x,e.y)-Math.hypot(t.x,t.y))[0],r=t.player;r.slots=8,r.core=12;for(let n of[`saints-lens`,`ember-iris`,`lattice-eye`,`bat-psalter`,`heat-choir`,`halo`,`spark-finger`])Oe(t,{kind:`mod`,mod:n}),W(t,`install ${e[n].name}`);if(!n)return;let[i,a]=[[0,3],[0,-3],[3,0],[-3,0],[0,2],[0,-2],[2,0],[-2,0]].find(([e,r])=>w(t,n.x+e,n.y+r)===h.floor&&w(t,n.x+e/2,n.y+r/2)===h.floor)??[0,.8];r.x=n.x+i,r.y=n.y+a,r.dir=Math.atan2(-i,a)}var cS=!1;kl.push(e=>{!cS&&/[?&]scene=sight/.test(globalThis.location?.search??``)&&(cS=!0,sS(e))});var lS=null,uS=null,dS=-99,fS=null;function pS(){return(!lS||!lS.isConnected)&&(lS=document.createElement(`div`),lS.className=`hpbar`,document.body.append(lS)),(!uS||!uS.isConnected)&&(uS=document.createElement(`div`),uS.className=`hurtflash`,document.body.append(uS)),[lS,uS]}kl.push(e=>{let[t,n]=pS(),r=e.player,i=`${An(r.hp)}/${r.maxHp}`,[a,o,s]=[r.installed.length,d(e),u(e)],c=hS(e),l=`${i} ${a}/${r.slots} ${o}/${s} ${c}`;t.dataset.text!==l&&(t.dataset.text=l,t.innerHTML=`hp <i><b style="width:${Math.max(0,r.hp)/r.maxHp*100}%"></b></i> ${i}`+(c?``:`<span class="sep">·</span>slots ${a}/${r.slots} ${ul(a,r.slots)}<span class="sep">·</span>power ${o}/${s} ${ul(o,s)}`)+(c?`<span class="sep">·</span><span class="fight" style="color:#ff6a50">${mS(c)}</span>`:``)),t.dataset.low=String(r.hp<=r.maxHp*.3),fS!==e&&(fS=e,dS=r.hurtAt),r.hurtAt>dS&&(dS=r.hurtAt,n.classList.remove(`on`),n.offsetWidth,n.classList.add(`on`))});var mS=e=>e.replace(/[▮▯]+/,e=>`<span class="fbar">${[...e].map(e=>`<b${e===`▮`?` class="on"`:``}></b>`).join(``)}</span>`);function hS(e){let t=Ny(e,6)[0];if(!t?.enemy)return``;let n=Number(t.enemy.data.maxHp??t.enemy.hp)||1,r=Math.max(0,t.enemy.hp),i=Math.min(8,Math.ceil(n)),a=Math.round(r/n*i),o=`▮`.repeat(a)+`▯`.repeat(Math.max(0,i-a)),s=Ny(e,6),c=s.length-1,l=s.every(e=>e.enemy.type===t.enemy.type),u=c>0?l?` ×${s.length}`:` +${c}`:``,d=(N[t.enemy.type]?.name??`something`).replace(/^(a|an|the) /,``),f=vS(e,Math.hypot(t.x-e.player.x,t.y-e.player.y)),p=Ny(e,8).filter(t=>t.enemy.data.move&&e.t<(t.enemy.data.windup??0)),m=p.find(e=>e.enemy.type!==`mite`)??p[0],h=p.filter(e=>e.enemy.type===`mite`).length,g=m?.enemy.type===`mite`&&h>1?`${h} mites rear`:String(m?.enemy.data.move??``),_=m?`⚠ ${_S(g,gS)} · `:``,v=s.find(t=>e.t<(t.enemy.data.open??0));return`${_}${v?v===t?`✦ open: hit it · `:`✦ ${N[v.enemy.type].name.replace(/^(a|an|the) /,``)} open · `:``}⚔ ${d} ${o}${u} · ${f}`}var gS=22,_S=(e,t)=>e.length>t?`${e.slice(0,t-1)}…`:e;function vS(e,t){let n=l(e,`weapon`);if(!n.length)return`no weapon on`;let r=t=>Math.max(0,(t.data.readyAt??0)-e.t),i=e=>o(e,`range`,o(e,`aim`,`auto`)===`aimed`?6:1.3),a=n.filter(e=>i(e)>=t);if(!a.length)return`out of reach`;let s=e=>Math.min(...e.map(r)),c=a.filter(e=>o(e,`aim`,`auto`)===`auto`),u=a.filter(e=>o(e,`aim`,`auto`)===`aimed`),d=[];return c.length&&d.push(s(c)<=.05?`your blow ready`:`your blow ${s(c).toFixed(1)}s`),u.length&&d.push(s(u)<=.05?`shoot ready`:`shoot ${s(u).toFixed(1)}s`),d.join(` · `)}var yS=0,bS=null;kl.push(e=>{let t=Vn.get(e);if(bS!==e&&(bS=e,yS=t?.n??0),!t||t.n<=yS)return;yS=t.n,document.querySelector(`.shard-fanfare`)?.remove();let n=document.createElement(`div`);n.className=`shard-fanfare`,e.ents.some(t=>t.kind===`enemy`&&Math.hypot(t.x-e.player.x,t.y-e.player.y)<8)&&n.classList.add(`live`),n.innerHTML=`<div class="shard-pulse"></div><p>SCRIPTURE SHARD ${t.n} of 3</p>`,document.body.append(n),setTimeout(()=>n.remove(),4200)});var xS=-1,SS=null;kl.push(e=>{let t=Pn.get(e);if(SS!==e&&(SS=e,xS=t?.at??-1),!t||t.at<=xS)return;xS=t.at,document.querySelector(`.elite-warn`)?.remove();let n=document.createElement(`div`);n.className=`elite-warn`,n.textContent=`⚠ ${t.text}`,document.body.append(n),setTimeout(()=>n.remove(),4e3)});var CS=new URLSearchParams(location.search).get(`scene`)!==`fight`;kl.push(e=>{if(CS)return;CS=!0,ho(e);let t=e.player;e.ents=e.ents.filter(e=>e.kind!==`item`||Math.hypot(e.x-t.x,e.y-t.y)>8),t.slots=6,t.core=10;for(let n of[`saints-lens`,`stepper-relay`,`nail-psalm`,`frost-coat`,`mirror-ward`])t.installed.push({uid:e.nextId++,mod:n,on:!0,readyAt:0,data:{}}),e.stats.mods.push(n);t.dir=-Math.PI/2;let n=(t,n,r)=>e.ents.push({id:e.nextId++,kind:`enemy`,x:n,y:r,enemy:{type:t,hp:N[t].hp,readyAt:0,data:{}}});n(`seraph`,5.5,8.5),n(`mite`,6.5,5.5),n(`mite`,5.5,5.5),n(`mite`,6.5,6.5),n(`walker`,10.5,11.5),e.log.push([`a fight, staged. you face west. `],[{text:`shoot`,cmd:`shoot`},`  `,{text:`face n`,cmd:`face n`},`  `,{text:`face w`,cmd:`face w`},`  `,{text:`go s 2`,cmd:`go s 2`},`  `,{text:`status`,cmd:`status`}])}),ao.draw.push((e,t,n,r,i)=>{for(let a of e.ents){let o=a.enemy?.data;o?.wide&&e.t<(o.windup??0)&&(t.strokeStyle=`#ff3a28`,t.lineWidth=Math.max(1,i*.25),t.setLineDash([Math.max(2,i*.5),Math.max(2,i*.4)]),t.beginPath(),t.arc((a.x-n)*i,(a.y-r)*i,2.3*i,0,Math.PI*2),t.stroke(),t.setLineDash([]))}});var wS=[`step`,`drag`,`take`,`install`,`remove`,`warm`,`ready`,`off`,`hit`,`hurt`,`kill`,`die`,`printer`,`card`,`heart`],TS=.5,ES=.11,DS=null,OS,kS,AS=null,jS=0,MS=new Map;function NS(){if(DS){DS.state===`suspended`&&DS.resume();return}let e=typeof window<`u`?window.AudioContext??window.webkitAudioContext:void 0;e&&(PS(new e),AS=QS(),LS(jS))}function PS(e){DS=e,OS=e.createGain(),OS.gain.value=TS,OS.connect(e.destination),kS=e.createBuffer(1,e.sampleRate*2,e.sampleRate);let t=kS.getChannelData(0);for(let e=0;e<t.length;e++)t[e]=Math.random()*2-1}async function FS(e){let t={ctx:DS,out:OS,noise:kS,drone:AS},n=e===`drone`?12:3,r=new OfflineAudioContext(1,44100*n,44100);PS(r),e===`drone`?QS():zS(e,{secs:1.5}),{ctx:DS,out:OS,noise:kS,drone:AS}=t;let i=(await r.startRendering()).getChannelData(0),a=0,o=0;for(let e of i)a=Math.max(a,Math.abs(e)),o+=e*e;let s=e=>Math.round(20*Math.log10(e+1e-9)),c=i.filter(e=>Math.abs(e)>1e-4).length||1;return{peak:s(a),rms:s(Math.sqrt(o/c))}}function IS(){return!!DS}function LS(e){if(jS=Math.max(0,Math.min(1,e)),!DS||!AS)return;let t=2**(-jS*.6);AS.pitch.forEach((e,n)=>e.frequency.setTargetAtTime(AS.base[n]*t,DS.currentTime,12))}function RS(e){if(DS){if(e&&!AS)AS=QS(),LS(jS);else if(!e&&AS){let e=AS;AS=null,BS(e.g,0,1.5);for(let t of e.srcs)t.stop(DS.currentTime+1.6)}}}function zS(e,t={}){if(!DS)return;let n=DS.currentTime;switch(e){case`step`:WS(n,.3,2400),KS(n,.18,120,.05),WS(n+.07,.2,1700);return;case`drag`:return JS(n,.45,.35);case`take`:return WS(n,.4,3e3),YS(n+.02,`triangle`,520,780,.12,.03);case`install`:return qS(n),qS(n+.11,.7);case`remove`:return qS(n,.7),qS(n+.09,.45,.8);case`warm`:return XS(n,Math.max(.2,t.secs??1),t.uid);case`ready`:return YS(n,`sine`,880,880,.09,.03,2e3);case`off`:return t.uid!==void 0&&ZS(t.uid),YS(n,`sine`,420,55,.6,.035,900);case`hit`:return GS(n,.4,3500,.06),YS(n,`square`,1400,300,.09,.025,4e3);case`hurt`:return KS(n,.45,90,.18),GS(n,.35,600,.12),YS(n,`sawtooth`,110,70,.22,.04,700);case`kill`:return GS(n,.6,1200,.2),YS(n+.03,`triangle`,300,60,.5,.05,1200);case`die`:for(let e of[...MS.keys()])ZS(e);return KS(n,.5,70,.4),YS(n,`sawtooth`,220,30,2.5,.05,500);case`printer`:for(let e=0;e<14;e++)WS(n+e*.055+(e%4==3?.03:0),.35+e%2*.15,1800+e%3*500);return KS(n+.85,.3,160,.05);case`card`:for(let e=0;e<6;e++){let t=[1320,990,1760,1175,1480,880][e];YS(n+e*.06,`square`,t,t,.045,.04,3e3)}return;case`heart`:return KS(n,.7,65,.25),KS(n+.28,.45,58,.22)}}function BS(e,t,n){let r=DS.currentTime;e.gain.cancelScheduledValues(r),e.gain.setValueAtTime(e.gain.value,r),e.gain.linearRampToValueAtTime(t,r+n)}function VS(e=!1){let t=DS.createBufferSource();return t.buffer=kS,t.loop=e,t}function HS(e,t,n=1){let r=DS.createBiquadFilter();return r.type=e,r.frequency.value=t,r.Q.value=n,r}function US(e,t,n,r=.002){let i=DS.createGain();return i.gain.setValueAtTime(0,e),i.gain.linearRampToValueAtTime(t,e+r),i.gain.exponentialRampToValueAtTime(1e-4,e+n),i.connect(OS),i}function WS(e,t,n){let r=VS();r.playbackRate.value=.9+Math.random()*.2,r.connect(HS(`bandpass`,n,1.2)).connect(US(e,t,.025,.001)),r.start(e,Math.random(),.04)}function GS(e,t,n,r){let i=VS();i.connect(HS(`bandpass`,n,.8)).connect(US(e,t,r,.003)),i.start(e,Math.random(),r+.05)}function KS(e,t,n,r){let i=DS.createOscillator();i.frequency.setValueAtTime(n,e),i.frequency.exponentialRampToValueAtTime(n*.4,e+r),i.connect(US(e,t,r,.003)),i.start(e),i.stop(e+r+.05)}function qS(e,t=1,n=1){WS(e,1.1*t,1500*n),KS(e,.4*t,140*n,.08)}function JS(e,t,n){let r=VS(),i=HS(`bandpass`,900,2);i.frequency.setValueAtTime(900+Math.random()*300,e),i.frequency.exponentialRampToValueAtTime(380,e+t);let a=DS.createGain();a.gain.setValueAtTime(0,e),a.gain.linearRampToValueAtTime(n,e+t*.3),a.gain.exponentialRampToValueAtTime(1e-4,e+t),a.connect(OS),r.connect(i).connect(HS(`lowpass`,1400)).connect(a),r.start(e,Math.random(),t+.05)}function YS(e,t,n,r,i,a,o=3e3){let s=DS.createOscillator();s.type=t,s.frequency.setValueAtTime(n,e),r!==n&&s.frequency.exponentialRampToValueAtTime(r,e+i);let c=DS.createGain();c.gain.setValueAtTime(0,e),c.gain.linearRampToValueAtTime(a,e+.008),c.gain.setValueAtTime(a,e+i*.6),c.gain.exponentialRampToValueAtTime(1e-4,e+i),s.connect(HS(`lowpass`,o)).connect(c).connect(OS),s.start(e),s.stop(e+i+.05)}function XS(e,t,n){n!==void 0&&ZS(n);let r=DS.createGain();r.gain.setValueAtTime(0,e),r.gain.linearRampToValueAtTime(.018,e+Math.min(.3,t/2)),r.gain.setValueAtTime(.018,e+t*.85),r.gain.linearRampToValueAtTime(0,e+t+.15),r.connect(OS);let i=[];for(let[n,a]of[[`sine`,1],[`triangle`,1.5]]){let o=DS.createOscillator();o.type=n,o.frequency.setValueAtTime(260*a,e),o.frequency.exponentialRampToValueAtTime(1100*a,e+t),o.connect(HS(`lowpass`,2500)).connect(r),o.start(e),o.stop(e+t+.2),i.push(o)}let a=$S(11,12,i[0].frequency);a.start(e),a.stop(e+t+.2),i.push(a),n!==void 0&&(MS.set(n,{g:r,o:i}),i[0].onended=()=>MS.get(n)?.g===r&&MS.delete(n))}function ZS(e){let t=MS.get(e);if(t){MS.delete(e),BS(t.g,0,.08);for(let e of t.o)e.stop(DS.currentTime+.1)}}function QS(){let e=DS.createGain();e.gain.value=0,e.connect(OS),BS(e,ES,6);let t=HS(`lowpass`,170,3);t.connect(e);let n=[41.2,61.7,82.812],r=[];n.forEach((e,n)=>{let i=DS.createOscillator();i.type=n===2?`triangle`:`sawtooth`,i.frequency.value=e;let a=DS.createGain();a.gain.value=[.5,.3,.25][n],i.connect(a).connect(t),i.start(),r.push(i)});let i=[$S(.031,70,t.frequency),$S(.017,.6,r[1].frequency),$S(.047,ES*.35,e.gain)];for(let e of i)e.start();let a=VS(!0),o=DS.createGain();return o.gain.value=.25,a.connect(HS(`lowpass`,90,.7)).connect(o).connect(e),a.start(),{g:e,pitch:r,base:n,srcs:[...r,...i,a]}}function $S(e,t,n){let r=DS.createOscillator();r.frequency.value=e;let i=DS.createGain();return i.gain.value=t,r.connect(i).connect(n),r}function eC(){let e=document.createElement(`div`);e.className=`soundboard`,e.style.cssText=`position:fixed;left:8px;bottom:8px;z-index:99;display:flex;flex-wrap:wrap;gap:6px;max-width:90vw;align-items:center`;let t=(t,n)=>{let r=document.createElement(`button`);r.textContent=t,r.dataset.cue=t,r.style.cssText=`font:inherit;background:#111;color:#9f9;border:1px solid #393;padding:2px 8px;cursor:pointer`,r.onclick=e=>{e.stopPropagation(),NS(),n()},e.append(r)};for(let e of wS)t(e,()=>zS(e,{secs:1.5}));let n=!0;t(`drone on/off`,()=>RS(n=!n));let r=document.createElement(`input`);r.type=`range`,r.min=`0`,r.max=`1`,r.step=`0.05`,r.value=`0`,r.title=`drone depth`,r.oninput=()=>LS(Number(r.value)),e.append(r),document.body.append(e)}var tC=e=>window.thaw.send(e);function nC(e,t){let n=document.createElement(`button`);return n.textContent=e,n.dataset.cmd=t,n.addEventListener(`click`,()=>tC(t)),n}function rC(e){let t=L(e);return e.kind===`mod`?[[`install`,`install ${a(e).name}`],[`drop`,`drop ${a(e).name}`]]:e.kind===`card`?[[`read`,`read card`],[`drop`,`drop memory card`]]:[[`drop`,`drop ${t.replace(/^\d+ /,``)}`]]}var iC=e=>{let t=document.createElement(`div`);t.className=`ledger`,e.append(t);let n=``;return{update(e){let r=e.player,i=Object.keys(Ze(e)),o=JSON.stringify([r.inv,r.slots,r.installed.length,d(e),u(e),i]);if(o===n)return;n=o;let s=document.createElement(`div`);s.className=`ledger-head`,s.textContent=`slots ${r.installed.length}/${r.slots} · power ${d(e)}/${u(e)}`;let c=r.inv.map(e=>{let t=document.createElement(`div`);t.className=`ledger-row`;let n=document.createElement(`span`);return n.textContent=L(e),e.kind===`mod`&&(n.title=`${a(e).family}: ${a(e).text}`),t.append(n,...rC(e).map(([e,t])=>nC(e,t))),t});if(!c.length){let e=document.createElement(`div`);e.className=`ledger-row dim`,e.textContent=`you carry nothing.`,c.push(e)}let l=document.createElement(`div`);l.className=`ledger-sets`;let f=document.createElement(`div`);f.append(`setup: `,...i.flatMap(e=>[nC(e,`setup ${e}`),` `])),i.length||f.append(`none saved`);let p=document.createElement(`div`);p.append(`save on-set as: `,nC(`battle`,`save setup battle`),` `,nC(`explore`,`save setup explore`)),l.append(f,p),t.replaceChildren(s,...c,l)}}},aC=6,oC=132,sC={ledger:iC,clock:(e,t)=>{let n=document.createElement(`canvas`);n.width=n.height=oC,n.className=`clock`,e.append(n);let r=n.getContext(`2d`);return{update(e){if(r.fillStyle=`#060505`,r.fillRect(0,0,oC,oC),!t.on||e.t<t.readyAt)return;let n=e.player,i=oC/2/aC,a=(e,t)=>[oC/2+(e-n.x)*i,oC/2+(t-n.y)*i];r.fillStyle=`#2a211c`;for(let t=Math.floor(n.y)-aC;t<=Math.floor(n.y)+aC;t++)for(let o=Math.floor(n.x)-aC;o<=Math.floor(n.x)+aC;o++){if(w(e,o,t)===h.floor)continue;let[n,s]=a(o,t);r.fillRect(n,s,i,i)}r.strokeStyle=`#3a2f28`,r.beginPath(),r.arc(oC/2,oC/2,oC/2-2,0,Math.PI*2),r.moveTo(oC/2,oC/2);let s=e.t%1*Math.PI*2;r.lineTo(oC/2+Math.sin(s)*(oC/2-2),oC/2-Math.cos(s)*(oC/2-2)),r.stroke();for(let n of nt(e,o(t,`ahead`,1))){let[e,t]=a(n.e.x,n.e.y),[i,o]=a(n.x,n.y);r.strokeStyle=`#a05030`,r.lineWidth=2,r.beginPath(),r.moveTo(e,t),r.lineTo(i,o),r.stroke(),r.lineWidth=1,r.fillStyle=`#d04030`,r.fillRect(e-2,t-2,4,4),r.strokeStyle=`#f0a050`,r.strokeRect(i-4,o-4,8,8)}r.fillStyle=`#d8c8b0`,r.fillRect(oC/2-2,oC/2-2,4,4),r.beginPath(),r.strokeStyle=`#d8c8b0`,r.moveTo(oC/2,oC/2),r.lineTo(oC/2+Math.sin(n.dir)*8,oC/2-Math.cos(n.dir)*8),r.stroke()}}}},cC=Qa.mind;$a(`mind`,(e,t,n)=>{let r=sC[o(t,`what`,``)]??cC;if(r)return r(e,t,n);let i=document.createElement(`p`);return i.className=`flavour`,i.textContent=a(t).text,e.append(i),{update(){}}});var lC={ArrowUp:`n`,ArrowRight:`e`,ArrowDown:`s`,ArrowLeft:`w`},uC={w:`n`,a:`w`,s:`s`,d:`e`},dC=new Set,fC=()=>window.thaw,pC=e=>e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement,mC=()=>document.querySelector(`.win-console input`),hC=()=>document.querySelector(`.dead button, .thaw-card button`)?.click();function gC(e,t){if(We(e,t)||l(e,`gait`).some(e=>o(e,`keys`,!1))||e.player.path.length>1)return;let n=l(e,`gait`).some(e=>o(e,`go`,!1));!n&&Ke(e)?(e.player.pace=2.5,Be(e,t,1)):yC(e,n?`go ${t}`:`crawl ${t}`)}var _C=e=>e.map(e=>typeof e==`string`?e:e.text).join(``),vC=new WeakMap;function yC(e,t){let n=`> `+t,r=e.log[e.log.length-1],i=r?.length===1&&typeof r[0]!=`string`&&!r[0].cmd?r[0].text:``,a=i===n?1:i.startsWith(n+` ×`)?Number(i.slice(n.length+2)):0,o=e.player,s=[o.path.length,o.path[o.path.length-1]?.join()].join(),c=e.log.length;W(e,t);let l=[o.path.length,o.path[o.path.length-1]?.join()].join()!==s,u=e.log.slice(c+1).map(_C).join(`
`);!l&&u&&vC.get(e)===u?e.log.length=c:a&&e.log.length===c+1&&(e.log.length=c,e.log[c-1]=[{text:`${n} ×${a+1}`,cmd:``}]),!l&&u?vC.set(e,u):l&&vC.delete(e);let d=fC()?.screen?.con;d&&(d.follow=!0)}function bC(e,t){let n=Math.PI/2,r=e.player;r.dir=((Math.round(r.dir/n)+t)*n%(4*n)+4*n)%(4*n)}addEventListener(`keydown`,e=>{let t=fC()?.g;if(t?.ended&&(e.key===`Enter`||e.key===` `||e.key.toLowerCase()===`r`)){let t=pC(e.target)?e.target:null;if(!t||e.key!==`Enter`||!t.value.trim()){t&&(t.value=``,t.blur()),hC(),e.preventDefault(),e.stopPropagation();return}}if(pC(e.target)){let n=lC[e.key];if(n&&t&&!t.ended&&!e.target.value&&!e.ctrlKey&&!e.metaKey&&!e.altKey){gC(t,n),e.preventDefault(),e.stopPropagation();return}e.key===`Escape`&&(e.target.blur(),e.preventDefault(),e.stopPropagation());return}if(e.key===`Enter`){mC()?.focus(),e.preventDefault();return}if(!t||e.ctrlKey||e.metaKey||e.altKey)return;let n=e.key.toLowerCase(),r=lC[e.key]??(Ke(t)?void 0:uC[n]);if(r)gC(t,r),e.preventDefault();else if(uC[n])dC.add(n),e.preventDefault();else if(!(e.repeat&&n!==`q`&&n!==`e`)){if(n===`q`||n===`e`)bC(t,n===`q`?-1:1);else if(n===`t`)dc();else if(n===`p`)Dl();else if(n>=`1`&&n<=`4`){let e=Object.keys(Ze(t))[Number(n)-1];fC().send(e?`setup ${e}`:`setup`)}else return;e.preventDefault()}},!0),addEventListener(`keyup`,e=>dC.delete(e.key.toLowerCase())),addEventListener(`blur`,()=>dC.clear()),addEventListener(`focusin`,e=>{pC(e.target)&&dC.clear()}),kl.push(e=>{let t=+!!dC.has(`w`)-!!dC.has(`s`),n=+!!dC.has(`d`)-!!dC.has(`a`);(t||n||e.player.move)&&Ge(e,t,n)}),addEventListener(`click`,e=>{let t=e.target;if(document.pointerLockElement){H.shoot&&(!H.shoot.when||H.shoot.when(fC().g))&&fC().send(`shoot`);return}let n=fC()?.g;n&&(t.matches(`canvas.eye`)||t.id===`desk`)&&Ke(n)&&(document.activeElement?.blur(),(t.requestPointerLock?.())?.catch?.(()=>{}))}),addEventListener(`mousemove`,e=>{let t=e.buttons===1&&e.target.matches?.(`canvas.eye`);if(!document.pointerLockElement&&!t)return;let n=fC()?.g;n&&qe(n,e.movementX*.004)});var xC=new URLSearchParams(location.search).get(`scene`)!==`body`;kl.push(e=>{if(xC)return;xC=!0,ho(e);let t=e.player;e.ents=e.ents.filter(e=>e.kind!==`item`||Math.hypot(e.x-t.x,e.y-t.y)>8),t.slots=6,t.core=10;for(let n of[`vidicon-tube`,`gyro-heart`,`ledger`,`clock-of-hours`,`tunnel-tongue`,`spark-finger`])t.installed.push({uid:e.nextId++,mod:n,on:!0,readyAt:0,data:{}}),e.stats.mods.push(n);for(let e of[`servo-gait`,`slot-board`,`votive-battery`,`heart-shard`])t.inv.push({kind:`mod`,mod:e});let n=e=>t.installed.forEach(t=>t.on=e.includes(t.mod));n([`vidicon-tube`,`gyro-heart`,`clock-of-hours`,`spark-finger`]),Qe(e,`battle`),n([`vidicon-tube`,`gyro-heart`,`ledger`,`tunnel-tongue`]),Qe(e,`explore`),n([`vidicon-tube`,`gyro-heart`,`ledger`,`clock-of-hours`,`tunnel-tongue`,`spark-finger`]),t.dir=Math.PI/2;for(let[t,n]of[[11.5,6.5],[11.5,10.5],[11.5,8.5]])e.ents.push({id:e.nextId++,kind:`enemy`,x:t,y:n,enemy:{type:`mite`,hp:2,readyAt:0,data:{noticed:!0}}});e.log.push([`a body, staged. you face east; three mites come. esc, then wasd walks; click the eye to turn with the mouse.`],[{text:`dig`,cmd:`dig`},`  `,{text:`setup battle`,cmd:`setup battle`},`  `,{text:`setup explore`,cmd:`setup explore`},`  `,{text:`status`,cmd:`status`}])});var SC=()=>({g:null,x:0,y:0,walked:wC,mods:new Map,cards:0}),CC={step:1,drag:.5,free:.8},wC=99;function TC(e,t){let n=t.player,r=[];if(e.g!==t){Object.assign(e,SC(),{g:t,x:n.x,y:n.y,cards:t.cards.length});for(let r of n.installed)e.mods.set(r.uid,DC(t,r));return r}let i=Math.hypot(n.x-e.x,n.y-e.y);if(e.x=n.x,e.y=n.y,i>3)e.walked=0;else if(i>0){let t=n.move?`free`:n.pace<=1?`drag`:`step`,a=!n.move&&!n.path.length;e.walked=e.walked>=wC?CC[t]:e.walked+i,e.walked>=CC[t]-1e-6&&!a&&(e.walked=Math.max(0,e.walked-CC[t]),r.push({cue:t===`drag`?`drag`:`step`}))}else e.walked=wC;let a=new Set;for(let e of t.events){let i=String(e.type);if(i===`warm`){let i=n.installed.find(t=>t.uid===e.data),a=i?i.readyAt-t.t:0;i&&a>.05&&r.push({cue:`warm`,uid:i.uid,secs:a});continue}let o=EC[i]??(i.includes(`print`)?`printer`:i.includes(`card`)||i.includes(`read`)?`card`:i===`thaw`?`heart`:null);o&&!a.has(o)&&(a.add(o),r.push({cue:o}))}let o=new Map;for(let i of n.installed){let n=DC(t,i),a=e.mods.get(i.uid);a&&a!==`off`&&n===`off`&&r.push({cue:`off`,uid:i.uid}),a===`warm`&&n===`on`&&r.push({cue:`ready`,uid:i.uid}),o.set(i.uid,n)}return e.mods=o,t.cards.length>e.cards&&!a.has(`card`)&&r.push({cue:`card`}),e.cards=t.cards.length,r}var EC={take:`take`,install:`install`,remove:`remove`,hit:`hit`,hurt:`hurt`,kill:`kill`,die:`die`};function DC(e,t){return t.on?e.t>=t.readyAt?`on`:`warm`:`off`}var OC=e=>Math.min(1,e.stats.far/60),kC=SC(),AC=-1;kl.push(e=>{let t=TC(kC,e);if(!IS())return;for(let e of t)zS(e.cue,e);let n=Math.round(OC(e)*20)/20;n!==AC&&LS(AC=n)}),typeof location<`u`&&new URLSearchParams(location.search).has(`sounds`)&&(document.body?eC():addEventListener(`DOMContentLoaded`,eC)),typeof window<`u`&&(window.thawAudio={start:NS,started:IS,cue:zS,CUES:wS,measure:FS});var jC=new WeakMap,MC=5;function NC(){document.querySelector(`.thaw-end`)?.remove();let e=document.createElement(`div`);e.className=`thaw-end`,e.innerHTML=`<div class="thaw-light"></div><div class="thaw-heart"></div><p class="thaw-drinks">the engine drinks…</p>`,document.body.append(e);let t=[...document.querySelectorAll(`#desk .win`)].sort((e,t)=>Number(e.dataset.win===`console`)-Number(t.dataset.win===`console`));for(let e of t){e.classList.add(`melting`);for(let t=0;t<MC;t++){let n=document.createElement(`i`);n.className=`drip`,n.style.left=`${8+(t*37+e.offsetWidth)%84}%`,n.style.setProperty(`--len`,String(.6+t*53%10/10)),e.append(n)}}return{t:0,el:e,wins:t}}function PC(e,t){let n=document.createElement(`div`);n.className=`thaw-card`,n.innerHTML=`<p class="big">the god is warm.</p><p>the engine turns in its breast. you are part of it now.</p>`;let r=document.createElement(`p`);r.className=`run`,r.textContent=$n(e);let i=document.createElement(`button`);i.textContent=`wake again`,i.addEventListener(`click`,()=>{t.el.remove(),window.thaw.restart()});let a=ar(e)??nr(e),o=document.createElement(`div`);o.className=`tally`;let s=document.createElement(`p`);s.className=`head`,s.textContent=a.total?`it drank what you carried:`:`you carried nothing to give it.`;let c=a.lines.map(([e,t])=>{let n=document.createElement(`p`);return n.className=`row`,n.innerHTML=`<span>${e}</span><span>${t}</span>`,n}),l=document.createElement(`p`);l.className=`row total`,l.innerHTML=`<span>${a.total}</span><span class="grade">${a.grade}</span>`,c.push(l),o.append(s,...c),n.append(o,r,i),t.el.querySelector(`.thaw-drinks`)?.remove(),t.el.append(n),t.card=n,t.rows=c}kl.push((e,t)=>{if(e.ended!==`thaw`)return;let n=jC.get(e);n||jC.set(e,n=NC()),n.t+=t;let r=n.t;if(n.el.style.setProperty(`--light`,Jn(r).toFixed(3)),n.el.style.setProperty(`--beat`,Xn(r).toFixed(3)),n.wins.forEach((e,t)=>{let n=Yn(r,t),i=Math.sin(t*1.7+r*.8)*6*n;e.style.setProperty(`--m`,n.toFixed(3)),e.style.transform=`translateY(${(n*n*80).toFixed(1)}vh) scaleY(${(1+n*.7).toFixed(3)}) skewX(${i.toFixed(1)}deg)`,e.style.filter=`blur(${(n*5).toFixed(1)}px) sepia(${(Jn(r)*.8).toFixed(2)}) brightness(${(1+Jn(r)*.8+n).toFixed(2)})`,e.style.opacity=(1-n*n).toFixed(3)}),Zn(r)&&!n.card&&PC(e,n),n.card&&(n.card.style.opacity=Math.min(1,(r-Gn)/1.2).toFixed(3)),n.rows){let e=cr(r,n.rows.length-1);n.rows.forEach((t,n)=>t.classList.toggle(`on`,n<e))}});var FC=!1;kl.push(e=>{if(!FC&&/[?&]scene=end\b/.test(globalThis.location?.search??``)){FC=!0,ho(e),Object.assign(e.player,{slots:5,core:12}),e.player.inv.push({kind:`res`,res:`bone`,n:31},{kind:`res`,res:`glass`,n:14},{kind:`res`,res:`copper`,n:17},{kind:`res`,res:`ichor`,n:6});for(let t of[`vidicon-tube`,`stepper-relay`,`map-spool`,`thaw-engine`]){e.player.inv.push({kind:`mod`,mod:t}),W(e,`install ${t.replace(/-/g,` `)}`);for(let t of e.player.installed)t.readyAt=e.t-1}}});var IC=new URLSearchParams(location.search),LC=[`localhost`,`127.0.0.1`].includes(location.hostname);`serviceWorker`in navigator&&(location.protocol===`https:`||LC)&&navigator.serviceWorker.register(`./sw.js`).catch(()=>{});var RC=Number(IC.get(`seed`))||Math.floor(Math.random()*1e9);function zC(e){mo(e);let t=e=>({text:`install ${e}`,cmd:`install ${e}`}),n=[`pinhole eye`,`map spool`,`stepper relay`,`spark finger`];F(e,`core ok. you hold four modules and wear none. slots 0/${e.player.slots}. power 0/${u(e)}.`,[`the goal, the keys and every verb: `,{text:`help`,cmd:`help`},`. lost or stuck? `,{text:`unstuck`,cmd:`unstuck`}],[`once they are in, walk with the arrow keys (esc leaves the console) or `,{text:`go e 3`,cmd:`go e 3`},`. things move out there; the spark bites what comes close.`],[`install them: `,{text:`install all`,cmd:n.map(e=>`install ${e}`).join(`; `)},`  or one by one: `,...n.flatMap(e=>[t(e),`  `])])}var BC=oe(RC),VC=new Al(BC);zC(BC),VC.con.input.focus(),addEventListener(`pointerdown`,()=>NS(),{once:!0}),addEventListener(`keydown`,()=>NS(),{once:!0});function HC(e=Math.floor(Math.random()*1e9)){document.getElementById(`desk`)?.replaceChildren(),Dl(!1),BC=oe(e),VC=new Al(BC),zC(BC),UC()}function UC(){window.thaw={g:BC,screen:VC,restart:HC,send:e=>VC.con.send(e)}}UC();function WC(){let e=document.createElement(`div`);e.className=`dead`;let t=document.createElement(`div`),n=mr(BC),r=BC.ents.find(e=>e.id===n.killerId&&e.enemy);if(r){BC.player.dir=Zt(BC,r);let e=BC.t;BC.t+=2,VC.frame(0),BC.t=e}let i=[...document.querySelectorAll(`canvas.eye`)].find(e=>e.width>0),a=``;try{i&&(a=`<img class="last-frame" alt="the last thing it saw" src="${i.toDataURL()}">`)}catch{a=``}let o=e=>e.replace(/&/g,`&amp;`).replace(/</g,`&lt;`);t.innerHTML=a+`<p class="killer">you stop. ${o(n.killer)}.</p>`+(n.blows.length?`<p class="blows">last blows: ${n.blows.map(o).join(` · `)}</p>`:``)+`<p class="lesson">what would have helped: ${o(n.lesson)}</p><p>${o($n(BC))}</p>`;let s=document.createElement(`button`);s.textContent=`wake again`;let c=()=>{removeEventListener(`keydown`,u,!0),e.remove(),HC()},l=performance.now(),u=e=>{performance.now()-l<600||e.key!==`Enter`&&e.key!==` `&&e.key.toLowerCase()!==`r`||(e.preventDefault(),e.stopPropagation(),c())};s.addEventListener(`click`,c),addEventListener(`keydown`,u,!0);let d=document.createElement(`p`);d.className=`keys`,d.textContent=`enter, r or space`,t.append(s,d),e.append(t),document.body.append(e)}var GC=performance.now(),KC=IC.has(`still`);window.step=e=>{for(let t=0;t<Math.round(e*30);t++)he(BC,1/30);VC.frame(e)};function qC(e){let t=Math.min(.1,(e-GC)/1e3);GC=e,!KC&&!Tl()&&he(BC,t),VC.frame(Tl()?0:t),document.body.dataset.state=BC.ended??`live`,BC.ended===`dead`&&!document.querySelector(`.dead`)&&WC(),requestAnimationFrame(qC)}requestAnimationFrame(qC);